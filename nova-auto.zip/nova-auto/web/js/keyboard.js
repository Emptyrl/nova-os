// Clavier à l'écran (AZERTY) pour l'écran tactile de la voiture : mot de passe Wi-Fi, destination…
// Le clavier physique marche aussi pendant qu'il est ouvert.
import { popIn, popOut } from "./motion.js";

const ROWS = {
  low: ["1234567890", "azertyuiop", "qsdfghjklm", "⇧wxcvbn'⌫", "?123 ␣ ⏎"],
  up: ["1234567890", "AZERTYUIOP", "QSDFGHJKLM", "⇧WXCVBN'⌫", "?123 ␣ ⏎"],
  sym: ["1234567890", "@#&_-+()/*", "!?.,;:\"=%€", "⇧<>[]{}$⌫", "abc ␣ ⏎"],
};

let el = null;
let st = null;

function build() {
  el = document.createElement("div");
  el.className = "overlay";
  el.style.cssText = "inset:0;z-index:80;display:none;align-items:flex-end;justify-content:center;background:rgba(0,0,0,.55);pointer-events:auto";
  el.innerHTML = `<div class="card" style="width:1000px;margin-bottom:6px;padding:12px;box-sizing:border-box;display:flex;flex-direction:column;gap:8px">
    <div style="display:flex;align-items:center;gap:10px">
      <span class="lbl" data-k="title" style="flex:1"></span>
      <button type="button" class="chip" data-k="eye" style="min-height:36px;padding:0 12px;font-size:10px">Afficher</button>
      <button type="button" class="chip" data-k="cancel" style="min-height:36px;padding:0 12px;font-size:10px">Annuler</button>
    </div>
    <div data-k="field" style="min-height:44px;display:flex;align-items:center;padding:0 14px;border-radius:10px;border:1px solid #4FD1E8;background:#15171B;font-size:20px;font-weight:600;color:#F1F3F5;letter-spacing:.04em;overflow:hidden;white-space:nowrap"></div>
    <div data-k="keys" style="display:flex;flex-direction:column;gap:6px"></div>
  </div>`;
  document.getElementById("stage").appendChild(el);
  el.addEventListener("click", (e) => {
    e.stopPropagation();
    const b = e.target.closest("button");
    if (!b) return;
    if (b.dataset.k === "cancel") return close();
    if (b.dataset.k === "eye") {
      st.show = !st.show;
      return render();
    }
    if (b.dataset.key) press(b.dataset.key);
  });
  window.addEventListener("keydown", (e) => {
    if (!st) return;
    e.preventDefault();
    if (e.key === "Enter") press("⏎");
    else if (e.key === "Backspace") press("⌫");
    else if (e.key === "Escape") close();
    else if (e.key.length === 1) press(e.key === " " ? "␣" : e.key);
  });
}

function press(k) {
  if (k === "⌫") st.value = st.value.slice(0, -1);
  else if (k === "⇧") st.layer = st.layer === "up" ? "low" : st.layer === "sym" ? "sym" : "up";
  else if (k === "?123") st.layer = "sym";
  else if (k === "abc") st.layer = "low";
  else if (k === "⏎") {
    const v = st.value;
    const done = st.onDone;
    close();
    done?.(v);
    return;
  } else {
    st.value += k === "␣" ? " " : k;
    if (st.layer === "up" && !st.caps) st.layer = "low";
  }
  render();
}

function render() {
  const $ = (k) => el.querySelector(`[data-k="${k}"]`);
  $("title").textContent = st.title;
  $("eye").style.display = st.secret ? "" : "none";
  $("eye").textContent = st.show ? "Masquer" : "Afficher";
  const shown = st.secret && !st.show ? "•".repeat(st.value.length) : st.value;
  $("field").textContent = shown || " ";
  $("field").style.color = st.value ? "#F1F3F5" : "#5A616B";
  if (!st.value) $("field").textContent = st.placeholder || " ";
  $("keys").innerHTML = ROWS[st.layer]
    .map((row) => {
      const keys = row.includes(" ") ? row.split(" ") : [...row];
      return `<div style="display:flex;gap:6px;justify-content:center">${keys
        .map((k) => {
          const wide = k === "␣" ? "flex:5" : k === "⏎" ? "flex:2" : k === "?123" || k === "abc" ? "flex:1.6" : "flex:1";
          const label = k === "␣" ? "espace" : k === "⏎" ? st.ok : k;
          const hot = k === "⏎" ? "border-color:#4FD1E8;background:rgba(79,209,232,.18);color:#FFFFFF;" : k === "⇧" && st.layer === "up" ? "border-color:#F1F3F5;" : "";
          return `<button type="button" class="chip" data-key="${k.replace(/"/g, "&quot;")}" style="${wide};min-height:52px;padding:0;font-size:${label.length > 2 ? 12 : 20}px;text-transform:none;letter-spacing:0;${hot}">${label.replace(/</g, "&lt;")}</button>`;
        })
        .join("")}</div>`;
    })
    .join("");
}

function close() {
  st = null;
  popOut(el, () => {
    if (!st) el.style.display = "none";
  }, "translateY(20px)");
}

export const keyboard = {
  /** open({ title, secret, ok, value, placeholder, onDone }) */
  open(opts) {
    if (!el) build();
    st = { title: "", secret: false, ok: "OK", value: "", placeholder: "", layer: "low", show: false, ...opts };
    render();
    el.style.display = "flex";
    popIn(el, "translateY(20px)", 360);
  },
  close,
};
