// Initialisation du tableau de bord : 1) compteur (jauge de carburant), 2) calculateur moteur, 3) lecture en continu.
// L'écran suit chaque étape en direct ; quand tout est bon, Nova passe tout seul au tableau de bord.
import { View, esc } from "../bind.js";

const panel = "border-radius:16px;background:rgba(14,16,19,.78);border:1px solid #33373E";
const ICON = {
  attente: `<span style="box-sizing:border-box;flex:none;width:30px;height:30px;border-radius:50%;border:2px solid #3E434B;display:inline-block"></span>`,
  "en cours": `<span class="init-spin" style="box-sizing:border-box;flex:none;width:30px;height:30px;border-radius:50%;border:3px solid #2A2E34;border-top-color:#4FD1E8;display:inline-block"></span>`,
  ok: `<span style="box-sizing:border-box;flex:none;width:30px;height:30px;border-radius:50%;background:#1F3B29;color:#7BD88F;display:inline-flex;align-items:center;justify-content:center;font-size:18px;font-weight:700">✓</span>`,
  erreur: `<span style="box-sizing:border-box;flex:none;width:30px;height:30px;border-radius:50%;background:#3E1F1F;color:#FF6B5B;display:inline-flex;align-items:center;justify-content:center;font-size:18px;font-weight:700">!</span>`,
};

const html = `
<style>@keyframes initspin{to{transform:rotate(360deg)}}.init-spin{animation:initspin .9s linear infinite}</style>
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:32px;right:32px;top:20px;display:flex;align-items:baseline;justify-content:space-between">
    <span style="font-size:24px;font-weight:700;letter-spacing:.06em">Initialisation du tableau de bord</span>
    <span class="lbl" style="font-size:11px;letter-spacing:.08em" data-t="sub"></span>
  </div>

  <div style="position:absolute;left:32px;top:76px;width:700px;display:flex;flex-direction:column;gap:14px" data-html="steps"></div>

  <div style="position:absolute;left:760px;right:32px;top:76px;height:330px;${panel};padding:20px;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px">
    <span class="lbl" style="font-size:11px;letter-spacing:.1em">Carburant</span>
    <span class="num" style="font-size:64px;font-weight:700;line-height:1" data-t="fuelL"></span>
    <span style="font-size:13px;color:#C9CED4" data-t="fuelSub"></span>
    <div style="width:100%;height:14px;border-radius:7px;background:#2A2E34;overflow:hidden;margin-top:10px"><div style="height:100%;background:linear-gradient(90deg,#F5B841,#7BD88F);transition:width .6s ease" data-s="width:fuelPct"></div></div>
    <span style="font-size:11px;color:#8A9099;text-align:center;line-height:1.4;margin-top:6px" data-t="fuelNote"></span>
  </div>

  <div style="position:absolute;left:32px;right:32px;bottom:22px;display:flex;align-items:center;gap:12px">
    <span style="flex:1;font-size:13px;line-height:1.4" data-t="result" data-s="color:resCol"></span>
    <button type="button" class="btn" data-on="click:again" data-s="opacity:againOp">Relancer</button>
    <button type="button" class="btn" data-on="click:go">Tableau de bord</button>
  </div>
</div>`;

export default {
  id: "initialisation",
  html,
  mount(el, app) {
    this.app = app;
    this.view = new View(el, {
      again: () => !this.app.dashinit?.running && app.send({ type: "dashinit.start" }),
      go: () => app.go("tableau"),
    });
  },
  show() {
    this.app.send({ type: "dashinit.get" });
    this.update();
  },
  update() {
    const d = this.app.dashinit || { steps: [], running: false };
    const steps = (d.steps || []).map(
      (s, i) => `<div style="${panel};padding:16px 18px;display:flex;align-items:center;gap:16px">
        ${ICON[s.state] || ICON.attente}
        <div style="display:flex;flex-direction:column;gap:4px;min-width:0">
          <span style="font-size:16px;font-weight:600">${i + 1}. ${esc(s.label)}</span>
          <span style="font-size:12px;line-height:1.35;color:${s.state === "erreur" ? "#FF8A7A" : "#AEB4BC"}">${esc(s.detail || (s.state === "attente" ? "en attente" : ""))}</span>
        </div>
      </div>`,
    );
    const L = d.fuelL;
    this.view.set({
      sub: d.running ? "en cours…" : d.at ? "terminée à " + new Date(d.at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) : "",
      steps: steps.join("") || `<div style="${panel};padding:18px;font-size:14px;color:#AEB4BC">Touche « Relancer » pour lancer l'initialisation (câble KKL branché, contact mis).</div>`,
      fuelL: L != null ? Math.round(L) + " L" : "—",
      fuelSub: d.fuelOhm != null ? `sonde ${Math.round(d.fuelOhm)} Ω${d.clusterL != null ? ` · le compteur dit ${d.clusterL} L` : ""}` : "jauge pas encore lue",
      fuelPct: L != null ? Math.round((100 * L) / 62) + "%" : "0%",
      fuelNote: "Calibrée sur ta TT : 59 Ω = vide, 282 Ω = plein (plus la résistance est haute, plus il y a de carburant).",
      result: d.running ? "Nova initialise le tableau de bord…" : d.text || "",
      resCol: d.running ? "#C9CED4" : d.ok ? "#7BD88F" : "#F5B841",
      againOp: d.running ? "0.4" : "1",
    });
  },
};
