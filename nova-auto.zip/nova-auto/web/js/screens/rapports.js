// Passages de rapport (maquette « Rapports ») : courbes de force à la roue, avec les rapports
// et la courbe de couple apprises par Nova quand elles existent.
import { View, interp, thousands, navHtml } from "../bind.js";

const F = 'font-family="Chakra Petch, system-ui, sans-serif"';
const PERF = "#4FD1E8", ECO = "#7BD88F";
const X = (v) => 60 + (v / 260) * 540;
const Y = (f) => 370 - (f / 36) * 330;

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Passages de rapport</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="sub"></span>
    </div>
    <div style="display:flex;gap:10px" role="group" aria-label="Stratégie">
      <button type="button" class="tab" style="padding:0 20px;font-size:13px;letter-spacing:.14em" data-on="click:perf" data-a="aria-pressed:perfOn" data-s="border-color:perfBorder;background:perfBg;color:perfInk">Performance</button>
      <button type="button" class="tab" style="padding:0 20px;font-size:13px;letter-spacing:.14em" data-on="click:eco" data-a="aria-pressed:ecoOn" data-s="border-color:ecoBorder;background:ecoBg;color:ecoInk">Économie</button>
    </div>
  </div>
  <div style="position:absolute;left:20px;top:84px;width:620px;height:420px;border-radius:14px;background:rgba(14,16,19,.75);border:1px solid #33373E">
    <svg width="620" height="420" viewBox="0 0 620 420" role="img" aria-label="Force à la roue selon la vitesse, pour chaque rapport">
      ${[0, 40, 80, 120, 160, 200, 240].map((v) => `<line x1="${X(v)}" y1="30" x2="${X(v)}" y2="370" stroke="#2A2E34" stroke-width="1"></line><text x="${X(v)}" y="390" fill="#9AA1AA" font-size="11" font-weight="600" text-anchor="middle" ${F}>${v}</text>`).join("")}
      <line x1="60" y1="370" x2="600" y2="370" stroke="#5A616B" stroke-width="1.5"></line>
      <line x1="60" y1="30" x2="60" y2="370" stroke="#5A616B" stroke-width="1.5"></line>
      <text x="600" y="408" fill="#7E858F" font-size="10" font-weight="600" letter-spacing="1.5" text-anchor="end" ${F}>VITESSE (KM/H)</text>
      <text x="24" y="200" fill="#7E858F" font-size="10" font-weight="600" letter-spacing="1.5" text-anchor="middle" transform="rotate(-90 24 200)" ${F}>FORCE À LA ROUE</text>
      <g data-html="curves"></g>
      <g data-html="marks"></g>
      <circle r="5" fill="#FFFFFF" stroke-width="3" data-a="cx:nx;cy:ny;stroke:ncol" data-s="opacity:nop" style="transition:opacity 300ms ease"></circle>
    </svg>
  </div>
  <div style="position:absolute;left:656px;right:20px;top:84px;height:420px;display:flex;flex-direction:column;gap:7px">
    <div style="display:grid;grid-template-columns:70px 1fr 1fr;padding:0 14px" class="lbl"><span>Rapport</span><span style="text-align:right">Passer à</span><span style="text-align:right">Tu retombes</span></div>
    <div data-html="rows" style="display:flex;flex-direction:column;gap:7px"></div>
    <div style="margin-top:auto;display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border-radius:12px;background:rgba(14,16,19,.8);border:1px solid" data-s="border-color:accent">
      <img src="logo.png" alt="" style="width:48px;height:27px;object-fit:contain;flex:none;margin-top:2px">
      <p style="margin:0;font-size:13px;line-height:1.45;color:#E6EAEE" data-t="tip"></p>
    </div>
  </div>
  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("rapports")}
    <span class="lbl" style="font-size:9px;letter-spacing:.06em;max-width:300px;text-align:right">Point = passage optimal · la shift light du tableau s'allume à ces régimes</span>
  </div>
</div>`;

export default {
  id: "rapports",
  html,
  mount(el, app) {
    this.app = app;
    this.perf = (app.car.mode ?? 0) > 0;
    this.view = new View(el, {
      perf: () => {
        this.perf = true;
        this.render();
      },
      eco: () => {
        this.perf = false;
        this.render();
      },
    });
  },
  show() {
    this.render();
  },
  update() {
    // point de fonctionnement actuel sur les courbes (2 fois par seconde suffit)
    if (++this.tick % 8 === 0) this.render();
  },
  tick: 0,
  frame() {
    // point de fonctionnement actuel, glissant à 60 images/s
    const R = this.app.rapports;
    const gear = this.app.car.v?.gear;
    const rpm = this.app.live?.rpm;
    if (!R?.ratios || !gear || !rpm) return this.view.set({ nop: 0 });
    const k = R.ratios[gear - 1];
    this.view.set({ nx: X((rpm * k) / 1000).toFixed(1), ny: Y(interp(R.torque, rpm) / k).toFixed(1), ncol: this.perf ? PERF : ECO, nop: 1 });
  },
  render() {
    const R = this.app.rapports;
    if (!R?.rows) return;
    const K = R.ratios, TQ = R.torque, LIMIT = R.limit;
    const T = (r) => interp(TQ, r);
    const perf = this.perf;
    const col = perf ? PERF : ECO;
    const v = this.app.car.v || {};
    const curves = K.map((k, g) => {
      const pts = [];
      for (let r = 1500; r <= LIMIT; r += 100) {
        const sp = (r * k) / 1000;
        if (sp <= 260) pts.push(X(sp).toFixed(1) + "," + Y(T(r) / k).toFixed(1));
      }
      const cur = v.gear === g + 1;
      return `<polyline points="${pts.join(" ")}" fill="none" stroke="${cur ? "#F1F3F5" : perf ? "#B9BFC7" : "#8A9099"}" stroke-width="${cur ? 3.5 : 2.5}" stroke-linejoin="round" stroke-linecap="round"></polyline>
        <text x="${Math.min(585, X((3800 * k) / 1000)).toFixed(1)}" y="${(Y(280 / k) - 10).toFixed(1)}" fill="#E6EAEE" font-size="14" font-weight="700" text-anchor="middle" ${F}>${g + 1}</text>`;
    }).join("");
    const marks = R.rows.map((s) => {
      const r = perf ? s.perf : s.eco;
      const g = s.gear - 1;
      const x = X((r * K[g]) / 1000).toFixed(1), y = Y(T(r) / K[g]).toFixed(1);
      return `<line x1="${x}" y1="${y}" x2="${x}" y2="370" stroke="${col}" stroke-width="1" stroke-dasharray="3 4" opacity="0.6"></line><circle cx="${x}" cy="${y}" r="6" fill="${col}" stroke="#0E1013" stroke-width="2"></circle>`;
    }).join("");
    const rows = R.rows.map((s) => {
      const r = perf ? s.perf : s.eco;
      const cur = v.gear === s.gear;
      return `<div style="display:grid;grid-template-columns:70px 1fr 1fr;align-items:center;padding:7px 14px;border-radius:12px;background:rgba(20,22,26,.75);border:1px solid ${cur ? col : "#33373E"}">
        <span class="num" style="font-size:18px">${s.gear} → ${s.gear + 1}</span>
        <span style="display:flex;flex-direction:column;align-items:flex-end"><span class="num" style="font-size:20px;color:${col}">${thousands(r)}</span><span class="lbl" style="font-size:9px;letter-spacing:.08em">${perf ? (s.cut ? "jusqu’au rupteur" : "croisement des courbes") : "tr/min"}</span></span>
        <span class="num" style="font-size:16px;text-align:right;color:#B9BFC7">${thousands(perf ? s.landPerf : s.landEco)}</span></div>`;
    }).join("");
    const cut = R.rows.filter((s) => s.cut).map((s) => s.gear);
    const first = R.rows.find((s) => !s.cut);
    const names = ["1re", "2e", "3e", "4e", "5e"];
    const tip = perf
      ? (cut.length ? `En ${cut.map((g) => names[g - 1]).join(", ").replace(/, ([^,]*)$/, " et $1")}, tire jusqu’au rupteur : le rapport suivant pousse moins fort. ` : "") +
        (first ? `À partir de la ${names[first.gear - 1]}, passe vers ${thousands(first.perf)} tr/min, c’est là que tu gardes le plus de force à la roue.` : "")
      : "Passe la vitesse dès que tu retombes au-dessus de 1 700 tr/min, avec moins d’un quart de pédale. Le turbo reste au repos et le moteur tourne dans sa zone la plus sobre.";
    this.view.set({
      sub: `1.8T 225 · ${R.learnedTorque ? "courbe de couple mesurée par Nova" : "courbe de couple type"} · ${R.learnedRatios ? R.learnedRatios + "/6 rapports mesurés" : "rapports d’origine"}`,
      curves, marks, rows, tip, accent: col,
      perfOn: perf ? "true" : "false", ecoOn: perf ? "false" : "true",
      perfBorder: perf ? PERF : "#4A5058", perfBg: perf ? "rgba(79,209,232,.14)" : "#1C1F24", perfInk: perf ? "#FFFFFF" : "#D6DBE1",
      ecoBorder: !perf ? ECO : "#4A5058", ecoBg: !perf ? "rgba(123,216,143,.14)" : "#1C1F24", ecoInk: !perf ? "#FFFFFF" : "#D6DBE1",
    });
  },
};
