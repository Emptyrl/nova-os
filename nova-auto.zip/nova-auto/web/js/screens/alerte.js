// Alerte plein écran (maquette « Alerte »). S'affiche par-dessus tout dès qu'une alerte arrive.
import { View, esc, hhmm } from "../bind.js";

const LEVELS = {
  Critique: { col: "#FF4D2E", colSoft: "rgba(255,77,46,.35)", colLine: "rgba(255,77,46,.6)", glow: "#4A2620", beat: "1s" },
  Attention: { col: "#F5B841", colSoft: "rgba(245,184,65,.28)", colLine: "rgba(245,184,65,.55)", glow: "#3E3320", beat: "1.8s" },
  Info: { col: "#9FB4C8", colSoft: "rgba(159,180,200,.2)", colLine: "rgba(159,180,200,.45)", glow: "#2A3138", beat: "3s" },
};
const ICONS = {
  temp: '<path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"></path><path d="M11.5 9v7"></path><path d="M17 6h3M17 9h2M17 12h3"></path>',
  oil: '<path d="M3 10h4l2-2h5l2 2h3l2-2v6l-4 4H7l-4-4z"></path><path d="M19 6c0 1.2.9 2 1.5 2.8.4.6-.1 1.2-.8 1.2"></path><path d="M7 10V7h4"></path>',
  service: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.2L3 17.8V21h3.2l6.3-6.3a4 4 0 0 0 5.2-5.4l-2.4 2.4-2.5-.5-.5-2.5z"></path>',
  battery: '<rect x="3" y="7" width="18" height="12" rx="2"></rect><path d="M7 7V5h3v2M14 7V5h3v2"></path><path d="M7 13h4M15 11v4M13 13h4"></path>',
  knock: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"></path>',
  fuel: '<path d="M4 21V5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v16"></path><path d="M3 21h13"></path><path d="M15 9h2a2 2 0 0 1 2 2v5a1.5 1.5 0 0 0 3 0V8l-3-3"></path><path d="M7 7h5"></path>',
  boost: '<circle cx="12" cy="13" r="8"></circle><path d="M12 13l4-4"></path><path d="M8 3h8"></path>',
  lean: '<path d="M12 2.7C8 8 6 11.3 6 14a6 6 0 0 0 12 0c0-2.7-2-6-6-11.3z"></path><path d="M9 15h6"></path>',
  dtc: '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"></path><path d="M12 9v4M12 17h.01"></path>',
};

const html = `
<div style="position:absolute;inset:0;color:#F1F3F5" data-s="background:bg">
  <div class="edge" aria-hidden="true" style="position:absolute;inset:0" data-s="box-shadow:edge;animation-duration:beat"></div>
  <div style="position:absolute;left:32px;right:32px;top:22px;display:flex;justify-content:space-between;align-items:center">
    <span style="display:flex;align-items:center;gap:10px">
      <span style="padding:6px 14px;border-radius:16px;color:#0E1013;font-size:12px;font-weight:700;letter-spacing:.18em;text-transform:uppercase" data-s="background:col" data-t="level"></span>
      <span class="lbl" data-t="system"></span>
    </span>
    <span class="lbl" data-t="idx"></span>
  </div>
  <div style="position:absolute;left:32px;right:32px;top:84px;display:flex;align-items:center;gap:40px">
    <div class="ico" style="flex:none;display:flex;align-items:center;justify-content:center;width:200px;height:200px;border-radius:50%;border:3px solid;background:rgba(10,11,13,.6)" data-s="border-color:col;animation-duration:beat">
      <svg width="96" height="96" viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-a="stroke:col" data-html="icon"></svg>
    </div>
    <div style="display:flex;flex-direction:column;gap:12px;min-width:0">
      <span style="font-size:40px;font-weight:700;line-height:1.05;letter-spacing:.02em;text-wrap:balance" data-t="title"></span>
      <span style="display:flex;align-items:baseline;gap:12px">
        <span class="num" style="font-size:64px;line-height:1" data-s="color:col" data-t="value"></span>
        <span class="lbl" style="font-size:13px;max-width:330px" data-t="limit"></span>
      </span>
      <svg width="420" height="54" viewBox="0 0 420 54" aria-hidden="true" style="max-width:100%" data-show="hasSpark">
        <line x1="0" x2="420" stroke-width="1" stroke-dasharray="4 4" opacity="0.7" data-a="y1:limitY;y2:limitY;stroke:col"></line>
        <polyline fill="none" stroke="#E6EAEE" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" data-a="points:spark"></polyline>
        <circle cx="416" r="4" data-a="cy:endY;fill:col"></circle>
      </svg>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="sparkLbl"></span>
    </div>
  </div>
  <div style="position:absolute;left:32px;right:32px;top:330px;display:flex;gap:16px;align-items:flex-start;padding:18px 20px;border-radius:16px;background:rgba(10,11,13,.72);border:1px solid" data-s="border-color:colLine">
    <img src="logo.png" alt="Nova" style="flex:none;width:70px;height:40px;object-fit:contain;margin-top:2px">
    <div style="display:flex;flex-direction:column;gap:6px">
      <span class="lbl" data-s="color:col">Nova</span>
      <p style="margin:0;font-size:19px;line-height:1.45;color:#F1F3F5" data-t="say"></p>
    </div>
  </div>
  <div style="position:absolute;left:32px;right:32px;bottom:26px;display:flex;justify-content:space-between;align-items:center">
    <button type="button" class="btn-al" style="border:1px solid #4A5058;background:#1C1F24;color:#D6DBE1" data-show="many" data-on="click:next">Alerte suivante</button>
    <span data-show="single"></span>
    <div style="display:flex;gap:12px">
      <button type="button" class="btn-al" style="border:1px solid #4A5058;background:#1C1F24;color:#D6DBE1" data-on="click:second" data-t="second" data-show="hasSecond"></button>
      <button type="button" class="btn-al" style="color:#0E1013;border:1px solid" data-s="border-color:col;background:col" data-on="click:ok">Compris</button>
    </div>
  </div>
</div>`;

export default {
  id: "alerte",
  html,
  mount(el, app) {
    this.app = app;
    this.i = 0;
    this.view = new View(el, {
      next: () => {
        this.i++;
        this.update();
      },
      ok: () => this.ack(null),
      second: () => this.ack(this.current?.second?.action),
    });
  },
  ack(action) {
    const a = this.current;
    if (!a) return;
    this.app.send({ type: "alert.ack", id: a.id, action: action && action !== "none" ? action : undefined });
    this.app.alertAcked(a.id);
  },
  update() {
    const list = this.app.pendingAlerts();
    if (!list.length) return;
    const a = list[this.i % list.length];
    this.current = a;
    const L = LEVELS[a.level] || LEVELS.Info;
    const yOf = (x) => (50 - ((x - a.min) / (a.max - a.min || 1)) * 46).toFixed(1);
    const spark = (a.spark || []).map((x, k, arr) => ((k / Math.max(1, arr.length - 1)) * 416).toFixed(1) + "," + yOf(x)).join(" ");
    const last = a.spark?.length ? a.spark[a.spark.length - 1] : a.lim;
    this.view.set({
      bg: `radial-gradient(ellipse 70% 65% at 50% 42%, ${L.glow} 0%, #1A1C20 55%, #0A0B0D 100%)`,
      edge: `inset 0 0 0 4px ${L.col}, inset 0 0 60px ${L.colSoft}`,
      beat: L.beat, col: L.col, colLine: L.colLine,
      level: a.level, system: a.system,
      idx: `${hhmm()} · alerte ${(this.i % list.length) + 1} / ${list.length}`,
      icon: ICONS[a.kind] || ICONS.service,
      title: a.title, value: a.value, limit: a.limit,
      hasSpark: !!(a.spark && a.spark.length > 1),
      spark, limitY: yOf(a.lim), endY: yOf(last),
      sparkLbl: a.sparkLbl || "",
      say: a.say,
      many: list.length > 1, single: list.length <= 1,
      hasSecond: !!(a.second && a.second.action !== "none"),
      second: a.second?.label || "",
    });
  },
};
export { esc };
