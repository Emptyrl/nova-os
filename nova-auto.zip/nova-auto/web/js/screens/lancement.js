// Démarrage de l'app (maquette « Lancement ») : le logo se dessine, puis les vraies vérifications
// (source des données, réseau, cerveau, voix, carte NovaHAT) et l'accueil.
import { View, esc, clamp } from "../bind.js";

const html = `
<div style="position:absolute;inset:0;background:#07080A;color:#F1F3F5" data-on="click:skip">
  <div class="fade" aria-hidden="true" data-s="opacity:bgOp" style="position:absolute;inset:0;background:radial-gradient(ellipse 65% 60% at 50% 40%, #5A616B 0%, #353A42 38%, #1C1F24 72%, #0E1013 100%)"></div>
  <div style="position:absolute;left:50%;top:36%;transform:translate(-50%,-50%);width:400px;height:225px">
    <img src="logo.png" alt="" data-s="clip-path:clip;filter:filt" style="position:absolute;inset:0;width:400px;height:225px;object-fit:contain">
    <div aria-hidden="true" data-s="top:scanY;opacity:scanOp" style="position:absolute;left:-40px;right:-40px;height:3px;background:#FFFFFF;box-shadow:0 0 16px 5px rgba(230,236,242,.7)"></div>
  </div>
  <div style="position:absolute;left:0;right:0;top:330px;display:flex;justify-content:center;gap:22px" aria-label="Nova" data-html="letters"></div>
  <div class="fade" data-s="opacity:listOp" style="position:absolute;left:50%;top:392px;width:420px;margin-left:-210px;display:flex;flex-direction:column;gap:7px">
    <div data-html="checks" style="display:flex;flex-direction:column;gap:7px"></div>
    <div style="height:3px;border-radius:2px;background:#2A2E34;margin-top:6px;overflow:hidden"><div data-s="width:prog" style="height:100%;background:#F1F3F5;transition:width 120ms linear"></div></div>
  </div>
  <div class="fade" data-s="opacity:helloOp;transform:helloY" style="position:absolute;left:0;right:0;top:400px;display:flex;flex-direction:column;align-items:center;gap:8px">
    <span style="font-size:34px;font-weight:600" data-t="hello"></span>
    <span class="lbl" style="font-size:13px;letter-spacing:.2em;color:#C9CED4" data-t="ready"></span>
  </div>
  <div style="position:absolute;left:28px;right:28px;bottom:16px;display:flex;justify-content:space-between;align-items:center">
    <span class="lbl" style="font-size:10px;color:#5E656F">NOVA system ver1.0</span>
    <span class="lbl" style="font-size:10px;color:#5E656F">Touche l'écran pour passer</span>
  </div>
</div>`;

export default {
  id: "lancement",
  html,
  mount(el, app) {
    this.app = app;
    this.view = new View(el, { skip: () => this.finish() });
  },
  show() {
    this.t0 = performance.now();
    this.checks = null;
    this.done = false;
    this.app.send({ type: "boot.get" });
    this.poll = setInterval(() => this.app.send({ type: "boot.get" }), 1500);
    const loop = () => {
      if (this.done) return;
      this.render();
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  },
  hide() {
    this.done = true;
    clearInterval(this.poll);
  },
  onBoot(checks) {
    this.checks = checks;
  },
  finish() {
    if (this.done) return;
    this.done = true;
    clearInterval(this.poll);
    this.app.bootDone();
  },
  render() {
    const t = performance.now() - this.t0;
    const reveal = clamp((t - 300) / 2200);
    const flash = t > 2500 && t < 3300 ? 1 - Math.abs(t - 2900) / 400 : 0;
    const letters = "NOVA".split("").map((c, i) => {
      const on = t > 2900 + i * 160;
      return `<span class="fade" style="font-size:30px;font-weight:700;opacity:${on ? 1 : 0};transform:translateY(${on ? 0 : 8}px)">${c}</span>`;
    }).join("");
    const list = this.checks ?? [];
    const slot = 700;
    const checks = list.map((c, i) => {
      const start = 3600 + i * slot, end = start + 550;
      const shown = t >= start;
      const settled = t >= end && (!c.wait || t >= end + 4000);
      const mark = !settled ? '<span class="spin"></span>' : c.ok ? '<span style="font-size:14px;font-weight:700;color:#7BD88F">✓</span>' : '<span style="font-size:14px;font-weight:700;color:#F5B841">!</span>';
      return `<div class="fade" style="display:flex;align-items:center;justify-content:space-between;opacity:${shown ? 1 : 0}">
        <span class="lbl" style="letter-spacing:.1em;color:#C9CED4">${esc(c.name)}</span>
        <span style="display:flex;align-items:center;gap:8px"><span class="lbl" style="font-size:10px;letter-spacing:.06em;color:${settled && !c.ok ? "#F5B841" : "#8A9099"}">${settled ? esc(c.val) : ""}</span>${mark}</span></div>`;
    }).join("");
    const listEnd = 3600 + Math.max(5, list.length) * slot + 900;
    const listOn = t > 3400 && t < listEnd;
    const hello = t > listEnd + 300;
    const bad = list.filter((c) => !c.ok).length;
    this.view.set({
      clip: `inset(${((1 - reveal) * 100).toFixed(1)}% 0 0 0)`,
      scanY: ((1 - reveal) * 225).toFixed(1) + "px",
      scanOp: reveal > 0 && reveal < 1 ? 1 : 0,
      filt: `brightness(${(1 + flash * 0.8).toFixed(2)}) drop-shadow(0 0 ${(4 + flash * 22).toFixed(1)}px rgba(240,244,248,.7)) drop-shadow(0 10px 22px rgba(0,0,0,.6))`,
      bgOp: clamp((t - 2400) / 1500).toFixed(2),
      letters,
      checks,
      listOp: listOn ? 1 : 0,
      prog: (clamp((t - 3600) / (listEnd - 4500)) * 100).toFixed(1) + "%",
      helloOp: hello ? 1 : 0,
      helloY: hello ? "translateY(0)" : "translateY(10px)",
      hello: `Bonjour ${this.app.driver}.`,
      ready: !list.length ? "" : bad === 0 ? "Tous les systèmes sont prêts" : bad === 1 ? "Un système à vérifier" : `${bad} systèmes à vérifier`,
    });
    if (t > listEnd + 3300) this.finish();
  },
};
