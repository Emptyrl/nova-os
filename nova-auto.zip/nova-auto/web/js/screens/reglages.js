// Réglages (dans le style des maquettes) : cerveau, voix, voiture, démarrage à distance, apprentissage.
import { View, esc } from "../bind.js";
import { saveSettings } from "../voice.js";

const panel = "padding:14px 16px;border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E;display:flex;flex-direction:column;gap:10px";
const row = "display:grid;grid-template-columns:1fr 1fr;gap:10px";

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:24px;right:24px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Réglages</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="dataDir"></span>
    </div>
    <button type="button" class="btn" data-on="click:close">Fermer</button>
  </div>
  <div class="scroll" style="position:absolute;left:20px;right:20px;top:76px;bottom:16px;display:grid;grid-template-columns:1fr 1fr;gap:12px;align-content:start">
    <div style="${panel}">
      <span class="lbl">Cerveau</span>
      <label class="field"><span class="lbl" style="font-size:9px">Clé Anthropic <span data-t="aKey"></span></span><input id="r-akey" type="password" autocomplete="off" placeholder="sk-ant-… (vide = inchangée)"></label>
      <label class="field"><span class="lbl" style="font-size:9px">Clé OpenAI, facultative <span data-t="oKey"></span></span><input id="r-okey" type="password" autocomplete="off" placeholder="voix naturelle, images, second avis"></label>
      <button type="button" class="btn" data-on="click:saveKeys">Enregistrer les clés</button>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Double cerveau</span><select id="r-fast"><option value="1">Activé (voix rapide)</option><option value="0">Désactivé</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Modèle rapide</span><input id="r-fastmodel" placeholder="claude-haiku-5-5"></label>
      </div>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none" data-t="fastTxt" data-s="color:fastCol"></span>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Sans clé, Nova utilise la connexion Claude Code du PC (commande claude puis /login).</span>
    </div>
    <div style="${panel}">
      <span class="lbl">Voix</span>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Voix de Nova</span><select id="r-engine"><option value="local">Locale (sans Internet)</option><option value="openai">OpenAI (naturelle)</option><option value="browser">Navigateur</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Voix locale</span><select id="r-voice" data-html="voiceOpts"></select></label>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn" data-on="click:install" data-t="installLbl"></button>
        <button type="button" class="btn" data-on="click:test">Tester</button>
      </div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Réveil « Nova »</span><select id="r-wake"><option value="1">Activé</option><option value="0">Désactivé</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Sensibilité</span><select id="r-sens"><option value="low">Faible</option><option value="normal">Normale</option><option value="high">Forte</option></select></label>
      </div>
      <label class="field"><span class="lbl" style="font-size:9px">Micro</span><select id="r-mic" data-html="micOpts"></select></label>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px"><span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none" data-t="sttTxt"></span><button type="button" class="btn" data-show="needModel" data-on="click:model">Télécharger</button></div>
      <div style="height:6px;border-radius:3px;background:#2A2E34;overflow:hidden"><div style="height:100%;background:#7BD88F;transition:width 80ms linear" data-s="width:micPct"></div></div>
    </div>
    <div style="${panel}">
      <span class="lbl">Voiture</span>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Source des données</span><select id="r-src"><option value="auto">Auto (câble détecté)</option><option value="kkl">Câble KKL (Nova lit le ME7.5)</option><option value="elm327">ELM327</option><option value="me7logger">ME7Logger (fichier CSV)</option><option value="can">CAN (NovaHAT)</option><option value="can+kkl">CAN + KKL</option><option value="can+elm327">CAN + ELM327</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Port série (vide = auto)</span><input id="r-port" placeholder="COM3 ou /dev/ttyUSB0"></label>
      </div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Carburant</span><select id="r-fuel"><option value="E85">E85</option><option value="SP98">SP98</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Dans le réservoir (L)</span><input id="r-tank" type="number" min="0" max="62" step="1" placeholder="après un plein : 62"></label>
      </div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Compteur (km)</span><input id="r-odo" type="number" min="0" step="1"></label>
        <label class="field"><span class="lbl" style="font-size:9px">Dernière vidange (km)</span><input id="r-service" type="number" min="0" step="1"></label>
      </div>
      <button type="button" class="btn" data-on="click:saveCar">Enregistrer</button>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Changer de source : enregistre puis relance Nova.</span>
    </div>
    <div style="${panel}">
      <span class="lbl">Démarrage à distance</span>
      <span style="font-size:15px;font-weight:600" data-t="remote"></span>
      <div style="display:flex;gap:8px">
        <button type="button" class="btn" data-on="click:rStart">Démarrer</button>
        <button type="button" class="btn" data-on="click:rStop">Couper</button>
      </div>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Contact, vérification sur le CAN (moteur arrêté, roues immobiles), démarreur jusqu’à ce que le moteur tourne. Une roue qui bouge coupe tout.</span>
      <span class="lbl" style="font-size:9px" data-t="hw"></span>
    </div>
    <div style="${panel}">
      <span class="lbl">Nova OS</span>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Sur la clé Nova OS ou le Raspberry Pi : le menu donne accès au bureau Linux (maintenance), à un terminal, au redémarrage.</span>
      <div style="display:flex;gap:8px">
        <button type="button" class="btn" data-on="click:sysMenu">Menu Nova OS</button>
        <button type="button" class="btn" data-on="click:sysOff" data-t="offLbl" data-s="border-color:offBorder"></button>
      </div>
    </div>
    <div style="${panel}">
      <span class="lbl">Apprentissage</span>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Efface les rapports, la courbe moteur et la consommation apprises, pour tout remesurer.</span>
      <button type="button" class="btn" data-on="click:learnReset" data-t="resetLbl"></button>
    </div>
  </div>
</div>`;

export default {
  id: "reglages",
  html,
  mount(el, app) {
    this.app = app;
    this.el = el;
    const $ = (id) => el.querySelector("#" + id);
    this.$ = $;
    const setS = (patch) => {
      Object.assign(app.settings, patch);
      saveSettings(app.settings);
      app.voice.reconfigure();
    };
    $("r-fast").onchange = (e) => app.send({ type: "config.set", patch: { fastEnabled: e.target.value === "1" } });
    $("r-fastmodel").onchange = (e) => e.target.value.trim() && app.send({ type: "config.set", patch: { fastModel: e.target.value.trim() } });
    $("r-engine").onchange = (e) => setS({ ttsEngine: e.target.value });
    $("r-voice").onchange = (e) => setS({ localVoice: e.target.value });
    $("r-wake").onchange = (e) => setS({ wakeWord: e.target.value === "1" });
    $("r-sens").onchange = (e) => setS({ sensitivity: e.target.value });
    $("r-mic").onchange = (e) => setS({ micId: e.target.value });
    let resetArmed = false;
    this.view = new View(el, {
      close: () => app.go(app.prevScreen && app.prevScreen !== "reglages" ? app.prevScreen : "veille"),
      saveKeys: () => {
        const patch = {};
        if ($("r-akey").value.trim()) patch.anthropicApiKey = $("r-akey").value.trim();
        if ($("r-okey").value.trim()) patch.openaiApiKey = $("r-okey").value.trim();
        app.send({ type: "config.set", patch });
        $("r-akey").value = $("r-okey").value = "";
        app.toast("Clés enregistrées");
      },
      install: () => {
        const id = $("r-voice").value || app.settings.localVoice;
        app.send({ type: "voices.install", id });
        app.toast("Téléchargement de la voix…");
      },
      test: () => app.voice.say(`Bonjour ${app.driver}. Je suis Nova, prête à rouler.`),
      model: () => app.send({ type: "model.download", name: "fr" }),
      saveCar: () => {
        const car = { source: $("r-src").value, serialPort: $("r-port").value.trim(), fuelType: $("r-fuel").value };
        if ($("r-odo").value) car.odometerKm = Number($("r-odo").value);
        if ($("r-service").value) car.lastServiceKm = Number($("r-service").value);
        app.send({ type: "config.set", patch: {}, car });
        if ($("r-tank").value !== "") app.send({ type: "fuel.set", liters: Number($("r-tank").value) });
        app.toast("Réglages de la voiture enregistrés");
      },
      sysMenu: () => app.send({ type: "system.menu" }),
      sysOff: () => {
        if (!this.offArmed) {
          this.offArmed = true;
          setTimeout(() => ((this.offArmed = false), this.update()), 4000);
          return this.update();
        }
        app.send({ type: "system.poweroff" });
      },
      rStart: () => app.send({ type: "remote.start" }),
      rStop: () => app.send({ type: "remote.stop" }),
      learnReset: () => {
        if (!resetArmed) {
          resetArmed = true;
          this.update();
          setTimeout(() => {
            resetArmed = false;
            this.update();
          }, 4000);
          return;
        }
        resetArmed = false;
        app.send({ type: "learn.reset" });
        app.toast("Apprentissage remis à zéro");
      },
    });
    this.resetArmed = () => resetArmed;
  },
  async show() {
    const app = this.app;
    const c = app.config?.car || {};
    const $ = this.$;
    $("r-engine").value = app.settings.ttsEngine;
    $("r-fast").value = app.config?.fastEnabled === false ? "0" : "1";
    $("r-fastmodel").value = app.config?.fastModel || "";
    $("r-wake").value = app.settings.wakeWord ? "1" : "0";
    $("r-sens").value = app.settings.sensitivity;
    $("r-src").value = c.source || "auto";
    $("r-port").value = c.serialPort || "";
    $("r-fuel").value = c.fuelType || "E85";
    $("r-odo").value = c.odometerKm ?? "";
    $("r-service").value = c.lastServiceKm || "";
    $("r-tank").value = "";
    try {
      const devs = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "audioinput");
      this.mics = devs.map((d, i) => ({ id: d.deviceId, label: d.label || "Micro " + (i + 1) }));
    } catch {
      this.mics = [];
    }
    this.update();
    $("r-voice").value = app.settings.localVoice;
    $("r-mic").value = app.settings.micId;
  },
  update() {
    const app = this.app;
    const voices = app.voices?.items || [];
    const cur = voices.find((v) => v.id === app.settings.localVoice);
    const fr = app.models?.fr || {};
    const r = app.hw?.remote || {};
    this.view.set({
      dataDir: "Données de Nova : " + (app.config?.dataDir || "…"),
      aKey: app.config?.anthropicKey ? "(" + app.config.anthropicKey + ")" : "(aucune)",
      fastTxt: app.config?.fastEnabled === false ? "Nova répond avec le cerveau réfléchi seul." : app.config?.fastReady ? "La voix rapide répond tout de suite, le cerveau réfléchi prend le relais si besoin." : "La voix rapide a besoin d’une clé Anthropic : sans clé, le cerveau réfléchi répond seul.",
      fastCol: app.config?.fastEnabled !== false && !app.config?.fastReady ? "#F5B841" : "#8A9099",
      oKey: app.config?.openaiKey ? "(" + app.config.openaiKey + ")" : "",
      voiceOpts: voices.map((v) => `<option value="${esc(v.id)}">${esc(v.name || v.id)}${v.status === "ready" ? "" : " · à installer"}</option>`).join("") || '<option value="siwis">Siwis</option>',
      installLbl: cur?.status === "ready" ? "Voix installée" : cur?.status === "downloading" ? `Téléchargement ${Math.round(cur.progress ?? 0)} %` : "Installer la voix",
      micOpts: '<option value="">Micro par défaut</option>' + (this.mics || []).map((m) => `<option value="${esc(m.id)}">${esc(m.label)}</option>`).join(""),
      sttTxt: fr.status === "ready" ? "Reconnaissance vocale locale prête" : fr.status === "downloading" ? `Reconnaissance vocale : téléchargement ${Math.round(fr.progress ?? 0)} %` : "Reconnaissance vocale locale à télécharger (≈ 100 Mo)",
      needModel: fr.status !== "ready" && fr.status !== "downloading",
      micPct: Math.round((app.nova.micLevel || 0) * 100) + "%",
      remote: { idle: "Prêt", checking: "Vérifications…", ignition: "Contact mis", cranking: "Démarreur…", running: "Moteur tournant", failed: "Échec", stopped: "Arrêté" }[r.state || "idle"] + (r.message ? " · " + r.message : ""),
      hw: app.hw?.mode === "pi" ? "NovaHAT connectée" : "Pas de NovaHAT sur cet appareil : le démarrage à distance se fera depuis le Raspberry Pi",
      offLbl: this.offArmed ? "Touche encore pour éteindre" : "Éteindre",
      offBorder: this.offArmed ? "#F5B841" : "#4A5058",
      resetLbl: this.resetArmed?.() ? "Touche encore pour confirmer" : "Tout réapprendre",
    });
  },
};
