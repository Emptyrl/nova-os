// Réglages (dans le style des maquettes) : écran, réseau, téléphone, cerveau, voix, voiture,
// démarrage à distance, apprentissage.
import { View, esc } from "../bind.js";
import { keyboard } from "../keyboard.js";
import { saveSettings } from "../voice.js";

const panel = "padding:14px 16px;border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E;display:flex;flex-direction:column;gap:10px";
const row = "display:grid;grid-template-columns:1fr 1fr;gap:10px";

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:24px;right:24px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Réglages</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="dataDir"></span>
    </div>
    <button type="button" class="btn" data-on="click:close">Fermer</button>
  </div>
  <div class="scroll" style="position:absolute;left:20px;right:20px;top:76px;bottom:16px;display:grid;grid-template-columns:1fr 1fr;gap:12px;align-content:start">
    <div style="${panel}">
      <span class="lbl">Écran</span>
      <span class="lbl" style="font-size:9px">Affichage</span>
      <div class="seg" role="group" aria-label="Affichage">
        <button type="button" class="chip" data-on="click:fitFill" data-a="aria-pressed:fitFillOn">Plein écran</button>
        <button type="button" class="chip" data-on="click:fitFit" data-a="aria-pressed:fitFitOn">Proportions gardées</button>
      </div>
      <span class="lbl" style="font-size:9px">Taille</span>
      <div class="seg" role="group" aria-label="Taille" data-html="zoomBtns"></div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Résolution</span><select id="r-res" data-html="resOpts"></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Effets</span><select id="r-fx"><option value="auto">Auto</option><option value="full">Complets</option><option value="lite">Légers (plus fluide)</option></select></label>
      </div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Accélération graphique</span><select id="r-gpu"><option value="auto">Auto (conseillé)</option><option value="force">Forcée</option><option value="off">Désactivée (si plantages)</option></select></label>
        <div style="display:flex;align-items:flex-end"><button type="button" class="btn" data-on="click:relaunch" style="width:100%">Relancer l'écran</button></div>
      </div>
      <span class="note" data-t="gpuTxt" data-s="color:gpuCol"></span>
    </div>
    <div style="${panel}">
      <div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">Wi-Fi</span><span class="lbl" style="font-size:9px;letter-spacing:.06em" data-t="netState"></span></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn" data-on="click:netScan" data-t="scanLbl"></button>
        <button type="button" class="btn" data-on="click:netRadio" data-t="radioLbl" data-show="hasWifi"></button>
      </div>
      <div data-html="netList" style="display:flex;flex-direction:column;gap:6px"></div>
      <span class="note" data-t="netNote" data-s="color:netNoteCol"></span>
      <button type="button" class="btn" data-on="click:report" data-show="isLinux">Rapport matériel</button>
    </div>
    <div style="${panel};grid-column:1 / -1">
      <div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">Téléphone</span><span class="lbl" style="font-size:9px;letter-spacing:.06em" data-t="phoneState"></span></div>
      <div style="${row}">
        <div style="display:flex;flex-direction:column;gap:8px">
          <span class="lbl" style="font-size:9px">1 · Bluetooth : musique, appels</span>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="button" class="btn" data-on="click:btScan" data-t="btScanLbl"></button>
            <button type="button" class="btn" data-on="click:btPower" data-t="btPowerLbl" data-show="btPresent"></button>
          </div>
          <div data-html="btList" style="display:flex;flex-direction:column;gap:6px"></div>
          <span class="note" data-t="btNote"></span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <span class="lbl" style="font-size:9px">2 · KDE Connect : notifications, batterie</span>
          <button type="button" class="btn" data-on="click:kdeRefresh">Chercher le téléphone</button>
          <div data-html="kdeList" style="display:flex;flex-direction:column;gap:6px"></div>
          <span class="note" data-t="kdeNote"></span>
          <span class="lbl" style="font-size:9px;margin-top:4px">3 · Waze / Maps du téléphone</span>
          <span class="note" data-t="usbNote"></span>
        </div>
      </div>
    </div>
    <div style="${panel};grid-column:1 / -1">
      <div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">Mises à jour</span><span class="lbl" style="font-size:9px;letter-spacing:.06em" data-t="majVer"></span></div>
      <span style="font-size:14px;font-weight:600" data-t="majTxt" data-s="color:majCol"></span>
      <div data-show="majProg" style="height:6px;border-radius:3px;background:#2A2E34;overflow:hidden"><div style="height:100%;background:#4FD1E8" data-s="width:majPct"></div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn" data-on="click:majCheck" data-t="majCheckLbl"></button>
        <button type="button" class="btn-cyan" data-show="majReady" data-on="click:majInstall" data-t="majInstallLbl"></button>
        <button type="button" class="btn" data-on="click:majRepo">Dépôt GitHub</button>
        <button type="button" class="btn" data-on="click:majToken" data-t="majTokenLbl"></button>
      </div>
      <span class="note">Nova prend le <b>nova-auto.zip</b> de ton dépôt GitHub (celui que tu y déposes déjà), ou celui posé à la racine de la clé depuis Windows. Pas besoin de refaire l'image, sauf quand le système change. Dépôt privé : ajoute un jeton GitHub en lecture seule (Settings → Developer settings → Fine-grained tokens, accès « Contents : Read » à ce seul dépôt).</span>
    </div>
    <div style="${panel};grid-column:1 / -1">
      <div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">Journaux</span><span class="note" data-t="logsDir"></span></div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px" data-html="logsList"></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn" data-on="click:logsRefresh">Actualiser</button>
        <button type="button" class="btn" data-on="click:logsExport" data-t="exportLbl"></button>
        <button type="button" class="btn" data-on="click:logsClear" data-t="clearLbl"></button>
      </div>
      <span class="note" data-t="exportTxt"></span>
      <pre id="r-logtxt" data-show="hasLog" style="margin:0;height:300px;overflow:auto;font-size:10px;line-height:1.35;color:#C9CED4;white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,monospace;background:#0E1013;border:1px solid #33373E;border-radius:10px;padding:8px"></pre>
    </div>
    <div data-show="hasReport" style="${panel};grid-column:1 / -1">
      <div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">Rapport matériel</span><span class="note" data-t="reportFile"></span></div>
      <pre data-t="reportTxt" style="margin:0;max-height:260px;overflow:auto;font-size:10px;line-height:1.35;color:#C9CED4;white-space:pre-wrap;font-family:ui-monospace,monospace"></pre>
    </div>
    <div style="${panel}">
      <span class="lbl">Cerveau</span>
      <label class="field"><span class="lbl" style="font-size:9px">Clé Anthropic <span data-t="aKey"></span></span><input id="r-akey" type="password" autocomplete="off" placeholder="sk-ant-… (vide = inchangée)"></label>
      <label class="field"><span class="lbl" style="font-size:9px">Clé OpenAI, facultative <span data-t="oKey"></span></span><input id="r-okey" type="password" autocomplete="off" placeholder="voix naturelle, images, second avis"></label>
      <button type="button" class="btn" data-on="click:saveKeys">Enregistrer les clés</button>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Double cerveau</span><select id="r-fast"><option value="1">Activé (voix rapide)</option><option value="0">Désactivé</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Modèle rapide</span><input id="r-fastmodel" placeholder="claude-haiku-5-5"></label>
      </div>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none" data-t="fastTxt" data-s="color:fastCol"></span>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Sans clé, Nova utilise la connexion Claude Code du PC (commande claude puis /login).</span>
    </div>
    <div style="${panel}">
      <span class="lbl">Voix</span>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Voix de Nova</span><select id="r-engine"><option value="local">Locale (sans Internet)</option><option value="openai">OpenAI (naturelle)</option><option value="browser">Navigateur</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Voix locale</span><select id="r-voice" data-html="voiceOpts"></select></label>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn" data-on="click:install" data-t="installLbl"></button>
        <button type="button" class="btn" data-on="click:test">Tester</button>
      </div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Réveil « Nova »</span><select id="r-wake"><option value="1">Activé</option><option value="0">Désactivé</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Sensibilité</span><select id="r-sens"><option value="low">Faible</option><option value="normal">Normale</option><option value="high">Forte</option></select></label>
      </div>
      <label class="field"><span class="lbl" style="font-size:9px">Micro</span><select id="r-mic" data-html="micOpts"></select></label>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px"><span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none" data-t="sttTxt"></span><button type="button" class="btn" data-show="needModel" data-on="click:model">Télécharger</button></div>
      <div style="height:6px;border-radius:3px;background:#2A2E34;overflow:hidden"><div style="height:100%;background:#7BD88F;transition:width 80ms linear" data-s="width:micPct"></div></div>
    </div>
    <div style="${panel}">
      <span class="lbl">Voiture</span>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Source des données</span><select id="r-src"><option value="auto">Auto (câble détecté)</option><option value="kkl">Câble KKL (Nova lit le ME7.5)</option><option value="elm327">ELM327</option><option value="me7logger">ME7Logger (fichier CSV)</option><option value="can">CAN (NovaHAT)</option><option value="can+kkl">CAN + KKL</option><option value="can+elm327">CAN + ELM327</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Port série (vide = auto)</span><input id="r-port" placeholder="COM3 ou /dev/ttyUSB0"></label>
      </div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Carburant</span><select id="r-fuel"><option value="E85">E85</option><option value="SP98">SP98</option></select></label>
        <label class="field"><span class="lbl" style="font-size:9px">Dans le réservoir (L)</span><input id="r-tank" type="number" min="0" max="62" step="1" placeholder="après un plein : 62"></label>
      </div>
      <div style="${row}">
        <label class="field"><span class="lbl" style="font-size:9px">Compteur (km)</span><input id="r-odo" type="number" min="0" step="1"></label>
        <label class="field"><span class="lbl" style="font-size:9px">Dernière vidange (km)</span><input id="r-service" type="number" min="0" step="1"></label>
      </div>
      <button type="button" class="btn" data-on="click:saveCar">Enregistrer</button>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Changer de source : enregistre puis relance Nova.</span>
    </div>
    <div style="${panel}">
      <span class="lbl">Démarrage à distance</span>
      <span style="font-size:15px;font-weight:600" data-t="remote"></span>
      <div style="display:flex;gap:8px">
        <button type="button" class="btn" data-on="click:rStart">Démarrer</button>
        <button type="button" class="btn" data-on="click:rStop">Couper</button>
      </div>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Contact, vérification sur le CAN (moteur arrêté, roues immobiles), démarreur jusqu’à ce que le moteur tourne. Une roue qui bouge coupe tout.</span>
      <span class="lbl" style="font-size:9px" data-t="hw"></span>
    </div>
    <div style="${panel}">
      <span class="lbl">Nova OS</span>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Sur la clé Nova OS ou le Raspberry Pi : le menu donne accès au bureau Linux (maintenance), à un terminal, au redémarrage.</span>
      <span class="note" data-t="persistTxt" data-s="color:persistCol"></span>
      <button type="button" class="btn" data-show="persistOff" data-on="click:persist" data-t="persistLbl" style="border-color:#F5B841"></button>
      <div style="display:flex;gap:8px">
        <button type="button" class="btn" data-on="click:sysMenu">Menu Nova OS</button>
        <button type="button" class="btn" data-on="click:sysOff" data-t="offLbl" data-s="border-color:offBorder"></button>
      </div>
    </div>
    <div style="${panel}">
      <span class="lbl">Apprentissage</span>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Efface les rapports, la courbe moteur et la consommation apprises, pour tout remesurer.</span>
      <button type="button" class="btn" data-on="click:learnReset" data-t="resetLbl"></button>
    </div>
  </div>
</div>`;

export default {
  id: "reglages",
  html,
  mount(el, app) {
    this.app = app;
    this.el = el;
    const $ = (id) => el.querySelector("#" + id);
    this.$ = $;
    const setS = (patch) => {
      Object.assign(app.settings, patch);
      saveSettings(app.settings);
      app.voice.reconfigure();
    };
    $("r-fast").onchange = (e) => app.send({ type: "config.set", patch: { fastEnabled: e.target.value === "1" } });
    $("r-fastmodel").onchange = (e) => e.target.value.trim() && app.send({ type: "config.set", patch: { fastModel: e.target.value.trim() } });
    $("r-engine").onchange = (e) => setS({ ttsEngine: e.target.value });
    $("r-voice").onchange = (e) => setS({ localVoice: e.target.value });
    $("r-wake").onchange = (e) => setS({ wakeWord: e.target.value === "1" });
    $("r-sens").onchange = (e) => setS({ sensitivity: e.target.value });
    $("r-mic").onchange = (e) => setS({ micId: e.target.value });
    $("r-fx").onchange = (e) => app.setDisplay({ effects: e.target.value });
    $("r-gpu").onchange = (e) => {
      app.send({ type: "display.gpu", mode: e.target.value });
      app.toast("Accélération graphique : " + e.target.selectedOptions[0].textContent + ". Touche « Relancer l'écran ».");
    };
    $("r-res").onchange = (e) => app.send({ type: "display.set", mode: e.target.value });
    let resetArmed = false;
    this.view = new View(el, {
      relaunch: () => app.send({ type: "system.restartScreen" }),
      majCheck: () => app.send({ type: "maj.check" }),
      majInstall: () => {
        if (!this.majArmed) {
          this.majArmed = true;
          setTimeout(() => ((this.majArmed = false), this.update()), 5000);
          return this.update();
        }
        this.majArmed = false;
        app.send({ type: "maj.install" });
      },
      majRepo: () =>
        keyboard.open({
          title: "Dépôt GitHub (propriétaire/nom)",
          ok: "Enregistrer",
          value: app.config?.updateRepo || "Emptyrl/nova-os",
          onDone: (v) => v.trim() && app.send({ type: "config.set", patch: { updateRepo: v.trim() } }),
        }),
      majToken: () =>
        keyboard.open({
          title: "Jeton GitHub (lecture seule, vide = aucun)",
          ok: "Enregistrer",
          secret: true,
          onDone: (v) => app.send({ type: "config.set", patch: { githubToken: v.trim() } }),
        }),
      persist: () => {
        if (app.sys?.persist?.state !== "off") return;
        app.send({ type: "persist.enable" });
        app.toast("Création de la sauvegarde sur la clé : 3 à 6 minutes, ne débranche pas la clé.", 8000);
      },
      logsRefresh: () => {
        app.send({ type: "logs.list" });
        if (this.logName) app.send({ type: "logs.read", name: this.logName, lines: 400 });
      },
      logOpen: (b) => {
        this.logName = b.dataset.name;
        app.send({ type: "logs.read", name: this.logName, lines: 400 });
        this.update();
      },
      logsExport: () => {
        this.exporting = true;
        this.update();
        app.send({ type: "logs.export" });
      },
      logsClear: () => {
        if (!this.clearArmed) {
          this.clearArmed = true;
          setTimeout(() => ((this.clearArmed = false), this.update()), 4000);
          return this.update();
        }
        this.clearArmed = false;
        app.send({ type: "logs.clear" });
      },
      fitFill: () => (app.setDisplay({ fit: "remplir" }), this.update()),
      fitFit: () => (app.setDisplay({ fit: "ajuster" }), this.update()),
      zoom: (b) => (app.setDisplay({ zoom: Number(b.dataset.z) }), this.update()),
      netScan: () => app.send({ type: "net.scan" }),
      netRadio: () => app.send({ type: "net.radio", on: !app.sys?.wifi?.radio }),
      net: (b) => {
        const n = (app.sys?.networks || []).find((x) => x.ssid === b.dataset.ssid);
        if (!n || n.inUse) return;
        if (!n.secure || n.known) return app.send({ type: "net.connect", ssid: n.ssid, password: "" });
        keyboard.open({ title: "Mot de passe de « " + n.ssid + " »", secret: true, ok: "Connecter", onDone: (pw) => app.send({ type: "net.connect", ssid: n.ssid, password: pw }) });
      },
      netForget: (b) => app.send({ type: "net.forget", ssid: b.dataset.ssid }),
      report: () => {
        app.toast("Rapport en cours…");
        app.send({ type: "sys.report" });
      },
      btScan: () => app.send({ type: "bt.scan" }),
      btPower: () => app.send({ type: "bt.power", on: !app.sys?.bt?.powered }),
      bt: (b) => {
        const d = (app.sys?.bt?.devices || []).find((x) => x.mac === b.dataset.mac);
        if (!d) return;
        if (!d.paired) {
          app.toast("Association avec " + d.name + " : confirme le code sur le téléphone", 8000);
          return app.send({ type: "bt.pair", mac: d.mac });
        }
        app.send({ type: "bt.connect", mac: d.mac, on: !d.connected });
      },
      btRemove: (b) => app.send({ type: "bt.remove", mac: b.dataset.mac }),
      kdeRefresh: () => app.send({ type: "kde.refresh" }),
      kde: (b) => app.send({ type: "kde.pair", id: b.dataset.id }),
      close: () => app.go(app.prevScreen && app.prevScreen !== "reglages" ? app.prevScreen : "veille"),
      saveKeys: () => {
        const patch = {};
        if ($("r-akey").value.trim()) patch.anthropicApiKey = $("r-akey").value.trim();
        if ($("r-okey").value.trim()) patch.openaiApiKey = $("r-okey").value.trim();
        app.send({ type: "config.set", patch });
        $("r-akey").value = $("r-okey").value = "";
        app.toast("Clés enregistrées");
      },
      install: () => {
        const id = $("r-voice").value || app.settings.localVoice;
        app.send({ type: "voices.install", id });
        app.toast("Téléchargement de la voix…");
      },
      test: () => app.voice.say(`Bonjour ${app.driver}. Je suis Nova, prête à rouler.`),
      model: () => app.send({ type: "model.download", name: "fr" }),
      saveCar: () => {
        const car = { source: $("r-src").value, serialPort: $("r-port").value.trim(), fuelType: $("r-fuel").value };
        if ($("r-odo").value) car.odometerKm = Number($("r-odo").value);
        if ($("r-service").value) car.lastServiceKm = Number($("r-service").value);
        app.send({ type: "config.set", patch: {}, car });
        if ($("r-tank").value !== "") app.send({ type: "fuel.set", liters: Number($("r-tank").value) });
        app.toast("Réglages de la voiture enregistrés");
      },
      sysMenu: () => app.send({ type: "system.menu" }),
      sysOff: () => {
        if (!this.offArmed) {
          this.offArmed = true;
          setTimeout(() => ((this.offArmed = false), this.update()), 4000);
          return this.update();
        }
        app.send({ type: "system.poweroff" });
      },
      rStart: () => app.send({ type: "remote.start" }),
      rStop: () => app.send({ type: "remote.stop" }),
      learnReset: () => {
        if (!resetArmed) {
          resetArmed = true;
          this.update();
          setTimeout(() => {
            resetArmed = false;
            this.update();
          }, 4000);
          return;
        }
        resetArmed = false;
        app.send({ type: "learn.reset" });
        app.toast("Apprentissage remis à zéro");
      },
    });
    this.resetArmed = () => resetArmed;
  },
  async show() {
    const app = this.app;
    const c = app.config?.car || {};
    const $ = this.$;
    $("r-fx").value = app.display.effects || "auto";
    $("r-gpu").value = app.sys?.gpuMode || "auto";
    app.send({ type: "logs.list" });
    app.send({ type: "sys.get" });
    $("r-engine").value = app.settings.ttsEngine;
    $("r-fast").value = app.config?.fastEnabled === false ? "0" : "1";
    $("r-fastmodel").value = app.config?.fastModel || "";
    $("r-wake").value = app.settings.wakeWord ? "1" : "0";
    $("r-sens").value = app.settings.sensitivity;
    $("r-src").value = c.source || "auto";
    $("r-port").value = c.serialPort || "";
    $("r-fuel").value = c.fuelType || "E85";
    $("r-odo").value = c.odometerKm ?? "";
    $("r-service").value = c.lastServiceKm || "";
    $("r-tank").value = "";
    try {
      const devs = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "audioinput");
      this.mics = devs.map((d, i) => ({ id: d.deviceId, label: d.label || "Micro " + (i + 1) }));
    } catch {
      this.mics = [];
    }
    this.update();
    $("r-voice").value = app.settings.localVoice;
    $("r-mic").value = app.settings.micId;
    $("r-res").value = app.sys?.display?.saved ? app.sys.display.saved.split(" ")[1] : "auto";
  },
  showLog(name, text) {
    if (name !== this.logName) return;
    const pre = this.$("r-logtxt");
    const atBottom = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 20;
    if (pre.textContent !== text) {
      pre.textContent = text;
      if (atBottom || !this.logShown) pre.scrollTop = pre.scrollHeight;
    }
    this.logShown = true;
  },
  update() {
    const app = this.app;
    const voices = app.voices?.items || [];
    const cur = voices.find((v) => v.id === app.settings.localVoice);
    const fr = app.models?.fr || {};
    const r = app.hw?.remote || {};
    const sy = app.sys || { wifi: {}, bt: { devices: [] }, kde: { devices: [] }, display: { modes: [] }, battery: {}, tools: {}, networks: [] };
    const linux = sy.platform === "linux";
    const w = sy.wifi || {};
    const d = app.display;
    const bars = (sig) => (sig > 66 ? "▂▄▆" : sig > 33 ? "▂▄" : "▂");
    const netList = (sy.networks || []).map((n) => `<div style="display:flex;gap:6px"><button type="button" class="li" data-on="click:net" data-ssid="${esc(n.ssid)}" aria-current="${n.inUse}">
        <span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(n.ssid)}</span>
        <span class="sub">${n.inUse ? "connecté" : sy.connecting === n.ssid ? "connexion…" : n.known ? "connu" : n.secure ? "🔒" : "ouvert"}</span><span style="color:#4FD1E8;font-size:12px;width:30px;text-align:right">${bars(n.signal)}</span></button>
        ${n.known ? `<button type="button" class="chip" data-on="click:netForget" data-ssid="${esc(n.ssid)}" style="padding:0 10px;font-size:10px" aria-label="Oublier ${esc(n.ssid)}">Oublier</button>` : ""}</div>`).join("");
    const bt = sy.bt || { devices: [] };
    const btList = bt.devices.map((x) => `<div style="display:flex;gap:6px"><button type="button" class="li" data-on="click:bt" data-mac="${esc(x.mac)}" aria-current="${x.connected}">
        <span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${x.phone ? "📱 " : ""}${esc(x.name)}</span>
        <span class="sub">${bt.pairing === x.mac ? "association…" : x.connected ? "connecté" : x.paired ? "toucher pour connecter" : "toucher pour associer"}</span></button>
        ${x.paired ? `<button type="button" class="chip" data-on="click:btRemove" data-mac="${esc(x.mac)}" style="padding:0 10px;font-size:10px" aria-label="Oublier ${esc(x.name)}">Oublier</button>` : ""}</div>`).join("");
    const kde = sy.kde || { devices: [] };
    const kdeList = kde.devices.map((x) => `<button type="button" class="li" data-on="click:kde" data-id="${esc(x.id)}" aria-current="${x.paired && x.reachable}">
        <span style="flex:1">${esc(x.name)}</span><span class="sub">${x.paired ? (x.reachable ? "connecté" : "associé · hors de portée") : "toucher pour associer"}</span></button>`).join("");
    const modes = sy.display?.modes || [];
    const fmtSize = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + " Mo" : n > 1024 ? Math.round(n / 1024) + " ko" : n + " o");
    const fmtAt = (t) => (t ? new Date(t).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "vide");
    const logsList = (app.logs?.items || []).map((l) => `<button type="button" class="li" data-on="click:logOpen" data-name="${esc(l.name)}" aria-current="${this.logName === l.name}" style="flex-direction:column;align-items:flex-start;gap:2px;padding:6px 10px">
        <span style="font-size:13px">${esc(l.label)}</span><span class="sub">${esc(l.name)} · ${fmtSize(l.size)} · ${fmtAt(l.at)}</span></button>`).join("");
    const ex = app.logsExported;
    this.view.set({
      ...(() => {
        const mj = app.maj || {};
        const busy = mj.status === "checking" || mj.status === "downloading" || mj.status === "installing";
        return {
          majVer: `Version ${mj.current || "?"}${mj.repo ? " · " + mj.repo : ""}`,
          majTxt: mj.text || "Touche « Chercher une mise à jour ».",
          majCol: mj.status === "error" ? "#FF8A73" : mj.status === "ready" ? "#4FD1E8" : mj.status === "uptodate" ? "#7BD88F" : "#E9ECEF",
          majProg: mj.status === "downloading",
          majPct: (mj.progress ?? 0) + "%",
          majCheckLbl: busy ? "Recherche…" : "Chercher une mise à jour",
          majReady: mj.status === "ready",
          majInstallLbl: this.majArmed ? "Touche encore pour installer" : `Installer Nova ${mj.available || ""}`,
          majTokenLbl: mj.hasToken ? "Jeton GitHub ✓" : "Jeton GitHub",
        };
      })(),
      persistTxt: sy.persist?.detail || "",
      persistCol: sy.persist?.state === "off" ? "#F5B841" : sy.persist?.state === "on" ? "#7BD88F" : "#8A9099",
      persistOff: sy.persist?.state === "off" || sy.persist?.state === "creating",
      persistLbl: sy.persist?.state === "creating" ? "Création en cours…" : "Activer la sauvegarde des réglages",
      logsDir: app.logs?.dir ? "Dossier : " + app.logs.dir : "",
      logsList,
      hasLog: !!this.logName,
      exportLbl: this.exporting ? "Export…" : "Exporter le rapport complet",
      clearLbl: this.clearArmed ? "Touche encore pour effacer" : "Effacer les journaux",
      exportTxt: ex ? (ex.copied?.length ? "Rapport copié sur : " + ex.copied.join(", ") + ". Sous Windows, ouvre la clé : dossier « nova-journaux »." : "Rapport enregistré dans " + ex.file + " (aucune clé USB lisible sous Windows trouvée).") : "Le rapport complet rassemble tous les journaux et le matériel : envoie-le-moi pour que je corrige.",
      fitFillOn: String(d.fit === "remplir"),
      fitFitOn: String(d.fit !== "remplir"),
      zoomBtns: [100, 95, 90, 85, 80].map((z) => `<button type="button" class="chip" data-on="click:zoom" data-z="${z}" aria-pressed="${(d.zoom || 100) === z}" style="padding:0 12px">${z} %</button>`).join(""),
      resOpts: `<option value="auto">Auto${sy.display?.current ? " (" + esc(sy.display.current) + ")" : ""}</option>` + modes.map((m) => `<option value="${esc(m)}">${esc(m)}</option>`).join(""),
      gpuTxt: app.lite ? "Effets allégés : " + (/swiftshader|llvmpipe|softpipe|software/i.test(app.gpu || "") ? "pas d'accélération graphique (rendu " + ((app.gpu || "").match(/swiftshader|llvmpipe|softpipe/i)?.[0] || "logiciel") + ")." + (Number((sy.display?.current || "0x0").split("x")[0]) > 1366 ? " Baisse la résolution à 1280×720 : 2 à 3 fois plus fluide." : "") + " Envoie-moi le rapport complet (Journaux)." : "images trop lentes, Nova s'est allégée.") : "Carte graphique : " + (app.gpu || "?").replace(/^ANGLE \((.*)\)$/, "$1").slice(0, 90),
      gpuCol: app.lite ? "#F5B841" : "#8A9099",
      netState: sy.ethernet ? "Câble réseau" : w.ssid ? w.ssid + (w.signal != null ? " · " + w.signal + " %" : "") : sy.online ? "En ligne" : "Hors ligne",
      hasWifi: !!w.hardware,
      isLinux: linux,
      scanLbl: sy.scanning ? "Recherche…" : "Chercher les réseaux",
      radioLbl: w.radio ? "Couper le Wi-Fi" : "Allumer le Wi-Fi",
      netList: netList || (sy.scanning ? "" : `<span class="note">${w.hardware ? "Touche « Chercher les réseaux », puis le réseau du téléphone (partage de connexion)." : ""}</span>`),
      netNote: !linux ? "Sous Windows, le Wi-Fi se règle dans Windows." : !sy.tools?.nmcli ? "NetworkManager absent sur ce système." : !w.hardware && !sy.ethernet ? "Aucune carte Wi-Fi reconnue : il lui manque sûrement un pilote. Touche « Rapport matériel » et envoie-le-moi, je l'ajouterai à Nova OS." : "",
      netNoteCol: linux && sy.tools?.nmcli && !w.hardware && !sy.ethernet ? "#F5B841" : "#8A9099",
      phoneState: app.phone?.name ? app.phone.name + (app.phone.battery != null ? " · " + app.phone.battery + " %" : "") : bt.devices.some((x) => x.connected) ? "Bluetooth connecté" : "Non connecté",
      btPresent: !!bt.present,
      btScanLbl: bt.scanning ? "Recherche… (Nova est visible)" : "Ajouter un téléphone",
      btPowerLbl: bt.powered ? "Couper le Bluetooth" : "Allumer le Bluetooth",
      btList,
      btNote: !linux ? "Sous Windows, associe le téléphone dans les paramètres Bluetooth de Windows." : !sy.tools?.bluetoothctl ? "BlueZ absent : mets à jour Nova OS." : !bt.present ? "Aucun adaptateur Bluetooth détecté (rapport matériel)." : "Touche « Ajouter », puis sur le téléphone : Bluetooth → « Nova » (ou touche le téléphone dans la liste). Confirme le code des deux côtés.",
      kdeList,
      kdeNote: !kde.available ? "KDE Connect absent : mets à jour Nova OS." : "Installe « KDE Connect » sur le téléphone (Play Store). Le PC et le téléphone doivent être sur le même Wi-Fi : connecte Nova au partage de connexion du téléphone, puis « Chercher ».",
      usbNote: !sy.tools?.scrcpy ? "scrcpy absent : mets à jour Nova OS." : "Branche le téléphone en USB, active le « Débogage USB » (Options pour les développeurs) et accepte la demande. Ensuite, écran Média → Waze ou Maps.",
      hasReport: !!app.sysReport,
      reportFile: app.sysReport ? "Enregistré : " + app.sysReport.file : "",
      reportTxt: app.sysReport?.text || "",
      dataDir: "Données de Nova : " + (app.config?.dataDir || "…"),
      aKey: app.config?.anthropicKey ? "(" + app.config.anthropicKey + ")" : "(aucune)",
      fastTxt: app.config?.fastEnabled === false ? "Nova répond avec le cerveau réfléchi seul." : app.config?.fastReady ? "La voix rapide répond tout de suite, le cerveau réfléchi prend le relais si besoin." : "La voix rapide a besoin d’une clé Anthropic : sans clé, le cerveau réfléchi répond seul.",
      fastCol: app.config?.fastEnabled !== false && !app.config?.fastReady ? "#F5B841" : "#8A9099",
      oKey: app.config?.openaiKey ? "(" + app.config.openaiKey + ")" : "",
      voiceOpts: voices.map((v) => `<option value="${esc(v.id)}">${esc(v.name || v.id)}${v.status === "ready" ? "" : " · à installer"}</option>`).join("") || '<option value="siwis">Siwis</option>',
      installLbl: cur?.status === "ready" ? "Voix installée" : cur?.status === "downloading" ? `Téléchargement ${Math.round(cur.progress ?? 0)} %` : "Installer la voix",
      micOpts: '<option value="">Micro par défaut</option>' + (this.mics || []).map((m) => `<option value="${esc(m.id)}">${esc(m.label)}</option>`).join(""),
      sttTxt: fr.status === "ready" ? "Reconnaissance vocale locale prête" : fr.status === "downloading" ? `Reconnaissance vocale : téléchargement ${Math.round(fr.progress ?? 0)} %` : "Reconnaissance vocale locale à télécharger (≈ 100 Mo)",
      needModel: fr.status !== "ready" && fr.status !== "downloading",
      micPct: Math.round((app.nova.micLevel || 0) * 100) + "%",
      remote: { idle: "Prêt", checking: "Vérifications…", ignition: "Contact mis", cranking: "Démarreur…", running: "Moteur tournant", failed: "Échec", stopped: "Arrêté" }[r.state || "idle"] + (r.message ? " · " + r.message : ""),
      hw: app.hw?.mode === "pi" ? "NovaHAT connectée" : "Pas de NovaHAT sur cet appareil : le démarrage à distance se fera depuis le Raspberry Pi",
      offLbl: this.offArmed ? "Touche encore pour éteindre" : "Éteindre",
      offBorder: this.offArmed ? "#F5B841" : "#4A5058",
      resetLbl: this.resetArmed?.() ? "Touche encore pour confirmer" : "Tout réapprendre",
    });
  },
};
