// Lecture multiple : plusieurs calculateurs lus à tour de rôle par la ligne K (moteur, ABS, combiné…),
// chacun dans sa carte, en grand.
import { View, esc, navHtml } from "../bind.js";
import { multi, diagTabs } from "../multi.js";

const pad3 = (n) => String(n).padStart(3, "0");
const hex = (a) => a.toString(16).toUpperCase().padStart(2, "0");
const panel = "border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E";

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em;white-space:nowrap">Lecture multiple</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="sub"></span>
    </div>
    ${diagTabs("multi")}
  </div>

  <div style="position:absolute;left:20px;top:76px;width:260px;height:430px;${panel};padding:14px;box-sizing:border-box;display:flex;flex-direction:column;gap:10px">
    <button type="button" class="btn-cyan" style="min-height:48px;font-size:13px" data-on="click:run" data-t="runLbl" data-s="border-color:runBorder"></button>
    <span style="font-size:12px;font-weight:600;line-height:1.35" data-t="state" data-s="color:stateCol"></span>
    <span class="lbl" style="font-size:9px;margin-top:4px">Ajouter un groupe</span>
    <div class="field"><select id="mu-mod" data-html="modOpts" style="min-height:36px;font-size:13px"></select></div>
    <div style="display:flex;align-items:center;gap:8px">
      <button type="button" class="ib" data-on="click:gMinus" aria-label="Groupe précédent" style="min-width:42px;height:42px;font-size:20px">−</button>
      <span class="num" style="font-size:24px;flex:1;text-align:center" data-t="gNum"></span>
      <button type="button" class="ib" data-on="click:gPlus" aria-label="Groupe suivant" style="min-width:42px;height:42px;font-size:20px">+</button>
    </div>
    <span style="font-size:11px;color:#9FB4C8;min-height:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" data-t="gTitle"></span>
    <button type="button" class="btn" style="font-size:12px" data-on="click:add" data-t="addLbl"></button>
    <div style="flex:1"></div>
    <button type="button" class="btn" style="font-size:11px" data-on="click:clear" data-t="clearLbl"></button>
    <span style="font-size:10px;line-height:1.4;color:#8A9099">La prise OBD ne parle qu'à un calculateur à la fois : Nova reste ~3 s sur chacun puis passe au suivant. Les valeurs vont aussi au tableau de bord. 8 groupes au plus.</span>
  </div>

  <div class="scroll" data-html="cards" style="position:absolute;left:294px;right:20px;top:76px;height:430px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;align-content:start"></div>

  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("diagnostic")}
    <span class="lbl" style="font-size:9px;letter-spacing:.06em;text-align:right">Câble KKL · contact mis</span>
  </div>
</div>`;

export default {
  id: "multi",
  html,
  mount(el, app) {
    this.app = app;
    this.el = el;
    this.addr = 0x01;
    this.group = 1;
    this.clearArmed = false;
    this.view = new View(el, {
      run: () => {
        if (!multi.run(app)) app.toast("Ajoute d'abord des groupes (à gauche, ou « + Multi » dans Calculateurs → Mesures)");
      },
      gMinus: () => ((this.group = this.group <= 1 ? 255 : this.group - 1), this.update()),
      gPlus: () => ((this.group = this.group >= 255 ? 1 : this.group + 1), this.update()),
      add: () => (multi.toggle(app, this.addr, this.group), this.update()),
      del: (b) => (multi.remove(app, Number(b.dataset.i)), this.update()),
      clear: () => {
        if (!this.clearArmed) {
          this.clearArmed = true;
          setTimeout(() => ((this.clearArmed = false), this.update()), 4000);
          return this.update();
        }
        this.clearArmed = false;
        multi.clear(app);
        this.update();
      },
    });
    el.querySelector("#mu-mod").onchange = (e) => {
      this.addr = Number(e.target.value) || 0x01;
      this.update();
    };
  },
  show() {
    this.visible = true;
  },
  hide() {
    this.visible = false;
  },
  update() {
    const app = this.app;
    const V = app.vag || { modules: [] };
    const mods = V.modules || [];
    const known = mods.filter((m) => m.status === "ok" || m.status === "defauts" || m.addr === this.addr);
    const list = known.length ? known : mods;
    const modOpts = list.map((m) => `<option value="${m.addr}"${m.addr === this.addr ? " selected" : ""}>${m.hex} · ${esc(m.short || m.name)}</option>`).join("") || `<option value="1">01 · Moteur</option>`;
    const m = mods.find((x) => x.addr === this.addr);
    const title = m?.groups?.[this.group]?.title || m?.catalog?.measuring?.find((x) => x.grp === this.group)?.title || "";
    const cards = multi.items.length
      ? multi.items
          .map((it, i) => {
            const mm = mods.find((x) => x.addr === it.addr);
            const gg = mm?.groups?.[it.group];
            const age = gg ? (Date.now() - gg.at) / 1000 : null;
            const on = V.multi && V.multi.current === it.addr;
            const vals = gg
              ? gg.fields
                  .map((f) => {
                    const col = f.inSpec === false ? "#FF4D2E" : f.inSpec === true ? "#7BD88F" : "#F1F3F5";
                    return `<span style="display:flex;justify-content:space-between;align-items:baseline;gap:8px"><span style="font-size:12px;color:#C9CED4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.label)}</span><span class="num" style="flex:none;font-size:18px;color:${col}">${esc(f.text)} <span style="color:#9AA1AA;font-size:10px">${esc(f.unit === "bits" ? "" : f.unit)}</span></span></span>`;
                  })
                  .join("")
              : `<span style="font-size:12px;color:#8A9099">Pas encore lu</span>`;
            return `<div style="display:flex;flex-direction:column;gap:5px;padding:10px 12px;border-radius:12px;background:rgba(20,22,26,.8);border:1px solid ${on ? "rgba(79,209,232,.7)" : "#33373E"}">
              <span style="display:flex;align-items:center;justify-content:space-between;gap:8px"><span style="font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${hex(it.addr)} · ${esc(mm?.short || "")} · ${pad3(it.group)}</span>
              <span style="display:flex;align-items:center;gap:6px;flex:none"><span class="lbl" style="font-size:9px">${on ? "● " : ""}${age == null ? "" : age < 1 ? "à l'instant" : Math.round(age) + " s"}</span><button type="button" class="ib" data-on="click:del" data-i="${i}" aria-label="Retirer" style="min-width:30px;height:26px;font-size:14px">×</button></span></span>${vals}</div>`;
          })
          .join("")
      : `<div style="grid-column:1 / -1;${panel};padding:18px;font-size:14px;line-height:1.5;color:#B9BFC7">Aucun groupe. À gauche, choisis un calculateur et un groupe puis « Ajouter » ; recommence pour l'ABS, le combiné, le Haldex… Puis « Démarrer ». Les calculateurs apparaissent dans la liste une fois connectés ou scannés dans Calculateurs.</div>`;
    this.view.set({
      sub: `${multi.items.length} groupe${multi.items.length > 1 ? "s" : ""}${V.port ? " · câble " + V.port : ""}`,
      runLbl: V.multi ? "Arrêter" : "Démarrer la lecture",
      runBorder: V.multi ? "#F5B841" : "#4FD1E8",
      state: V.multi ? (V.multi.error ? "Erreur : " + V.multi.error : `En cours${V.multi.current ? " · sur " + hex(V.multi.current) : ""}${V.multi.cycleMs ? ` · un tour en ${(V.multi.cycleMs / 1000).toFixed(1)} s` : ""}`) : multi.items.length ? "Arrêtée" : "",
      stateCol: V.multi?.error ? "#FF8A73" : V.multi ? "#4FD1E8" : "#8A9099",
      modOpts,
      gNum: pad3(this.group),
      gTitle: title,
      addLbl: multi.has(this.addr, this.group) ? `Retirer ${hex(this.addr)} · ${pad3(this.group)}` : `Ajouter ${hex(this.addr)} · ${pad3(this.group)}`,
      clearLbl: this.clearArmed ? "Touche encore pour tout vider" : "Vider la liste",
      cards,
    });
  },
};
