// Apprentissage (maquette « Apprentissage ») : rapports, courbe moteur, consommation, log en direct.
import { View, esc, fr, thousands, interp, REF_TQ, navHtml } from "../bind.js";

const F = 'font-family="Chakra Petch, system-ui, sans-serif"';
const X = (r) => 40 + ((r - 1500) / 5500) * 344;
const Y = (t) => 300 - ((t - 100) / 220) * 250;
const REFPTS = [];
for (let r = 1500; r <= 7000; r += 100) REFPTS.push(X(r).toFixed(1) + "," + Y(interp(REF_TQ, r)).toFixed(1));

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:24px;right:24px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Apprentissage</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em">Nova apprend comment ta voiture marche</span>
    </div>
    <div style="display:flex;align-items:center;gap:10px;padding:8px 14px;border-radius:18px;background:rgba(10,11,13,.7);border:1px solid" data-s="border-color:recBorder">
      <span style="width:10px;height:10px;border-radius:50%" data-a="class:recCls" data-s="background:recDot"></span>
      <span class="lbl" style="color:#F1F3F5" data-t="recTxt"></span>
      <span class="num" style="font-size:13px;color:#B9BFC7" data-t="clock"></span>
    </div>
  </div>
  <div style="position:absolute;left:20px;top:80px;width:290px;display:flex;flex-direction:column;gap:8px">
    <span class="lbl">Programme</span>
    <div style="padding:10px 12px;border-radius:12px;background:rgba(20,22,26,.75);border:1px solid #33373E;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;justify-content:space-between;align-items:baseline"><span style="font-size:14px;font-weight:600">1 · Rapports de boîte</span><span class="lbl" style="font-size:9px;color:#7BD88F"><span data-t="gearsDone"></span> / 6</span></div>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Roule normalement, je mesure chaque rapport</span>
      <div style="display:grid;grid-template-columns:repeat(6, minmax(0, 1fr));gap:5px" data-html="gears"></div>
    </div>
    <div style="padding:10px 12px;border-radius:12px;display:flex;flex-direction:column;gap:6px;border:1px solid" data-s="background:pullBg;border-color:pullBorder">
      <div style="display:flex;justify-content:space-between;align-items:baseline"><span style="font-size:14px;font-weight:600">2 · Courbe du moteur</span><span class="lbl" style="font-size:9px" data-s="color:pullInk"><span data-t="pulls"></span> / 2 tirages</span></div>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Pied au plancher en 3e, de 2 000 tr/min au rupteur. Sur circuit ou route fermée.</span>
      <div style="height:5px;border-radius:3px;background:#2A2E34;overflow:hidden"><div style="height:100%;background:#4FD1E8;transition:width 120ms linear" data-s="width:pullPct"></div></div>
    </div>
    <div style="padding:10px 12px;border-radius:12px;background:rgba(20,22,26,.75);border:1px solid #33373E;display:flex;flex-direction:column;gap:6px">
      <div style="display:flex;justify-content:space-between;align-items:baseline"><span style="font-size:14px;font-weight:600">3 · Consommation</span><span class="lbl" style="font-size:9px"><span data-t="kmTxt"></span> / 300 km</span></div>
      <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">Trajets de tous les jours, pour trouver les régimes les plus sobres</span>
      <div style="height:5px;border-radius:3px;background:#2A2E34;overflow:hidden"><div style="height:100%;background:#7BD88F" data-s="width:kmPct"></div></div>
    </div>
  </div>
  <div style="position:absolute;left:324px;top:80px;width:400px;height:350px;border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E">
    <div style="position:absolute;left:14px;top:10px;right:14px;display:flex;justify-content:space-between"><span class="lbl">Couple mesuré</span><span class="lbl" style="font-size:9px;letter-spacing:.06em"><span data-t="ptsCount"></span> points</span></div>
    <svg width="400" height="350" viewBox="0 0 400 350" role="img" aria-label="Courbe de couple mesurée en fonction du régime">
      ${[2000, 3000, 4000, 5000, 6000, 7000].map((r) => `<line x1="${X(r).toFixed(1)}" y1="40" x2="${X(r).toFixed(1)}" y2="300" stroke="#2A2E34" stroke-width="1"></line><text x="${X(r).toFixed(1)}" y="318" fill="#9AA1AA" font-size="10" font-weight="600" text-anchor="middle" ${F}>${r / 1000}</text>`).join("")}
      ${[150, 200, 250, 300].map((t) => `<line x1="40" y1="${Y(t).toFixed(1)}" x2="384" y2="${Y(t).toFixed(1)}" stroke="#2A2E34" stroke-width="1"></line><text x="34" y="${Y(t).toFixed(1)}" fill="#9AA1AA" font-size="10" font-weight="600" text-anchor="end" dominant-baseline="central" ${F}>${t}</text>`).join("")}
      <line x1="40" y1="300" x2="384" y2="300" stroke="#5A616B" stroke-width="1.5"></line>
      <text x="384" y="338" fill="#7E858F" font-size="9" font-weight="600" letter-spacing="1.5" text-anchor="end" ${F}>×1000 TR/MIN</text>
      <text x="40" y="34" fill="#7E858F" font-size="9" font-weight="600" letter-spacing="1.5" ${F}>NM</text>
      <polyline points="${REFPTS.join(" ")}" fill="none" stroke="#6B727C" stroke-width="1.5" stroke-dasharray="5 5"></polyline>
      <g data-html="dots"></g>
      <polyline fill="none" stroke="#4FD1E8" stroke-width="2.5" stroke-linejoin="round" data-a="points:fit"></polyline>
    </svg>
    <div style="position:absolute;left:14px;bottom:10px;display:flex;gap:14px" class="lbl">
      <span style="font-size:9px;letter-spacing:.06em;display:flex;align-items:center;gap:6px"><span style="width:16px;height:2px;background:#4FD1E8"></span>Ta voiture</span>
      <span style="font-size:9px;letter-spacing:.06em;display:flex;align-items:center;gap:6px"><span style="width:16px;height:0;border-top:2px dashed #6B727C"></span>Référence 225</span>
    </div>
  </div>
  <div style="position:absolute;left:738px;right:20px;top:80px;height:350px;display:flex;flex-direction:column;gap:6px">
    <span class="lbl">Log en direct</span>
    <div data-html="live" style="display:flex;flex-direction:column;gap:6px"></div>
    <span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#6B727C;margin-top:auto" data-t="file"></span>
  </div>
  <div style="position:absolute;left:20px;right:20px;top:446px;display:flex;gap:14px;align-items:center;padding:12px 16px;border-radius:14px;background:rgba(10,11,13,.75);border:1px solid" data-s="border-color:sayBorder">
    <img src="logo.png" alt="Nova" style="flex:none;width:62px;height:35px;object-fit:contain">
    <p style="margin:0;font-size:16px;line-height:1.4;color:#F1F3F5" data-t="say"></p>
  </div>
  <div style="position:absolute;left:20px;right:24px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("apprentissage")}
    <div style="display:flex;gap:8px">
      <button type="button" class="btn" style="font-size:11px;padding:0 12px" data-on="click:rec" data-t="recBtn"></button>
      <button type="button" class="btn" style="font-size:11px;padding:0 12px" data-on="click:passages" data-s="border-color:doneBorder;color:doneInk">Voir les passages</button>
    </div>
  </div>
</div>`;

export default {
  id: "apprentissage",
  html,
  mount(el, app) {
    this.app = app;
    this.view = new View(el, {
      rec: () => {
        const r = app.car.rec;
        if (r?.on) app.send({ type: "log.stop" });
        else app.send({ type: "log.start", reason: "apprentissage", hz: 20 });
      },
      passages: () => app.go("rapports"),
    });
  },
  update() {
    const app = this.app;
    const L = app.learn || { gears: [], dots: [], fit: [], pulls: 0, consoKm: 0, say: "" };
    const v = app.car.v || {};
    const rec = app.car.rec || {};
    const gears = (L.gears || []).map((g) => {
      const ok = g.k != null;
      const p = Math.round((g.progress || 0) * 100);
      return `<div style="display:flex;flex-direction:column;align-items:center;gap:1px;padding:5px 0;border-radius:8px;border:1px solid ${ok ? "rgba(123,216,143,.6)" : "#33373E"};background:${ok ? "rgba(123,216,143,.1)" : `linear-gradient(to top, rgba(79,209,232,.12) ${p}%, transparent ${p}%)`}">
        <span class="num" style="font-size:14px;color:${ok ? "#F1F3F5" : "#6B727C"}">${g.n}</span><span style="font-size:9px;color:#9AA1AA;font-variant-numeric:tabular-nums">${ok ? fr(g.k, 1) : "—"}</span></div>`;
    }).join("");
    const dots = (L.dots || []).map(([r, t, p]) => `<circle cx="${X(r).toFixed(1)}" cy="${Y(t).toFixed(1)}" r="2.6" fill="${p % 2 === 0 ? "rgba(230,234,238,.55)" : "rgba(79,209,232,.75)"}"></circle>`).join("");
    const fit = (L.fit || []).filter(([r]) => r >= 1500).map(([r, t]) => X(r).toFixed(1) + "," + Y(t).toFixed(1)).join(" ");
    const inPull = L.pullActive;
    const sec = rec.on ? Math.floor((Date.now() - rec.since) / 1000) : 0;
    const b = (x) => (x == null ? "—" : (x >= 0 ? "+" : "−") + fr(Math.abs(x), 2) + " bar");
    const kn = [v.knock1, v.knock2, v.knock3, v.knock4];
    const live = [
      ["Régime", v.rpm == null ? "—" : thousands(Math.round(v.rpm / 10) * 10) + " tr/min"],
      ["Rapport", v.gear ? String(v.gear) : "N"],
      ["Charge", v.load == null ? "—" : Math.round(v.load) + " %"],
      ["Turbo réel", b(v.boost)],
      ["Turbo demandé", b(v.boostReq)],
      ["Débit d’air", v.maf == null ? "—" : fr(v.maf, 1) + " g/s"],
      ["Avance", v.timing == null ? "—" : fr(v.timing, 1) + "°"],
      ["Recul (cyl. 1-4)", kn.every((x) => x == null) ? "—" : kn.map((x) => fr(x ?? 0, 0)).join(" · ")],
      ["Richesse (λ)", v.lambda == null ? "—" : fr(v.lambda, 2)],
    ].map(([n, val]) => `<div style="display:flex;justify-content:space-between;align-items:baseline;padding:5px 10px;border-radius:8px;background:rgba(20,22,26,.7);border:1px solid #2E3238"><span style="font-size:12px;color:#C9CED4">${n}</span><span class="num" style="font-size:13px">${esc(val)}</span></div>`).join("");
    const done = L.phase === "done";
    this.view.set({
      recBorder: rec.on ? "#4A2620" : "#33373E",
      recCls: rec.on ? "rec" : "",
      recDot: rec.on ? "#FF4D2E" : "#4A5058",
      recTxt: rec.on ? `Enregistrement` : "Pas d'enregistrement",
      clock: rec.on ? String(Math.floor(sec / 60)).padStart(2, "0") + ":" + String(sec % 60).padStart(2, "0") : "",
      gears, gearsDone: L.gearsDone ?? 0,
      pulls: L.pulls ?? 0,
      pullPct: ((L.pullProgress || 0) * 100).toFixed(0) + "%",
      pullBg: inPull ? "rgba(79,209,232,.1)" : "rgba(20,22,26,.75)",
      pullBorder: inPull ? "rgba(79,209,232,.6)" : "#33373E",
      pullInk: (L.pulls ?? 0) >= 2 ? "#7BD88F" : "#9AA1AA",
      kmTxt: Math.floor(L.consoKm || 0), kmPct: Math.min(100, (L.consoKm || 0) / 3).toFixed(0) + "%",
      dots, fit, ptsCount: (L.dots || []).length,
      live,
      file: rec.on ? `${rec.file} · ${fr((rec.kb || 0) / 1024, 1)} Mo` : "Les logs démarrent tout seuls quand le moteur tourne",
      say: L.say || "",
      sayBorder: done ? "rgba(123,216,143,.6)" : inPull ? "rgba(79,209,232,.6)" : "#33373E",
      recBtn: rec.on ? "Arrêter le log" : "Log 20 Hz",
      doneBorder: done ? "#7BD88F" : "#4A5058", doneInk: done ? "#FFFFFF" : "#D6DBE1",
    });
  },
};
