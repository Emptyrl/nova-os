// Calculateurs (diagnostic complet par câble KKL, comme VCDS) dans la DA de Nova :
// liste des calculateurs, identification, codes défaut, groupes de mesure, lecture complète, test de connexion.
import { View, esc, navHtml } from "../bind.js";

const COL = { ok: "#7BD88F", defauts: "#F5B841", erreur: "#FF4D2E", absent: "#4A5058", inconnu: "#4A5058" };
const STATUS = { ok: "OK", defauts: "défauts", erreur: "erreur", absent: "absent", inconnu: "non testé" };
const pad3 = (n) => String(n).padStart(3, "0");
const panel = "border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E";

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Calculateurs</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="sub"></span>
    </div>
    <div style="display:flex;gap:8px" role="group" aria-label="Diagnostic">
      <button type="button" class="tab" data-go="diagnostic" style="border-color:#4A5058">Test moteur</button>
      <button type="button" class="tab" aria-current="page">Calculateurs</button>
    </div>
  </div>

  <div style="position:absolute;left:20px;top:76px;width:250px;height:430px;display:flex;flex-direction:column;gap:6px">
    <div class="scroll" data-html="mods" style="flex:1;display:flex;flex-direction:column;gap:5px;padding-right:2px"></div>
    <span data-show="scanning" style="font-size:11px;font-weight:600;color:#4FD1E8;line-height:1.3" data-t="scanTxt"></span>
    <button type="button" class="btn-cyan" data-on="click:scan" data-t="scanLbl" data-s="border-color:scanBorder" style="min-height:44px;font-size:12px"></button>
  </div>

  <div style="position:absolute;left:284px;top:76px;width:474px;height:430px;${panel};display:flex;flex-direction:column;padding:14px 16px;box-sizing:border-box;gap:10px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">
      <div style="display:flex;flex-direction:column;gap:2px;min-width:0">
        <span style="font-size:18px;font-weight:700" data-t="mName"></span>
        <span class="lbl" style="font-size:10px;letter-spacing:.06em" data-t="mSub"></span>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none;max-width:230px">
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:open" data-t="openLbl" data-s="border-color:openBorder"></button>
        <span style="font-size:10px;font-weight:600;line-height:1.3;text-align:right" data-t="opTxt" data-s="color:opCol"></span>
      </div>
    </div>
    <div data-show="showIdent" data-html="ident" style="display:grid;grid-template-columns:110px 1fr;gap:3px 10px;font-size:13px"></div>
    <div style="display:flex;gap:4px">
      <button type="button" class="tab" data-on="click:tab" data-v="defauts" data-a="aria-current:tDef" style="min-height:36px;font-size:10px;padding:0 9px;white-space:nowrap;letter-spacing:.06em" data-t="defLbl"></button>
      <button type="button" class="tab" data-on="click:tab" data-v="mesures" data-a="aria-current:tMes" style="min-height:36px;font-size:10px;padding:0 9px;white-space:nowrap;letter-spacing:.06em">Mesures</button>
      <button type="button" class="tab" data-on="click:tab" data-v="base" data-a="aria-current:tBas" style="min-height:36px;font-size:10px;padding:0 9px;white-space:nowrap;letter-spacing:.06em">Rég. base</button>
      <button type="button" class="tab" data-on="click:tab" data-v="actionneurs" data-a="aria-current:tAct" style="min-height:36px;font-size:10px;padding:0 9px;white-space:nowrap;letter-spacing:.06em">Actionneurs</button>
      <button type="button" class="tab" data-on="click:tab" data-v="infos" data-a="aria-current:tInf" style="min-height:36px;font-size:10px;padding:0 9px;white-space:nowrap;letter-spacing:.06em">Infos</button>
      <button type="button" class="tab" data-on="click:tab" data-v="tout" data-a="aria-current:tAll" style="min-height:36px;font-size:10px;padding:0 9px;white-space:nowrap;letter-spacing:.06em">Tout</button>
    </div>

    <div data-show="isDef" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div class="scroll" data-html="faults" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:faults">Relire</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:clear" data-t="clearLbl" data-s="border-color:clearBorder"></button>
      </div>
    </div>

    <div data-show="isMes" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;gap:8px">
        <button type="button" class="ib" data-on="click:gMinus" aria-label="Groupe précédent" style="min-width:44px;height:44px;font-size:20px">−</button>
        <span class="num" style="font-size:26px;min-width:64px;text-align:center" data-t="gNum"></span>
        <button type="button" class="ib" data-on="click:gPlus" aria-label="Groupe suivant" style="min-width:44px;height:44px;font-size:20px">+</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:gRead">Lire</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:gLive" data-t="liveLbl" data-s="border-color:liveBorder"></button>
      </div>
      <div data-show="hasMesList" class="field"><select id="c-mes" data-html="mesOpts" style="min-height:34px;font-size:13px"></select></div>
      <span class="lbl" style="font-size:10px;letter-spacing:.04em;text-transform:none;color:#C9CED4" data-t="gTitle"></span>
      <div class="scroll" data-html="fields" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isBas" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;gap:8px">
        <button type="button" class="ib" data-on="click:bMinus" aria-label="Groupe précédent" style="min-width:44px;height:44px;font-size:20px">−</button>
        <span class="num" style="font-size:26px;min-width:64px;text-align:center" data-t="bNum"></span>
        <button type="button" class="ib" data-on="click:bPlus" aria-label="Groupe suivant" style="min-width:44px;height:44px;font-size:20px">+</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:bRun" data-t="bRunLbl" data-s="border-color:bRunBorder"></button>
      </div>
      <div data-show="hasBasList" class="field"><select id="c-bas" data-html="basOpts" style="min-height:34px;font-size:13px"></select></div>
      <span class="lbl" style="font-size:10px;letter-spacing:.04em;text-transform:none;color:#C9CED4" data-t="bTitle"></span>
      <div class="scroll" data-html="bFields" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isAct" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <span style="font-size:12px;line-height:1.4;color:#B9BFC7">Moteur arrêté, contact mis. Chaque appui fait fonctionner l'actionneur suivant : écoute le claquement, ou regarde le ventilateur, le compteur…</span>
      <div style="display:flex;gap:8px"><button type="button" class="btn-cyan" data-on="click:out" data-t="outLbl" style="flex:1"></button></div>
      <div class="scroll" data-html="outs" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isInf" class="scroll" data-html="infos" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px;font-size:12px"></div>

    <div data-show="isAll" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
        <span class="lbl" style="font-size:10px;letter-spacing:.06em" data-t="allTxt"></span>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px;flex:none" data-on="click:readAll">Lire les 255 groupes</button>
      </div>
      <div class="scroll" data-html="all" style="flex:1;display:flex;flex-direction:column;gap:2px;font-size:12px"></div>
    </div>
  </div>

  <div style="position:absolute;left:772px;right:20px;top:76px;height:430px;display:flex;flex-direction:column;gap:8px">
    <div style="${panel};padding:12px 14px;display:flex;flex-direction:column;gap:7px;flex:1;min-height:0">
      <span class="lbl">Test de connexion</span>
      <div class="scroll" data-html="steps" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:5px"></div>
      <p style="margin:0;font-size:13px;font-weight:600;line-height:1.35" data-t="tSum" data-s="color:tCol"></p>
      <p style="margin:0;font-size:11px;line-height:1.4;color:#B9BFC7" data-t="tAdv"></p>
      <button type="button" class="btn" style="font-size:11px" data-on="click:test" data-t="testLbl"></button>
    </div>
    <div style="${panel};padding:10px 12px;height:96px;flex:none;display:flex;flex-direction:column;gap:4px">
      <span class="lbl" style="font-size:9px">Journal ligne K</span>
      <div class="scroll" data-html="trace" style="flex:1;font-family:ui-monospace,monospace;font-size:9.5px;line-height:1.35;color:#8A9099;white-space:pre-wrap;word-break:break-all"></div>
    </div>
  </div>

  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("diagnostic")}
    <span class="lbl" style="font-size:9px;letter-spacing:.06em;text-align:right">Contact mis · un seul logiciel sur le câble</span>
  </div>
</div>`;

export default {
  id: "calculateurs",
  html,
  mount(el, app) {
    this.app = app;
    this.addr = 0x01;
    this.tab = "defauts";
    this.groupNo = 1;
    this.basicNo = 60;
    this.basicRun = false;
    this.live = false;
    this.clearArmed = false;
    const send = (type, extra = {}) => app.send({ type, addr: this.addr, ...extra });
    this.view = new View(el, {
      pick: (b) => {
        if (this.basicRun) send("vag.basicStop", { group: this.basicNo });
        this.addr = Number(b.dataset.addr);
        this.live = false;
        this.basicRun = false;
        this.update();
      },
      open: () => {
        const V = app.vag || {};
        if (V.busy && !V.busy.startsWith("Connexion")) return app.toast("Attends la fin de : " + V.busy);
        this.ask(`Demande de connexion à ${this.addr.toString(16).toUpperCase().padStart(2, "0")} envoyée…`);
        send("vag.open");
      },
      scan: () => {
        if (app.vag?.scan) {
          this.ask("Arrêt du scan demandé : il s'arrête après le calculateur en cours…");
          return app.send({ type: "vag.cancel" });
        }
        this.live = false;
        this.basicRun = false;
        this.ask("Scan demandé : il démarre dès que la ligne est libre…");
        app.send({ type: "vag.scan" });
      },
      test: () => {
        this.live = false;
        this.basicRun = false;
        this.ask("Test de connexion demandé…");
        app.send({ type: "vag.test" });
      },
      tab: (b) => {
        if (this.basicRun && b.dataset.v !== "base") {
          this.basicRun = false;
          send("vag.basicStop", { group: this.basicNo });
        }
        this.tab = b.dataset.v;
        this.update();
      },
      faults: () => send("vag.faults"),
      clear: () => {
        if (!this.clearArmed) {
          this.clearArmed = true;
          setTimeout(() => {
            this.clearArmed = false;
            this.update();
          }, 4000);
          this.update();
          return;
        }
        this.clearArmed = false;
        send("vag.clear");
      },
      gMinus: () => {
        this.groupNo = this.groupNo <= 1 ? 255 : this.groupNo - 1;
        if (this.live) send("vag.watch", { group: this.groupNo });
        this.update();
      },
      gPlus: () => {
        this.groupNo = this.groupNo >= 255 ? 1 : this.groupNo + 1;
        if (this.live) send("vag.watch", { group: this.groupNo });
        this.update();
      },
      gRead: () => send("vag.group", { group: this.groupNo }),
      gLive: () => {
        this.live = !this.live;
        if (this.live) send("vag.watch", { group: this.groupNo });
        else app.send({ type: "vag.unwatch" });
        this.update();
      },
      readAll: () => send("vag.readAll"),
      bMinus: () => {
        this.basicNo = this.basicNo <= 1 ? 255 : this.basicNo - 1;
        this.update();
      },
      bPlus: () => {
        this.basicNo = this.basicNo >= 255 ? 1 : this.basicNo + 1;
        this.update();
      },
      bRun: () => {
        this.basicRun = !this.basicRun;
        if (!this.basicRun) send("vag.basicStop", { group: this.basicNo });
        else send("vag.basic", { group: this.basicNo });
        this.update();
      },
      out: () => {
        if ((app.vag?.busy || "").startsWith("Test des actionneurs")) return;
        this.ask("Actionneur suivant demandé…");
        send("vag.output");
      },
      reloadLabels: () => app.send({ type: "vag.labelsReload" }),
    });
    el.querySelector("#c-mes").onchange = (e) => {
      this.groupNo = Number(e.target.value);
      send("vag.group", { group: this.groupNo });
      this.update();
    };
    el.querySelector("#c-bas").onchange = (e) => {
      if (this.basicRun) send("vag.basicStop", { group: this.basicNo });
      this.basicRun = false;
      this.basicNo = Number(e.target.value);
      this.update();
    };
    // réglage de base : redemandé en continu tant qu'il tourne (sinon le calculateur l'arrête)
    setInterval(() => {
      if (this.visible && this.basicRun && this.tab === "base" && !app.vag?.busy) send("vag.basic", { group: this.basicNo });
    }, 350);
    // lecture continue : le serveur relit le groupe sans pause ; on renouvelle la demande chaque seconde
    setInterval(() => {
      if (this.visible && this.live && this.tab === "mesures") send("vag.watch", { group: this.groupNo });
    }, 1000);
  },
  /** Réaction immédiate au toucher, en attendant la réponse de la ligne K. */
  ask(text) {
    this.pending = { text, at: Date.now() };
    this.update();
  },
  show() {
    this.visible = true;
    this.update();
  },
  hide() {
    this.visible = false;
    if (this.live) this.app.send({ type: "vag.unwatch" });
    this.live = false;
    if (this.basicRun) this.app.send({ type: "vag.basicStop", addr: this.addr, group: this.basicNo });
    this.basicRun = false;
  },
  update() {
    const app = this.app;
    const V = app.vag || { modules: [], trace: [] };
    const mods = V.modules || [];
    const m = mods.find((x) => x.addr === this.addr) || { addr: this.addr, hex: this.addr.toString(16).toUpperCase().padStart(2, "0"), name: "Calculateur", status: "inconnu", groups: {}, faults: null, ident: null };
    const modsHtml = mods
      .map((x) => {
        const sel = x.addr === this.addr;
        const nf = x.faults?.length ?? 0;
        const st = x.status === "defauts" ? `${nf} défaut${nf > 1 ? "s" : ""}` : STATUS[x.status];
        const live = V.connected === x.addr;
        return `<button type="button" data-on="click:pick" data-addr="${x.addr}" style="display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:10px;cursor:pointer;text-align:left;color:#E9ECEF;font-family:inherit;background:${sel ? "rgba(79,209,232,.1)" : "rgba(20,22,26,.7)"};border:1px solid ${sel ? "rgba(79,209,232,.6)" : "#33373E"}">
          <span class="num" style="flex:none;width:28px;font-size:13px;color:${sel ? "#FFFFFF" : "#B9BFC7"}">${x.hex}</span>
          <span style="flex:1;min-width:0;font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(x.short)}</span>
          <span class="lbl" style="flex:none;font-size:9px;letter-spacing:.06em;color:${COL[x.status]}">${live ? "● " : ""}${st}</span></button>`;
      })
      .join("");
    const id = m.ident;
    const row = (k, v) => `<span class="lbl" style="font-size:9px;letter-spacing:.06em;align-self:center">${k}</span><span style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(v || "—")}</span>`;
    const ident = id
      ? row("Référence", id.partNumber) + row("Désignation", id.component) + row("Codage", id.coding != null ? String(id.coding).padStart(5, "0") : "") + row("Atelier (WSC)", id.wsc != null ? String(id.wsc).padStart(5, "0") : "") + (id.extra?.length ? row("Infos", id.extra.join(" · ")) : "")
      : `<span style="grid-column:1 / -1;font-size:13px;color:#8A9099">${m.status === "absent" ? "Ce calculateur ne répond pas : il n'existe pas sur la voiture, ou le contact est coupé." : "Touche « Connecter » pour lire l'identification et les codes défaut."}</span>`;
    // défauts
    const faults = m.faults == null
      ? `<span style="font-size:13px;color:#8A9099">Pas encore lus.</span>`
      : m.faults.length === 0
        ? `<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(123,216,143,.08);border:1px solid rgba(123,216,143,.4)"><span style="width:10px;height:10px;border-radius:50%;background:#7BD88F"></span><span style="font-size:14px;font-weight:600">Aucun code défaut</span></div>`
        : m.faults.map((f) => `<div style="display:flex;flex-direction:column;gap:2px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid rgba(245,184,65,.45)">
            <span style="display:flex;justify-content:space-between;gap:8px"><span class="num" style="font-size:14px;color:#F5B841">${f.vag}${f.obd ? " · " + f.obd : ""}</span><span class="lbl" style="font-size:9px;letter-spacing:.04em">${f.sporadic ? "sporadique" : "permanent"} · état ${f.status.toString(16).toUpperCase().padStart(2, "0")}</span></span>
            <span style="font-size:13px;font-weight:600">${esc(f.text)}</span>
            ${f.elaboration ? `<span style="font-size:12px;color:#B9BFC7">${esc(f.elaboration)}</span>` : ""}</div>`).join("");
    // groupe affiché
    const g = m.groups?.[this.groupNo];
    const fieldRow = (f, i, n) => {
      const col = f.inSpec === true ? "#7BD88F" : f.inSpec === false ? "#FF4D2E" : "#F1F3F5";
      const border = f.inSpec === false ? "rgba(255,77,46,.55)" : f.inSpec === true ? "rgba(123,216,143,.35)" : "#33373E";
      const sub = f.spec ? "Spéc. " + f.spec : `formule ${f.type} · a=${f.a} b=${f.b}`;
      const bits = f.bitsText?.length ? `<span style="grid-column:2 / -1;font-size:10px;color:#B9BFC7;line-height:1.35">${f.bitsText.map(esc).join("<br>")}</span>` : "";
      return `<div style="display:grid;grid-template-columns:46px 1fr auto;align-items:center;gap:4px 10px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid ${border}">
        <span class="num" style="font-size:12px;color:#8A9099">${pad3(n)}.${i + 1}</span>
        <span style="display:flex;flex-direction:column;min-width:0"><span style="font-size:13px;font-weight:600">${esc(f.label)}</span><span class="lbl" style="font-size:9px;letter-spacing:.02em;text-transform:none;color:#6B727C;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(sub)}</span></span>
        <span class="num" style="font-size:16px;text-align:right;color:${col}">${esc(f.text)} <span style="font-size:11px;color:#9AA1AA">${esc(f.unit === "bits" ? "" : f.unit)}</span></span>${bits}</div>`;
    };
    const fields = g ? g.fields.map((f, i) => fieldRow(f, i, this.groupNo)).join("") : `<span style="font-size:13px;color:#8A9099">Groupe ${pad3(this.groupNo)} pas encore lu${m.status === "ok" || m.status === "defauts" ? "" : " (connecte d'abord le calculateur)"}.</span>`;
    // toutes les mesures
    const gs = Object.keys(m.groups || {}).map(Number).sort((a, b) => a - b);
    const all = gs.length
      ? gs.map((n) => m.groups[n].fields.map((f, i) => `<div style="display:grid;grid-template-columns:48px 1fr auto;gap:8px;padding:3px 6px;border-bottom:1px solid #22252A"><span class="num" style="color:#8A9099;font-size:11px">${pad3(n)}.${i + 1}</span><span style="color:#C9CED4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.label)}</span><span class="num" style="text-align:right">${esc(f.text)} <span style="color:#9AA1AA;font-weight:600">${esc(f.unit === "bits" ? "" : f.unit)}</span></span></div>`).join("")).join("")
      : `<span style="font-size:13px;color:#8A9099">Lance la lecture : Nova interroge les 255 groupes et garde tous ceux qui existent (quelques minutes).</span>`;
    // test
    const t = V.test;
    const steps = (t?.steps || []).map((s) => `<div style="display:flex;gap:8px;align-items:flex-start"><span style="flex:none;margin-top:4px;width:8px;height:8px;border-radius:50%;background:${s.ok === null ? "#4A5058" : s.ok ? "#7BD88F" : "#FF4D2E"}"></span><span style="display:flex;flex-direction:column;min-width:0"><span style="font-size:12px;font-weight:600">${esc(s.name)}</span>${s.detail ? `<span style="font-size:10px;color:#8A9099;word-break:break-word">${esc(s.detail)}</span>` : ""}</span></div>`).join("")
      || `<span style="font-size:12px;color:#8A9099">Vérifie le câble, la prise OBD et le dialogue avec le calculateur moteur.</span>`;
    const failed = t && !t.running && t.steps.some((s) => s.ok === false);
    const busy = V.busy;
    const prog = V.progress ? ` ${V.progress.done}/${V.progress.total}` : "";
    const srcs = app.sources.map((s) => s.name).join(" + ");
    const cat = m.catalog || null;
    // état de la connexion de ce calculateur (ou réaction immédiate au toucher)
    const op = V.op && V.op.addr === this.addr ? V.op : null;
    const pend = this.pending && (!V.op || V.op.at < this.pending.at) && Date.now() - this.pending.at < 30000 ? this.pending : null;
    const opBusy = !!pend || op?.state === "busy";
    const opErr = !pend && op?.state === "error";
    const opText = pend ? pend.text : op ? op.text : V.connected === this.addr ? `Connecté · ${V.protocol}` : "";
    const bg = m.basic?.[this.basicNo];
    const L = V.labels || {};
    const sec = (t, body) => `<div style="display:flex;flex-direction:column;gap:4px;padding:8px 10px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid #33373E"><span class="lbl" style="font-size:9px">${t}</span>${body}</div>`;
    let infos;
    if (!L.ready) infos = sec("Base de libellés", `<span style="line-height:1.45;color:#B9BFC7">Pas de base de libellés. Pose <b>base_diagnostic.sqlite</b> à la racine de la clé Nova OS (depuis Windows) ou dans ton dossier Nova, puis touche « Recharger ».</span><button type="button" class="btn" data-on="click:reloadLabels" style="align-self:flex-start;font-size:11px">Recharger</button>`);
    else if (!m.ident) infos = sec("Base de libellés", `<span style="color:#B9BFC7">Base chargée (${L.labels} libellés). Connecte ce calculateur pour trouver son fichier.</span>`);
    else if (!cat) infos = sec("Base de libellés", `<span style="color:#B9BFC7">Aucun fichier de libellés pour ${esc(m.ident.partNumber)}.</span>`);
    else {
      const cod = cat.coding;
      infos =
        sec("Fichier de libellés", `<span style="font-weight:600">${esc(cat.lbl.file)}</span><span style="color:#8A9099">${esc(cat.lbl.component)} · ${esc(cat.lbl.vehicle)} · trouvé par ${esc(cat.lbl.via)}</span>`) +
        (cod ? sec(`Codage ${m.ident.coding != null ? String(m.ident.coding).padStart(5, "0") : ""} · ${esc(cod.title)}`, cod.sections.map((x) => `<span><b>${esc(x.mask)}</b> ${esc(x.title)}${x.value != null ? " = " + x.value : ""}</span>${x.active.map((a) => `<span style="color:#7BD88F;padding-left:10px">${esc(a)}</span>`).join("")}`).join("")) : "") +
        (cat.adaptation.length ? sec("Canaux d'adaptation (lecture seule pour l'instant)", cat.adaptation.map((a) => `<span><b>${pad3(a.channel)}</b> ${esc(a.title)}</span>${a.lines.slice(0, 3).map((l) => `<span style="color:#8A9099;padding-left:10px">${esc(l)}</span>`).join("")}`).join("")) : "") +
        (cat.login.length ? sec("Codes d'accès (login)", cat.login.map((l) => `<span style="color:#C9CED4">${esc(l)}</span>`).join("")) : "");
    }
    this.view.set({
      sub: `${V.port ? "Câble " + V.port : "Câble KKL non ouvert"} · ${V.connected ? `en ligne avec ${V.connected.toString(16).toUpperCase().padStart(2, "0")} (${V.protocol})` : "au repos"}${busy ? " · " + busy + prog : ""}${srcs ? " · source " + srcs : ""}`,
      mods: modsHtml,
      scanLbl: V.scan ? `Arrêter le scan (${V.scan.index}/${V.scan.total})` : "Scanner tous les calculateurs",
      scanBorder: V.scan ? "#F5B841" : "#4FD1E8",
      scanning: !!V.scan,
      scanTxt: V.scan ? `Interroge ${V.scan.addr.toString(16).toUpperCase().padStart(2, "0")} · ${V.scan.name} · ${V.scan.found} trouvé${V.scan.found > 1 ? "s" : ""}` : "",
      openLbl: V.connected === this.addr ? "Reconnecter" : opBusy ? "Connexion…" : "Connecter",
      openBorder: V.connected === this.addr ? "#7BD88F" : opErr ? "#FF4D2E" : "#4A5058",
      opTxt: opText,
      opCol: opErr ? "#FF8A73" : opBusy ? "#4FD1E8" : "#7BD88F",
      mName: `${m.hex} · ${m.name}`,
      mSub: `${STATUS[m.status]}${m.protocol ? " · " + m.protocol : ""}${m.error ? " · " + m.error : ""}`,
      ident,
      showIdent: this.tab === "defauts" || this.tab === "infos",
      defLbl: `Défauts${m.faults?.length ? " (" + m.faults.length + ")" : ""}`,
      tDef: this.tab === "defauts" ? "page" : "false",
      tMes: this.tab === "mesures" ? "page" : "false",
      tAll: this.tab === "tout" ? "page" : "false",
      isDef: this.tab === "defauts", isMes: this.tab === "mesures", isAll: this.tab === "tout",
      faults,
      clearLbl: this.clearArmed ? "Touche encore pour effacer" : "Effacer les codes",
      clearBorder: this.clearArmed ? "#F5B841" : "#4A5058",
      gNum: pad3(this.groupNo),
      gTitle: g?.title || (cat?.measuring.find((x) => x.grp === this.groupNo)?.title ?? ""),
      hasMesList: !!cat?.measuring.length,
      mesOpts: cat ? `<option value="">Groupes nommés…</option>` + cat.measuring.map((x) => `<option value="${x.grp}"${x.grp === this.groupNo ? " selected" : ""}>${pad3(x.grp)} · ${esc(x.title)}</option>`).join("") : "",
      tBas: this.tab === "base" ? "page" : "false",
      tAct: this.tab === "actionneurs" ? "page" : "false",
      tInf: this.tab === "infos" ? "page" : "false",
      isBas: this.tab === "base", isAct: this.tab === "actionneurs", isInf: this.tab === "infos",
      bNum: pad3(this.basicNo),
      bTitle: bg?.title || (cat?.basic.find((x) => x.grp === this.basicNo)?.title ?? (cat ? "" : "Sans base de libellés : choisis le groupe à la main (060 = papillon du moteur)")),
      hasBasList: !!cat?.basic.length,
      basOpts: cat ? `<option value="">Réglages de base connus…</option>` + cat.basic.map((x) => `<option value="${x.grp}"${x.grp === this.basicNo ? " selected" : ""}>${pad3(x.grp)} · ${esc(x.title)}</option>`).join("") : "",
      bRunLbl: this.basicRun ? "Arrêter" : "Lancer",
      bRunBorder: this.basicRun ? "#4FD1E8" : "#4A5058",
      bFields: bg ? bg.fields.map((f, i) => fieldRow(f, i, this.basicNo)).join("") : `<span style="font-size:13px;color:#8A9099">${this.basicRun ? "Réglage de base en cours…" : "Choisis le groupe puis « Lancer ». Le calculateur fait la procédure tant que Nova la lui demande ; « Arrêter » revient en lecture normale."}</span>`,
      outLbl: busy.startsWith("Test des actionneurs") ? "Actionneur en cours…" : (m.outputs?.length && m.outputs[m.outputs.length - 1].code > 0 ? "Actionneur suivant" : "Démarrer le test des actionneurs"),
      outs: (m.outputs || []).slice().reverse().map((o, k) => `<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid ${k === 0 ? "rgba(79,209,232,.6)" : "#33373E"}"><span class="num" style="font-size:13px;color:${o.code < 0 ? "#FF8A73" : "#4FD1E8"}">${o.code > 0 ? String(o.code).padStart(5, "0") : o.code < 0 ? "ERR" : "FIN"}</span><span style="font-size:13px;font-weight:600">${esc(o.text)}</span></div>`).join("") || `<span style="font-size:13px;color:#8A9099">Aucun actionneur testé.</span>`,
      infos,
      fields,
      liveLbl: this.live ? (app.vag?.reconnecting ? "Reconnexion…" : "Arrêter") : "En continu",
      liveBorder: this.live ? "#4FD1E8" : "#4A5058",
      allTxt: busy.startsWith("Lecture complète") ? `Lecture en cours${prog}` : `${gs.length} groupe${gs.length > 1 ? "s" : ""} en mémoire · rapport CSV dans Nova/diagnostics`,
      all,
      steps,
      tSum: t?.summary || (t?.running ? "Test en cours…" : ""),
      tCol: failed ? "#F5B841" : "#7BD88F",
      tAdv: t?.advice || "",
      testLbl: t?.running ? "Test en cours…" : "Tester la connexion",
      trace: esc((V.trace || []).slice(-30).reverse().join("\n")),
    });
  },
};
