// Calculateurs (diagnostic complet par câble KKL, comme VCDS) dans la DA de Nova :
// liste des calculateurs, identification, codes défaut, groupes de mesure, lecture complète, test de connexion.
import { View, esc, navHtml } from "../bind.js";

const COL = { ok: "#7BD88F", defauts: "#F5B841", erreur: "#FF4D2E", absent: "#4A5058", inconnu: "#4A5058" };
const STATUS = { ok: "OK", defauts: "défauts", erreur: "erreur", absent: "absent", inconnu: "non testé" };
const pad3 = (n) => String(n).padStart(3, "0");
const panel = "border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E";

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Calculateurs</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="sub"></span>
    </div>
    <div style="display:flex;gap:8px" role="group" aria-label="Diagnostic">
      <button type="button" class="tab" data-go="diagnostic" style="border-color:#4A5058">Test moteur</button>
      <button type="button" class="tab" aria-current="page">Calculateurs</button>
    </div>
  </div>

  <div style="position:absolute;left:20px;top:76px;width:250px;height:430px;display:flex;flex-direction:column;gap:6px">
    <div class="scroll" data-html="mods" style="flex:1;display:flex;flex-direction:column;gap:5px;padding-right:2px"></div>
    <button type="button" class="btn-cyan" data-on="click:scan" data-t="scanLbl" style="min-height:44px;font-size:12px"></button>
  </div>

  <div style="position:absolute;left:284px;top:76px;width:474px;height:430px;${panel};display:flex;flex-direction:column;padding:14px 16px;box-sizing:border-box;gap:10px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">
      <div style="display:flex;flex-direction:column;gap:2px;min-width:0">
        <span style="font-size:18px;font-weight:700" data-t="mName"></span>
        <span class="lbl" style="font-size:10px;letter-spacing:.06em" data-t="mSub"></span>
      </div>
      <button type="button" class="btn" style="font-size:11px;padding:0 14px;flex:none" data-on="click:open">Connecter</button>
    </div>
    <div data-html="ident" style="display:grid;grid-template-columns:110px 1fr;gap:3px 10px;font-size:13px"></div>
    <div style="display:flex;gap:6px">
      <button type="button" class="tab" data-on="click:tab" data-v="defauts" data-a="aria-current:tDef" style="min-height:36px;font-size:11px;padding:0 12px;white-space:nowrap;letter-spacing:.1em" data-t="defLbl"></button>
      <button type="button" class="tab" data-on="click:tab" data-v="mesures" data-a="aria-current:tMes" style="min-height:36px;font-size:11px;padding:0 12px;white-space:nowrap;letter-spacing:.1em">Mesures</button>
      <button type="button" class="tab" data-on="click:tab" data-v="tout" data-a="aria-current:tAll" style="min-height:36px;font-size:11px;padding:0 12px;white-space:nowrap;letter-spacing:.1em">Tout lire</button>
    </div>

    <div data-show="isDef" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div class="scroll" data-html="faults" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:faults">Relire</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:clear" data-t="clearLbl" data-s="border-color:clearBorder"></button>
      </div>
    </div>

    <div data-show="isMes" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;gap:8px">
        <button type="button" class="ib" data-on="click:gMinus" aria-label="Groupe précédent" style="min-width:44px;height:44px;font-size:20px">−</button>
        <span class="num" style="font-size:26px;min-width:64px;text-align:center" data-t="gNum"></span>
        <button type="button" class="ib" data-on="click:gPlus" aria-label="Groupe suivant" style="min-width:44px;height:44px;font-size:20px">+</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:gRead">Lire</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:gLive" data-t="liveLbl" data-s="border-color:liveBorder"></button>
      </div>
      <div class="scroll" data-html="fields" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isAll" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
        <span class="lbl" style="font-size:10px;letter-spacing:.06em" data-t="allTxt"></span>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px;flex:none" data-on="click:readAll">Lire les 255 groupes</button>
      </div>
      <div class="scroll" data-html="all" style="flex:1;display:flex;flex-direction:column;gap:2px;font-size:12px"></div>
    </div>
  </div>

  <div style="position:absolute;left:772px;right:20px;top:76px;height:430px;display:flex;flex-direction:column;gap:8px">
    <div style="${panel};padding:12px 14px;display:flex;flex-direction:column;gap:7px;flex:1;min-height:0">
      <span class="lbl">Test de connexion</span>
      <div class="scroll" data-html="steps" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:5px"></div>
      <p style="margin:0;font-size:13px;font-weight:600;line-height:1.35" data-t="tSum" data-s="color:tCol"></p>
      <p style="margin:0;font-size:11px;line-height:1.4;color:#B9BFC7" data-t="tAdv"></p>
      <button type="button" class="btn" style="font-size:11px" data-on="click:test" data-t="testLbl"></button>
    </div>
    <div style="${panel};padding:10px 12px;height:96px;flex:none;display:flex;flex-direction:column;gap:4px">
      <span class="lbl" style="font-size:9px">Journal ligne K</span>
      <div class="scroll" data-html="trace" style="flex:1;font-family:ui-monospace,monospace;font-size:9.5px;line-height:1.35;color:#8A9099;white-space:pre-wrap;word-break:break-all"></div>
    </div>
  </div>

  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("diagnostic")}
    <span class="lbl" style="font-size:9px;letter-spacing:.06em;text-align:right">Contact mis · un seul logiciel sur le câble</span>
  </div>
</div>`;

export default {
  id: "calculateurs",
  html,
  mount(el, app) {
    this.app = app;
    this.addr = 0x01;
    this.tab = "defauts";
    this.groupNo = 1;
    this.live = false;
    this.clearArmed = false;
    const send = (type, extra = {}) => app.send({ type, addr: this.addr, ...extra });
    this.view = new View(el, {
      pick: (b) => {
        this.addr = Number(b.dataset.addr);
        this.live = false;
        this.update();
      },
      open: () => send("vag.open"),
      scan: () => app.send({ type: "vag.scan" }),
      test: () => app.send({ type: "vag.test" }),
      tab: (b) => {
        this.tab = b.dataset.v;
        this.update();
      },
      faults: () => send("vag.faults"),
      clear: () => {
        if (!this.clearArmed) {
          this.clearArmed = true;
          setTimeout(() => {
            this.clearArmed = false;
            this.update();
          }, 4000);
          this.update();
          return;
        }
        this.clearArmed = false;
        send("vag.clear");
      },
      gMinus: () => {
        this.groupNo = this.groupNo <= 1 ? 255 : this.groupNo - 1;
        this.update();
      },
      gPlus: () => {
        this.groupNo = this.groupNo >= 255 ? 1 : this.groupNo + 1;
        this.update();
      },
      gRead: () => send("vag.group", { group: this.groupNo }),
      gLive: () => {
        this.live = !this.live;
        this.update();
      },
      readAll: () => send("vag.readAll"),
    });
    // lecture continue du groupe affiché
    setInterval(() => {
      if (this.visible && this.live && this.tab === "mesures" && !app.vag?.busy) send("vag.group", { group: this.groupNo });
    }, 700);
  },
  show() {
    this.visible = true;
    this.update();
  },
  hide() {
    this.visible = false;
    this.live = false;
  },
  update() {
    const app = this.app;
    const V = app.vag || { modules: [], trace: [] };
    const mods = V.modules || [];
    const m = mods.find((x) => x.addr === this.addr) || { addr: this.addr, hex: this.addr.toString(16).toUpperCase().padStart(2, "0"), name: "Calculateur", status: "inconnu", groups: {}, faults: null, ident: null };
    const modsHtml = mods
      .map((x) => {
        const sel = x.addr === this.addr;
        const nf = x.faults?.length ?? 0;
        const st = x.status === "defauts" ? `${nf} défaut${nf > 1 ? "s" : ""}` : STATUS[x.status];
        const live = V.connected === x.addr;
        return `<button type="button" data-on="click:pick" data-addr="${x.addr}" style="display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:10px;cursor:pointer;text-align:left;color:#E9ECEF;font-family:inherit;background:${sel ? "rgba(79,209,232,.1)" : "rgba(20,22,26,.7)"};border:1px solid ${sel ? "rgba(79,209,232,.6)" : "#33373E"}">
          <span class="num" style="flex:none;width:28px;font-size:13px;color:${sel ? "#FFFFFF" : "#B9BFC7"}">${x.hex}</span>
          <span style="flex:1;min-width:0;font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(x.short)}</span>
          <span class="lbl" style="flex:none;font-size:9px;letter-spacing:.06em;color:${COL[x.status]}">${live ? "● " : ""}${st}</span></button>`;
      })
      .join("");
    const id = m.ident;
    const row = (k, v) => `<span class="lbl" style="font-size:9px;letter-spacing:.06em;align-self:center">${k}</span><span style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(v || "—")}</span>`;
    const ident = id
      ? row("Référence", id.partNumber) + row("Désignation", id.component) + row("Codage", id.coding != null ? String(id.coding).padStart(5, "0") : "") + row("Atelier (WSC)", id.wsc != null ? String(id.wsc).padStart(5, "0") : "") + (id.extra?.length ? row("Infos", id.extra.join(" · ")) : "")
      : `<span style="grid-column:1 / -1;font-size:13px;color:#8A9099">${m.status === "absent" ? "Ce calculateur ne répond pas : il n'existe pas sur la voiture, ou le contact est coupé." : "Touche « Connecter » pour lire l'identification et les codes défaut."}</span>`;
    // défauts
    const faults = m.faults == null
      ? `<span style="font-size:13px;color:#8A9099">Pas encore lus.</span>`
      : m.faults.length === 0
        ? `<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(123,216,143,.08);border:1px solid rgba(123,216,143,.4)"><span style="width:10px;height:10px;border-radius:50%;background:#7BD88F"></span><span style="font-size:14px;font-weight:600">Aucun code défaut</span></div>`
        : m.faults.map((f) => `<div style="display:flex;flex-direction:column;gap:2px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid rgba(245,184,65,.45)">
            <span style="display:flex;justify-content:space-between;gap:8px"><span class="num" style="font-size:14px;color:#F5B841">${f.vag}${f.obd ? " · " + f.obd : ""}</span><span class="lbl" style="font-size:9px;letter-spacing:.04em">${f.sporadic ? "sporadique" : "permanent"} · état ${f.status.toString(16).toUpperCase().padStart(2, "0")}</span></span>
            <span style="font-size:13px;font-weight:600">${esc(f.text)}</span>
            ${f.elaboration ? `<span style="font-size:12px;color:#B9BFC7">${esc(f.elaboration)}</span>` : ""}</div>`).join("");
    // groupe affiché
    const g = m.groups?.[this.groupNo];
    const fieldRow = (f, i, n) => `<div style="display:grid;grid-template-columns:46px 1fr auto;align-items:center;gap:10px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid #33373E">
        <span class="num" style="font-size:12px;color:#8A9099">${pad3(n)}.${i + 1}</span>
        <span style="display:flex;flex-direction:column;min-width:0"><span style="font-size:13px;font-weight:600">${esc(f.label)}</span><span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#6B727C">formule ${f.type} · a=${f.a} b=${f.b}</span></span>
        <span class="num" style="font-size:16px;text-align:right">${esc(f.text)} <span style="font-size:11px;color:#9AA1AA">${esc(f.unit === "bits" ? "" : f.unit)}</span></span></div>`;
    const fields = g ? g.fields.map((f, i) => fieldRow(f, i, this.groupNo)).join("") : `<span style="font-size:13px;color:#8A9099">Groupe ${pad3(this.groupNo)} pas encore lu${m.status === "ok" || m.status === "defauts" ? "" : " (connecte d'abord le calculateur)"}.</span>`;
    // toutes les mesures
    const gs = Object.keys(m.groups || {}).map(Number).sort((a, b) => a - b);
    const all = gs.length
      ? gs.map((n) => m.groups[n].fields.map((f, i) => `<div style="display:grid;grid-template-columns:48px 1fr auto;gap:8px;padding:3px 6px;border-bottom:1px solid #22252A"><span class="num" style="color:#8A9099;font-size:11px">${pad3(n)}.${i + 1}</span><span style="color:#C9CED4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.label)}</span><span class="num" style="text-align:right">${esc(f.text)} <span style="color:#9AA1AA;font-weight:600">${esc(f.unit === "bits" ? "" : f.unit)}</span></span></div>`).join("")).join("")
      : `<span style="font-size:13px;color:#8A9099">Lance la lecture : Nova interroge les 255 groupes et garde tous ceux qui existent (quelques minutes).</span>`;
    // test
    const t = V.test;
    const steps = (t?.steps || []).map((s) => `<div style="display:flex;gap:8px;align-items:flex-start"><span style="flex:none;margin-top:4px;width:8px;height:8px;border-radius:50%;background:${s.ok === null ? "#4A5058" : s.ok ? "#7BD88F" : "#FF4D2E"}"></span><span style="display:flex;flex-direction:column;min-width:0"><span style="font-size:12px;font-weight:600">${esc(s.name)}</span>${s.detail ? `<span style="font-size:10px;color:#8A9099;word-break:break-word">${esc(s.detail)}</span>` : ""}</span></div>`).join("")
      || `<span style="font-size:12px;color:#8A9099">Vérifie le câble, la prise OBD et le dialogue avec le calculateur moteur.</span>`;
    const failed = t && !t.running && t.steps.some((s) => s.ok === false);
    const busy = V.busy;
    const prog = V.progress ? ` ${V.progress.done}/${V.progress.total}` : "";
    const srcs = app.sources.map((s) => s.name).join(" + ");
    this.view.set({
      sub: `${V.port ? "Câble " + V.port : "Câble KKL non ouvert"} · ${V.connected ? `en ligne avec ${V.connected.toString(16).toUpperCase().padStart(2, "0")} (${V.protocol})` : "au repos"}${busy ? " · " + busy + prog : ""}${srcs ? " · source " + srcs : ""}`,
      mods: modsHtml,
      scanLbl: busy.startsWith("Scan") ? `Scan…${prog}` : "Scanner tous les calculateurs",
      mName: `${m.hex} · ${m.name}`,
      mSub: `${STATUS[m.status]}${m.protocol ? " · " + m.protocol : ""}${m.error ? " · " + m.error : ""}`,
      ident,
      defLbl: `Défauts${m.faults?.length ? " (" + m.faults.length + ")" : ""}`,
      tDef: this.tab === "defauts" ? "page" : "false",
      tMes: this.tab === "mesures" ? "page" : "false",
      tAll: this.tab === "tout" ? "page" : "false",
      isDef: this.tab === "defauts", isMes: this.tab === "mesures", isAll: this.tab === "tout",
      faults,
      clearLbl: this.clearArmed ? "Touche encore pour effacer" : "Effacer les codes",
      clearBorder: this.clearArmed ? "#F5B841" : "#4A5058",
      gNum: pad3(this.groupNo),
      fields,
      liveLbl: this.live ? "Arrêter" : "En continu",
      liveBorder: this.live ? "#4FD1E8" : "#4A5058",
      allTxt: busy.startsWith("Lecture complète") ? `Lecture en cours${prog}` : `${gs.length} groupe${gs.length > 1 ? "s" : ""} en mémoire · rapport CSV dans Nova/diagnostics`,
      all,
      steps,
      tSum: t?.summary || (t?.running ? "Test en cours…" : ""),
      tCol: failed ? "#F5B841" : "#7BD88F",
      tAdv: t?.advice || "",
      testLbl: t?.running ? "Test en cours…" : "Tester la connexion",
      trace: esc((V.trace || []).slice(-30).join("\n")),
    });
  },
};
