// Calculateurs (diagnostic complet par câble KKL, comme VCDS) dans la DA de Nova :
// liste des calculateurs, identification, codes défaut, groupes de mesure, lecture complète, test de connexion.
import { View, esc, navHtml } from "../bind.js";

const COL = { ok: "#7BD88F", defauts: "#F5B841", erreur: "#FF4D2E", absent: "#4A5058", inconnu: "#4A5058" };
const STATUS = { ok: "OK", defauts: "défauts", erreur: "erreur", absent: "absent", inconnu: "non testé" };
const pad3 = (n) => String(n).padStart(3, "0");
const panel = "border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E";

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Calculateurs</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="sub"></span>
    </div>
    <div style="display:flex;gap:8px" role="group" aria-label="Diagnostic">
      <button type="button" class="tab" data-go="diagnostic" style="border-color:#4A5058">Test moteur</button>
      <button type="button" class="tab" aria-current="page">Calculateurs</button>
    </div>
  </div>

  <div style="position:absolute;left:20px;top:76px;width:250px;height:430px;display:flex;flex-direction:column;gap:6px">
    <div class="scroll" data-html="mods" style="flex:1;display:flex;flex-direction:column;gap:5px;padding-right:2px"></div>
    <span data-show="scanning" style="font-size:11px;font-weight:600;color:#4FD1E8;line-height:1.3" data-t="scanTxt"></span>
    <button type="button" class="btn-cyan" data-on="click:scan" data-t="scanLbl" data-s="border-color:scanBorder" style="min-height:44px;font-size:12px"></button>
  </div>

  <div style="position:absolute;left:284px;top:76px;width:474px;height:430px;${panel};display:flex;flex-direction:column;padding:14px 16px;box-sizing:border-box;gap:10px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">
      <div style="display:flex;flex-direction:column;gap:2px;min-width:0">
        <span style="font-size:18px;font-weight:700" data-t="mName"></span>
        <span class="lbl" style="font-size:10px;letter-spacing:.06em" data-t="mSub"></span>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none;max-width:230px">
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:open" data-t="openLbl" data-s="border-color:openBorder"></button>
        <span style="font-size:10px;font-weight:600;line-height:1.3;text-align:right" data-t="opTxt" data-s="color:opCol"></span>
      </div>
    </div>
    <div data-show="showIdent" data-html="ident" style="display:grid;grid-template-columns:110px 1fr;gap:3px 10px;font-size:13px"></div>
    <div style="display:flex;gap:4px">
      <button type="button" class="tab" data-on="click:tab" data-v="defauts" data-a="aria-current:tDef" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em" data-t="defLbl"></button>
      <button type="button" class="tab" data-on="click:tab" data-v="mesures" data-a="aria-current:tMes" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em">Mesures</button>
      <button type="button" class="tab" data-on="click:tab" data-v="base" data-a="aria-current:tBas" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em">Rég. base</button>
      <button type="button" class="tab" data-on="click:tab" data-v="actionneurs" data-a="aria-current:tAct" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em">Actionneurs</button>
      <button type="button" class="tab" data-on="click:tab" data-v="infos" data-a="aria-current:tInf" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em">Infos</button>
      <button type="button" class="tab" data-on="click:tab" data-v="tout" data-a="aria-current:tAll" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em">Tout</button>
      <button type="button" class="tab" data-on="click:tab" data-v="multi" data-a="aria-current:tMul" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em" data-t="mulTab"></button>
      <button type="button" class="tab" data-on="click:tab" data-v="can" data-a="aria-current:tCan" style="min-height:36px;font-size:10px;padding:0 6px;white-space:nowrap;letter-spacing:.02em">CAN</button>
    </div>

    <div data-show="isDef" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div class="scroll" data-html="faults" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:faults">Relire</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:clear" data-t="clearLbl" data-s="border-color:clearBorder"></button>
      </div>
    </div>

    <div data-show="isMes" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;gap:8px">
        <button type="button" class="ib" data-on="click:gMinus" aria-label="Groupe précédent" style="min-width:44px;height:44px;font-size:20px">−</button>
        <span class="num" style="font-size:26px;min-width:64px;text-align:center" data-t="gNum"></span>
        <button type="button" class="ib" data-on="click:gPlus" aria-label="Groupe suivant" style="min-width:44px;height:44px;font-size:20px">+</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:gRead">Lire</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:gLive" data-t="liveLbl" data-s="border-color:liveBorder"></button>
        <button type="button" class="btn" style="font-size:11px;padding:0 10px" data-on="click:mAdd" data-t="mAddLbl" aria-label="Ajouter ce groupe à la lecture multiple"></button>
      </div>
      <div data-show="hasMesList" class="field"><select id="c-mes" data-html="mesOpts" style="min-height:34px;font-size:13px"></select></div>
      <span class="lbl" style="font-size:10px;letter-spacing:.04em;text-transform:none;color:#C9CED4" data-t="gTitle"></span>
      <div data-show="hasFind" data-html="findBox" style="display:flex;flex-direction:column;gap:5px;padding:8px 10px;border-radius:10px;background:rgba(79,209,232,.06);border:1px solid rgba(79,209,232,.45);max-height:190px;overflow:auto"></div>
      <div class="scroll" data-html="fields" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isBas" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;gap:8px">
        <button type="button" class="ib" data-on="click:bMinus" aria-label="Groupe précédent" style="min-width:44px;height:44px;font-size:20px">−</button>
        <span class="num" style="font-size:26px;min-width:64px;text-align:center" data-t="bNum"></span>
        <button type="button" class="ib" data-on="click:bPlus" aria-label="Groupe suivant" style="min-width:44px;height:44px;font-size:20px">+</button>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px" data-on="click:bRun" data-t="bRunLbl" data-s="border-color:bRunBorder"></button>
      </div>
      <div data-show="hasBasList" class="field"><select id="c-bas" data-html="basOpts" style="min-height:34px;font-size:13px"></select></div>
      <span class="lbl" style="font-size:10px;letter-spacing:.04em;text-transform:none;color:#C9CED4" data-t="bTitle"></span>
      <div class="scroll" data-html="bFields" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isAct" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <span style="font-size:12px;line-height:1.4;color:#B9BFC7">Moteur arrêté, contact mis. Chaque appui fait fonctionner l'actionneur suivant : écoute le claquement, ou regarde le ventilateur, le compteur…</span>
      <div style="display:flex;gap:8px"><button type="button" class="btn-cyan" data-on="click:out" data-t="outLbl" style="flex:1"></button></div>
      <div class="scroll" data-html="outs" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isMul" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <span style="font-size:11px;line-height:1.4;color:#B9BFC7">Plusieurs calculateurs à la suite (moteur, ABS, combiné…). La prise OBD ne parle qu'à un calculateur à la fois : Nova reste ~3 s sur chacun puis passe au suivant (≈ 2,5 s par changement). Les valeurs vont aussi au tableau de bord. Ajoute des groupes avec « + Multi » dans Mesures.</span>
      <div style="display:flex;align-items:center;gap:8px">
        <button type="button" class="btn-cyan" style="flex:1;font-size:12px" data-on="click:mRun" data-t="mRunLbl" data-s="border-color:mRunBorder"></button>
        <button type="button" class="btn" style="font-size:11px;padding:0 12px" data-on="click:mClear">Vider</button>
      </div>
      <span style="font-size:11px;font-weight:600;line-height:1.3" data-t="mState" data-s="color:mStateCol"></span>
      <div class="scroll" data-html="mItems" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
    </div>

    <div data-show="isCan" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <span style="font-size:11px;line-height:1.4;color:#B9BFC7">Bus CAN propulsion (moteur, ABS, combiné, Haldex) écouté sans rien y envoyer (CANable ou ELM327 relié à CAN-H / CAN-L). Tout arrive en même temps, en continu, et va au tableau de bord.</span>
      <div style="display:flex;gap:8px;align-items:center">
        <span style="font-size:11px;line-height:1.35;color:#C9CED4;flex:1" data-t="canUseLbl"></span>
        <button type="button" class="btn" style="font-size:11px;padding:0 12px;flex:none" data-go="reglages">Choisir le câble</button>
      </div>
      <span style="font-size:11px;font-weight:600;line-height:1.3" data-t="canState" data-s="color:canCol"></span>
      <div class="scroll" data-html="canIds" style="flex:1;display:flex;flex-direction:column;gap:3px;font-family:ui-monospace,monospace;font-size:11px"></div>
    </div>

    <div data-show="isInf" class="scroll" data-html="infos" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px;font-size:12px"></div>

    <div data-show="isAll" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
        <span class="lbl" style="font-size:10px;letter-spacing:.06em" data-t="allTxt"></span>
        <button type="button" class="btn" style="font-size:11px;padding:0 14px;flex:none" data-on="click:readAll">Lire les 255 groupes</button>
      </div>
      <div class="scroll" data-html="all" style="flex:1;display:flex;flex-direction:column;gap:2px;font-size:12px"></div>
    </div>
  </div>

  <div style="position:absolute;left:772px;right:20px;top:76px;height:430px;display:flex;flex-direction:column;gap:8px">
    <div style="${panel};padding:12px 14px;display:flex;flex-direction:column;gap:7px;flex:1;min-height:0">
      <span class="lbl">Test de connexion</span>
      <div class="scroll" data-html="steps" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:5px"></div>
      <p style="margin:0;font-size:13px;font-weight:600;line-height:1.35" data-t="tSum" data-s="color:tCol"></p>
      <p style="margin:0;font-size:11px;line-height:1.4;color:#B9BFC7" data-t="tAdv"></p>
      <button type="button" class="btn" style="font-size:11px" data-on="click:test" data-t="testLbl"></button>
    </div>
    <div style="${panel};padding:10px 12px;height:96px;flex:none;display:flex;flex-direction:column;gap:4px">
      <span class="lbl" style="font-size:9px">Journal ligne K</span>
      <div class="scroll" data-html="trace" style="flex:1;font-family:ui-monospace,monospace;font-size:9.5px;line-height:1.35;color:#8A9099;white-space:pre-wrap;word-break:break-all"></div>
    </div>
  </div>

  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("diagnostic")}
    <span class="lbl" style="font-size:9px;letter-spacing:.06em;text-align:right">Contact mis · un seul logiciel sur le câble</span>
  </div>
</div>`;

export default {
  id: "calculateurs",
  html,
  mount(el, app) {
    this.app = app;
    this.el = el;
    this.addr = 0x01;
    this.tab = "defauts";
    this.groupNo = 1;
    this.basicNo = 60;
    this.basicRun = false;
    this.live = false;
    this.clearArmed = false;
    try {
      this.multi = JSON.parse(localStorage.getItem("nova.multi") || "[]").filter((x) => x && x.addr && x.group);
    } catch {
      this.multi = [];
    }
    const saveMulti = () => {
      try {
        localStorage.setItem("nova.multi", JSON.stringify(this.multi));
      } catch {}
      if (app.vag?.multi) {
        if (this.multi.length) app.send({ type: "vag.multi", items: this.multi });
        else app.send({ type: "vag.multiStop" });
      }
    };
    const send = (type, extra = {}) => app.send({ type, addr: this.addr, ...extra });
    this.view = new View(el, {
      pick: (b) => {
        if (this.basicRun) send("vag.basicStop", { group: this.basicNo });
        this.addr = Number(b.dataset.addr);
        this.live = false;
        this.basicRun = false;
        this.update();
      },
      open: () => {
        const V = app.vag || {};
        if (V.busy && !V.busy.startsWith("Connexion")) return app.toast("Attends la fin de : " + V.busy);
        this.ask(`Demande de connexion à ${this.addr.toString(16).toUpperCase().padStart(2, "0")} envoyée…`);
        send("vag.open");
      },
      scan: () => {
        if (app.vag?.scan) {
          this.ask("Arrêt du scan demandé : il s'arrête après le calculateur en cours…");
          return app.send({ type: "vag.cancel" });
        }
        this.live = false;
        this.basicRun = false;
        this.ask("Scan demandé : il démarre dès que la ligne est libre…");
        app.send({ type: "vag.scan" });
      },
      test: () => {
        this.live = false;
        this.basicRun = false;
        this.ask("Test de connexion demandé…");
        app.send({ type: "vag.test" });
      },
      tab: (b) => {
        if (this.basicRun && b.dataset.v !== "base") {
          this.basicRun = false;
          send("vag.basicStop", { group: this.basicNo });
        }
        this.tab = b.dataset.v;
        this.update();
      },
      faults: () => send("vag.faults"),
      clear: () => {
        if (!this.clearArmed) {
          this.clearArmed = true;
          setTimeout(() => {
            this.clearArmed = false;
            this.update();
          }, 4000);
          this.update();
          return;
        }
        this.clearArmed = false;
        send("vag.clear");
      },
      gMinus: () => {
        this.groupNo = this.groupNo <= 1 ? 255 : this.groupNo - 1;
        if (this.live) send("vag.watch", { group: this.groupNo });
        this.update();
      },
      gPlus: () => {
        this.groupNo = this.groupNo >= 255 ? 1 : this.groupNo + 1;
        if (this.live) send("vag.watch", { group: this.groupNo });
        this.update();
      },
      gRead: () => send("vag.group", { group: this.groupNo }),
      gLive: () => {
        this.live = !this.live;
        if (this.live) send("vag.watch", { group: this.groupNo });
        else app.send({ type: "vag.unwatch" });
        this.update();
      },
      readAll: () => send("vag.readAll"),
      mAdd: () => {
        const i = this.multi.findIndex((x) => x.addr === this.addr && x.group === this.groupNo);
        if (i >= 0) this.multi.splice(i, 1);
        else {
          if (this.multi.length >= 8) return app.toast("Lecture multiple : 8 groupes au plus");
          this.multi.push({ addr: this.addr, group: this.groupNo });
          app.toast(`Groupe ${pad3(this.groupNo)} de ${this.addr.toString(16).toUpperCase().padStart(2, "0")} ajouté à la lecture multiple`);
        }
        saveMulti();
        this.update();
      },
      mDel: (b) => {
        this.multi.splice(Number(b.dataset.i), 1);
        saveMulti();
        this.update();
      },
      mRun: () => {
        if (app.vag?.multi) app.send({ type: "vag.multiStop" });
        else if (!this.multi.length) app.toast("Ajoute d'abord des groupes avec « + Multi » dans l'onglet Mesures");
        else {
          this.live = false;
          app.send({ type: "vag.multi", items: this.multi });
        }
      },
      canUse: () => {
        app.send({ type: "config.set", car: { elmMode: "can", source: "elmcan+kkl" } });
        app.toast("Source : ELM327 sur le CAN + câble KKL. Nova redémarre…");
        setTimeout(() => app.send({ type: "system.restartBrain" }), 800);
      },
      btFind: () => {
        if (!app.sys?.bt?.present) return app.toast("Aucun adaptateur Bluetooth : branche la clé Bluetooth puis réessaie (rapport matériel dans Réglages → Journaux)");
        app.send({ type: "bt.scan" });
      },
      btUse: (b) => {
        const mac = b.dataset.mac;
        app.toast("Association de l'ELM327 (code 1234)… jusqu'à une minute");
        app.send({ type: "can.useBt", mac });
      },
      canObd: () => {
        app.send({ type: "config.set", car: { elmMode: "obd", source: "auto" } });
        app.toast("Source : automatique (ELM327 sur la prise OBD). Nova redémarre…");
        setTimeout(() => app.send({ type: "system.restartBrain" }), 800);
      },
      findStart: (b) => {
        const i = Number(b.dataset.i);
        const m = (app.vag?.modules || []).find((x) => x.addr === this.addr);
        const f = m?.groups?.[this.groupNo]?.fields?.[i];
        if (!f) return;
        if (!this.live) {
          this.live = true;
          send("vag.watch", { group: this.groupNo });
        }
        app.send({ type: "can.find", addr: this.addr, group: this.groupNo, field: i, label: f.label, unit: f.unit === "bits" ? "" : f.unit, seconds: 40 });
      },
      findStop: () => app.send({ type: "can.findStop" }),
      findSave: (b) => {
        const sel = this.el.querySelector("#c-findkey");
        app.send({ type: "can.save", index: Number(b.dataset.i), key: sel ? sel.value : "" });
      },
      findForget: (b) => app.send({ type: "can.forget", key: b.dataset.key }),
      findClose: () => {
        app.canFind = null;
        this.update();
      },
      mClear: () => {
        this.multi = [];
        saveMulti();
        this.update();
      },
      bMinus: () => {
        this.basicNo = this.basicNo <= 1 ? 255 : this.basicNo - 1;
        this.update();
      },
      bPlus: () => {
        this.basicNo = this.basicNo >= 255 ? 1 : this.basicNo + 1;
        this.update();
      },
      bRun: () => {
        this.basicRun = !this.basicRun;
        if (!this.basicRun) send("vag.basicStop", { group: this.basicNo });
        else send("vag.basic", { group: this.basicNo });
        this.update();
      },
      out: () => {
        if ((app.vag?.busy || "").startsWith("Test des actionneurs")) return;
        this.ask("Actionneur suivant demandé…");
        send("vag.output");
      },
      reloadLabels: () => app.send({ type: "vag.labelsReload" }),
    });
    el.querySelector("#c-mes").onchange = (e) => {
      this.groupNo = Number(e.target.value);
      send("vag.group", { group: this.groupNo });
      this.update();
    };
    el.querySelector("#c-bas").onchange = (e) => {
      if (this.basicRun) send("vag.basicStop", { group: this.basicNo });
      this.basicRun = false;
      this.basicNo = Number(e.target.value);
      this.update();
    };
    // réglage de base : redemandé en continu tant qu'il tourne (sinon le calculateur l'arrête)
    setInterval(() => {
      if (this.visible && this.basicRun && this.tab === "base" && !app.vag?.busy) send("vag.basic", { group: this.basicNo });
    }, 350);
    // bus CAN : état et trames, chaque seconde quand l'onglet est ouvert
    setInterval(() => {
      if (this.visible && this.tab === "can") app.send({ type: "can.view" });
    }, 1000);
    setInterval(() => {
      if (this.visible && this.tab === "can") app.send({ type: "sys.get" });
    }, 3000);
    // lecture continue : le serveur relit le groupe sans pause ; on renouvelle la demande chaque seconde
    setInterval(() => {
      if (this.visible && this.live && this.tab === "mesures") send("vag.watch", { group: this.groupNo });
    }, 1000);
  },
  findVals(app) {
    const F = app.canFind;
    const KEYS = { "°C": ["oil", "water", "iat", "ext"], "km/h": ["speed", "wfl", "wfr", "wrl", "wrr"], "tr/min": ["rpm"], l: ["fuel"], "%": ["load", "throttle", "pedal", "haldex"], V: ["volt"], mbar: ["boost"], "g/s": ["maf"], "°": ["timing"] };
    const NAMES = { oil: "Huile", water: "Eau", iat: "Air admission", ext: "Extérieur", speed: "Vitesse", wfl: "Roue AVG", wfr: "Roue AVD", wrl: "Roue ARG", wrr: "Roue ARD", rpm: "Régime", fuel: "Carburant", load: "Charge", throttle: "Papillon", pedal: "Pédale", haldex: "Haldex", volt: "Batterie", boost: "Turbo", maf: "Débit d'air", timing: "Avance" };
    const customs = F?.customs || [];
    if (!F || (F.status === "idle" && !customs.length)) return { hasFind: false, findBox: "" };
    const fmt = (x, d = 3) => (Number.isFinite(x) ? String(Math.round(x * 10 ** d) / 10 ** d).replace(".", ",") : "—");
    let body = "";
    if (F.status === "recording") {
      const left = Math.max(0, Math.round(F.seconds - (Date.now() - F.startedAt) / 1000));
      body = `<span style="font-size:12px;font-weight:600;color:#4FD1E8">${esc(F.text)}</span><span style="font-size:11px;color:#B9BFC7">${F.samples} lectures · ${F.min ?? "—"} → ${F.max ?? "—"} ${esc(F.unit)} · encore ${left} s</span><button type="button" class="btn" data-on="click:findStop" style="font-size:11px;align-self:flex-start">Arrêter</button>`;
    } else if (F.status === "done" || F.status === "error") {
      const keys = KEYS[F.unit] || [];
      const opts = keys.map((k) => `<option value="${k}">${esc(NAMES[k] || k)} (tableau de bord)</option>`).join("") + `<option value="">Nouvelle mesure « ${esc(F.label)} »</option>`;
      body = `<span style="font-size:12px;font-weight:600;color:${F.status === "error" ? "#FF8A73" : "#7BD88F"}">« ${esc(F.label)} » : ${esc(F.text)}</span>` +
        (F.results.length
          ? `<label style="display:flex;gap:6px;align-items:center;font-size:11px;color:#B9BFC7">Enregistrer comme <select id="c-findkey" style="min-height:28px;font-size:11px">${opts}</select></label>` +
            F.results.map((r, i) => `<div style="display:flex;align-items:center;gap:8px;font-size:11px;padding:3px 6px;border-radius:6px;background:rgba(20,22,26,.8)"><span class="num" style="color:#4FD1E8">0x${r.idHex}</span><span style="flex:1;color:#C9CED4">${r.kind === "u8" ? "octet " + (r.at + 1) : "octets " + (r.at + 1) + "-" + (r.at + 2) + (r.kind === "u16le" ? " (bas d'abord)" : " (haut d'abord)")} · ×${fmt(r.a, 4)} ${r.b >= 0 ? "+" : "−"} ${fmt(Math.abs(r.b), 2)} · r ${fmt(Math.abs(r.r), 3)} · écart ${fmt(r.rms, 2)} ${esc(F.unit)}</span><span class="num">${fmt(r.sample, 1)}</span><button type="button" class="btn" data-on="click:findSave" data-i="${i}" style="font-size:10px;padding:0 8px;min-height:26px">Garder</button></div>`).join("")
          : "") +
        `<button type="button" class="btn" data-on="click:findClose" style="font-size:10px;align-self:flex-start;min-height:26px">Fermer</button>`;
    }
    const saved = customs.length ? `<span class="lbl" style="font-size:9px;margin-top:4px">Lu sur le CAN grâce à la comparaison</span>` + customs.map((c) => `<div style="display:flex;align-items:center;gap:8px;font-size:11px"><span style="flex:1;color:#C9CED4">${esc(c.label)} → ${esc(NAMES[c.key] || c.key)} · 0x${c.id.toString(16).toUpperCase().padStart(3, "0")} octet ${c.at + 1}</span><button type="button" class="ib" data-on="click:findForget" data-key="${esc(c.key)}" aria-label="Oublier" style="min-width:28px;height:24px;font-size:12px">×</button></div>`).join("") : "";
    return { hasFind: true, findBox: body + saved };
  },
  canVals(app) {
    const C = app.can || {};
    const v = C.view;
    const using = /can/.test(C.config?.source || "") || C.config?.elmMode === "can" || !!v;
    const ids = v?.ids || [];
    const keyTxt = (d) => Object.entries(d || {}).filter(([k]) => k !== "fuelSensor").map(([k, x]) => `${k} ${Math.round(x * 10) / 10}`).join(" · ");
    return {
      canUseLbl: /elmcan/.test(C.config?.source || "") ? `ELM327 sur le CAN${C.config?.elmBt ? " (Bluetooth " + C.config.elmBt + ")" : " (USB)"}` : using ? "Adaptateur CAN USB (CANable), écoute seule" : "Pour écouter le CAN : branche le CANable (source Auto), ou Réglages → Voiture → « Adaptateur CAN USB (CANable) + câble KKL ».",
      canState: !C.config ? "…" : !v ? (using ? "ELM327 pas encore trouvé (branché ?)" : "Source CAN non active : touche le bouton ci-dessus") : `${v.state === "ok" ? "Écoute" : v.state === "error" ? "Erreur" : "Connexion"} · ${v.detail}${v.version ? " · " + v.version : ""}`,
      canCol: v?.state === "ok" ? "#7BD88F" : v?.state === "error" ? "#FF8A73" : "#4FD1E8",
      canIds: ids.length
        ? ids.map((e) => {
            const bytes = e.bytes.map((b, i) => `<span style="color:${e.changed & (1 << i) ? "#4FD1E8" : "#C9CED4"}">${b.toString(16).toUpperCase().padStart(2, "0")}</span>`).join(" ");
            return `<div style="display:grid;grid-template-columns:40px 1fr auto;gap:8px;padding:4px 8px;border-radius:6px;background:rgba(20,22,26,.75);border:1px solid ${e.decoded ? "rgba(123,216,143,.35)" : "#33373E"}"><span style="color:${e.decoded ? "#7BD88F" : "#8A9099"}">${e.idHex}</span><span>${bytes}${e.decoded ? `<br><span style="font-family:inherit;color:#9FB4C8">${esc(keyTxt(e.decoded))}</span>` : ""}</span><span style="color:#6B727C">${e.age < 3000 ? e.count : "—"}</span></div>`;
          }).join("")
        : `<span style="font-family:system-ui;font-size:12px;color:#8A9099">Aucune trame pour l'instant. En bleu : les octets qui bougent ; en vert : les messages que Nova sait décoder.</span>`,
    };
  },
  /** Réaction immédiate au toucher, en attendant la réponse de la ligne K. */
  ask(text) {
    this.pending = { text, at: Date.now() };
    this.update();
  },
  show() {
    this.visible = true;
    this.app.send({ type: "can.findGet" });
    this.update();
  },
  hide() {
    this.visible = false;
    if (this.live) this.app.send({ type: "vag.unwatch" });
    this.live = false;
    if (this.basicRun) this.app.send({ type: "vag.basicStop", addr: this.addr, group: this.basicNo });
    this.basicRun = false;
  },
  update() {
    const app = this.app;
    const V = app.vag || { modules: [], trace: [] };
    const mods = V.modules || [];
    const m = mods.find((x) => x.addr === this.addr) || { addr: this.addr, hex: this.addr.toString(16).toUpperCase().padStart(2, "0"), name: "Calculateur", status: "inconnu", groups: {}, faults: null, ident: null };
    const modsHtml = mods
      .map((x) => {
        const sel = x.addr === this.addr;
        const nf = x.faults?.length ?? 0;
        const st = x.status === "defauts" ? `${nf} défaut${nf > 1 ? "s" : ""}` : STATUS[x.status];
        const live = V.connected === x.addr;
        return `<button type="button" data-on="click:pick" data-addr="${x.addr}" style="display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:10px;cursor:pointer;text-align:left;color:#E9ECEF;font-family:inherit;background:${sel ? "rgba(79,209,232,.1)" : "rgba(20,22,26,.7)"};border:1px solid ${sel ? "rgba(79,209,232,.6)" : "#33373E"}">
          <span class="num" style="flex:none;width:28px;font-size:13px;color:${sel ? "#FFFFFF" : "#B9BFC7"}">${x.hex}</span>
          <span style="flex:1;min-width:0;font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(x.short)}</span>
          <span class="lbl" style="flex:none;font-size:9px;letter-spacing:.06em;color:${COL[x.status]}">${live ? "● " : ""}${st}</span></button>`;
      })
      .join("");
    const id = m.ident;
    const row = (k, v) => `<span class="lbl" style="font-size:9px;letter-spacing:.06em;align-self:center">${k}</span><span style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(v || "—")}</span>`;
    const ident = id
      ? row("Référence", id.partNumber) + row("Désignation", id.component) + row("Codage", id.coding != null ? String(id.coding).padStart(5, "0") : "") + row("Atelier (WSC)", id.wsc != null ? String(id.wsc).padStart(5, "0") : "") + (id.extra?.length ? row("Infos", id.extra.join(" · ")) : "")
      : !/kkl|auto/.test(app.config?.car?.source || "auto")
        ? `<span style="grid-column:1 / -1;font-size:13px;line-height:1.4;color:#F5B841">Le diagnostic des calculateurs passe par le câble KKL : la source choisie (${esc(app.config?.car?.source || "")}) n'en a pas. Avec l'ELM327 sur la prise OBD, utilise « Test moteur » (codes et mesures OBD2 du moteur). Réglages → Voiture pour changer.</span>`
        : `<span style="grid-column:1 / -1;font-size:13px;color:#8A9099">${m.status === "absent" ? "Ce calculateur ne répond pas : il n'existe pas sur la voiture, ou le contact est coupé." : "Touche « Connecter » pour lire l'identification et les codes défaut."}</span>`;
    // défauts
    const faults = m.faults == null
      ? `<span style="font-size:13px;color:#8A9099">Pas encore lus.</span>`
      : m.faults.length === 0
        ? `<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;background:rgba(123,216,143,.08);border:1px solid rgba(123,216,143,.4)"><span style="width:10px;height:10px;border-radius:50%;background:#7BD88F"></span><span style="font-size:14px;font-weight:600">Aucun code défaut</span></div>`
        : m.faults.map((f) => `<div style="display:flex;flex-direction:column;gap:2px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid rgba(245,184,65,.45)">
            <span style="display:flex;justify-content:space-between;gap:8px"><span class="num" style="font-size:14px;color:#F5B841">${f.vag}${f.obd ? " · " + f.obd : ""}</span><span class="lbl" style="font-size:9px;letter-spacing:.04em">${f.sporadic ? "sporadique" : "permanent"} · état ${f.status.toString(16).toUpperCase().padStart(2, "0")}</span></span>
            <span style="font-size:13px;font-weight:600">${esc(f.text)}${f.english ? ' <span class="lbl" style="font-size:8px;letter-spacing:.06em">anglais</span>' : ""}</span>
            ${f.elaboration ? `<span style="font-size:12px;color:#B9BFC7">${esc(f.elaboration)}</span>` : ""}
            ${f.tip ? `<span style="font-size:11px;line-height:1.4;color:#9FB4C8">Piste : ${esc(f.tip)}</span>` : ""}</div>`).join("");
    // groupe affiché
    const canOn = (app.sources || []).some((s) => /CAN/.test(s.name) && s.state === "ok");
    const g = m.groups?.[this.groupNo];
    const fieldRow = (f, i, n) => {
      const col = f.inSpec === true ? "#7BD88F" : f.inSpec === false ? "#FF4D2E" : "#F1F3F5";
      const border = f.inSpec === false ? "rgba(255,77,46,.55)" : f.inSpec === true ? "rgba(123,216,143,.35)" : "#33373E";
      const sub = f.spec ? "Spéc. " + f.spec : `formule ${f.type} · a=${f.a} b=${f.b}`;
      const bits = f.bitsText?.length ? `<span style="grid-column:2 / -1;font-size:10px;color:#B9BFC7;line-height:1.35">${f.bitsText.map(esc).join("<br>")}</span>` : "";
      return `<div style="display:grid;grid-template-columns:46px 1fr auto;align-items:center;gap:4px 10px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid ${border}">
        <span class="num" style="font-size:12px;color:#8A9099">${pad3(n)}.${i + 1}</span>
        <span style="display:flex;flex-direction:column;min-width:0"><span style="font-size:13px;font-weight:600">${esc(f.label)}</span><span class="lbl" style="font-size:9px;letter-spacing:.02em;text-transform:none;color:#6B727C;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(sub)}</span></span>
        <span style="display:flex;align-items:center;gap:8px;justify-content:flex-end"><span class="num" style="font-size:16px;text-align:right;color:${col}">${esc(f.text)} <span style="font-size:11px;color:#9AA1AA">${esc(f.unit === "bits" ? "" : f.unit)}</span></span>${canOn && n === this.groupNo && f.value != null && f.unit !== "bits" ? `<button type="button" class="ib" data-on="click:findStart" data-i="${i}" title="Chercher cette valeur sur le bus CAN" aria-label="Chercher sur le CAN" style="min-width:34px;height:28px;font-size:10px">CAN</button>` : ""}</span>${bits}</div>`;
    };
    const fields = g ? g.fields.map((f, i) => fieldRow(f, i, this.groupNo)).join("") : `<span style="font-size:13px;color:#8A9099">Groupe ${pad3(this.groupNo)} pas encore lu${m.status === "ok" || m.status === "defauts" ? "" : " (connecte d'abord le calculateur)"}.</span>`;
    // toutes les mesures
    const gs = Object.keys(m.groups || {}).map(Number).sort((a, b) => a - b);
    const all = gs.length
      ? gs.map((n) => m.groups[n].fields.map((f, i) => `<div style="display:grid;grid-template-columns:48px 1fr auto;gap:8px;padding:3px 6px;border-bottom:1px solid #22252A"><span class="num" style="color:#8A9099;font-size:11px">${pad3(n)}.${i + 1}</span><span style="color:#C9CED4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.label)}</span><span class="num" style="text-align:right">${esc(f.text)} <span style="color:#9AA1AA;font-weight:600">${esc(f.unit === "bits" ? "" : f.unit)}</span></span></div>`).join("")).join("")
      : `<span style="font-size:13px;color:#8A9099">Lance la lecture : Nova interroge les 255 groupes et garde tous ceux qui existent (quelques minutes).</span>`;
    // test
    const t = V.test;
    const steps = (t?.steps || []).map((s) => `<div style="display:flex;gap:8px;align-items:flex-start"><span style="flex:none;margin-top:4px;width:8px;height:8px;border-radius:50%;background:${s.ok === null ? "#4A5058" : s.ok ? "#7BD88F" : "#FF4D2E"}"></span><span style="display:flex;flex-direction:column;min-width:0"><span style="font-size:12px;font-weight:600">${esc(s.name)}</span>${s.detail ? `<span style="font-size:10px;color:#8A9099;word-break:break-word">${esc(s.detail)}</span>` : ""}</span></div>`).join("")
      || `<span style="font-size:12px;color:#8A9099">Vérifie le câble, la prise OBD et le dialogue avec le calculateur moteur.</span>`;
    const failed = t && !t.running && t.steps.some((s) => s.ok === false);
    const busy = V.busy;
    const prog = V.progress ? ` ${V.progress.done}/${V.progress.total}` : "";
    const srcs = app.sources.map((s) => s.name).join(" + ");
    const cat = m.catalog || null;
    // état de la connexion de ce calculateur (ou réaction immédiate au toucher)
    const op = V.op && V.op.addr === this.addr ? V.op : null;
    const pend = this.pending && (!V.op || V.op.at < this.pending.at) && Date.now() - this.pending.at < 30000 ? this.pending : null;
    const opBusy = !!pend || op?.state === "busy";
    const opErr = !pend && op?.state === "error";
    const opText = pend ? pend.text : op ? op.text : V.connected === this.addr ? `Connecté · ${V.protocol}` : "";
    const bg = m.basic?.[this.basicNo];
    const L = V.labels || {};
    const sec = (t, body) => `<div style="display:flex;flex-direction:column;gap:4px;padding:8px 10px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid #33373E"><span class="lbl" style="font-size:9px">${t}</span>${body}</div>`;
    let infos;
    if (!L.ready) infos = sec("Base de libellés", `<span style="line-height:1.45;color:#B9BFC7">Pas de base de libellés. Pose <b>base_diagnostic.sqlite</b> à la racine de la clé Nova OS (depuis Windows) ou dans ton dossier Nova, puis touche « Recharger ».</span><button type="button" class="btn" data-on="click:reloadLabels" style="align-self:flex-start;font-size:11px">Recharger</button>`);
    else if (!m.ident) infos = sec("Base de libellés", `<span style="color:#B9BFC7">Base chargée (${L.labels} libellés). Connecte ce calculateur pour trouver son fichier.</span>`);
    else if (!cat) infos = sec("Base de libellés", `<span style="color:#B9BFC7">Aucun fichier de libellés pour ${esc(m.ident.partNumber)}.</span>`);
    else {
      const cod = cat.coding;
      infos =
        sec("Fichier de libellés", `<span style="font-weight:600">${esc(cat.lbl.file)}</span><span style="color:#8A9099">${esc(cat.lbl.component)} · ${esc(cat.lbl.vehicle)} · trouvé par ${esc(cat.lbl.via)}</span>`) +
        (cod ? sec(`Codage ${m.ident.coding != null ? String(m.ident.coding).padStart(5, "0") : ""} · ${esc(cod.title)}`, cod.sections.map((x) => `<span><b>${esc(x.mask)}</b> ${esc(x.title)}${x.value != null ? " = " + x.value : ""}</span>${x.active.map((a) => `<span style="color:#7BD88F;padding-left:10px">${esc(a)}</span>`).join("")}`).join("")) : "") +
        (cat.adaptation.length ? sec("Canaux d'adaptation (lecture seule pour l'instant)", cat.adaptation.map((a) => `<span><b>${pad3(a.channel)}</b> ${esc(a.title)}</span>${a.lines.slice(0, 3).map((l) => `<span style="color:#8A9099;padding-left:10px">${esc(l)}</span>`).join("")}`).join("")) : "") +
        (cat.login.length ? sec("Codes d'accès (login)", cat.login.map((l) => `<span style="color:#C9CED4">${esc(l)}</span>`).join("")) : "");
    }
    this.view.set({
      sub: `${V.port ? "Câble " + V.port : "Câble KKL non ouvert"} · ${V.connected ? `en ligne avec ${V.connected.toString(16).toUpperCase().padStart(2, "0")} (${V.protocol})` : "au repos"}${busy ? " · " + busy + prog : ""}${srcs ? " · source " + srcs : ""}`,
      mods: modsHtml,
      scanLbl: V.scan ? `Arrêter le scan (${V.scan.index}/${V.scan.total})` : "Scanner tous les calculateurs",
      scanBorder: V.scan ? "#F5B841" : "#4FD1E8",
      scanning: !!V.scan,
      scanTxt: V.scan ? `Interroge ${V.scan.addr.toString(16).toUpperCase().padStart(2, "0")} · ${V.scan.name} · ${V.scan.found} trouvé${V.scan.found > 1 ? "s" : ""}` : "",
      openLbl: V.connected === this.addr ? "Reconnecter" : opBusy ? "Connexion…" : "Connecter",
      openBorder: V.connected === this.addr ? "#7BD88F" : opErr ? "#FF4D2E" : "#4A5058",
      opTxt: opText,
      opCol: opErr ? "#FF8A73" : opBusy ? "#4FD1E8" : "#7BD88F",
      mName: `${m.hex} · ${m.name}`,
      mSub: `${STATUS[m.status]}${m.protocol ? " · " + m.protocol : ""}${m.error ? " · " + m.error : ""}`,
      ident,
      showIdent: this.tab === "defauts" || this.tab === "infos",
      defLbl: `Défauts${m.faults?.length ? " (" + m.faults.length + ")" : ""}`,
      tDef: this.tab === "defauts" ? "page" : "false",
      tMes: this.tab === "mesures" ? "page" : "false",
      tAll: this.tab === "tout" ? "page" : "false",
      isDef: this.tab === "defauts", isMes: this.tab === "mesures", isAll: this.tab === "tout", isMul: this.tab === "multi",
      tMul: this.tab === "multi" ? "page" : "false",
      tCan: this.tab === "can" ? "page" : "false",
      isCan: this.tab === "can",
      ...this.canVals(app),
      ...this.findVals(app),
      mulTab: V.multi ? "● Multi" : `Multi${this.multi.length ? " (" + this.multi.length + ")" : ""}`,
      mAddLbl: this.multi.some((x) => x.addr === this.addr && x.group === this.groupNo) ? "− Multi" : "+ Multi",
      mRunLbl: V.multi ? "Arrêter la lecture multiple" : "Démarrer la lecture multiple",
      mRunBorder: V.multi ? "#F5B841" : "#4FD1E8",
      mState: V.multi ? (V.multi.error ? "Erreur " + V.multi.error : `En cours${V.multi.current ? " · sur " + V.multi.current.toString(16).toUpperCase().padStart(2, "0") : ""}${V.multi.cycleMs ? ` · un tour en ${(V.multi.cycleMs / 1000).toFixed(1)} s` : ""}`) : this.multi.length ? "Arrêtée" : "",
      mStateCol: V.multi?.error ? "#FF8A73" : V.multi ? "#4FD1E8" : "#8A9099",
      mItems: this.multi.length
        ? this.multi.map((it, i) => {
            const mm = mods.find((x) => x.addr === it.addr);
            const gg = mm?.groups?.[it.group];
            const age = gg ? (Date.now() - gg.at) / 1000 : null;
            const on = V.multi && V.multi.current === it.addr;
            const vals = gg ? gg.fields.map((f) => `<span style="display:flex;justify-content:space-between;gap:8px;font-size:12px"><span style="color:#C9CED4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.label)}</span><span class="num" style="flex:none">${esc(f.text)} <span style="color:#9AA1AA;font-size:10px">${esc(f.unit === "bits" ? "" : f.unit)}</span></span></span>`).join("") : `<span style="font-size:12px;color:#8A9099">Pas encore lu</span>`;
            return `<div style="display:flex;flex-direction:column;gap:3px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid ${on ? "rgba(79,209,232,.6)" : "#33373E"}">
              <span style="display:flex;align-items:center;justify-content:space-between;gap:8px"><span style="font-size:12px;font-weight:700">${it.addr.toString(16).toUpperCase().padStart(2, "0")} · ${esc(mm?.short || "")} · groupe ${pad3(it.group)}</span>
              <span style="display:flex;align-items:center;gap:8px"><span class="lbl" style="font-size:9px">${age == null ? "" : age < 1 ? "à l'instant" : "il y a " + Math.round(age) + " s"}</span><button type="button" class="ib" data-on="click:mDel" data-i="${i}" aria-label="Retirer" style="min-width:32px;height:28px;font-size:14px">×</button></span></span>${vals}</div>`;
          }).join("")
        : `<span style="font-size:13px;color:#8A9099">Aucun groupe. Dans Mesures, choisis un groupe puis « + Multi » ; recommence pour l'ABS, le combiné…</span>`,
      faults,
      clearLbl: this.clearArmed ? "Touche encore pour effacer" : "Effacer les codes",
      clearBorder: this.clearArmed ? "#F5B841" : "#4A5058",
      gNum: pad3(this.groupNo),
      gTitle: g?.title || (cat?.measuring.find((x) => x.grp === this.groupNo)?.title ?? ""),
      hasMesList: !!cat?.measuring.length,
      mesOpts: cat ? `<option value="">Groupes nommés…</option>` + cat.measuring.map((x) => `<option value="${x.grp}"${x.grp === this.groupNo ? " selected" : ""}>${pad3(x.grp)} · ${esc(x.title)}</option>`).join("") : "",
      tBas: this.tab === "base" ? "page" : "false",
      tAct: this.tab === "actionneurs" ? "page" : "false",
      tInf: this.tab === "infos" ? "page" : "false",
      isBas: this.tab === "base", isAct: this.tab === "actionneurs", isInf: this.tab === "infos",
      bNum: pad3(this.basicNo),
      bTitle: bg?.title || (cat?.basic.find((x) => x.grp === this.basicNo)?.title ?? (cat ? "" : "Sans base de libellés : choisis le groupe à la main (060 = papillon du moteur)")),
      hasBasList: !!cat?.basic.length,
      basOpts: cat ? `<option value="">Réglages de base connus…</option>` + cat.basic.map((x) => `<option value="${x.grp}"${x.grp === this.basicNo ? " selected" : ""}>${pad3(x.grp)} · ${esc(x.title)}</option>`).join("") : "",
      bRunLbl: this.basicRun ? "Arrêter" : "Lancer",
      bRunBorder: this.basicRun ? "#4FD1E8" : "#4A5058",
      bFields: bg ? bg.fields.map((f, i) => fieldRow(f, i, this.basicNo)).join("") : `<span style="font-size:13px;color:#8A9099">${this.basicRun ? "Réglage de base en cours…" : "Choisis le groupe puis « Lancer ». Le calculateur fait la procédure tant que Nova la lui demande ; « Arrêter » revient en lecture normale."}</span>`,
      outLbl: busy.startsWith("Test des actionneurs") ? "Actionneur en cours…" : (m.outputs?.length && m.outputs[m.outputs.length - 1].code > 0 ? "Actionneur suivant" : "Démarrer le test des actionneurs"),
      outs: (m.outputs || []).slice().reverse().map((o, k) => `<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid ${k === 0 ? "rgba(79,209,232,.6)" : "#33373E"}"><span class="num" style="font-size:13px;color:${o.code < 0 ? "#FF8A73" : "#4FD1E8"}">${o.code > 0 ? String(o.code).padStart(5, "0") : o.code < 0 ? "ERR" : "FIN"}</span><span style="font-size:13px;font-weight:600">${esc(o.text)}</span></div>`).join("") || `<span style="font-size:13px;color:#8A9099">Aucun actionneur testé.</span>`,
      infos,
      fields,
      liveLbl: this.live ? (app.vag?.reconnecting ? "Reconnexion…" : "Arrêter") : "En continu",
      liveBorder: this.live ? "#4FD1E8" : "#4A5058",
      allTxt: busy.startsWith("Lecture complète") ? `Lecture en cours${prog}` : `${gs.length} groupe${gs.length > 1 ? "s" : ""} en mémoire · rapport CSV dans Nova/diagnostics`,
      all,
      steps,
      tSum: t?.summary || (t?.running ? "Test en cours…" : ""),
      tCol: failed ? "#F5B841" : "#7BD88F",
      tAdv: t?.advice || "",
      testLbl: t?.running ? "Test en cours…" : "Tester la connexion",
      trace: esc((V.trace || []).slice(-30).reverse().join("\n")),
    });
  },
};
