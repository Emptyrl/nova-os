// Tableau de bord (maquette « Tableau ») sur les vraies mesures.
import { View, fr, thousands, hhmm, navHtml } from "../bind.js";

const F = "font-family=\"Chakra Petch, system-ui, sans-serif\"";
const segs = Array.from({ length: 28 }, (_, i) => `<div style="border-radius:1px" data-s="background:sc${i};box-shadow:sg${i}"></div>`).join("");

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;height:32px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;align-items:baseline;gap:18px">
      <span class="num" style="font-size:20px" data-t="clock"></span>
      <span class="lbl" style="letter-spacing:.08em">Ext. <span class="num" style="font-size:14px" data-t="ext"></span></span>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <span style="width:8px;height:8px;border-radius:50%" data-s="background:modeDot"></span>
      <span class="lbl" style="color:#D6DBE1">Mode <span data-t="modeName"></span></span>
      <span class="lbl" style="letter-spacing:.08em;margin-left:10px">Passage <span data-t="strat"></span> · <span class="num" style="font-size:13px" data-t="recTxt"></span></span>
    </div>
    <div style="display:flex;align-items:baseline;gap:18px">
      <span class="lbl" style="letter-spacing:.08em">Trajet <span class="num" style="font-size:14px" data-t="trip"></span></span>
      <span class="lbl" style="letter-spacing:.08em"><span class="num" style="font-size:14px" data-t="odo"></span> km</span>
    </div>
  </div>

  <div style="position:absolute;left:30px;top:68px;width:340px;height:340px">
    <div class="bezel"></div><div class="face"></div>
    <svg width="340" height="340" viewBox="0 0 340 340" style="position:absolute;inset:0" role="img" data-a="aria-label:qAria">
      <text x="170" y="40" fill="#7E858F" font-size="11" font-weight="600" letter-spacing="2" text-anchor="middle" ${F}>QUATTRO</text>
      <line x1="170" y1="112" x2="170" y2="230" stroke="#4A5058" stroke-width="4"></line>
      <line x1="170" y1="112" x2="170" y2="230" stroke="#FF4D2E" stroke-width="4" stroke-dasharray="8 8" data-a="stroke-dashoffset:flow;opacity:flowOp"></line>
      <line x1="118" y1="100" x2="222" y2="100" stroke="#5A616B" stroke-width="3"></line>
      <line x1="118" y1="240" x2="222" y2="240" stroke="#5A616B" stroke-width="3"></line>
      <rect x="132" y="62" width="76" height="216" rx="34" fill="#2A2E34" stroke="#B9BFC7" stroke-width="2"></rect>
      <rect x="142" y="128" width="56" height="78" rx="18" fill="#15171B" stroke="#6B727C" stroke-width="1.5"></rect>
      <rect class="wheel" x="104" y="78" width="20" height="44" rx="6" fill="#F1F3F5" data-a="fill-opacity:wF" stroke="#D6DBE1" stroke-width="1.5"></rect>
      <rect class="wheel" x="216" y="78" width="20" height="44" rx="6" fill="#F1F3F5" data-a="fill-opacity:wF" stroke="#D6DBE1" stroke-width="1.5"></rect>
      <rect class="wheel" x="104" y="218" width="20" height="44" rx="6" fill="#FF4D2E" data-a="fill-opacity:wR" stroke="#D6DBE1" stroke-width="1.5"></rect>
      <rect class="wheel" x="216" y="218" width="20" height="44" rx="6" fill="#FF4D2E" data-a="fill-opacity:wR" stroke="#D6DBE1" stroke-width="1.5"></rect>
      <text x="70" y="104" fill="#F1F3F5" font-size="22" font-weight="700" text-anchor="middle" ${F} data-t="front"></text>
      <text x="70" y="124" fill="#7E858F" font-size="10" font-weight="600" letter-spacing="2" text-anchor="middle" ${F}>AVANT</text>
      <text x="270" y="244" fill="#FF6B4E" font-size="22" font-weight="700" text-anchor="middle" ${F} data-t="rear"></text>
      <text x="270" y="264" fill="#7E858F" font-size="10" font-weight="600" letter-spacing="2" text-anchor="middle" ${F}>ARRIÈRE</text>
      <text x="170" y="304" fill="#B9BFC7" font-size="12" font-weight="600" letter-spacing="1.5" text-anchor="middle" ${F}>HALDEX · ESTIMATION</text>
    </svg>
  </div>

  <div style="position:absolute;right:30px;top:68px;width:340px;height:340px">
    <div class="bezel"></div><div class="face"></div>
    <svg width="340" height="340" viewBox="0 0 340 340" style="position:absolute;inset:0" role="img" data-a="aria-label:gAria">
      <circle cx="170" cy="170" r="125" fill="none" stroke="#4A5058" stroke-width="1.5"></circle>
      <circle cx="170" cy="170" r="83" fill="none" stroke="#3A3F46" stroke-width="1.5"></circle>
      <circle cx="170" cy="170" r="42" fill="none" stroke="#3A3F46" stroke-width="1.5" stroke-dasharray="3 5"></circle>
      <line x1="45" y1="170" x2="295" y2="170" stroke="#3A3F46" stroke-width="1.5"></line>
      <line x1="170" y1="45" x2="170" y2="295" stroke="#3A3F46" stroke-width="1.5"></line>
      <text x="170" y="80" fill="#6B727C" font-size="10" font-weight="600" text-anchor="middle" ${F}>1,0</text>
      <text x="170" y="122" fill="#6B727C" font-size="10" font-weight="600" text-anchor="middle" ${F}>0,5</text>
      <text x="170" y="40" fill="#7E858F" font-size="11" font-weight="600" letter-spacing="2" text-anchor="middle" ${F}>FREINAGE</text>
      <text x="170" y="310" fill="#7E858F" font-size="11" font-weight="600" letter-spacing="2" text-anchor="middle" ${F}>ACCÉLÉRATION</text>
      <polyline fill="none" stroke="#FF4D2E" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" opacity="0.55" data-a="points:trail"></polyline>
      <circle class="gdot" r="10" fill="#FF4D2E" stroke="#FFFFFF" stroke-width="2" data-a="cx:gx;cy:gy"></circle>
      <text x="170" y="214" fill="#F1F3F5" font-size="26" font-weight="700" text-anchor="middle" ${F} data-t="gTxt"></text>
      <text x="170" y="234" fill="#7E858F" font-size="10" font-weight="600" letter-spacing="2" text-anchor="middle" ${F} data-t="gMax"></text>
    </svg>
  </div>

  <div style="position:absolute;left:384px;width:256px;top:62px;height:356px;display:flex;flex-direction:column;align-items:center;gap:6px">
    <span class="miniwrap mini" role="button" aria-label="Parler à Nova" data-on="click:talk" style="width:120px;height:68px;margin-top:2px;cursor:pointer"><img class="lg pulse-t" src="logo-glow-t.png" alt=""><img src="logo.png" alt="Nova" style="position:relative;display:block;width:120px;height:68px;object-fit:contain"></span>
    <span class="lbl" style="font-size:10px;color:#B9BFC7">Nova · <span data-t="novaState"></span></span>
    <div style="display:flex;flex-direction:column;align-items:center;margin-top:4px">
      <span class="num" style="font-size:88px;line-height:1;letter-spacing:-.02em" data-t="speed"></span>
      <span class="lbl" style="font-size:11px;margin-top:2px">km/h</span>
    </div>
    <div style="display:flex;align-items:center;gap:10px;margin-top:2px">
      <span class="lbl" style="font-size:10px">Rapport</span>
      <span class="num" style="display:flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:10px;border:2px solid;background:#15171B;font-size:28px" data-s="border-color:gearBorder;color:gearColor" data-t="gear"></span>
      <span class="lbl" style="font-size:12px;color:#4FD1E8;transition:opacity 120ms linear" data-s="opacity:upOp" data-t="nextGear"></span>
    </div>
    <div style="width:220px;display:flex;flex-direction:column;gap:5px;margin-top:4px">
      <div style="display:flex;justify-content:space-between;align-items:baseline"><span class="lbl">Régime</span><span class="num" style="font-size:15px"><span data-t="rpmTxt"></span> <span style="font-size:10px;color:#9AA1AA">tr/min</span></span></div>
      <div style="position:relative">
        <div style="display:grid;grid-template-columns:repeat(28, minmax(0, 1fr));gap:2px;height:14px">${segs}</div>
        <div style="position:absolute;top:-4px;bottom:-4px;width:2px;margin-left:-1px;background:#4FD1E8;border-radius:1px" data-s="left:recPos"></div>
      </div>
    </div>
    <div style="width:220px;display:flex;flex-direction:column;gap:5px;margin-top:8px">
      <div style="display:flex;justify-content:space-between;align-items:baseline"><span class="lbl">Turbo</span><span class="num" style="font-size:15px"><span data-t="boost"></span> <span style="font-size:10px;color:#9AA1AA">bar</span></span></div>
      <div style="position:relative;height:8px;border-radius:4px;background:#1A1C20;border:1px solid #3A3F46;overflow:hidden">
        <div style="position:absolute;top:0;bottom:0;transition:background-color 300ms ease" data-s="left:boostLeft;width:boostW;background:boostColor"></div>
        <div style="position:absolute;left:39%;top:0;bottom:0;width:1px;background:#6B727C"></div>
      </div>
      <div style="display:flex;justify-content:space-between" class="lbl"><span style="font-size:9px">−0,7</span><span style="font-size:9px">0</span><span style="font-size:9px">+1,1</span></div>
    </div>
  </div>

  <div style="position:absolute;left:28px;right:28px;top:440px;display:grid;grid-template-columns:repeat(5, minmax(0, 1fr));gap:12px">
    <div class="tile"><span class="lbl">Eau</span><span class="num" style="font-size:24px"><span data-t="water"></span> <span style="font-size:12px;color:#9AA1AA">°C</span></span><div style="height:4px;border-radius:2px;background:#2A2E34"><div style="height:100%;border-radius:2px" data-s="width:waterPct;background:waterCol"></div></div></div>
    <div class="tile"><span class="lbl">Huile</span><span class="num" style="font-size:24px"><span data-t="oil"></span> <span style="font-size:12px;color:#9AA1AA">°C</span></span><div style="height:4px;border-radius:2px;background:#2A2E34"><div style="height:100%;border-radius:2px" data-s="width:oilPct;background:oilCol"></div></div></div>
    <div class="tile"><span class="lbl">E85</span><span class="num" style="font-size:24px"><span data-t="fuel"></span> <span style="font-size:12px;color:#9AA1AA">L</span></span><div style="height:4px;border-radius:2px;background:#2A2E34"><div style="height:100%;border-radius:2px;background:#D6DBE1" data-s="width:fuelPct"></div></div></div>
    <div class="tile"><span class="lbl">Conso</span><span class="num" style="font-size:24px"><span data-t="conso"></span> <span style="font-size:12px;color:#9AA1AA" data-t="consoUnit"></span></span><span class="lbl" style="font-size:9px;letter-spacing:.08em" data-t="avg"></span></div>
    <div class="tile"><span class="lbl">Batterie</span><span class="num" style="font-size:24px"><span data-t="volt"></span> <span style="font-size:12px;color:#9AA1AA">V</span></span><span class="lbl" style="font-size:9px;letter-spacing:.08em" data-t="charge" data-s="color:chargeCol"></span></div>
  </div>

  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("tableau")}
    <span class="lbl" style="font-size:9px;color:#6B727C;max-width:150px;text-align:center" data-t="src"></span>
    <div style="display:flex;gap:10px">
      <button type="button" class="btn" data-on="click:night" data-t="nightLabel" data-a="aria-pressed:nightPressed"></button>
      <button type="button" class="btn" data-on="click:mode">Mode : <span data-t="modeName"></span></button>
    </div>
  </div>
</div>`;

export default {
  id: "tableau",
  perFrame: true, // redessiné à chaque image avec les mesures lissées
  html,
  mount(el, app) {
    this.app = app;
    this.trail = [];
    this.gmax = 0;
    this.flow = 0;
    this.t = 0;
    this.view = new View(el, {
      night: () => app.send({ type: "car.night", on: !app.night }),
      mode: () => app.send({ type: "car.mode", mode: ((app.car.mode ?? 0) + 1) % 3 }),
      talk: () => app.voice.toggle(),
    });
  },
  update() {
    const app = this.app;
    const c = app.car;
    const v = { ...(app.live || {}), gear: c.v?.gear, tripKm: c.v?.tripKm };
    const now = performance.now();
    const dt = Math.min(0.1, (now - (this.lastT || now)) / 1000);
    this.lastT = now;
    const M = app.modes[c.mode ?? 0] || { name: "Normal", dot: "#D6DBE1", strat: "éco" };
    this.t++;
    const rpm = v.rpm ?? 0;
    const gear = v.gear || 0;
    const shiftAt = c.shiftAt || 6000;
    const canUp = gear > 0 && gear < 6 && c.running;
    const flash = canUp && rpm >= shiftAt;
    const blink = flash && Math.floor(now / 120) % 2 === 0;
    const lit = Math.round((rpm / 7000) * 28);
    const vals = {};
    for (let i = 0; i < 28; i++) {
      vals["sc" + i] = blink ? "#4FD1E8" : i < lit ? (i >= 26 ? "#FF4D2E" : i >= 22 ? "#FF8A6E" : "#E6EAEE") : "#2A2E34";
      vals["sg" + i] = blink ? "0 0 8px rgba(79,209,232,.9)" : "none";
    }
    // G-mètre
    const glat = v.glat ?? 0, glong = v.glong ?? 0;
    const tot = Math.sqrt(glat * glat + glong * glong);
    this.gmax = Math.max(this.gmax * Math.pow(0.995, dt * 10), tot);
    if (now - (this.trailT || 0) > 50) {
      this.trailT = now;
      this.trail = this.trail.concat([[glat, glong]]).slice(-24);
    }
    const gp = (la, lo) => [(170 + Math.max(-1.4, Math.min(1.4, la)) * 83).toFixed(1), (170 - Math.max(-1.4, Math.min(1.4, lo)) * 83).toFixed(1)];
    const [gx, gy] = gp(glat, glong);
    // turbo
    const hasBoost = v.boost != null;
    const b = Math.max(-0.7, Math.min(1.1, v.boost ?? -0.7));
    const zero = 0.7 / 1.8, pos = (b + 0.7) / 1.8;
    const hal = Math.round(v.haldex ?? 4);
    const thr = v.pedal ?? v.throttle ?? 0;
    this.flow = (this.flow - (2 + hal / 10) * dt * 10) % 16;
    const speed = v.speed ?? 0;
    const water = v.water, oil = v.oil, volt = v.volt;
    const nova = app.nova.mode;
    Object.assign(vals, {
      clock: hhmm(),
      ext: v.ext != null ? `${Math.round(v.ext)} °C` : "—",
      modeDot: M.dot, modeName: M.name, strat: M.strat,
      recTxt: `${thousands(shiftAt)} tr/min`,
      trip: `${fr(v.tripKm, 1)} km`,
      odo: thousands(c.odo),
      trail: this.trail.map(([la, lo]) => gp(la, lo).join(",")).join(" "),
      gx, gy,
      gTxt: `${fr(tot, 2)} g`,
      gMax: `MAX ${fr(this.gmax, 2)} g`,
      gAria: `Accélérations : ${fr(tot, 2)} g`,
      front: `${100 - hal}%`, rear: `${hal}%`,
      qAria: `Répartition estimée : avant ${100 - hal} %, arrière ${hal} %`,
      wF: (0.25 + ((100 - hal) / 100) * 0.75).toFixed(2),
      wR: (0.12 + (hal / 100) * 0.88).toFixed(2),
      flow: this.flow.toFixed(1), flowOp: thr > 50 ? 1 : 0.25,
      novaState: { idle: c.running ? "surveille" : "en veille", listen: "écoute", think: "réfléchit", speak: "parle" }[nova] || "surveille",
      speed: v.speed == null ? "—" : Math.round(speed),
      gear: gear ? String(gear) : "N",
      gearColor: rpm > 6600 ? "#FF4D2E" : "#F1F3F5",
      gearBorder: flash ? "#4FD1E8" : "#B9BFC7",
      nextGear: canUp ? `▲ ${gear + 1}` : "",
      upOp: flash ? 1 : 0,
      rpmTxt: v.rpm == null ? "—" : thousands(Math.round(rpm / 10) * 10),
      recPos: ((shiftAt / 7000) * 100).toFixed(1) + "%",
      boost: hasBoost ? (b >= 0 ? "+" : "−") + fr(Math.abs(b), 2) : "—",
      boostLeft: hasBoost ? (Math.min(pos, zero) * 100).toFixed(1) + "%" : "0%",
      boostW: hasBoost ? (Math.abs(pos - zero) * 100).toFixed(1) + "%" : "0%",
      boostColor: b > 0 ? "#F1F3F5" : "#6B727C",
      water: water == null ? "—" : Math.round(water),
      waterPct: water == null ? "0%" : Math.max(0, Math.min(100, ((water - 40) / 80) * 100)).toFixed(0) + "%",
      waterCol: water >= 105 ? "#FF4D2E" : water >= 100 ? "#F5B841" : "#D6DBE1",
      oil: oil == null ? "—" : Math.round(oil),
      oilPct: oil == null ? "0%" : Math.max(0, Math.min(100, ((oil - 50) / 90) * 100)).toFixed(0) + "%",
      oilCol: oil >= 120 ? "#F5B841" : "#D6DBE1",
      fuel: fr(v.fuel, 1),
      fuelPct: v.fuel == null ? "0%" : Math.round((v.fuel / 62) * 100) + "%",
      conso: speed > 3 ? fr(v.l100, 1) : fr(v.fuelRate, 1),
      consoUnit: speed > 3 ? "l/100" : "l/h",
      avg: c.avgL100 ? `Moy. ${fr(c.avgL100, 1)} l/100` : "Moy. —",
      volt: fr(volt, 1),
      charge: volt == null ? "—" : !c.running ? "Moteur arrêté" : volt < 13.2 ? "Ne charge pas" : volt > 15.1 ? "Surtension" : "Charge OK",
      chargeCol: c.running && volt != null && (volt < 13.2 || volt > 15.1) ? "#F5B841" : "#9AA1AA",
      src: "NOVA ver1.0 · " + (app.sources.map((s) => s.name).join(" + ") || "—") + (app.vag?.multi ? " · diag " + [...new Set(app.vag.multi.items.map((x) => x.addr.toString(16).toUpperCase().padStart(2, "0")))].join("+") : ""),
      nightLabel: app.night ? "Jour" : "Nuit",
      nightPressed: app.night ? "true" : "false",
    });
    this.view.set(vals);
  },
};
