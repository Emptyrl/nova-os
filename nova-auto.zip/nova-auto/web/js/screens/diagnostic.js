// Diagnostic moteur guidé (maquette « Diagnostic ») : étapes pilotées par le serveur, régime en direct.
import { View, esc, fr, thousands, navHtml } from "../bind.js";

const OK = "#7BD88F", WARN = "#F5B841", BAD = "#FF4D2E", IDLE = "#4A5058";
const STEPS = [
  { name: "Préparation", sub: "Moteur chaud, point mort" },
  { name: "Ralenti", sub: "30 s sans toucher" },
  { name: "Régime stable", sub: "3 000 tr/min tenus" },
  { name: "Coup de gaz", sub: "Franc puis relâché" },
  { name: "Résultats", sub: "Analyse de Nova" },
];

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Diagnostic moteur</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em">Test à l'arrêt · point mort · frein à main serré</span>
    </div>
    <div style="display:flex;align-items:center;gap:14px">
      <span class="lbl" style="font-size:10px;color:#6B727C" data-t="src"></span>
      <div style="display:flex;gap:8px" role="group" aria-label="Diagnostic">
        <button type="button" class="tab" aria-current="page">Test moteur</button>
        <button type="button" class="tab" data-go="calculateurs" style="border-color:#4A5058">Calculateurs</button>
      </div>
    </div>
  </div>
  <div style="position:absolute;left:20px;top:84px;width:230px;display:flex;flex-direction:column;gap:8px" data-html="steps"></div>
  <div style="position:absolute;left:266px;width:420px;top:84px;height:420px;display:flex;flex-direction:column;align-items:center;gap:16px;padding:22px 24px;box-sizing:border-box;border-radius:16px;background:rgba(14,16,19,.78);border:1px solid #33373E">
    <img class="mini2" src="logo.png" alt="Nova" style="width:110px;height:62px;object-fit:contain">
    <p style="margin:0;text-align:center;font-weight:600;line-height:1.35;text-wrap:balance;min-height:90px" data-t="say" data-s="font-size:sayFs"></p>
    <div data-show="showGauge" style="width:100%;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;justify-content:space-between;align-items:baseline"><span class="lbl">Régime</span><span class="num" style="font-size:34px"><span data-t="rpm"></span> <span style="font-size:12px;color:#9AA1AA">tr/min</span></span></div>
      <div style="position:relative;height:16px;border-radius:8px;background:#1A1C20;border:1px solid #3A3F46;overflow:hidden">
        <div style="position:absolute;top:0;bottom:0;background:rgba(123,216,143,.28);border-left:2px solid #7BD88F;border-right:2px solid #7BD88F;box-sizing:border-box" data-s="left:zoneL;width:zoneW"></div>
        <div style="position:absolute;left:0;top:3px;bottom:3px;border-radius:5px;transition:background-color 250ms ease" data-s="width:rpmPct;background:barCol"></div>
      </div>
      <div style="display:flex;justify-content:space-between" class="lbl"><span style="font-size:9px">0</span><span style="font-size:9px">2 000</span><span style="font-size:9px">4 000</span><span style="font-size:9px">7 000</span></div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-top:4px">
        <span class="lbl" data-t="zoneTxt" data-s="color:zoneInk"></span>
        <div style="width:140px;height:6px;border-radius:3px;background:#2A2E34;overflow:hidden"><div style="height:100%;background:#7BD88F;transition:width 260ms cubic-bezier(.33,0,.2,1)" data-s="width:holdPct"></div></div>
      </div>
    </div>
    <div data-show="showStart" style="margin-top:auto;display:flex;gap:10px">
      <button type="button" class="btn-cyan" data-on="click:start" data-t="startLabel"></button>
      <button type="button" class="btn" data-show="showAsk" data-on="click:ask">Demander à Nova</button>
    </div>
    <button type="button" class="btn" data-show="showCancel" data-on="click:cancel" style="margin-top:auto">Annuler</button>
  </div>
  <div style="position:absolute;left:702px;right:20px;top:84px;height:420px;display:flex;flex-direction:column;gap:7px">
    <span class="lbl" data-t="rightTitle"></span>
    <div data-html="meas" style="display:flex;flex-direction:column;gap:7px"></div>
  </div>
  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("diagnostic")}
    <span class="lbl" style="font-size:9px;letter-spacing:.06em;max-width:330px;text-align:right">Test en charge (turbo réel / demandé) : pleine charge en 3e, sur circuit ou route fermée uniquement</span>
  </div>
</div>`;

export default {
  id: "diagnostic",
  html,
  mount(el, app) {
    this.app = app;
    this.view = new View(el, {
      start: () => app.send({ type: "diag.start" }),
      cancel: () => app.send({ type: "diag.cancel" }),
      ask: () => app.send({ type: "diag.ask" }),
    });
  },
  frame() {
    const d = this.app.diag || { step: -1 };
    if (!(d.step >= 1 && d.step <= 3)) return;
    const rpm = this.app.live?.rpm ?? 0;
    const zone = d.zone;
    const inZone = zone && rpm >= zone[0] && rpm <= zone[1];
    this.view.set({
      rpm: thousands(Math.round(rpm / 10) * 10),
      rpmPct: Math.min(100, rpm / 70).toFixed(2) + "%",
      barCol: inZone ? OK : "#E6EAEE",
      zoneInk: inZone ? OK : "#B9BFC7",
    });
  },
  update() {
    const app = this.app;
    const d = app.diag || { step: -1 };
    const v = app.car.v || {};
    const step = d.step ?? -1;
    const steps = STEPS.map((st, i) => {
      const done = i < step || (step === 4 && i === 4), cur = i === step && step !== 4;
      return `<div style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:12px;background:${cur ? "rgba(79,209,232,.08)" : "rgba(20,22,26,.6)"};border:1px solid ${cur ? "rgba(79,209,232,.5)" : "#33373E"}">
        <span class="${cur ? "cur" : ""}" style="flex:none;display:flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;border:2px solid ${done ? OK : cur ? "#4FD1E8" : IDLE};background:${done ? "rgba(123,216,143,.18)" : cur ? "rgba(79,209,232,.16)" : "transparent"};font-size:13px;font-weight:700;color:${done ? OK : cur ? "#FFFFFF" : "#8A9099"}">${done ? "✓" : i + 1}</span>
        <span style="display:flex;flex-direction:column;gap:1px;min-width:0"><span style="font-size:14px;font-weight:600;color:${cur || done ? "#F1F3F5" : "#8A9099"}">${st.name}</span><span class="lbl" style="font-size:9px;letter-spacing:.06em">${st.sub}</span></span></div>`;
    }).join("");
    const rpm = v.rpm ?? 0;
    const zone = d.zone;
    const inZone = zone && rpm >= zone[0] && rpm <= zone[1];
    const row = (m) => `<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 12px;border-radius:10px;background:rgba(20,22,26,.75);border:1px solid #33373E">
      <span style="display:flex;flex-direction:column;min-width:0"><span style="font-size:13px;font-weight:600;color:#E6EAEE">${esc(m.name)}</span><span class="lbl" style="font-size:9px;letter-spacing:.04em;text-transform:none;color:#8A9099">${esc(m.hint)}</span></span>
      <span style="display:flex;align-items:center;gap:8px;flex:none"><span class="num" style="font-size:15px">${esc(m.val)}</span><span style="width:10px;height:10px;border-radius:50%;background:${m.dot}"></span></span></div>`;
    let meas;
    if (step === 0) meas = (d.checks || []).map((c) => row({ name: c.name, hint: "Vérification", val: c.val, dot: c.ok === true ? OK : c.ok === false ? WARN : IDLE })).join("");
    else if (step === 4) meas = (d.results || []).map((r) => row({ ...r, dot: { ok: OK, warn: WARN, bad: BAD, na: IDLE }[r.grade] })).join("");
    else {
      const sign = (x) => (x == null ? "—" : (x >= 0 ? "+" : "") + fr(x, 1) + " %");
      const trim = v.stft != null || v.ltft != null ? (v.stft ?? 0) + (v.ltft ?? 0) : null;
      meas = [
        { name: "Régime", hint: "Calculateur moteur", val: v.rpm == null ? "—" : thousands(Math.round(rpm / 10) * 10) + " tr/min" },
        { name: "Débit d’air", hint: "Débitmètre", val: v.maf == null ? "—" : fr(v.maf, 1) + " g/s" },
        { name: "Correction de richesse", hint: "Courte + longue", val: sign(trim) },
        { name: "Avance à l’allumage", hint: "Moyenne 4 cylindres", val: v.timing == null ? "—" : fr(v.timing, 1) + "°" },
        { name: "Recul d’allumage", hint: "Cliquetis (câble KKL)", val: v.knock == null ? "—" : fr(v.knock, 1) + "°" },
        { name: "Température d’eau", hint: "Moteur", val: v.water == null ? "—" : Math.round(v.water) + " °C" },
        { name: "Tension batterie", hint: "Bord", val: v.volt == null ? "—" : fr(v.volt, 1) + " V" },
      ].map((m) => row({ ...m, dot: IDLE })).join("");
    }
    const say = d.say || "";
    this.view.set({
      src: "ME7.5 · " + (app.sources.map((s) => s.name).join(" + ") || "—"),
      steps, say, meas,
      sayFs: say.length > 140 ? "17px" : "22px",
      rightTitle: step === 4 ? "Résultats" : step === 0 ? "Vérifications" : "Mesures en direct",
      showGauge: step >= 1 && step <= 3,
      showStart: step === -1 || step === 4,
      showAsk: step === 4,
      showCancel: step >= 0 && step <= 3,
      startLabel: step === 4 ? "Refaire" : "Lancer le diagnostic",

      zoneL: zone ? (zone[0] / 70).toFixed(1) + "%" : "0%",
      zoneW: zone ? ((zone[1] - zone[0]) / 70).toFixed(1) + "%" : "0%",
      zoneTxt: d.zoneTxt || "",
      holdPct: Math.min(100, (d.hold || 0) * 100).toFixed(0) + "%",
    });
  },
};
