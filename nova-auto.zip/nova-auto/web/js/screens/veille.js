// Écran de veille (maquette « VeilleFluide ») : le logo flotte, écoute et parle avec Nova.
import { View } from "../bind.js";

const html = `
<div style="position:absolute;inset:0;background:radial-gradient(ellipse 65% 60% at 50% 44%, #5A616B 0%, #353A42 38%, #1C1F24 72%, #0E1013 100%)" data-on="click:bg">
  <div style="position:absolute;left:50%;top:44%;transform:translate(-50%,-50%)">
    <button type="button" class="core" data-on="click:toggle" data-a="aria-label:aria" style="display:block;width:420px;height:236px;border:0;background:transparent;padding:0;cursor:pointer">
      <div class="fl" data-s="animation-play-state:floatState">
        <div data-s="transform:xf;transition:tr" style="will-change:transform">
          <div class="br" style="width:420px;height:236px">
            <img class="lg pulse-w" src="logo-glow-w.png" alt="">
            <img class="lg" src="logo-glow-w.png" alt="" data-s="opacity:boost;transition:otr" style="opacity:0">
            <img class="lg" src="logo-shadow.png" alt="" style="will-change:auto">
            <img class="lg pulse-t" src="logo-glow-t.png" alt="">
            <img src="logo.png" alt="" style="position:relative;display:block;width:420px;height:236px;object-fit:contain">
            <img class="lg" src="logo-bright.png" alt="" data-s="opacity:bright;transition:otr" style="opacity:0">
            <span class="sh" data-a="class:shCls"><i></i></span>
          </div>
        </div>
      </div>
    </button>
  </div>
  <div style="position:absolute;left:0;right:0;top:466px;display:flex;flex-direction:column;align-items:center;gap:10px;padding:0 80px;box-sizing:border-box">
    <span data-show="offline" style="font-size:16px;font-weight:700;letter-spacing:.34em;text-transform:uppercase;color:#F1F3F5">Connexion…</span>
  </div>
  <div style="position:absolute;left:0;right:0;bottom:14px;display:flex;justify-content:center">
    <span style="font-size:12px;font-weight:500;letter-spacing:.12em;color:#B9BFC7">NOVA system ver1.0</span>
  </div>
  <button type="button" class="tab" data-on="click:settings" aria-label="Réglages" style="position:absolute;right:14px;bottom:6px;opacity:.55">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#B9BFC7" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"></path></svg>
  </button>
</div>`;

export default {
  id: "veille",
  html,
  mount(el, app) {
    this.app = app;
    this.view = new View(el, {
      toggle: () => app.voice.toggle(),
      bg: () => app.go("tableau"),
      settings: () => app.go("reglages"),
    });
    // animation fluide : niveau de voix et « coups » sur chaque mot, à chaque image.
    // Au repos rien ne bouge : on ne recalcule que 5 fois par seconde (moins de travail pour le vieux PC).
    let lastIdle = 0;
    const loop = (t) => {
      if (this.visible && (this.app.nova.mode !== "idle" || t - lastIdle > 200)) {
        lastIdle = t;
        this.render();
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  },
  show() {
    this.visible = true;
  },
  hide() {
    this.visible = false;
  },
  render() {
    const n = this.app.nova;
    const m = n.mode;
    let sc = 1, ty = 0, bri = 1, ng = 0, tr;
    if (m === "speak") {
      const k = n.kick;
      sc = 1 + k * 0.025;
      ty = -k * 2;
      bri = 1 + k * 0.12 + n.level * 0.04;
      ng = k * 10 + n.level * 3;
      tr = k ? "transform 150ms cubic-bezier(.33,0,.2,1), filter 150ms cubic-bezier(.33,0,.2,1)" : "transform 450ms cubic-bezier(.37,0,.63,1), filter 500ms cubic-bezier(.37,0,.63,1)";
    } else if (m === "listen") {
      const l = n.micLevel;
      sc = 1.04 + l * 0.006;
      ty = -4;
      bri = 1.04 + l * 0.1;
      ng = 4 + l * 16;
      tr = "transform 700ms cubic-bezier(.37,0,.63,1), filter 160ms linear";
    } else if (m === "think") {
      const p = (Math.sin(performance.now() / 260) + 1) / 2;
      sc = 1.02;
      ty = -2;
      bri = 1.02 + p * 0.06;
      ng = 3 + p * 8;
      tr = "transform 700ms cubic-bezier(.37,0,.63,1), filter 120ms linear";
    } else tr = "transform 700ms cubic-bezier(.37,0,.63,1), filter 500ms ease-out";
    this.view.set({
      offline: !this.app.connected,
      floatState: m === "listen" ? "paused" : "running",
      xf: `translateY(${ty.toFixed(1)}px) scale(${sc.toFixed(4)})`,
      boost: Math.min(1, ng / 16).toFixed(2),
      bright: Math.min(0.7, Math.max(0, (bri - 1) * 4)).toFixed(2),
      otr: m === "speak" && n.kick ? "opacity 120ms ease-out" : "opacity 420ms cubic-bezier(.33,0,.2,1)",
      tr: tr.split(", filter")[0],
      shCls: m === "think" ? "sh fast" : "sh",
      aria: m === "idle" ? "Parler à Nova" : "Mettre Nova en veille",
    });
  },
};
