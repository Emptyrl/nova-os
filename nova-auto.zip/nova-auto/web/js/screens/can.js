// Bus CAN : écoute du bus (CANable ou ELM327 relié à CAN-H / CAN-L), sans jamais rien y envoyer.
// Liste des messages en grand, octets qui bougent en bleu, messages décodés en vert.
import { View, esc, navHtml } from "../bind.js";
import { diagTabs } from "../multi.js";

const panel = "border-radius:14px;background:rgba(14,16,19,.78);border:1px solid #33373E";
const NAMES = { rpm: "Régime", water: "Eau", oil: "Huile", iat: "Air admission", ext: "Extérieur", speed: "Vitesse", wfl: "Roue AVG", wfr: "Roue AVD", wrl: "Roue ARG", wrr: "Roue ARD", fuel: "Carburant", load: "Charge", throttle: "Papillon", pedal: "Pédale", haldex: "Haldex", volt: "Batterie", boost: "Turbo", maf: "Débit d'air", timing: "Avance" };
const UNITS = { rpm: "tr/min", water: "°C", oil: "°C", iat: "°C", ext: "°C", speed: "km/h", wfl: "km/h", wfr: "km/h", wrl: "km/h", wrr: "km/h", fuel: "l", load: "%", throttle: "%", pedal: "%", haldex: "%", volt: "V", boost: "mbar", maf: "g/s", timing: "°" };

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:28px;right:28px;top:16px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;flex-direction:column;gap:2px">
      <span style="font-size:22px;font-weight:700;letter-spacing:.06em">Bus CAN</span>
      <span class="lbl" style="font-size:10px;letter-spacing:.08em" data-t="sub"></span>
    </div>
    ${diagTabs("can")}
  </div>

  <div style="position:absolute;left:20px;top:76px;width:260px;height:430px;${panel};padding:14px;box-sizing:border-box;display:flex;flex-direction:column;gap:9px">
    <span style="font-size:13px;font-weight:600;line-height:1.35" data-t="state" data-s="color:stateCol"></span>
    <span style="font-size:11px;line-height:1.4;color:#C9CED4" data-t="useLbl"></span>
    <button type="button" class="btn" style="font-size:11px" data-go="reglages">Choisir le câble (Réglages → Voiture)</button>
    <span class="lbl" style="font-size:9px;margin-top:2px">Afficher</span>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <button type="button" class="tab" data-on="click:filt" data-v="tout" data-a="aria-current:fAll" style="min-height:32px;font-size:10px;padding:0 10px">Tout</button>
      <button type="button" class="tab" data-on="click:filt" data-v="bouge" data-a="aria-current:fMove" style="min-height:32px;font-size:10px;padding:0 10px">Qui bougent</button>
      <button type="button" class="tab" data-on="click:filt" data-v="decode" data-a="aria-current:fDec" style="min-height:32px;font-size:10px;padding:0 10px">Décodés</button>
    </div>
    <span class="lbl" style="font-size:9px;margin-top:2px">Valeurs lues sur le bus</span>
    <div class="scroll" data-html="values" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:4px"></div>
    <span style="font-size:10px;line-height:1.4;color:#8A9099">Écoute seule : Nova n'envoie jamais rien sur ce bus. Pour apprendre une nouvelle valeur : Calculateurs → Mesures → bouton « CAN » à côté d'une mesure.</span>
  </div>

  <div style="position:absolute;left:294px;right:20px;top:76px;height:430px;${panel};padding:10px 12px;box-sizing:border-box;display:flex;flex-direction:column;gap:6px">
    <div style="display:grid;grid-template-columns:52px minmax(0,1fr) 150px 54px;gap:10px;padding:0 8px" class="lbl"><span style="font-size:9px">ID</span><span style="font-size:9px">Octets</span><span style="font-size:9px">Décodé</span><span style="font-size:9px;text-align:right">Reçus</span></div>
    <div class="scroll" data-html="ids" style="flex:1;min-height:0;display:flex;flex-direction:column;gap:3px;font-family:ui-monospace,monospace;font-size:13px"></div>
  </div>

  <div style="position:absolute;left:20px;right:28px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("diagnostic")}
    <span class="lbl" style="font-size:9px;letter-spacing:.06em;text-align:right">En bleu : octets qui bougent · en vert : messages décodés</span>
  </div>
</div>`;

export default {
  id: "can",
  html,
  mount(el, app) {
    this.app = app;
    this.el = el;
    this.filter = "tout";
    this.view = new View(el, {
      filt: (b) => ((this.filter = b.dataset.v), this.update()),
    });
    setInterval(() => {
      if (this.visible) app.send({ type: "can.view" });
    }, 1000);
    setInterval(() => {
      if (this.visible) app.send({ type: "sys.get" });
    }, 3000);
  },
  show() {
    this.visible = true;
    this.app.send({ type: "can.view" });
    this.app.send({ type: "can.findGet" });
  },
  hide() {
    this.visible = false;
  },
  update() {
    const app = this.app;
    const C = app.can || {};
    const v = C.view;
    const using = /can/.test(C.config?.source || "") || C.config?.elmMode === "can" || !!v;
    let ids = v?.ids || [];
    const total = ids.length;
    if (this.filter === "bouge") ids = ids.filter((e) => e.changed);
    else if (this.filter === "decode") ids = ids.filter((e) => e.decoded);
    const fmt = (x) => (Math.abs(x) >= 100 ? Math.round(x) : Math.round(x * 10) / 10).toLocaleString("fr-FR");
    const decTxt = (d) => Object.entries(d || {}).filter(([k]) => k !== "fuelSensor").map(([k, x]) => `${NAMES[k] || k} ${fmt(x)}`).join(" · ");
    // dernières valeurs connues, tous messages confondus
    const vals = {};
    for (const e of v?.ids || []) for (const [k, x] of Object.entries(e.decoded || {})) if (k !== "fuelSensor" && Number.isFinite(x)) vals[k] = x;
    const customs = app.canFind?.customs || [];
    const values = Object.keys(vals).length
      ? Object.entries(vals)
          .map(([k, x]) => `<div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px;padding:4px 8px;border-radius:8px;background:rgba(20,22,26,.75)"><span style="font-size:12px;color:#C9CED4">${esc(NAMES[k] || k)}</span><span class="num" style="font-size:17px;color:#7BD88F">${fmt(x)} <span style="font-size:10px;color:#9AA1AA">${esc(UNITS[k] || "")}</span></span></div>`)
          .join("") +
        (customs.length ? `<span class="lbl" style="font-size:8px;margin-top:4px">Appris par comparaison : ${customs.map((c) => esc(c.label)).join(", ")}</span>` : "")
      : `<span style="font-size:12px;color:#8A9099">Rien de décodé pour l'instant.</span>`;
    const rows = ids.length
      ? ids
          .map((e) => {
            const bytes = e.bytes.map((b, i) => `<span style="color:${e.changed & (1 << i) ? "#4FD1E8" : "#C9CED4"}">${b.toString(16).toUpperCase().padStart(2, "0")}</span>`).join(" ");
            const stale = e.age >= 3000;
            return `<div style="display:grid;grid-template-columns:52px minmax(0,1fr) 150px 54px;gap:10px;align-items:center;padding:5px 8px;border-radius:7px;background:rgba(20,22,26,.75);border:1px solid ${e.decoded ? "rgba(123,216,143,.35)" : "#2C3036"};opacity:${stale ? 0.5 : 1}"><span style="color:${e.decoded ? "#7BD88F" : "#8A9099"}">${e.idHex}</span><span style="white-space:nowrap;overflow:hidden">${bytes}</span><span style="font-family:system-ui;font-size:11px;color:#9FB4C8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(decTxt(e.decoded))}</span><span style="color:#6B727C;text-align:right">${stale ? "—" : e.count}</span></div>`;
          })
          .join("")
      : `<span style="font-family:system-ui;font-size:13px;line-height:1.5;color:#8A9099;padding:8px">${total ? "Aucun message ne correspond à ce filtre." : !v ? "Écoute non démarrée : choisis une source avec le CAN dans Réglages → Voiture (CANable, ou ELM327 sur le CAN)." : "Aucune trame pour l'instant : vérifie CAN-H / CAN-L, la masse, et que le contact est mis."}</span>`;
    this.view.set({
      sub: v ? `${total} identifiant${total > 1 ? "s" : ""}${v.version ? " · " + v.version : ""}` : "écoute non démarrée",
      state: !C.config ? "…" : !v ? (using ? "Adaptateur pas encore trouvé (branché ?)" : "Source CAN non active") : `${v.state === "ok" ? "Écoute en cours" : v.state === "error" ? "Erreur" : "Connexion"} · ${v.detail}`,
      stateCol: v?.state === "ok" ? "#7BD88F" : v?.state === "error" ? "#FF8A73" : "#4FD1E8",
      useLbl: /elmcan/.test(C.config?.source || "") ? `Source : ELM327 sur le CAN${C.config?.elmBt ? " (Bluetooth " + C.config.elmBt + ")" : " (USB)"}` : using ? "Source : adaptateur CAN USB (CANable), écoute seule" : "Pour écouter le CAN : branche le CANable (source Auto), ou Réglages → Voiture → « Adaptateur CAN USB (CANable) + câble KKL ».",
      fAll: this.filter === "tout" ? "page" : "false",
      fMove: this.filter === "bouge" ? "page" : "false",
      fDec: this.filter === "decode" ? "page" : "false",
      values,
      ids: rows,
    });
  },
};
