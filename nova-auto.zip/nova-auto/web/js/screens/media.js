// Média et téléphone (maquette « Média ») : musique du téléphone ou YouTube Music en 4G,
// navigation Waze / Maps du téléphone (scrcpy), notifications lues par Nova.
import { View, esc, hhmm, navHtml } from "../bind.js";
import { keyboard } from "../keyboard.js";

const fmtT = (s) => (Number.isFinite(s) ? Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0") : "0:00");
const COVERS = ["linear-gradient(135deg, #5A616B, #1C1F24 70%)", "linear-gradient(135deg, #4FD1E8 0%, #1E3A44 55%, #0E1013 100%)", "linear-gradient(135deg, #FF4D2E 0%, #4A2620 55%, #0E1013 100%)"];
const TINTS = { WhatsApp: "#7BD88F", SMS: "#D6DBE1", Messages: "#D6DBE1", Snapchat: "#F5B841" };

const html = `
<div class="bg-steel" style="position:absolute;inset:0">
  <div style="position:absolute;left:24px;right:24px;top:14px;height:34px;display:flex;align-items:center;justify-content:space-between">
    <div style="display:flex;align-items:center;gap:14px">
      <span class="num" style="font-size:20px" data-t="clock"></span>
      <span class="lbl" style="letter-spacing:.08em;display:flex;align-items:center;gap:6px">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4FD1E8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7l10 10-5 5V2l5 5L7 17"></path></svg>
        <span data-t="phone"></span>
      </span>
    </div>
    <div style="display:flex;align-items:center;gap:10px">
      <img src="logo.png" alt="" style="width:40px;height:22px;object-fit:contain">
      <span class="lbl" style="color:#D6DBE1" data-t="driveTxt"></span>
    </div>
  </div>

  <div style="position:absolute;left:20px;top:60px;width:470px;height:420px;box-sizing:border-box;padding:20px;border-radius:16px;background:rgba(14,16,19,.78);border:1px solid #33373E;display:flex;flex-direction:column;gap:16px">
    <div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">Musique</span><span class="lbl" style="font-size:9px;letter-spacing:.08em" data-t="source"></span></div>
    <div style="display:flex;gap:18px;align-items:center">
      <div style="flex:none;width:150px;height:150px;border-radius:12px;display:flex;align-items:flex-end;justify-content:flex-start;padding:12px;box-sizing:border-box;box-shadow:0 10px 30px rgba(0,0,0,.5);background-size:cover;background-position:center" data-s="background-image:cover">
        <span data-show="playing" style="display:flex;gap:3px;align-items:flex-end;height:14px" aria-hidden="true"><span class="eqb"></span><span class="eqb" style="animation-delay:.2s"></span><span class="eqb" style="animation-delay:.4s"></span><span class="eqb" style="animation-delay:.1s"></span></span>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px;min-width:0">
        <span style="font-size:24px;font-weight:700;line-height:1.15;text-wrap:balance;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical" data-t="title"></span>
        <span style="font-size:15px;color:#B9BFC7" data-t="artist"></span>
        <span class="lbl" style="font-size:9px;letter-spacing:.08em;margin-top:4px" data-t="album"></span>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:6px">
      <div style="height:5px;border-radius:3px;background:#2A2E34;overflow:hidden"><div style="height:100%;background:#F1F3F5;transition:width 900ms linear" data-s="width:progPct"></div></div>
      <div style="display:flex;justify-content:space-between" class="lbl"><span style="font-size:10px;letter-spacing:.04em" data-t="pos"></span><span style="font-size:10px;letter-spacing:.04em" data-t="dur"></span></div>
    </div>
    <div style="display:flex;justify-content:center;align-items:center;gap:18px">
      <button type="button" class="ib" data-on="click:prev" aria-label="Morceau précédent"><svg width="22" height="22" viewBox="0 0 24 24" fill="#F1F3F5" aria-hidden="true"><path d="M6 5h2v14H6zM20 5v14L9 12z"></path></svg></button>
      <button type="button" class="ib" data-on="click:toggle" data-a="aria-label:playLabel" style="min-width:72px;height:72px;border-radius:36px;background:#F1F3F5;border-color:#F1F3F5">
        <svg data-show="playing" width="28" height="28" viewBox="0 0 24 24" fill="#0E1013" aria-hidden="true"><path d="M7 5h4v14H7zM13 5h4v14h-4z"></path></svg>
        <svg data-show="paused" width="28" height="28" viewBox="0 0 24 24" fill="#0E1013" aria-hidden="true"><path d="M8 5v14l11-7z"></path></svg>
      </button>
      <button type="button" class="ib" data-on="click:next" aria-label="Morceau suivant"><svg width="22" height="22" viewBox="0 0 24 24" fill="#F1F3F5" aria-hidden="true"><path d="M16 5h2v14h-2zM4 5v14l11-7z"></path></svg></button>
    </div>
    <div style="display:flex;gap:8px;justify-content:center">
      <button type="button" class="chip" data-on="click:srcPhone" data-a="aria-pressed:srcPhoneOn" data-s="border-color:srcPhoneBorder">YouTube Music · téléphone</button>
      <button type="button" class="chip" data-on="click:srcPi" data-a="aria-pressed:srcPiOn" data-s="border-color:srcPiBorder">YouTube Music · 4G</button>
    </div>
  </div>

  <div id="nav-box" style="position:absolute;left:504px;right:20px;top:60px;height:206px;border-radius:16px;overflow:hidden;border:1px solid #33373E;background:#15171B">
    <svg width="500" height="206" viewBox="0 0 500 206" aria-hidden="true" style="position:absolute;inset:0">
      <rect width="500" height="206" fill="#15171B"></rect>
      <path d="M-10 160 L140 150 L260 170 L520 140" stroke="#2A2E34" stroke-width="14" fill="none"></path>
      <path d="M60 -10 L90 220" stroke="#2A2E34" stroke-width="10" fill="none"></path>
      <path d="M330 -10 L300 220" stroke="#2A2E34" stroke-width="12" fill="none"></path>
      <path d="M-10 60 L520 40" stroke="#22252A" stroke-width="8" fill="none"></path>
      <path d="M180 -10 L200 220" stroke="#22252A" stroke-width="6" fill="none"></path>
      <path d="M150 206 L170 152 L262 168 L304 160 L318 40 L520 30" stroke="#4FD1E8" stroke-width="5" fill="none" stroke-linejoin="round" stroke-linecap="round" opacity=".35"></path>
      <circle cx="170" cy="152" r="9" fill="#F1F3F5" stroke="#4FD1E8" stroke-width="3"></circle>
    </svg>
    <div id="maps-holder" style="position:absolute;inset:0"></div>
    <button type="button" data-on="click:dest" style="position:absolute;left:14px;top:12px;max-width:calc(100% - 190px);overflow:hidden;display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:12px;background:rgba(10,11,13,.85);border:1px solid #33373E;color:#F1F3F5;cursor:pointer;text-align:left">
      <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#4FD1E8" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 20V10h10"></path><path d="M12 6l4 4-4 4"></path></svg>
      <span style="display:flex;flex-direction:column"><span class="num" style="font-size:20px" data-t="navTitle"></span><span style="font-size:13px;color:#C9CED4" data-t="navSub"></span></span>
    </button>
    <div style="position:absolute;right:12px;top:12px;display:flex;gap:6px" role="group" aria-label="Application de navigation">
      <button type="button" class="chip" data-on="click:waze" data-a="aria-pressed:wazeOn" style="min-height:36px;padding:0 12px;font-size:10px" data-s="border-color:wazeBorder;background:wazeBg">Waze</button>
      <button type="button" class="chip" data-on="click:maps" data-a="aria-pressed:mapsOn" style="min-height:36px;padding:0 12px;font-size:10px" data-s="border-color:mapsBorder;background:mapsBg">Maps</button>
    </div>
    <div style="position:absolute;left:12px;bottom:12px;padding:6px 10px;border-radius:10px;background:rgba(10,11,13,.85);border:1px solid #33373E"><span class="lbl" style="font-size:9px;letter-spacing:.06em" data-t="navSrc"></span></div>
    <div style="position:absolute;right:12px;bottom:12px;display:flex;gap:6px;align-items:center">
      <button type="button" class="chip" data-on="click:clearRoute" data-show="hasRoute" style="min-height:36px;padding:0 12px;font-size:10px">Effacer</button>
      <button type="button" class="chip" data-on="click:closeNav" data-show="navRunning" style="min-height:36px;padding:0 12px;font-size:10px">Fermer</button>
      <button type="button" class="chip" data-on="click:full" data-show="navRunning" style="min-height:36px;padding:0 12px;font-size:10px">Plein écran</button>
    </div>
  </div>

  <div style="position:absolute;left:504px;right:20px;top:278px;height:202px;display:flex;flex-direction:column;gap:7px">
    <div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">Notifications</span><span class="lbl" style="font-size:9px;letter-spacing:.06em">via KDE Connect</span></div>
    <div data-html="notifs" style="display:flex;flex-direction:column;gap:7px"></div>
  </div>

  <div data-show="reading" class="toast" style="position:absolute;left:20px;right:20px;top:416px;display:flex;align-items:center;gap:14px;padding:12px 16px;border-radius:14px;background:rgba(10,11,13,.94);border:1px solid #4FD1E8">
    <img src="logo.png" alt="Nova" style="flex:none;width:56px;height:32px;object-fit:contain">
    <p style="margin:0;font-size:16px;line-height:1.4;flex:1" data-t="readTxt"></p>
    <button type="button" class="chip" data-on="click:closeRead">Fermer</button>
  </div>

  <div style="position:absolute;left:20px;right:20px;bottom:12px;display:flex;justify-content:space-between;align-items:center">
    ${navHtml("media")}
    <button type="button" class="chip" data-on="click:youtube" data-s="opacity:ytOp;cursor:ytCursor" data-a="aria-disabled:ytDisabled" data-t="ytLabel"></button>
  </div>
</div>`;

export default {
  id: "media",
  html,
  mount(el, app) {
    this.app = app;
    this.el = el;
    this.src = "phone";
    try {
      this.src = localStorage.getItem("nova.musicSrc") || "phone";
    } catch {}
    this.reading = null;
    const navRect = () => {
      const r = el.querySelector("#nav-box").getBoundingClientRect();
      const k = window.devicePixelRatio || 1;
      return { x: Math.round((window.screenX + r.left) * k), y: Math.round((window.screenY + r.top) * k), w: Math.round(r.width * k), h: Math.round(r.height * k) };
    };
    const setSrc = (s) => {
      this.src = s;
      try {
        localStorage.setItem("nova.musicSrc", s);
      } catch {}
      this.update();
    };
    const media = (action) => app.send({ type: "media", action, source: this.src === "phone" ? "phone" : "pi" });
    this.view = new View(el, {
      prev: () => media("previous"),
      next: () => media("next"),
      toggle: () => media("play_pause"),
      srcPhone: () => setSrc("phone"),
      srcPi: () => setSrc("pi"),
      waze: () => app.send({ type: "nav.open", app: "waze", rect: navRect() }),
      maps: () => app.send({ type: "nav.open", app: "maps", rect: navRect() }),
      dest: () =>
        keyboard.open({
          title: "Où va-t-on ?",
          ok: "Itinéraire",
          value: app.maps?.dest || "",
          placeholder: "Adresse, ville, lieu…",
          onDone: (v) => v.trim() && app.send({ type: "maps.route", dest: v.trim(), from: app.maps?.from || "" }),
        }),
      clearRoute: () => app.send({ type: "maps.route", dest: "" }),
      full: () => app.send({ type: "nav.open", app: app.phone?.nav || "waze", rect: null }),
      closeNav: () => app.send({ type: "nav.close" }),
      read: (b) => this.read(b.dataset.id),
      closeRead: () => {
        this.reading = null;
        this.update();
      },
      youtube: () => {
        if (!app.car.moving) app.send({ type: "youtube.open" });
      },
    });
  },
  read(id) {
    const n = (this.app.phone?.notifs || []).find((x) => x.id === id);
    if (!n) return;
    const txt = /snap/i.test(n.app) ? `${n.from} t’a envoyé un snap. Je ne peux pas l’afficher en roulant, tu le verras à l’arrêt.` : `Message de ${n.from} : « ${n.text} ». Tu veux répondre ?`;
    this.reading = txt;
    this.app.voice.say(txt);
    this.update();
  },
  /** Google Maps intégré : carte de la destination ou itinéraire (Internet nécessaire). */
  route() {
    const holder = this.el.querySelector("#maps-holder");
    const m = this.app.maps || {};
    const key = m.dest ? m.from + "→" + m.dest : "";
    if (key === this.routeKey) return;
    this.routeKey = key;
    holder.innerHTML = "";
    if (!m.dest) return this.update();
    const q = m.from ? `saddr=${encodeURIComponent(m.from)}&daddr=${encodeURIComponent(m.dest)}` : `q=${encodeURIComponent(m.dest)}`;
    const f = document.createElement("iframe");
    f.className = "maps-frame";
    f.title = "Carte Google Maps";
    f.loading = "eager";
    f.referrerPolicy = "no-referrer-when-downgrade";
    f.src = `https://maps.google.com/maps?${q}&hl=fr&z=12&output=embed`;
    holder.appendChild(f);
    this.update();
  },
  show() {
    this.route();
    this.update();
  },
  update() {
    const app = this.app;
    const ph = app.phone || {};
    const pi = this.src === "pi";
    const t = pi ? app.music : ph.track;
    const v = app.car.v || {};
    const moving = app.car.moving;
    const notifs = (ph.notifs || []).slice(0, 3).map((n, k) => {
      const fresh = Date.now() - n.at < 15000;
      const ago = Math.round((Date.now() - n.at) / 60000);
      return `<div class="${fresh ? "toast" : ""}" style="display:flex;align-items:center;gap:12px;padding:8px 10px;border-radius:12px;background:rgba(20,22,26,.8);border:1px solid ${fresh ? "rgba(79,209,232,.6)" : "#33373E"}">
        <span style="flex:none;display:flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:10px;background:${TINTS[n.app] || "#9FB4C8"};font-size:12px;font-weight:700;color:#0E1013">${esc((n.from || "?").slice(0, 1).toUpperCase())}</span>
        <span style="display:flex;flex-direction:column;min-width:0;flex:1"><span style="display:flex;justify-content:space-between;gap:8px"><span style="font-size:13px;font-weight:700">${esc(n.from)}</span><span class="lbl" style="font-size:9px;letter-spacing:.04em">${esc(n.app)} · ${ago < 1 ? "maintenant" : ago + " min"}</span></span>
        <span style="font-size:12px;color:#B9BFC7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(n.text)}</span></span>
        <button type="button" class="chip" data-on="click:read" data-id="${esc(n.id)}" style="flex:none;min-height:36px;padding:0 12px;font-size:10px">Lire</button></div>`;
    }).join("") || `<span class="lbl" style="font-size:10px;letter-spacing:.06em;text-transform:none;color:#6B727C">Aucune notification${ph.name ? "" : " · téléphone non connecté"}</span>`;
    const coverIdx = t?.title ? t.title.length % COVERS.length : 0;
    const nav = ph.nav || "waze";
    this.view.set({
      clock: hhmm(),
      phone: ph.name ? `${ph.name}${ph.battery != null ? " · " + ph.battery + " %" : ""}` : "Téléphone non connecté",
      driveTxt: moving ? `En roulant · ${Math.round(v.speed ?? 0)} km/h` : "À l’arrêt",
      source: pi ? "YouTube Music sur Nova · 4G" : "YouTube Music du téléphone · Bluetooth",
      title: t?.title || (pi ? "Dis « Nova, mets… »" : "Rien en lecture"),
      artist: t?.artist || (pi ? "et le titre ou l’artiste" : "Lance la musique sur le téléphone"),
      album: t?.album || "",
      cover: t?.artwork ? `url("${t.artwork}")` : COVERS[coverIdx],
      playing: !!t?.playing, paused: !t?.playing,
      playLabel: t?.playing ? "Pause" : "Lecture",
      progPct: t?.duration ? ((t.position / t.duration) * 100).toFixed(1) + "%" : "0%",
      pos: fmtT(t?.position ?? 0), dur: fmtT(t?.duration ?? 0),
      srcPhoneOn: pi ? "false" : "true", srcPiOn: pi ? "true" : "false",
      srcPhoneBorder: pi ? "#4A5058" : "#4FD1E8", srcPiBorder: pi ? "#4FD1E8" : "#4A5058",
      navTitle: ph.navRunning ? (nav === "waze" ? "Waze" : "Maps") + " du téléphone" : app.maps?.dest ? app.maps.dest.slice(0, 26) : "Où va-t-on ?",
      navSub: ph.navRunning ? "affiché ici par câble USB" : app.maps?.dest ? "toucher pour changer" : "ou dis « Nova, emmène-moi à… »",
      navRunning: !!ph.navRunning,
      hasRoute: !!app.maps?.dest && !ph.navRunning,
      navSrc: ph.navRunning ? (nav === "waze" ? "Waze" : "Google Maps") + " du téléphone · scrcpy" : app.maps?.dest ? (app.sys && !app.sys.online ? "Pas d'Internet : connecte le partage du téléphone" : "Google Maps · Internet") : "Waze / Maps : écran du téléphone par USB",
      wazeOn: nav === "waze" ? "true" : "false", mapsOn: nav === "maps" ? "true" : "false",
      wazeBorder: nav === "waze" ? "#4FD1E8" : "#4A5058", mapsBorder: nav === "maps" ? "#4FD1E8" : "#4A5058",
      wazeBg: nav === "waze" ? "rgba(79,209,232,.16)" : "rgba(10,11,13,.85)", mapsBg: nav === "maps" ? "rgba(79,209,232,.16)" : "rgba(10,11,13,.85)",
      notifs,
      reading: !!this.reading, readTxt: this.reading || "",
      ytLabel: moving ? "YouTube · à l’arrêt" : "Ouvrir YouTube",
      ytOp: moving ? 0.45 : 1, ytCursor: moving ? "not-allowed" : "pointer", ytDisabled: moving ? "true" : "false",
    });
  },
};
