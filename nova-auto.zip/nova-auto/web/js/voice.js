// Voix de Nova (repris de Nova v0.14.1) : chaque phrase est dite dès qu'elle est écrite.
// Voix locale (Piper, sur le Pi, sans Internet), voix OpenAI en option, ou voix du navigateur en secours.
// En plus : on sait quelle phrase est dite et combien de temps elle dure, pour surligner les mots à l'écran.

export const DEFAULT_SETTINGS = {
  ttsEngine: "local", // local | openai | browser
  localVoice: "siwis",
  localSpeaker: 0,
  openaiVoice: "alloy",
  voiceStyle: "Voix féminine posée et chaleureuse, ton de copilote, phrases nettes.",
  rate: 1.05,
  volume: 1,
  wakeWord: true,
  sensitivity: "normal",
  silence: 0.8,
  localStt: true,
  followUp: "question", // question | always | never
  chimes: true,
  micId: "",
  outputId: "",
};

export function loadSettings() {
  try {
    const s = { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem("nova.settings") || "{}") };
    // 1,2 s était l'ancien réglage par défaut de fin de phrase : trop long pour une conversation
    if (s.silence === 1.2) s.silence = 0.8;
    return s;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}
export function saveSettings(s) {
  try {
    localStorage.setItem("nova.settings", JSON.stringify(s));
  } catch {
    /* stockage indisponible : réglages gardés en mémoire */
  }
}

export function cleanForSpeech(text) {
  return text
    .replace(/```[\s\S]*?```/g, " (voir à l'écran) ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\*\*|__|\*|#+\s?/g, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/^\s*[-•]\s+/gm, "")
    .replace(/[A-Z]:\\[^\s]+|\/[\w./-]{12,}/g, "le fichier")
    .trim();
}

const SENTENCE_END = /[.!?…](?=["»)\]]?\s)|\n+/;

async function contextFor(outputId) {
  const ctx = new AudioContext();
  if (outputId && ctx.setSinkId) {
    try {
      await ctx.setSinkId(outputId);
    } catch {
      /* sortie débranchée */
    }
  }
  return ctx;
}

export async function chime(kind, s) {
  if (!s.chimes) return;
  const ctx = await contextFor(s.outputId);
  const now = ctx.currentTime;
  const notes = kind === "start" ? [660, 990] : kind === "alert" ? [880, 660, 880] : [880, 520];
  notes.forEach((f, i) => {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = f;
    const t = now + i * 0.09;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.12 * s.volume, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
    o.connect(g).connect(ctx.destination);
    o.start(t);
    o.stop(t + 0.2);
  });
  setTimeout(() => ctx.close().catch(() => {}), 700);
}

/**
 * cb.onActive(bool), cb.onLevel(0..1), cb.onSentence(text, seconds), cb.onWord(index), cb.onError(msg)
 * tts(req) → Promise<base64>
 */
export class Speaker {
  constructor(settings, tts, cb) {
    this.settings = settings;
    this.tts = tts;
    this.cb = cb;
    this.buf = "";
    this.inCode = false;
    this.generation = 0;
    this.outstanding = 0;
    this.chain = Promise.resolve();
    this.ctx = null;
    this.ctxSink = "";
    this.sources = new Set();
    this.raf = 0;
    this.analyser = null;
    this.waiters = [];
  }

  get active() {
    return this.outstanding > 0;
  }
  push(delta) {
    this.buf += delta;
    this.extract(false);
  }
  flush() {
    this.extract(true);
    if (this.outstanding === 0) this.idle();
  }
  say(text) {
    this.push(text + "\n");
    this.flush();
  }
  stop() {
    this.generation++;
    this.buf = "";
    this.inCode = false;
    window.speechSynthesis?.cancel();
    for (const s of this.sources) {
      try {
        s.stop();
      } catch {
        /* déjà arrêté */
      }
    }
    this.sources.clear();
    this.chain = Promise.resolve();
    cancelAnimationFrame(this.raf);
    if (this.outstanding) {
      this.outstanding = 0;
      this.cb.onActive(false);
    }
    this.idle();
  }
  whenIdle() {
    if (this.outstanding === 0) return Promise.resolve();
    return new Promise((r) => this.waiters.push(r));
  }
  idle() {
    const w = this.waiters;
    this.waiters = [];
    w.forEach((f) => f());
  }

  extract(final) {
    for (;;) {
      if (this.inCode) {
        const end = this.buf.indexOf("```");
        if (end < 0) {
          if (final) this.buf = "";
          return;
        }
        this.buf = this.buf.slice(end + 3);
        this.inCode = false;
        continue;
      }
      const fence = this.buf.indexOf("```");
      const head = fence >= 0 ? this.buf.slice(0, fence) : this.buf;
      let m = head.match(SENTENCE_END);
      // début de réponse : on n'attend pas la fin de la phrase, une virgule après quelques mots suffit
      // (la synthèse de la suite se fait pendant que le début est dit)
      if (!m && this.outstanding === 0) {
        const c = /[,;:](?=\s)/g;
        let x;
        while ((x = c.exec(head))) {
          if (x.index >= 12) {
            m = Object.assign([x[0]], { index: x.index });
            break;
          }
        }
      }
      if (m && m.index !== undefined) {
        const cut = m.index + m[0].length;
        this.enqueue(head.slice(0, cut));
        this.buf = this.buf.slice(cut);
        continue;
      }
      if (fence >= 0) {
        this.enqueue(head);
        this.buf = this.buf.slice(fence + 3);
        this.inCode = true;
        continue;
      }
      if (final) {
        this.enqueue(this.buf);
        this.buf = "";
      }
      return;
    }
  }

  enqueue(raw) {
    const text = cleanForSpeech(raw);
    if (!/[\p{L}\p{N}]/u.test(text)) return;
    const s = this.settings();
    const gen = this.generation;
    if (this.outstanding++ === 0) this.cb.onActive(true);
    const done = () => {
      if (gen !== this.generation) return;
      this.outstanding = Math.max(0, this.outstanding - 1);
      if (this.outstanding === 0) {
        this.cb.onActive(false);
        this.cb.onLevel(0);
        this.idle();
      }
    };
    if (s.ttsEngine === "openai" || s.ttsEngine === "local") {
      const local = s.ttsEngine === "local";
      const audio = this.tts(local ? { text, engine: "local", voice: s.localVoice, speed: s.rate, speaker: s.localSpeaker } : { text, engine: "openai", voice: s.openaiVoice, instructions: s.voiceStyle });
      audio.catch(() => {});
      this.chain = this.chain.then(async () => {
        if (gen !== this.generation) return;
        try {
          await this.play(await audio, text, s, gen, local ? 1 : s.rate);
        } catch (e) {
          this.cb.onError(String(e?.message || e));
          await this.browserSay(text, s, gen);
        }
        done();
      });
    } else {
      this.chain = this.chain.then(async () => {
        if (gen !== this.generation) return;
        await this.browserSay(text, s, gen);
        done();
      });
    }
  }

  browserSay(text, s, gen) {
    return new Promise((resolve) => {
      const synth = window.speechSynthesis;
      if (!synth || gen !== this.generation) return resolve();
      const u = new SpeechSynthesisUtterance(text);
      const voices = synth.getVoices();
      const fr = voices.filter((v) => v.lang.toLowerCase().startsWith("fr"));
      const v = fr.find((x) => /natural|neural|online/i.test(x.name)) ?? fr[0];
      if (v) {
        u.voice = v;
        u.lang = v.lang;
      } else u.lang = "fr-FR";
      u.rate = s.rate;
      u.volume = s.volume;
      let word = 0;
      const n = text.split(/\s+/).length;
      this.cb.onSentence(text, Math.max(1, n * 0.36 / s.rate), true);
      u.onboundary = (e) => {
        if (e.name && e.name !== "word") return;
        this.cb.onWord(word++);
        this.cb.onLevel(0.8);
        setTimeout(() => this.cb.onLevel(0.25), 120);
      };
      const end = () => resolve();
      u.onend = end;
      u.onerror = end;
      synth.speak(u);
      // certains navigateurs n'appellent jamais onend
      setTimeout(end, 20000);
    });
  }

  async play(base64, text, s, gen, rate) {
    if (gen !== this.generation) return;
    if (!this.ctx || this.ctxSink !== s.outputId || this.ctx.state === "closed") {
      this.ctx?.close().catch(() => {});
      this.ctx = await contextFor(s.outputId);
      this.ctxSink = s.outputId;
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 512;
      this.analyser.connect(this.ctx.destination);
    }
    const ctx = this.ctx;
    const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
    const buffer = await ctx.decodeAudioData(bytes.buffer);
    if (gen !== this.generation) return;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    if (window.__novaAsk) {
      window.nova?.clog?.("info", `Voix : premier son ${Math.round(performance.now() - window.__novaAsk)} ms après la fin de la demande`);
      window.__novaAsk = 0;
    }
    src.playbackRate.value = Math.max(0.7, Math.min(1.4, rate));
    const gain = ctx.createGain();
    gain.gain.value = s.volume;
    src.connect(gain).connect(this.analyser);
    this.sources.add(src);
    const data = new Uint8Array(this.analyser.fftSize);
    const tick = () => {
      this.analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (const v of data) sum += ((v - 128) / 128) ** 2;
      this.cb.onLevel(Math.min(1, Math.sqrt(sum / data.length) * 5));
      this.raf = requestAnimationFrame(tick);
    };
    await new Promise((resolve) => {
      src.onended = () => {
        this.sources.delete(src);
        cancelAnimationFrame(this.raf);
        resolve();
      };
      if (ctx.state === "suspended") ctx.resume().catch(() => {});
      this.cb.onSentence(text, buffer.duration / src.playbackRate.value, false);
      src.start();
      tick();
    });
  }
}

/** Micro en continu vers le cerveau (mot d'activation « Nova » + reconnaissance locale). */
export async function startMicStream(micId, sendBinary, onLevel) {
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { deviceId: micId ? { exact: micId } : undefined, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
  });
  const ctx = new AudioContext();
  const source = ctx.createMediaStreamSource(stream);
  const proc = ctx.createScriptProcessor(2048, 1, 1);
  const mute = ctx.createGain();
  mute.gain.value = 0;
  proc.onaudioprocess = (e) => {
    const data = e.inputBuffer.getChannelData(0);
    sendBinary(new Float32Array(data).buffer);
    if (onLevel) {
      let sum = 0;
      for (let i = 0; i < data.length; i += 4) sum += data[i] * data[i];
      onLevel(Math.min(1, Math.sqrt(sum / (data.length / 4)) * 4));
    }
  };
  source.connect(proc);
  proc.connect(mute).connect(ctx.destination);
  let stopped = false;
  return {
    sampleRate: ctx.sampleRate,
    stop() {
      if (stopped) return;
      stopped = true;
      proc.disconnect();
      source.disconnect();
      stream.getTracks().forEach((t) => t.stop());
      ctx.close().catch(() => {});
    },
  };
}
