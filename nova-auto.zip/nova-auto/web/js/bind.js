// Petite liaison données → écran, sans dépendance.
//   data-t="clé"                  texte
//   data-s="left:clé;width:clé2"  propriétés CSS
//   data-a="cx:clé;cy:clé2"       attributs (SVG…)
//   data-html="clé"               contenu HTML (listes)
//   data-show="clé"               affiché si vrai
//   data-on="click:action"        action au toucher
// Ne touche au DOM que si la valeur a changé : les animations CSS ne redémarrent pas.
const REDUCED = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export class View {
  constructor(root, actions = {}) {
    this.root = root;
    this.actions = actions;
    this.scan();
    root.addEventListener("click", (e) => {
      const el = e.target.closest("[data-on]");
      if (!el || !root.contains(el)) return;
      for (const pair of el.dataset.on.split(";")) {
        const [ev, name] = pair.split(":");
        if (ev === "click" && this.actions[name]) {
          e.stopPropagation();
          this.actions[name](el, e);
        }
      }
    });
  }

  scan() {
    const q = (sel) => [...this.root.querySelectorAll(sel)];
    this.t = q("[data-t]").map((el) => ({ el, k: el.dataset.t, v: undefined }));
    this.s = q("[data-s]").map((el) => ({ el, pairs: el.dataset.s.split(";").filter(Boolean).map((p) => p.split(":")), v: {} }));
    this.a = q("[data-a]").map((el) => ({ el, pairs: el.dataset.a.split(";").filter(Boolean).map((p) => p.split(":")), v: {} }));
    this.h = q("[data-html]").map((el) => ({ el, k: el.dataset.html, v: undefined }));
    this.sh = q("[data-show]").map((el) => ({ el, k: el.dataset.show, v: undefined, d: el.style.display }));
  }

  set(vals) {
    for (const b of this.t) {
      if (!(b.k in vals)) continue;
      const x = vals[b.k] == null ? "" : String(vals[b.k]);
      if (b.v !== x) b.el.textContent = b.v = x;
    }
    for (const b of this.s) {
      for (const [prop, k] of b.pairs) {
        if (!(k in vals)) continue;
        const x = String(vals[k]);
        if (b.v[prop] !== x) b.el.style.setProperty(prop, (b.v[prop] = x));
      }
    }
    for (const b of this.a) {
      for (const [attr, k] of b.pairs) {
        if (!(k in vals)) continue;
        const x = String(vals[k]);
        if (b.v[attr] !== x) b.el.setAttribute(attr, (b.v[attr] = x));
      }
    }
    for (const b of this.h) {
      if (!(b.k in vals)) continue;
      const x = String(vals[b.k]);
      if (b.v !== x) b.el.innerHTML = b.v = x;
    }
    for (const b of this.sh) {
      if (!(b.k in vals)) continue;
      const x = !!vals[b.k];
      if (b.v !== x) {
        const first = b.v === undefined;
        b.v = x;
        b.anim?.cancel();
        if (x) {
          b.el.style.display = b.d;
          // apparition douce (sauf au premier affichage)
          if (!first && !REDUCED()) b.anim = b.el.animate([{ opacity: 0, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }], { duration: 320, easing: "cubic-bezier(.16,1,.3,1)" });
        } else if (first || REDUCED()) b.el.style.display = "none";
        else {
          const a = (b.anim = b.el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 140, easing: "ease-in", fill: "forwards" }));
          a.onfinish = () => {
            if (!b.v) b.el.style.display = "none";
            a.cancel();
          };
        }
      }
    }
  }
}

export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
export const fr = (n, d = 0) => (n == null || !Number.isFinite(n) ? "—" : n.toFixed(d).replace(".", ","));
export const thousands = (n) => (n == null || !Number.isFinite(n) ? "—" : Math.round(n).toLocaleString("fr-FR"));
export const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const hhmm = () => new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });

// Courbe de couple de référence du 1.8T 225 (comme les maquettes)
export const REF_TQ = [[1000, 150], [1800, 235], [2200, 280], [5500, 280], [5900, 267], [6500, 232], [7000, 195]];
export function interp(table, x) {
  if (x <= table[0][0]) return table[0][1];
  for (let i = 1; i < table.length; i++) if (x <= table[i][0]) {
    const [a, b] = table[i - 1], [c, d] = table[i];
    return b + ((d - b) * (x - a)) / (c - a);
  }
  return table[table.length - 1][1];
}

/** Barre de navigation entre les écrans (reprise de l'écran Média). */
export function navHtml(current) {
  const tabs = [["tableau", "Tableau"], ["media", "Média"], ["diagnostic", "Diagnostic"], ["rapports", "Rapports"], ["apprentissage", "Appr."]];
  return `<nav style="display:flex;gap:2px" aria-label="Écrans">${tabs
    .map(([id, name]) => `<button type="button" class="tab" data-go="${id}" ${id === current ? 'aria-current="page"' : ""}>${name}</button>`)
    .join("")}<button type="button" class="tab" data-go="veille" aria-label="Veille" style="padding:0 10px"><img src="logo.png" alt="" style="width:34px;height:19px;object-fit:contain"></button></nav>`;
}
