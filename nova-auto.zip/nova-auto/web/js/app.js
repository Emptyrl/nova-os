// Nova Auto : l'écran de la voiture. Relie les 8 écrans au cerveau de Nova (WebSocket),
// gère la voix (micro, mot « Nova », synthèse) et les surcouches (alerte, autorisation, fenêtres).
import { esc } from "./bind.js";
import { swap, stagger, popIn, popOut, Smoother, EASE, reduced } from "./motion.js";
import { Speaker, startMicStream, chime, loadSettings } from "./voice.js";
import veille from "./screens/veille.js";
import lancement from "./screens/lancement.js";
import tableau from "./screens/tableau.js";
import rapports from "./screens/rapports.js";
import diagnostic from "./screens/diagnostic.js";
import alerte from "./screens/alerte.js";
import apprentissage from "./screens/apprentissage.js";
import media from "./screens/media.js";
import reglages from "./screens/reglages.js";
import calculateurs from "./screens/calculateurs.js";

const stage = document.getElementById("stage");
const SCREENS = [lancement, veille, tableau, media, diagnostic, calculateurs, rapports, apprentissage, reglages];

// ---------- mise à l'échelle 1024×600 ----------
function fit() {
  const k = Math.min(window.innerWidth / 1024, window.innerHeight / 600);
  stage.style.transform = `scale(${k})`;
}
window.addEventListener("resize", fit);
fit();

// ---------- état ----------
const app = {
  connected: false,
  driver: "Joan",
  modes: [],
  car: { v: {}, mode: 0 },
  sources: [],
  diag: null,
  learn: null,
  rapports: null,
  phone: {},
  music: null,
  hw: {},
  config: null,
  voices: null,
  models: {},
  night: false,
  alerts: new Map(),
  acked: new Set(),
  busy: false,
  settings: loadSettings(),
  nova: { mode: "idle", words: [], wi: -1, kick: 0, level: 0, micLevel: 0, heard: "" },
  screen: null,
  prevScreen: null,
  booted: false,
};
window.nova = app; // pour le débogage depuis la console

let ws = null;
app.send = (m) => {
  if (ws?.readyState === 1) ws.send(JSON.stringify(m));
};
app.sendBinary = (buf) => {
  if (ws?.readyState === 1 && ws.bufferedAmount < 256_000) {
    ws.send(buf);
    return true;
  }
  return false;
};

// ---------- écrans ----------
const els = {};
for (const s of SCREENS) {
  const el = document.createElement("div");
  el.className = "screen";
  el.dataset.screen = s.id;
  el.innerHTML = s.html;
  stage.appendChild(el);
  els[s.id] = el;
  s.mount(el, app);
}
// l'alerte passe par-dessus tout
const alertLayer = document.createElement("div");
alertLayer.className = "screen";
alertLayer.style.zIndex = 40;
alertLayer.innerHTML = alerte.html;
stage.appendChild(alertLayer);
alerte.mount(alertLayer, app);

// navigation par les onglets
stage.addEventListener("click", (e) => {
  const b = e.target.closest("[data-go]");
  if (b) app.go(b.dataset.go);
});

const byId = Object.fromEntries(SCREENS.map((s) => [s.id, s]));
app.go = (id) => {
  if (!byId[id] || id === app.screen) return;
  if (!app.booted && id !== "lancement") return;
  const cur = byId[app.screen];
  const fromId = app.screen;
  const fromEl = fromId ? els[fromId] : null;
  if (cur) cur.hide?.();
  app.prevScreen = app.screen;
  app.screen = id;
  els[id].classList.add("on");
  byId[id].show?.();
  byId[id].update?.();
  byId[id].frame?.();
  swap(fromEl, els[id], fromId, id, () => {
    if (fromEl && app.screen !== fromId) fromEl.classList.remove("on");
  });
  if (id !== "lancement" && fromId !== "lancement") stagger(els[id]);
  if (id !== "lancement") app.send({ type: "screen.changed", name: id });
};
app.bootDone = () => {
  app.booted = true;
  app.go(app.car.running && app.config?.car?.autoDashboard !== false ? "tableau" : "veille");
  refreshAlertLayer();
};

// ---------- alertes ----------
app.pendingAlerts = () => {
  const rank = { Critique: 0, Attention: 1, Info: 2 };
  return [...app.alerts.values()].filter((a) => !app.acked.has(a.id)).sort((a, b) => rank[a.level] - rank[b.level] || a.at - b.at);
};
app.alertAcked = (id) => {
  app.acked.add(id);
  refreshAlertLayer();
};
let alertShown = false;
function refreshAlertLayer() {
  const show = app.booted && app.pendingAlerts().length > 0;
  if (show) alerte.update();
  if (show === alertShown) return;
  alertShown = show;
  if (show) {
    alertLayer.classList.add("on");
    popIn(alertLayer, "scale(1.03)", 460);
    stagger(alertLayer, 120);
  } else
    popOut(alertLayer, () => {
      if (!alertShown) alertLayer.classList.remove("on");
    }, "scale(.98)", 260);
}

// ---------- surcouches : autorisation, fenêtres, message ----------
const overlay = document.createElement("div");
overlay.style.cssText = "position:absolute;inset:0;z-index:60;pointer-events:none";
stage.appendChild(overlay);
const toastEl = document.createElement("div");
toastEl.style.cssText = "position:absolute;left:50%;top:14px;transform:translateX(-50%);max-width:760px;padding:10px 18px;border-radius:14px;background:rgba(10,11,13,.94);border:1px solid #4A5058;font-size:14px;font-weight:600;color:#F1F3F5;display:none;pointer-events:auto";
overlay.appendChild(toastEl);
let toastTimer = 0;
toastEl.style.transform = "none";
toastEl.style.left = "0";
toastEl.style.right = "0";
toastEl.style.margin = "0 auto";
toastEl.style.width = "fit-content";
app.toast = (t, ms = 4000) => {
  const wasHidden = toastEl.style.display !== "block";
  toastEl.textContent = t;
  toastEl.style.display = "block";
  if (wasHidden) popIn(toastEl, "translateY(-14px)", 360);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => popOut(toastEl, () => (toastEl.style.display = "none"), "translateY(-10px)", 240), ms);
};

const permEl = document.createElement("div");
permEl.className = "card";
permEl.style.cssText += ";position:absolute;left:212px;top:150px;width:600px;padding:20px;display:none;flex-direction:column;gap:12px;pointer-events:auto";
overlay.appendChild(permEl);
const perms = [];
let permShownId = null;
function renderPerm() {
  const p = perms[0];
  if (!p) {
    if (permShownId) popOut(permEl, () => (permEl.style.display = perms.length ? "flex" : "none"), "scale(.97)");
    permShownId = null;
    return;
  }
  const danger = p.level === "danger";
  permEl.style.display = "flex";
  if (permShownId !== p.id) popIn(permEl, "translateY(12px) scale(.96)", 420);
  permShownId = p.id;
  permEl.style.borderColor = danger ? "#F5B841" : "#4FD1E8";
  permEl.innerHTML = `<div style="display:flex;align-items:center;gap:12px"><img src="logo.png" alt="" style="width:56px;height:32px;object-fit:contain"><span style="font-size:20px;font-weight:700">${esc(p.title || "Nova demande ton accord")}</span></div>
    <p style="margin:0;font-size:15px;line-height:1.45;color:#E6EAEE;word-break:break-word">${esc(p.summary)}</p>
    ${p.detail ? `<pre class="win-body" style="margin:0;max-height:160px;white-space:pre-wrap;font-size:12px;padding:8px;border-radius:8px;background:#15171B">${esc(p.detail)}</pre>` : ""}
    ${p.note ? `<span class="lbl" style="font-size:10px;letter-spacing:.04em;text-transform:none">${esc(p.note)}</span>` : ""}
    <div style="display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn" data-perm="0">Refuser</button><button type="button" class="btn" data-perm="1" style="border-color:${danger ? "#F5B841" : "#4FD1E8"};color:#FFFFFF">Autoriser</button></div>`;
}
permEl.addEventListener("click", (e) => {
  const b = e.target.closest("[data-perm]");
  if (!b || !perms[0]) return;
  app.send({ type: "permission", id: perms[0].id, allow: b.dataset.perm === "1" });
});

// fenêtres ouvertes par Nova (show_window) : une carte à droite
const winEl = document.createElement("div");
winEl.className = "card";
winEl.style.cssText += ";position:absolute;right:16px;top:60px;width:430px;padding:14px 16px;display:none;flex-direction:column;gap:8px;pointer-events:auto";
overlay.appendChild(winEl);
const wins = new Map();
function md(s) {
  let h = esc(s || "");
  h = h.replace(/```([\s\S]*?)```/g, (_, c) => `<pre>${c}</pre>`);
  h = h.replace(/^### (.*)$/gm, "<b>$1</b>").replace(/^## (.*)$/gm, '<b style="font-size:16px">$1</b>').replace(/^# (.*)$/gm, '<b style="font-size:17px">$1</b>');
  h = h.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>");
  h = h.replace(/^\s*[-*] (.*)$/gm, "• $1");
  h = h.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1");
  return h.replace(/\n/g, "<br>");
}
let winShownId = null;
function renderWins() {
  const list = [...wins.values()].filter((w) => w.kind !== "music").sort((a, b) => b.createdAt - a.createdAt);
  const w = list[0];
  if (!w) {
    if (winShownId) popOut(winEl, () => (winEl.style.display = wins.size ? "flex" : "none"), "translateX(24px)");
    winShownId = null;
    return;
  }
  if (winShownId !== w.id) {
    winEl.style.display = "flex";
    popIn(winEl, "translateX(28px)", 420);
  }
  winShownId = w.id;
  let body = "";
  if (w.kind === "markdown" || w.kind === "code") body = md(w.kind === "code" ? "```" + (w.content || "") + "```" : w.content);
  else if (w.kind === "list" || w.kind === "checklist") body = (w.items || []).map((it, i) => `<div data-check="${i}" style="padding:4px 0;${it.done ? "color:#7BD88F" : ""}">${w.kind === "checklist" ? (it.done ? "☑ " : "☐ ") : "• "}${esc(it.text)}</div>`).join("");
  else if (w.kind === "table") body = `<table><tr>${(w.columns || []).map((c) => `<th>${esc(c)}</th>`).join("")}</tr>${(w.rows || []).map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</table>`;
  else if (w.kind === "log" || w.kind === "activity") body = (w.lines || []).slice(-14).map((l) => `<div style="font-size:12px">${esc(l)}</div>`).join("");
  else if (w.kind === "progress") body = `<div style="height:8px;border-radius:4px;background:#2A2E34;overflow:hidden"><div style="height:100%;width:${w.percent ?? 0}%;background:#4FD1E8"></div></div>${md(w.content)}`;
  else if (w.kind === "image") body = `<img src="${esc(w.url || "")}" alt="" style="max-width:100%;border-radius:8px">`;
  else if (w.kind === "timer") body = `<span class="num" style="font-size:40px">${w.endsAt ? Math.max(0, Math.round((w.endsAt - Date.now()) / 1000)) + " s" : ""}</span>`;
  else body = md(w.content);
  winEl.style.display = "flex";
  winEl.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><span style="font-size:16px;font-weight:700">${esc(w.title)}</span><span style="display:flex;gap:6px;align-items:center">${list.length > 1 ? `<span class="lbl" style="font-size:9px">+${list.length - 1}</span>` : ""}<button type="button" class="tab" data-close="${esc(w.id)}" aria-label="Fermer" style="min-height:36px;padding:0 10px">✕</button></span></div><div class="win-body scroll">${body}</div>`;
}
winEl.addEventListener("click", (e) => {
  const c = e.target.closest("[data-close]");
  if (c) {
    app.send({ type: "ui.closed", id: c.dataset.close });
    wins.delete(c.dataset.close);
    renderWins();
  }
  const k = e.target.closest("[data-check]");
  if (k) {
    const w = [...wins.values()].sort((a, b) => b.createdAt - a.createdAt)[0];
    if (w) app.send({ type: "ui.check", id: w.id, index: Number(k.dataset.check) });
  }
});

// ---------- voix ----------
const N = app.nova;
let wordTimers = [];
let returnTimer = 0;
let returnTo = null;
let listenMode = null; // "local" | "browser" | null
let localReady = false;
let lastLevelSent = 0;
let turnAsked = false;
let convo = false; // une conversation est en cours (et pas une simple annonce)

function setMode(m) {
  N.mode = m;
  if (m === "listen") convo = true;
  if (m === "idle") convo = false;
  if (convo && (m === "listen" || m === "think" || m === "speak")) {
    clearTimeout(returnTimer);
    if (app.booted && app.config?.car?.voiceFullscreen !== false && app.screen !== "veille" && app.screen !== "reglages" && !app.diag?.running) {
      returnTo = app.screen;
      app.go("veille");
    }
  } else if (m === "idle" && returnTo) {
    clearTimeout(returnTimer);
    returnTimer = setTimeout(() => {
      if (N.mode === "idle" && app.screen === "veille" && returnTo) app.go(returnTo);
      returnTo = null;
    }, 3500);
  }
}

const speaker = new Speaker(
  () => app.settings,
  (req) =>
    new Promise((resolve, reject) => {
      const id = Math.random().toString(36).slice(2);
      ttsWaiters.set(id, { resolve, reject });
      app.send({ type: "tts", id, ...req });
      setTimeout(() => {
        if (ttsWaiters.has(id)) {
          ttsWaiters.delete(id);
          reject(new Error("la voix locale ne répond pas"));
        }
      }, 20000);
    }),
  {
    onActive: (on) => {
      app.send({ type: "audio.pause", paused: on });
      app.send({ type: "voice.speaking", on });
      if (on) setMode("speak");
      else {
        N.kick = 0;
        N.wi = N.words.length;
        setMode(app.busy ? "think" : "idle");
      }
    },
    onLevel: (l) => {
      N.level = l;
      const now = performance.now();
      if (now - lastLevelSent > 100) {
        lastLevelSent = now;
        app.send({ type: "voice.level", level: l });
      }
    },
    onSentence: (text, seconds, browser) => {
      wordTimers.forEach(clearTimeout);
      wordTimers = [];
      const words = text.split(/\s+/).filter(Boolean);
      N.words = words;
      N.wi = -1;
      if (browser) return; // les mots avancent avec la voix du navigateur
      // même rythme que la maquette, étiré sur la durée réelle de la phrase
      const w = words.map((x) => 150 + x.replace(/[^\p{L}\p{N}]/gu, "").length * 55 + (/[.,!?;:]$/.test(x) ? 380 : 0));
      const total = w.reduce((a, b) => a + b, 0) || 1;
      const k = (seconds * 1000) / total;
      let t = 0;
      words.forEach((x, i) => {
        const len = x.replace(/[^\p{L}\p{N}]/gu, "").length;
        const amp = Math.min(1, 0.35 + len * 0.08);
        wordTimers.push(setTimeout(() => ((N.wi = i), (N.kick = amp)), t * k));
        wordTimers.push(setTimeout(() => (N.kick = 0), t * k + 150));
        t += w[i];
      });
    },
    onWord: (i) => {
      N.wi = i;
      N.kick = 0.7;
      setTimeout(() => (N.kick = 0), 150);
    },
    onError: (m) => console.warn("voix :", m),
  },
);
const ttsWaiters = new Map();

let recog = null;
function startListening() {
  speaker.stop();
  N.heard = "";
  chime("start", app.settings);
  setMode("listen");
  if (app.settings.localStt && localReady) {
    listenMode = "local";
    app.send({ type: "listen.start" });
    return;
  }
  // secours : reconnaissance vocale du navigateur (Chrome / Chromium, passe par Internet)
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    setMode("idle");
    app.toast("Reconnaissance vocale indisponible : télécharge-la dans les réglages.");
    return;
  }
  listenMode = "browser";
  recog = new SR();
  recog.lang = "fr-FR";
  recog.interimResults = true;
  recog.onresult = (e) => {
    const r = e.results[e.results.length - 1];
    N.heard = r[0].transcript;
    if (r.isFinal) submit(N.heard);
  };
  recog.onerror = () => endListening();
  recog.onend = () => {
    if (listenMode === "browser") endListening();
  };
  recog.start();
}
function endListening() {
  listenMode = null;
  if (N.mode === "listen") setMode("idle");
}
function submit(text) {
  listenMode = null;
  const t = text.trim();
  if (!t) return endListening();
  N.heard = t;
  turnAsked = true;
  setMode("think");
  app.send({ type: "chat", text: t });
}
app.voice = {
  toggle() {
    if (N.mode === "idle") startListening();
    else {
      speaker.stop();
      if (listenMode === "local") app.send({ type: "listen.cancel" });
      recog?.abort?.();
      listenMode = null;
      if (app.busy) app.send({ type: "interrupt" });
      setMode("idle");
    }
  },
  say(text) {
    speaker.say(text);
  },
  reconfigure() {
    restartMic();
  },
};

let mic = null;
async function restartMic() {
  mic?.stop();
  mic = null;
  localReady = false;
  const s = app.settings;
  if (!app.connected || (!s.wakeWord && !s.localStt)) return;
  try {
    mic = await startMicStream(s.micId, app.sendBinary, (l) => (N.micLevel = N.micLevel * 0.6 + l * 0.4));
    app.send({ type: "audio.config", sampleRate: mic.sampleRate, wake: s.wakeWord, sensitivity: s.sensitivity, silence: s.silence, localStt: s.localStt });
  } catch (e) {
    console.warn("micro :", e);
    app.toast("Micro inaccessible : " + (e?.message || e));
  }
}

// ---------- connexion au cerveau ----------
function connect() {
  const token = new URLSearchParams(location.search).get("token");
  ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws${token ? "?token=" + encodeURIComponent(token) : ""}`);
  ws.binaryType = "arraybuffer";
  ws.onopen = () => {
    app.connected = true;
    restartMic();
  };
  ws.onclose = () => {
    app.connected = false;
    mic?.stop();
    mic = null;
    setTimeout(connect, 1500);
  };
  ws.onmessage = (ev) => {
    let m;
    try {
      m = JSON.parse(ev.data);
    } catch {
      return;
    }
    handle(m);
  };
}

function handle(m) {
  switch (m.type) {
    case "hello":
      app.driver = m.driver || "Joan";
      app.modes = m.modes || [];
      break;
    case "car":
      app.car = m;
      if (!byId[app.screen]?.perFrame) byId[app.screen]?.update?.();
      if (alertLayer.classList.contains("on") && Math.random() < 0.2) alerte.update();
      break;
    case "sources":
      app.sources = m.items || [];
      break;
    case "diag":
      app.diag = m;
      break;
    case "learn":
      app.learn = m;
      break;
    case "rapports":
      app.rapports = m;
      if (app.screen === "rapports") rapports.render();
      break;
    case "phone":
      app.phone = m;
      if (app.screen === "media") media.update();
      break;
    case "music":
      app.music = m.state;
      if (app.screen === "media") media.update();
      break;
    case "hw":
      app.hw = m;
      break;
    case "vag":
      app.vag = m;
      if (app.screen === "calculateurs") calculateurs.update();
      break;
    case "toast":
      app.toast(m.message);
      break;
    case "night":
      app.night = !!m.on;
      nightEl.style.opacity = app.night ? "1" : "0";
      break;
    case "config":
      app.config = m;
      break;
    case "voices":
      app.voices = m;
      if (app.screen === "reglages") reglages.update();
      break;
    case "model":
      app.models = m.models || {};
      break;
    case "boot":
      lancement.onBoot(m.checks);
      break;
    case "screen":
      if (app.booted) {
        returnTo = null;
        app.go(m.name);
      }
      break;
    case "alert":
    case "alert.update": {
      const isNew = m.type === "alert" && !app.alerts.has(m.alert.id);
      if (m.type === "alert" && m.alert.acked === false) app.acked.delete(m.alert.id);
      app.alerts.set(m.alert.id, m.alert);
      if (isNew && app.booted) chime("alert", app.settings);
      refreshAlertLayer();
      break;
    }
    case "alert.clear":
      app.alerts.delete(m.id);
      app.acked.delete(m.id);
      refreshAlertLayer();
      break;
    case "say":
      speaker.say(m.text);
      break;
    case "snapshot":
      app.busy = !!m.busy;
      break;
    case "state":
      app.busy = m.state === "think";
      if (m.state === "think" && N.mode === "idle") setMode("think");
      if (m.state === "idle" && N.mode === "think" && !speaker.active) setMode("idle");
      break;
    case "text.delta":
      speaker.push(m.text);
      break;
    case "done": {
      speaker.flush();
      const full = (m.text || "").trim();
      const mode = app.settings.followUp;
      if (turnAsked && mode !== "never" && (mode === "always" || /\?\s*["»)]?\s*$/.test(full))) {
        speaker.whenIdle().then(() => {
          if (!listenMode && N.mode === "idle") startListening();
        });
      }
      turnAsked = false;
      break;
    }
    case "error":
      app.toast(m.message);
      if (N.mode === "think" && !speaker.active) setMode("idle");
      break;
    case "wake":
      speaker.stop();
      if (listenMode) break;
      if (m.local) {
        chime("start", app.settings);
        listenMode = "local";
        N.heard = m.command || "";
        setMode("listen");
      } else startListening();
      break;
    case "audio.ready":
      localReady = !!m.localStt;
      break;
    case "stt.partial":
      N.heard = m.text;
      break;
    case "stt.final":
      listenMode = null;
      if (m.text && m.text.trim()) submit(m.text);
      else endListening();
      break;
    case "tts.audio":
      ttsWaiters.get(m.id)?.resolve(m.data);
      ttsWaiters.delete(m.id);
      break;
    case "tts.error":
      ttsWaiters.get(m.id)?.reject(new Error(m.message));
      ttsWaiters.delete(m.id);
      break;
    case "permission.request":
      perms.push(m);
      renderPerm();
      speaker.say(m.title || "J'ai besoin de ton accord.");
      break;
    case "permission.resolved": {
      const i = perms.findIndex((p) => p.id === m.id);
      if (i >= 0) perms.splice(i, 1);
      renderPerm();
      break;
    }
    case "ui.snapshot":
      wins.clear();
      for (const w of m.windows || []) wins.set(w.id, w);
      renderWins();
      break;
    case "ui.open":
    case "ui.update":
      wins.set(m.win.id, m.win);
      renderWins();
      break;
    case "ui.close":
      wins.delete(m.id);
      renderWins();
      break;
    case "nav.status":
      if (m.message) app.toast(m.message);
      break;
  }
}

// ---------- 60 images/s : mesures lissées, écrans animés ----------
const smoother = new Smoother();
app.live = smoother.v;
function loop() {
  smoother.step(app.car?.v);
  const s = byId[app.screen];
  if (s?.perFrame) s.update?.();
  s?.frame?.();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

// ---------- mode nuit : voile sombre (bien plus léger qu'un filtre sur tout l'écran) ----------
const nightEl = document.createElement("div");
nightEl.style.cssText = "position:absolute;inset:0;z-index:70;pointer-events:none;background:#000;opacity:0;transition:opacity 900ms cubic-bezier(.33,0,.2,1)";
nightEl.style.background = "rgba(0,0,0,.5)";
stage.appendChild(nightEl);

// les écrans sans données temps réel se rafraîchissent quand même (horloges, réglages)
setInterval(() => {
  if (app.screen === "reglages") reglages.update();
}, 250);

app.go("lancement");

// Préchauffage pendant l'écran de lancement : chaque écran est dessiné une fois, invisible,
// pour que les images soient décodées et les calques prêts : la première transition est aussi fluide que les suivantes.
for (const src of ["logo.png", "logo-glow-w.png", "logo-glow-t.png", "logo-shadow.png", "logo-bright.png"]) {
  const im = new Image();
  im.src = src;
  im.decode?.().catch(() => {});
}
(async () => {
  for (const s of SCREENS) {
    if (s.id === "lancement") continue;
    await new Promise((r) => setTimeout(r, 120));
    if (app.booted || app.screen !== "lancement") return;
    const el = els[s.id];
    el.style.opacity = "0.001";
    el.style.zIndex = "0";
    el.classList.add("on");
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (app.screen !== s.id) el.classList.remove("on");
    el.style.opacity = "";
    el.style.zIndex = "";
  }
})();
connect();
