// Nova Auto : l'écran de la voiture. Relie les 8 écrans au cerveau de Nova (WebSocket),
// gère la voix (micro, mot « Nova », synthèse) et les surcouches (alerte, autorisation, fenêtres).
import { esc } from "./bind.js";
import { swap, stagger, popIn, popOut, Smoother, EASE, reduced } from "./motion.js";
import { Speaker, startMicStream, chime, loadSettings } from "./voice.js";
import veille from "./screens/veille.js";
import lancement from "./screens/lancement.js";
import tableau from "./screens/tableau.js";
import rapports from "./screens/rapports.js";
import diagnostic from "./screens/diagnostic.js";
import alerte from "./screens/alerte.js";
import apprentissage from "./screens/apprentissage.js";
import media from "./screens/media.js";
import reglages from "./screens/reglages.js";
import calculateurs from "./screens/calculateurs.js";
import multiScreen from "./screens/multi.js";
import canScreen from "./screens/can.js";

const stage = document.getElementById("stage");

// ---------- journal de l'écran (Réglages → Journaux → Écran) ----------
const T0 = performance.now();
const logQueue = [];
function clog(level, text) {
  const m = { type: "client.log", level, text };
  const w = window.__novaWs;
  if (w?.readyState === 1) w.send(JSON.stringify(m));
  else if (logQueue.length < 200) logQueue.push(m);
}
window.addEventListener("error", (e) => clog("error", `${e.message} (${(e.filename || "").split("/").pop()}:${e.lineno}:${e.colno})${e.error?.stack ? "\n" + e.error.stack : ""}`));
window.addEventListener("unhandledrejection", (e) => clog("error", "Promesse rejetée : " + (e.reason?.stack || e.reason)));
// la page a-t-elle été relancée sans être fermée proprement (plantage de l'écran) ?
try {
  const prev = JSON.parse(localStorage.getItem("nova.alive") || "null");
  if (prev && !prev.clean) setTimeout(() => clog("error", `L'écran de Nova a redémarré sans s'être fermé proprement (plantage du navigateur ou de l'affichage) · dernier écran : ${prev.screen} · il y a ${Math.round((Date.now() - prev.at) / 1000)} s`), 1500);
} catch {}
const alive = () => {
  if (window.nova?.closing) return;
  try {
    localStorage.setItem("nova.alive", JSON.stringify({ screen: window.nova?.screen || "?", at: Date.now(), clean: false }));
  } catch {}
};
setInterval(alive, 2000);
window.addEventListener("pagehide", () => {
  try {
    localStorage.setItem("nova.alive", JSON.stringify({ screen: window.nova?.screen || "?", at: Date.now(), clean: true }));
  } catch {}
});
const SCREENS = [lancement, veille, tableau, media, diagnostic, calculateurs, multiScreen, canScreen, rapports, apprentissage, reglages];

// ---------- mise à l'échelle 1024×600, réglable dans Réglages → Écran ----------
//   ajuster : tout l'écran de Nova visible, proportions gardées (bandes si l'écran n'est pas au même format)
//   remplir : occupe tout l'écran, quitte à étirer un peu
//   taille  : 70 à 100 % (marge pour les écrans qui rognent les bords)
export function loadDisplay() {
  try {
    return { fit: "remplir", zoom: 100, effects: "auto", ...JSON.parse(localStorage.getItem("nova.display") || "{}") };
  } catch {
    return { fit: "remplir", zoom: 100, effects: "auto" };
  }
}
function fit() {
  const d = app.display;
  const z = Math.max(0.5, Math.min(1, (d.zoom || 100) / 100));
  const kx = (window.innerWidth / 1024) * z;
  const ky = (window.innerHeight / 600) * z;
  const k = Math.min(kx, ky);
  stage.style.transform = d.fit === "remplir" ? `scale(${kx}, ${ky})` : `scale(${k})`;
}
window.addEventListener("resize", () => fit());

// ---------- état ----------
const app = {
  connected: false,
  driver: "Joan",
  modes: [],
  car: { v: {}, mode: 0 },
  sources: [],
  diag: null,
  learn: null,
  rapports: null,
  phone: {},
  music: null,
  hw: {},
  config: null,
  voices: null,
  models: {},
  night: false,
  alerts: new Map(),
  acked: new Set(),
  busy: false,
  settings: loadSettings(),
  nova: { mode: "idle", words: [], wi: -1, kick: 0, level: 0, micLevel: 0, heard: "" },
  screen: null,
  prevScreen: null,
  booted: false,
  sys: null,
  maps: { dest: "", from: "" },
  display: loadDisplay(),
};
window.nova = app; // pour le débogage depuis la console

fit();
app.setDisplay = (patch, fromServer = false) => {
  Object.assign(app.display, patch);
  try {
    localStorage.setItem("nova.display", JSON.stringify(app.display));
  } catch {}
  // copie chez le serveur : « Relancer l'écran » coupe le navigateur avant qu'il ait tout écrit sur le disque
  if (!fromServer) app.send({ type: "display.prefs", prefs: app.display });
  fit();
  applyEffects();
};

// ---------- effets : allégés automatiquement si l'image est dessinée sans carte graphique ----------
let softwareGpu = false;
try {
  const gl = document.createElement("canvas").getContext("webgl");
  const dbg = gl?.getExtension("WEBGL_debug_renderer_info");
  const r = gl ? String(gl.getParameter(dbg ? dbg.UNMASKED_RENDERER_WEBGL : gl.RENDERER)) : "aucun";
  app.gpu = r;
  softwareGpu = !gl || /swiftshader|llvmpipe|softpipe|software|microsoft basic/i.test(r);
} catch {
  softwareGpu = true;
}
if (softwareGpu) setTimeout(() => clog("warn", "Pas d'accélération graphique : " + app.gpu + " → effets légers"), 2000);
let slowFrames = false;
function applyEffects() {
  const e = app.display.effects;
  const lite = e === "lite" || (e === "auto" && (softwareGpu || slowFrames));
  document.body.classList.toggle("lite", lite);
  app.lite = lite;
}
applyEffects();

let ws = null;
let bootSent = false;
app.clog = clog;
app.send = (m) => {
  if (ws?.readyState === 1) ws.send(JSON.stringify(m));
};
app.sendBinary = (buf) => {
  if (ws?.readyState === 1 && ws.bufferedAmount < 256_000) {
    ws.send(buf);
    return true;
  }
  return false;
};

// ---------- écrans ----------
const els = {};
for (const s of SCREENS) {
  const el = document.createElement("div");
  el.className = "screen";
  el.dataset.screen = s.id;
  el.innerHTML = s.html;
  stage.appendChild(el);
  els[s.id] = el;
  s.mount(el, app);
}
// l'alerte passe par-dessus tout
const alertLayer = document.createElement("div");
alertLayer.className = "screen";
alertLayer.style.zIndex = 40;
alertLayer.innerHTML = alerte.html;
stage.appendChild(alertLayer);
alerte.mount(alertLayer, app);

// navigation par les onglets
stage.addEventListener("click", (e) => {
  const b = e.target.closest("[data-go]");
  if (b) app.go(b.dataset.go);
});

const byId = Object.fromEntries(SCREENS.map((s) => [s.id, s]));
app.go = (id) => {
  if (!byId[id] || id === app.screen) return;
  if (!app.booted && id !== "lancement") return;
  const cur = byId[app.screen];
  const fromId = app.screen;
  const fromEl = fromId ? els[fromId] : null;
  if (cur) cur.hide?.();
  app.prevScreen = app.screen;
  app.screen = id;
  els[id].classList.add("on");
  byId[id].show?.();
  byId[id].update?.();
  byId[id].frame?.();
  swap(fromEl, els[id], fromId, id, () => {
    if (fromEl && app.screen !== fromId) fromEl.classList.remove("on");
  });
  if (id !== "lancement" && fromId !== "lancement") stagger(els[id]);
  if (id !== "lancement") app.send({ type: "screen.changed", name: id });
  renderStatus();
  // temps d'affichage de l'écran (deux images : dessiné et montré)
  const t0 = performance.now();
  requestAnimationFrame(() => requestAnimationFrame(() => clog("info", `Écran « ${id} » affiché en ${Math.round(performance.now() - t0)} ms (depuis « ${fromId || "-"} »)`)));
};
app.bootDone = () => {
  app.booted = true;
  app.go(app.car.running && app.config?.car?.autoDashboard !== false ? "tableau" : "veille");
  refreshAlertLayer();
};

// ---------- alertes ----------
app.pendingAlerts = () => {
  const rank = { Critique: 0, Attention: 1, Info: 2 };
  return [...app.alerts.values()].filter((a) => !app.acked.has(a.id)).sort((a, b) => rank[a.level] - rank[b.level] || a.at - b.at);
};
app.alertAcked = (id) => {
  app.acked.add(id);
  refreshAlertLayer();
};
let alertShown = false;
function refreshAlertLayer() {
  const show = app.booted && app.pendingAlerts().length > 0;
  if (show) alerte.update();
  if (show === alertShown) return;
  alertShown = show;
  if (show) {
    alertLayer.classList.add("on");
    popIn(alertLayer, "scale(1.03)", 460);
    stagger(alertLayer, 120);
  } else
    popOut(alertLayer, () => {
      if (!alertShown) alertLayer.classList.remove("on");
    }, "scale(.98)", 260);
}

// ---------- barre d'état : heure, batterie du PC, réseau, téléphone ----------
const statusEl = document.createElement("button");
statusEl.type = "button";
statusEl.className = "statusbar";
statusEl.setAttribute("aria-label", "État du PC : ouvrir les réglages");
statusEl.addEventListener("click", (e) => {
  e.stopPropagation();
  app.go("reglages");
});
stage.appendChild(statusEl);
const ICON = {
  wifi: (n) => `<svg width="15" height="12" viewBox="0 0 24 18" aria-hidden="true"><path d="M12 17l3-3.5a4.7 4.7 0 0 0-6 0z" fill="${n > 0 ? "#F1F3F5" : "#5A616B"}"/><path d="M5.6 10.4a9.5 9.5 0 0 1 12.8 0" stroke="${n > 1 ? "#F1F3F5" : "#5A616B"}" stroke-width="2.2" fill="none" stroke-linecap="round"/><path d="M2 6.6a14.6 14.6 0 0 1 20 0" stroke="${n > 2 ? "#F1F3F5" : "#5A616B"}" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg>`,
  bt: `<svg width="10" height="14" viewBox="0 0 12 20" aria-hidden="true"><path d="M1 5.5l9 8.5-4.5 4.5V1.5L10 6 1 14.5" stroke="#4FD1E8" stroke-width="2" fill="none" stroke-linejoin="round" stroke-linecap="round"/></svg>`,
  bat: (p, ch) => {
    const col = ch ? "#7BD88F" : p <= 15 ? "#FF4D2E" : p <= 30 ? "#F5B841" : "#F1F3F5";
    const w = Math.max(1, Math.round((Math.min(100, p) / 100) * 17));
    return `<svg width="26" height="13" viewBox="0 0 26 13" aria-hidden="true"><rect x=".75" y=".75" width="21.5" height="11.5" rx="3" stroke="#9AA1AA" stroke-width="1.5" fill="none"/><rect x="23.3" y="4" width="2" height="5" rx="1" fill="#9AA1AA"/><rect x="2.75" y="2.75" width="${w}" height="7.5" rx="1.5" fill="${col}"/>${ch ? '<path d="M12.5 2.2L8.8 7h3l-1.3 3.8L14.3 6h-3z" fill="#0E1013"/>' : ""}</svg>`;
  },
};
let statusKey = "";
function renderStatus() {
  const show = app.booted && app.screen !== "lancement";
  statusEl.style.display = show ? "flex" : "none";
  if (!show) return;
  const now = new Date();
  const time = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
  const st = app.sys;
  // Média et Tableau ont déjà leur horloge
  const parts = app.screen === "media" || app.screen === "tableau" ? [] : [`<span class="sb-time">${time}</span>`];
  if (st) {
    const w = st.wifi || {};
    if (st.ethernet) parts.push(`<span class="sb-it">Câble</span>`);
    else if (w.ssid) parts.push(`<span class="sb-it">${ICON.wifi(w.signal == null ? 3 : w.signal > 66 ? 3 : w.signal > 33 ? 2 : 1)}</span>`);
    else if (w.hardware) parts.push(`<span class="sb-it sb-dim">${ICON.wifi(0)}</span>`);
    else if (!st.online && st.platform === "linux") parts.push(`<span class="sb-it sb-warn">Hors ligne</span>`);
    if ((st.bt?.devices || []).some((d) => d.connected) || app.phone?.name) parts.push(`<span class="sb-it">${ICON.bt}</span>`);
    const b = st.battery || {};
    if (b.present && b.pct != null) parts.push(`<span class="sb-it">${ICON.bat(b.pct, b.charging)}<span>${b.pct}%</span></span>`);
  }
  const html = parts.join("");
  if (!parts.length) {
    statusEl.style.display = "none";
    return;
  }
  if (html !== statusKey) statusEl.innerHTML = statusKey = html;
}
setInterval(renderStatus, 1000);

// ---------- surcouches : autorisation, fenêtres, message ----------
const overlay = document.createElement("div");
overlay.style.cssText = "position:absolute;inset:0;z-index:60;pointer-events:none";
stage.appendChild(overlay);
const toastEl = document.createElement("div");
toastEl.style.cssText = "position:absolute;left:50%;top:14px;transform:translateX(-50%);max-width:760px;padding:10px 18px;border-radius:14px;background:rgba(10,11,13,.94);border:1px solid #4A5058;font-size:14px;font-weight:600;color:#F1F3F5;display:none;pointer-events:auto";
overlay.appendChild(toastEl);
let toastTimer = 0;
toastEl.style.transform = "none";
toastEl.style.left = "0";
toastEl.style.right = "0";
toastEl.style.margin = "0 auto";
toastEl.style.width = "fit-content";
app.toast = (t, ms = 4000) => {
  const wasHidden = toastEl.style.display !== "block";
  toastEl.textContent = t;
  toastEl.style.display = "block";
  if (wasHidden) popIn(toastEl, "translateY(-14px)", 360);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => popOut(toastEl, () => (toastEl.style.display = "none"), "translateY(-10px)", 240), ms);
};

const permEl = document.createElement("div");
permEl.className = "card";
permEl.style.cssText += ";position:absolute;left:212px;top:150px;width:600px;padding:20px;display:none;flex-direction:column;gap:12px;pointer-events:auto";
overlay.appendChild(permEl);
const perms = [];
let permShownId = null;
function renderPerm() {
  const p = perms[0];
  if (!p) {
    if (permShownId) popOut(permEl, () => (permEl.style.display = perms.length ? "flex" : "none"), "scale(.97)");
    permShownId = null;
    return;
  }
  const danger = p.level === "danger";
  permEl.style.display = "flex";
  if (permShownId !== p.id) popIn(permEl, "translateY(12px) scale(.96)", 420);
  permShownId = p.id;
  permEl.style.borderColor = danger ? "#F5B841" : "#4FD1E8";
  permEl.innerHTML = `<div style="display:flex;align-items:center;gap:12px"><img src="logo.png" alt="" style="width:56px;height:32px;object-fit:contain"><span style="font-size:20px;font-weight:700">${esc(p.title || "Nova demande ton accord")}</span></div>
    <p style="margin:0;font-size:15px;line-height:1.45;color:#E6EAEE;word-break:break-word">${esc(p.summary)}</p>
    ${p.detail ? `<pre class="win-body" style="margin:0;max-height:160px;white-space:pre-wrap;font-size:12px;padding:8px;border-radius:8px;background:#15171B">${esc(p.detail)}</pre>` : ""}
    ${p.note ? `<span class="lbl" style="font-size:10px;letter-spacing:.04em;text-transform:none">${esc(p.note)}</span>` : ""}
    <div style="display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn" data-perm="0">Refuser</button><button type="button" class="btn" data-perm="1" style="border-color:${danger ? "#F5B841" : "#4FD1E8"};color:#FFFFFF">Autoriser</button></div>`;
}
permEl.addEventListener("click", (e) => {
  const b = e.target.closest("[data-perm]");
  if (!b || !perms[0]) return;
  app.send({ type: "permission", id: perms[0].id, allow: b.dataset.perm === "1" });
});

// fenêtres ouvertes par Nova (show_window) : une carte à droite
const winEl = document.createElement("div");
winEl.className = "card";
winEl.style.cssText += ";position:absolute;right:16px;top:60px;width:430px;padding:14px 16px;display:none;flex-direction:column;gap:8px;pointer-events:auto";
overlay.appendChild(winEl);
const wins = new Map();
function md(s) {
  let h = esc(s || "");
  h = h.replace(/```([\s\S]*?)```/g, (_, c) => `<pre>${c}</pre>`);
  h = h.replace(/^### (.*)$/gm, "<b>$1</b>").replace(/^## (.*)$/gm, '<b style="font-size:16px">$1</b>').replace(/^# (.*)$/gm, '<b style="font-size:17px">$1</b>');
  h = h.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>");
  h = h.replace(/^\s*[-*] (.*)$/gm, "• $1");
  h = h.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1");
  return h.replace(/\n/g, "<br>");
}
let winShownId = null;
function renderWins() {
  const list = [...wins.values()].filter((w) => w.kind !== "music").sort((a, b) => b.createdAt - a.createdAt);
  const w = list[0];
  if (!w) {
    if (winShownId) popOut(winEl, () => (winEl.style.display = wins.size ? "flex" : "none"), "translateX(24px)");
    winShownId = null;
    return;
  }
  if (winShownId !== w.id) {
    winEl.style.display = "flex";
    popIn(winEl, "translateX(28px)", 420);
  }
  winShownId = w.id;
  let body = "";
  if (w.kind === "markdown" || w.kind === "code") body = md(w.kind === "code" ? "```" + (w.content || "") + "```" : w.content);
  else if (w.kind === "list" || w.kind === "checklist") body = (w.items || []).map((it, i) => `<div data-check="${i}" style="padding:4px 0;${it.done ? "color:#7BD88F" : ""}">${w.kind === "checklist" ? (it.done ? "☑ " : "☐ ") : "• "}${esc(it.text)}</div>`).join("");
  else if (w.kind === "table") body = `<table><tr>${(w.columns || []).map((c) => `<th>${esc(c)}</th>`).join("")}</tr>${(w.rows || []).map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</table>`;
  else if (w.kind === "log" || w.kind === "activity") body = (w.lines || []).slice(-14).map((l) => `<div style="font-size:12px">${esc(l)}</div>`).join("");
  else if (w.kind === "progress") body = `<div style="height:8px;border-radius:4px;background:#2A2E34;overflow:hidden"><div style="height:100%;width:${w.percent ?? 0}%;background:#4FD1E8"></div></div>${md(w.content)}`;
  else if (w.kind === "image") body = `<img src="${esc(w.url || "")}" alt="" style="max-width:100%;border-radius:8px">`;
  else if (w.kind === "timer") body = `<span class="num" style="font-size:40px">${w.endsAt ? Math.max(0, Math.round((w.endsAt - Date.now()) / 1000)) + " s" : ""}</span>`;
  else body = md(w.content);
  winEl.style.display = "flex";
  winEl.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><span style="font-size:16px;font-weight:700">${esc(w.title)}</span><span style="display:flex;gap:6px;align-items:center">${list.length > 1 ? `<span class="lbl" style="font-size:9px">+${list.length - 1}</span>` : ""}<button type="button" class="tab" data-close="${esc(w.id)}" aria-label="Fermer" style="min-height:36px;padding:0 10px">✕</button></span></div><div class="win-body scroll">${body}</div>`;
}
winEl.addEventListener("click", (e) => {
  const c = e.target.closest("[data-close]");
  if (c) {
    app.send({ type: "ui.closed", id: c.dataset.close });
    wins.delete(c.dataset.close);
    renderWins();
  }
  const k = e.target.closest("[data-check]");
  if (k) {
    const w = [...wins.values()].sort((a, b) => b.createdAt - a.createdAt)[0];
    if (w) app.send({ type: "ui.check", id: w.id, index: Number(k.dataset.check) });
  }
});

// ---------- voix ----------
const N = app.nova;
let wordTimers = [];
let returnTimer = 0;
let returnTo = null;
let listenMode = null; // "local" | "browser" | null
let localReady = false;
let lastLevelSent = 0;
let turnAsked = false;
let convo = false; // une conversation est en cours (et pas une simple annonce)

function setMode(m) {
  N.mode = m;
  if (m === "listen") convo = true;
  if (m === "idle") convo = false;
  if (convo && (m === "listen" || m === "think" || m === "speak")) {
    clearTimeout(returnTimer);
    if (app.booted && app.config?.car?.voiceFullscreen !== false && app.screen !== "veille" && app.screen !== "reglages" && !app.diag?.running) {
      returnTo = app.screen;
      app.go("veille");
    }
  } else if (m === "idle" && returnTo) {
    clearTimeout(returnTimer);
    returnTimer = setTimeout(() => {
      if (N.mode === "idle" && app.screen === "veille" && returnTo) app.go(returnTo);
      returnTo = null;
    }, 3500);
  }
}

const speaker = new Speaker(
  () => app.settings,
  (req) =>
    new Promise((resolve, reject) => {
      const id = Math.random().toString(36).slice(2);
      ttsWaiters.set(id, { resolve, reject });
      app.send({ type: "tts", id, ...req });
      setTimeout(() => {
        if (ttsWaiters.has(id)) {
          ttsWaiters.delete(id);
          reject(new Error("la voix locale ne répond pas"));
        }
      }, 20000);
    }),
  {
    onActive: (on) => {
      app.send({ type: "audio.pause", paused: on });
      app.send({ type: "voice.speaking", on });
      if (on) setMode("speak");
      else {
        N.kick = 0;
        N.wi = N.words.length;
        setMode(app.busy ? "think" : "idle");
      }
    },
    onLevel: (l) => {
      N.level = l;
      const now = performance.now();
      if (now - lastLevelSent > 100) {
        lastLevelSent = now;
        app.send({ type: "voice.level", level: l });
      }
    },
    onSentence: (text, seconds, browser) => {
      wordTimers.forEach(clearTimeout);
      wordTimers = [];
      const words = text.split(/\s+/).filter(Boolean);
      N.words = words;
      N.wi = -1;
      if (browser) return; // les mots avancent avec la voix du navigateur
      // même rythme que la maquette, étiré sur la durée réelle de la phrase
      const w = words.map((x) => 150 + x.replace(/[^\p{L}\p{N}]/gu, "").length * 55 + (/[.,!?;:]$/.test(x) ? 380 : 0));
      const total = w.reduce((a, b) => a + b, 0) || 1;
      const k = (seconds * 1000) / total;
      let t = 0;
      words.forEach((x, i) => {
        const len = x.replace(/[^\p{L}\p{N}]/gu, "").length;
        const amp = Math.min(1, 0.35 + len * 0.08);
        wordTimers.push(setTimeout(() => ((N.wi = i), (N.kick = amp)), t * k));
        wordTimers.push(setTimeout(() => (N.kick = 0), t * k + 150));
        t += w[i];
      });
    },
    onWord: (i) => {
      N.wi = i;
      N.kick = 0.7;
      setTimeout(() => (N.kick = 0), 150);
    },
    onError: (m) => console.warn("voix :", m),
  },
);
const ttsWaiters = new Map();

let recog = null;
function startListening() {
  speaker.stop();
  N.heard = "";
  chime("start", app.settings);
  setMode("listen");
  if (app.settings.localStt && localReady) {
    listenMode = "local";
    app.send({ type: "listen.start" });
    return;
  }
  // secours : reconnaissance vocale du navigateur (Chrome / Chromium, passe par Internet)
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    setMode("idle");
    app.toast("Reconnaissance vocale indisponible : télécharge-la dans les réglages.");
    return;
  }
  listenMode = "browser";
  recog = new SR();
  recog.lang = "fr-FR";
  recog.interimResults = true;
  recog.onresult = (e) => {
    const r = e.results[e.results.length - 1];
    N.heard = r[0].transcript;
    if (r.isFinal) submit(N.heard);
  };
  recog.onerror = () => endListening();
  recog.onend = () => {
    if (listenMode === "browser") endListening();
  };
  recog.start();
}
function endListening() {
  listenMode = null;
  if (N.mode === "listen") setMode("idle");
}
function submit(text) {
  listenMode = null;
  const t = text.trim();
  if (!t) return endListening();
  N.heard = t;
  turnAsked = true;
  setMode("think");
  app.send({ type: "chat", text: t });
}
app.voice = {
  toggle() {
    if (N.mode === "idle") startListening();
    else {
      speaker.stop();
      if (listenMode === "local") app.send({ type: "listen.cancel" });
      recog?.abort?.();
      listenMode = null;
      if (app.busy) app.send({ type: "interrupt" });
      setMode("idle");
    }
  },
  say(text) {
    speaker.say(text);
  },
  reconfigure() {
    restartMic();
  },
};

let mic = null;
async function restartMic() {
  mic?.stop();
  mic = null;
  localReady = false;
  const s = app.settings;
  if (!app.connected || (!s.wakeWord && !s.localStt)) return;
  try {
    mic = await startMicStream(s.micId, app.sendBinary, (l) => (N.micLevel = N.micLevel * 0.6 + l * 0.4));
    app.send({ type: "audio.config", sampleRate: mic.sampleRate, wake: s.wakeWord, sensitivity: s.sensitivity, silence: s.silence, localStt: s.localStt });
  } catch (e) {
    console.warn("micro :", e);
    app.toast("Micro inaccessible : " + (e?.message || e));
  }
}

// ---------- connexion au cerveau ----------
function connect() {
  const token = new URLSearchParams(location.search).get("token");
  ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws${token ? "?token=" + encodeURIComponent(token) : ""}`);
  ws.binaryType = "arraybuffer";
  window.__novaWs = ws;
  ws.onopen = () => {
    app.connected = true;
    restartMic();
    while (logQueue.length) ws.send(JSON.stringify(logQueue.shift()));
    if (!bootSent) {
      bootSent = true;
      ws.send(JSON.stringify({ type: "client.boot", gpu: app.gpu, load: Math.round(performance.now()), ua: navigator.userAgent.replace(/^Mozilla\/5\.0 /, "") + ` · écran ${screen.width}×${screen.height} · fenêtre ${innerWidth}×${innerHeight} · ${navigator.hardwareConcurrency} cœurs · ${navigator.deviceMemory || "?"} Go` }));
    }
  };
  ws.onclose = () => {
    app.connected = false;
    mic?.stop();
    mic = null;
    setTimeout(connect, 1500);
  };
  ws.onmessage = (ev) => {
    let m;
    try {
      m = JSON.parse(ev.data);
    } catch {
      return;
    }
    handle(m);
  };
}

function handle(m) {
  switch (m.type) {
    case "hello":
      app.driver = m.driver || "Joan";
      app.modes = m.modes || [];
      break;
    case "car":
      app.car = m;
      if (!byId[app.screen]?.perFrame) byId[app.screen]?.update?.();
      if (alertLayer.classList.contains("on") && Math.random() < 0.2) alerte.update();
      break;
    case "sources":
      app.sources = m.items || [];
      break;
    case "diag":
      app.diag = m;
      break;
    case "learn":
      app.learn = m;
      break;
    case "rapports":
      app.rapports = m;
      if (app.screen === "rapports") rapports.render();
      break;
    case "phone":
      app.phone = m;
      if (app.screen === "media") media.update();
      break;
    case "music":
      app.music = m.state;
      if (app.screen === "media") media.update();
      break;
    case "hw":
      app.hw = m;
      break;
    case "vag":
      app.vag = m;
      if (app.screen === "calculateurs") calculateurs.update();
      if (app.screen === "multi") multiScreen.update();
      break;
    case "can.find":
      app.canFind = m;
      if (app.screen === "calculateurs") calculateurs.update();
      if (app.screen === "can") canScreen.update();
      break;
    case "can.view":
      app.can = m;
      if (app.screen === "can") canScreen.update();
      break;
    case "toast":
      app.toast(m.message);
      break;
    case "night":
      app.night = !!m.on;
      nightEl.style.opacity = app.night ? "1" : "0";
      break;
    case "config":
      app.config = m;
      break;
    case "voices":
      app.voices = m;
      if (app.screen === "reglages") reglages.update();
      break;
    case "model":
      app.models = m.models || {};
      break;
    case "boot":
      lancement.onBoot(m.checks);
      break;
    case "screen":
      if (app.booted) {
        returnTo = null;
        app.go(m.name);
      }
      break;
    case "alert":
    case "alert.update": {
      const isNew = m.type === "alert" && !app.alerts.has(m.alert.id);
      if (m.type === "alert" && m.alert.acked === false) app.acked.delete(m.alert.id);
      app.alerts.set(m.alert.id, m.alert);
      if (isNew && app.booted) chime("alert", app.settings);
      refreshAlertLayer();
      break;
    }
    case "alert.clear":
      app.alerts.delete(m.id);
      app.acked.delete(m.id);
      refreshAlertLayer();
      break;
    case "say":
      speaker.say(m.text);
      break;
    case "snapshot":
      app.busy = !!m.busy;
      break;
    case "state":
      app.busy = m.state === "think";
      if (m.state === "think" && N.mode === "idle") setMode("think");
      if (m.state === "idle" && N.mode === "think" && !speaker.active) setMode("idle");
      break;
    case "text.delta":
      speaker.push(m.text);
      break;
    case "done": {
      speaker.flush();
      const full = (m.text || "").trim();
      const mode = app.settings.followUp;
      if (turnAsked && mode !== "never" && (mode === "always" || /\?\s*["»)]?\s*$/.test(full))) {
        speaker.whenIdle().then(() => {
          if (!listenMode && N.mode === "idle") startListening();
        });
      }
      turnAsked = false;
      break;
    }
    case "error":
      app.toast(m.message);
      if (N.mode === "think" && !speaker.active) setMode("idle");
      break;
    case "wake":
      speaker.stop();
      if (listenMode) break;
      if (m.local) {
        chime("start", app.settings);
        listenMode = "local";
        N.heard = m.command || "";
        setMode("listen");
      } else startListening();
      break;
    case "audio.ready":
      localReady = !!m.localStt;
      break;
    case "stt.partial":
      N.heard = m.text;
      break;
    case "stt.final":
      listenMode = null;
      if (m.text && m.text.trim()) submit(m.text);
      else endListening();
      break;
    case "tts.audio":
      ttsWaiters.get(m.id)?.resolve(m.data);
      ttsWaiters.delete(m.id);
      break;
    case "tts.error":
      ttsWaiters.get(m.id)?.reject(new Error(m.message));
      ttsWaiters.delete(m.id);
      break;
    case "permission.request":
      perms.push(m);
      renderPerm();
      speaker.say(m.title || "J'ai besoin de ton accord.");
      break;
    case "permission.resolved": {
      const i = perms.findIndex((p) => p.id === m.id);
      if (i >= 0) perms.splice(i, 1);
      renderPerm();
      break;
    }
    case "ui.snapshot":
      wins.clear();
      for (const w of m.windows || []) wins.set(w.id, w);
      renderWins();
      break;
    case "ui.open":
    case "ui.update":
      wins.set(m.win.id, m.win);
      renderWins();
      break;
    case "ui.close":
      wins.delete(m.id);
      renderWins();
      break;
    case "nav.status":
      if (m.message) app.toast(m.message);
      break;
    case "screen.closing":
      // fermeture voulue (relance, menu) : ce n'est pas un plantage
      try {
        localStorage.setItem("nova.alive", JSON.stringify({ screen: app.screen, at: Date.now(), clean: true }));
      } catch {}
      app.closing = true;
      break;
    case "sys":
      if (m.persist?.state === "off" && !app.persistWarned && app.booted) {
        app.persistWarned = true;
        setTimeout(() => app.toast("Tes réglages ne sont pas sauvegardés sur la clé : Réglages → Nova OS → « Activer la sauvegarde des réglages ».", 9000), 3000);
      }
      for (const d of m.kde?.devices || []) {
        if (d.requested && !app.sys?.kde?.devices?.some((x) => x.id === d.id && x.requested)) app.toast(`${d.name} demande à s'associer à Nova : Réglages → Téléphone → touche-le pour accepter.`, 10000);
      }
      app.sys = m;
      renderStatus();
      if (app.screen === "reglages") reglages.update();
      if (app.screen === "calculateurs") calculateurs.update();
      break;
    case "maj":
      app.maj = m;
      if (m.status === "ready" && !app.majWarned) {
        app.majWarned = true;
        app.toast(`Nova ${m.available} est disponible : Réglages → Mises à jour.`, 8000);
      }
      if (app.screen === "reglages") reglages.update();
      break;
    case "display.prefs":
      if (m.prefs && typeof m.prefs === "object" && JSON.stringify(m.prefs) !== JSON.stringify(app.display)) {
        app.setDisplay(m.prefs, true);
        if (app.screen === "reglages") reglages.update();
      }
      break;
    case "fichiers":
      app.fichiers = m;
      if (app.screen === "reglages") reglages.update();
      break;
    case "majos":
      if (m.status === "available" && app.majos?.status !== "available") app.toast(`Nova OS ${m.disponible} est disponible : Réglages → Système Nova OS.`, 8000);
      app.majos = m;
      if (app.screen === "reglages") reglages.update();
      break;
    case "logs.list":
      app.logs = m;
      if (app.screen === "reglages") reglages.update();
      break;
    case "logs.read":
      reglages.showLog?.(m.name, m.text);
      break;
    case "logs.exported":
      app.logsExported = m;
      reglages.exporting = false;
      app.toast(m.copied?.length ? "Rapport copié sur la clé : dossier nova-journaux" : "Rapport enregistré (pas de clé USB lisible trouvée)", 6000);
      if (app.screen === "reglages") reglages.update();
      break;
    case "sys.report":
      app.sysReport = m;
      if (app.screen === "reglages") reglages.update();
      break;
    case "maps.route":
      app.maps = { dest: m.dest || "", from: m.from || "" };
      media.route?.();
      break;
  }
}

// ---------- 60 images/s : mesures lissées, écrans animés ----------
const smoother = new Smoother();
app.live = smoother.v;
let fT = 0,
  fN = 0,
  fSum = 0;
// mesure de fluidité envoyée au journal toutes les 30 s
const perf = { frames: 0, worst: 0, since: performance.now(), long: 0 };
try {
  new PerformanceObserver((l) => (perf.long += l.getEntries().length)).observe({ entryTypes: ["longtask"] });
} catch {}
setInterval(() => {
  const dt = (performance.now() - perf.since) / 1000;
  if (document.hidden || !app.booted || dt < 5) return;
  const fps = Math.round(perf.frames / dt);
  app.send({ type: "client.perf", perf: { fps, worst: Math.round(perf.worst), longTasks: perf.long, screen: app.screen, lite: !!app.lite, heapMb: performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : 0, w: innerWidth, h: innerHeight, dpr: devicePixelRatio } });
  perf.frames = 0;
  perf.worst = 0;
  perf.long = 0;
  perf.since = performance.now();
}, 30000);
let lastWork = 0;
function loop(t) {
  // images trop lentes pendant 4 s d'affiche → effets allégés (mode « auto »)
  if (fT && !slowFrames && app.booted && !document.hidden) {
    const dt = t - fT;
    if (dt < 3000) {
      fSum += dt;
      if (++fN >= 240 || fSum > 6000) {
        if (fSum / fN > 24) {
          slowFrames = true;
          applyEffects();
          clog("warn", `Images trop lentes (${Math.round(1000 / (fSum / fN))} images/s en moyenne) : effets allégés automatiquement`);
        }
        fN = fSum = 0;
      }
    }
  }
  if (fT) {
    perf.frames++;
    perf.worst = Math.max(perf.worst, t - fT);
  }
  fT = t;
  requestAnimationFrame(loop);
  // effets légers : les mesures sont redessinées 20 fois par seconde au lieu de 60
  if (app.lite && t - lastWork < 48) return;
  lastWork = t;
  smoother.step(app.car?.v);
  const s = byId[app.screen];
  if (s?.perFrame) s.update?.();
  s?.frame?.();
}
requestAnimationFrame(loop);

// ---------- mode nuit : voile sombre (bien plus léger qu'un filtre sur tout l'écran) ----------
const nightEl = document.createElement("div");
nightEl.style.cssText = "position:absolute;inset:0;z-index:70;pointer-events:none;background:#000;opacity:0;transition:opacity 900ms cubic-bezier(.33,0,.2,1)";
nightEl.style.background = "rgba(0,0,0,.5)";
stage.appendChild(nightEl);

// les écrans sans données temps réel se rafraîchissent quand même (horloges, réglages)
setInterval(() => {
  if (app.screen === "reglages") reglages.update();
}, 250);

app.go("lancement");

// Préchauffage pendant l'écran de lancement : chaque écran est dessiné une fois, invisible,
// pour que les images soient décodées et les calques prêts : la première transition est aussi fluide que les suivantes.
for (const src of ["logo.png", "logo-glow-w.png", "logo-glow-t.png", "logo-shadow.png", "logo-bright.png"]) {
  const im = new Image();
  im.src = src;
  im.decode?.().catch(() => {});
}
(async () => {
  if (app.lite) return; // sans carte graphique, le préchauffage coûte plus qu'il ne rapporte
  for (const s of SCREENS) {
    if (s.id === "lancement") continue;
    await new Promise((r) => setTimeout(r, 120));
    if (app.booted || app.screen !== "lancement") return;
    const el = els[s.id];
    el.style.opacity = "0.001";
    el.style.zIndex = "0";
    el.classList.add("on");
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (app.screen !== s.id) el.classList.remove("on");
    el.style.opacity = "";
    el.style.zIndex = "";
  }
})();
connect();
