// Liste de la lecture multiple (groupes de plusieurs calculateurs lus à tour de rôle), partagée entre
// l'écran Calculateurs (bouton « + Multi » dans Mesures) et l'écran Lecture multiple.
const KEY = "nova.multi";
const hex = (a) => a.toString(16).toUpperCase().padStart(2, "0");

function load() {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]").filter((x) => x && x.addr && x.group);
  } catch {
    return [];
  }
}

export const multi = {
  items: load(),
  save(app) {
    try {
      localStorage.setItem(KEY, JSON.stringify(this.items));
    } catch {}
    // lecture en cours : elle suit la nouvelle liste
    if (app.vag?.multi) {
      if (this.items.length) app.send({ type: "vag.multi", items: this.items });
      else app.send({ type: "vag.multiStop" });
    }
  },
  has(addr, group) {
    return this.items.some((x) => x.addr === addr && x.group === group);
  },
  toggle(app, addr, group) {
    const i = this.items.findIndex((x) => x.addr === addr && x.group === group);
    if (i >= 0) this.items.splice(i, 1);
    else {
      if (this.items.length >= 8) return app.toast("Lecture multiple : 8 groupes au plus");
      this.items.push({ addr, group });
      app.toast(`Groupe ${String(group).padStart(3, "0")} de ${hex(addr)} ajouté à la lecture multiple`);
    }
    this.save(app);
  },
  remove(app, i) {
    this.items.splice(i, 1);
    this.save(app);
  },
  clear(app) {
    this.items = [];
    this.save(app);
  },
  /** Démarre ou arrête ; renvoie false s'il n'y a rien à lire. */
  run(app) {
    if (app.vag?.multi) {
      app.send({ type: "vag.multiStop" });
      return true;
    }
    if (!this.items.length) return false;
    app.send({ type: "vag.multi", items: this.items });
    return true;
  },
};

/** Onglets du haut, communs aux écrans de diagnostic. */
export function diagTabs(current) {
  const tabs = [["diagnostic", "Test moteur"], ["calculateurs", "Calculateurs"], ["multi", "Multi"], ["can", "CAN"]];
  const st = "font-size:11px;padding:0 12px;white-space:nowrap";
  return `<div style="display:flex;gap:6px;flex:none" role="group" aria-label="Diagnostic">${tabs
    .map(([id, name]) => (id === current ? `<button type="button" class="tab" aria-current="page" style="${st}">${name}</button>` : `<button type="button" class="tab" data-go="${id}" style="border-color:#4A5058;${st}">${name}</button>`))
    .join("")}</div>`;
}
