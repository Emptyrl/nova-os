// Mouvement de Nova : transitions entre écrans, apparitions, et lissage des valeurs à 60 images/s.
// Uniquement des transformations et de l'opacité (calculées par la carte graphique) : fluide même sur un vieux PC ou le Pi.

export const reduced = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

const OUT = "cubic-bezier(.4,0,1,1)";
const IN = "cubic-bezier(.16,1,.3,1)"; // sortie exponentielle : rapide puis très douce
export const EASE = { IN, OUT, SOFT: "cubic-bezier(.33,0,.2,1)" };

// ordre des écrans : sert à choisir le sens du glissement
const ORDER = ["veille", "tableau", "media", "diagnostic", "calculateurs", "rapports", "apprentissage", "reglages"];

const running = new WeakMap();
function stopAll(el) {
  for (const a of running.get(el) ?? []) a.cancel();
  running.set(el, []);
}
function track(el, a) {
  running.get(el)?.push(a) ?? running.set(el, [a]);
  return a;
}

/** Fait apparaître les blocs d'un écran les uns après les autres. */
export function stagger(screenEl, delay = 70) {
  if (reduced() || screenEl.dataset.screen === "veille") return;
  const root = screenEl.firstElementChild;
  if (!root) return;
  const kids = [...root.children].filter((k) => getComputedStyle(k).display !== "none").slice(0, 12);
  kids.forEach((k, i) => {
    track(
      screenEl,
      k.animate(
        [
          { opacity: 0, transform: "translateY(14px)" },
          { opacity: 1, transform: "none" },
        ],
        { duration: 520, delay: delay + i * 32, easing: IN, fill: "backwards" },
      ),
    );
  });
}

/** Transition entre deux écrans. done() est appelé quand l'ancien écran peut être caché. */
export function swap(fromEl, toEl, from, to, done) {
  if (fromEl) stopAll(fromEl);
  stopAll(toEl);
  if (reduced() || !fromEl) {
    done();
    return;
  }
  const a = ORDER.indexOf(from), b = ORDER.indexOf(to);
  let outK, inK, dur = 440;
  if (from === "lancement") {
    outK = [{ opacity: 1 }, { opacity: 0 }];
    inK = [{ opacity: 0, transform: "scale(1.04)" }, { opacity: 1, transform: "none" }];
    dur = 900;
  } else if (to === "veille") {
    // fondu des écrans ; seul le logo (petit calque) fait le zoom : léger même sans carte graphique
    outK = [{ opacity: 1 }, { opacity: 0 }];
    inK = [{ opacity: 0 }, { opacity: 1 }];
    dur = 520;
    const logo = toEl.querySelector(".core");
    if (logo && !reduced()) track(toEl, logo.animate([{ opacity: 0, transform: "scale(1.12)" }, { opacity: 1, transform: "none" }], { duration: 760, delay: 60, easing: IN, fill: "backwards" }));
  } else if (from === "veille") {
    outK = [{ opacity: 1 }, { opacity: 0 }];
    inK = [{ opacity: 0, transform: "translateY(10px)" }, { opacity: 1, transform: "none" }];
    dur = 480;
    const logo = fromEl.querySelector(".core");
    if (logo && !reduced()) track(fromEl, logo.animate([{ transform: "none" }, { transform: "scale(.9)" }], { duration: 260, easing: OUT, fill: "forwards" }));
  } else {
    const dir = b >= a ? 1 : -1;
    outK = [{ opacity: 1, transform: "none" }, { opacity: 0, transform: `translateX(${-dir * 40}px)` }];
    inK = [{ opacity: 0, transform: `translateX(${dir * 56}px)` }, { opacity: 1, transform: "none" }];
  }
  fromEl.style.pointerEvents = "none";
  fromEl.style.zIndex = "1";
  toEl.style.zIndex = "2";
  const o = track(fromEl, fromEl.animate(outK, { duration: Math.min(300, dur * 0.6), easing: OUT, fill: "forwards" }));
  track(toEl, toEl.animate(inK, { duration: dur, delay: 40, easing: IN, fill: "backwards" }));
  const end = () => {
    fromEl.style.pointerEvents = "";
    fromEl.style.zIndex = "";
    toEl.style.zIndex = "";
    o.cancel();
    done();
  };
  o.onfinish = end;
  o.oncancel = () => {
    fromEl.style.pointerEvents = "";
    fromEl.style.zIndex = "";
  };
}

/** Apparition d'une carte ou d'une surcouche. */
export function popIn(el, from = "translateY(-10px) scale(.98)", dur = 380) {
  if (reduced()) return;
  stopAll(el);
  track(el, el.animate([{ opacity: 0, transform: from }, { opacity: 1, transform: "none" }], { duration: dur, easing: IN }));
}

/** Disparition puis done() (pour masquer l'élément). */
export function popOut(el, done, to = "translateY(-6px) scale(.98)", dur = 220) {
  if (reduced()) return done();
  stopAll(el);
  const a = track(el, el.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: to }], { duration: dur, easing: OUT, fill: "forwards" }));
  a.onfinish = () => {
    done();
    a.cancel();
  };
}

// ---------- lissage des mesures ----------
// Les mesures arrivent 15 fois par seconde (ou moins avec la ligne K) : l'écran les fait glisser à 60 images/s.
const TAU = { rpm: 0.07, speed: 0.14, boost: 0.09, boostReq: 0.12, glat: 0.11, glong: 0.11, throttle: 0.08, pedal: 0.08, load: 0.12, maf: 0.12, water: 0.5, oil: 0.5, iat: 0.5, volt: 0.4, fuel: 0.8, l100: 0.35, fuelRate: 0.3, haldex: 0.25, timing: 0.15, lambda: 0.2 };

export class Smoother {
  constructor() {
    this.v = {};
    this.last = performance.now();
  }
  step(target) {
    const now = performance.now();
    const dt = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    for (const [k, t] of Object.entries(target || {})) {
      const cur = this.v[k];
      if (typeof t !== "number" || typeof cur !== "number" || !Number.isFinite(cur)) {
        this.v[k] = t;
        continue;
      }
      const tau = TAU[k] ?? 0.15;
      this.v[k] = cur + (t - cur) * (1 - Math.exp(-dt / tau));
      if (Math.abs(this.v[k] - t) < 1e-4) this.v[k] = t;
    }
    return this.v;
  }
}
