#!/usr/bin/env bash
# Linux : ./lancer.sh auto | kkl [/dev/ttyUSB0] | elm327 [/dev/ttyUSB0] | can | can+kkl
cd "$(dirname "$0")"
[ -d node_modules ] || npm install
[ -d dist ] || npm run build
SRC="${1:-auto}"
if [ -n "$2" ]; then exec node dist/server.js --source "$SRC" --port "$2"; else exec node dist/server.js --source "$SRC"; fi
