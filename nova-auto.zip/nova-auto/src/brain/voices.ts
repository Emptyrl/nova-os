// Voix locales : synthèse vocale 100 % sur le PC (sherpa-onnx + modèles Piper).
//
// %USERPROFILE%\Jarvis\voix\<id>\ contient un modèle :
//   - *.onnx (avec les métadonnées sherpa-onnx) + tokens.txt
//   - espeak-ng-data\ (ou à défaut celui partagé dans voix\_espeak-ng-data)
//   - voix.json facultatif : { "nom": "Nova", "description": "…", "locuteurs": ["…"] }
// Les voix du catalogue se téléchargent en un clic ; une voix perso (créée avec l'atelier de voix,
// dossier voix/ du projet) se dépose simplement dans ce dossier.
import { createRequire } from "node:module";
import { promises as fs, createWriteStream, existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import path from "node:path";

const require = createRequire(import.meta.url);
let sherpa: any = null;
try {
  sherpa = require("sherpa-onnx-node");
} catch {
  /* moteur local indisponible : seules les autres voix fonctionnent */
}

const RELEASE = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/";
const ESPEAK_DIR = "_espeak-ng-data";

interface CatalogVoice {
  id: string;
  name: string;
  description: string;
  archive: string; // nom de l'archive (sans .tar.bz2) = nom du dossier décompressé
  size: number;
  speakers?: string[];
}

export const CATALOG: CatalogVoice[] = [
  { id: "siwis", name: "Siwis", description: "Voix féminine claire, la plus naturelle du catalogue.", archive: "vits-piper-fr_FR-siwis-medium", size: 67_207_459 },
  { id: "tom", name: "Tom", description: "Voix masculine posée.", archive: "vits-piper-fr_FR-tom-medium", size: 67_202_955 },
  { id: "upmc", name: "UPMC", description: "Deux voix : Jessica (féminine) et Pierre (masculine).", archive: "vits-piper-fr_FR-upmc-medium", size: 80_422_639, speakers: ["Jessica", "Pierre"] },
  { id: "gilles", name: "Gilles", description: "Voix masculine grave, qualité plus modeste.", archive: "vits-piper-fr_FR-gilles-low", size: 67_094_350 },
];

export interface VoiceInfo {
  id: string;
  name: string;
  description: string;
  custom: boolean; // voix perso (créée avec l'atelier ou ajoutée à la main)
  status: "absent" | "downloading" | "ready" | "error";
  progress: number;
  error: string;
  size: number;
  speakers: string[];
}

interface Loaded {
  id: string;
  tts: any;
}

export class LocalVoices {
  info = new Map<string, VoiceInfo>();
  private root: string;
  private loaded: Loaded | null = null;
  private loading: Promise<Loaded> | null = null;
  private queue: Promise<unknown> = Promise.resolve();

  constructor(dataDir: string, private onChange: () => void, private log: (t: string) => void) {
    this.root = path.join(dataDir, "voix");
  }

  get available() {
    return !!sherpa;
  }

  list(): VoiceInfo[] {
    return [...this.info.values()];
  }

  /** Relit le dossier des voix (catalogue + voix perso). */
  async scan() {
    await fs.mkdir(this.root, { recursive: true });
    const keep = new Map<string, VoiceInfo>();
    for (const c of CATALOG) {
      const prev = this.info.get(c.id);
      const ready = !!(await this.findModel(path.join(this.root, c.archive)));
      keep.set(c.id, {
        id: c.id,
        name: c.name,
        description: c.description,
        custom: false,
        status: prev?.status === "downloading" ? "downloading" : ready ? "ready" : prev?.status === "error" ? "error" : "absent",
        progress: prev?.status === "downloading" ? prev.progress : ready ? 100 : 0,
        error: prev?.error ?? "",
        size: c.size,
        speakers: c.speakers ?? [],
      });
    }
    const catalogDirs = new Set(CATALOG.map((c) => c.archive));
    for (const d of await fs.readdir(this.root, { withFileTypes: true }).catch(() => [])) {
      if (!d.isDirectory() || catalogDirs.has(d.name) || d.name.startsWith("_") || d.name.startsWith(".")) continue;
      const dir = path.join(this.root, d.name);
      const model = await this.findModel(dir);
      let meta: { nom?: string; description?: string; locuteurs?: string[] } = {};
      try {
        meta = JSON.parse(await fs.readFile(path.join(dir, "voix.json"), "utf8"));
      } catch {
        /* facultatif */
      }
      keep.set("perso:" + d.name, {
        id: "perso:" + d.name,
        name: meta.nom || d.name,
        description: meta.description || "Voix perso.",
        custom: true,
        status: model ? "ready" : "error",
        progress: model ? 100 : 0,
        error: model ? "" : "Il manque le modèle (.onnx) ou tokens.txt dans ce dossier.",
        size: 0,
        speakers: meta.locuteurs ?? [],
      });
    }
    this.info = keep;
    this.onChange();
  }

  private dirOf(id: string) {
    const c = CATALOG.find((x) => x.id === id);
    if (c) return path.join(this.root, c.archive);
    if (id.startsWith("perso:")) {
      const name = id.slice(6);
      if (!name || name.includes("/") || name.includes("\\") || name.includes("..")) throw new Error("Voix inconnue.");
      return path.join(this.root, name);
    }
    throw new Error("Voix inconnue : " + id);
  }

  private async findModel(dir: string): Promise<{ model: string; tokens: string } | null> {
    try {
      const files = await fs.readdir(dir);
      const model = files.find((f) => f.endsWith(".onnx"));
      if (!model || !files.includes("tokens.txt")) return null;
      return { model: path.join(dir, model), tokens: path.join(dir, "tokens.txt") };
    } catch {
      return null;
    }
  }

  private async download(url: string, archive: string, size: number, onPct: (p: number) => void) {
    const res = await fetch(url);
    if (!res.ok || !res.body) throw new Error("téléchargement impossible (" + res.status + ")");
    const total = Number(res.headers.get("content-length")) || size;
    let received = 0;
    let last = -1;
    const body = Readable.fromWeb(res.body as any);
    body.on("data", (chunk: Buffer) => {
      received += chunk.length;
      const pct = Math.min(99, Math.floor((received / total) * 100));
      if (pct !== last) onPct((last = pct));
    });
    await pipeline(body, createWriteStream(archive));
    // tar est fourni avec Windows 10/11 et sait lire le .bz2
    await new Promise<void>((resolve, reject) => {
      const p = spawn("tar", ["-xjf", archive, "-C", this.root], { windowsHide: true });
      p.on("error", reject);
      p.on("exit", (code) => (code === 0 ? resolve() : reject(new Error("décompression impossible (" + code + ")"))));
    });
    await fs.rm(archive, { force: true });
  }

  /** Télécharge une voix du catalogue. */
  async install(id: string) {
    const c = CATALOG.find((x) => x.id === id);
    const info = this.info.get(id);
    if (!c || !info || info.status === "downloading" || info.status === "ready") return;
    Object.assign(info, { status: "downloading", progress: 0, error: "" });
    this.onChange();
    const archive = path.join(this.root, c.archive + ".tar.bz2");
    try {
      await fs.mkdir(this.root, { recursive: true });
      await this.download(RELEASE + c.archive + ".tar.bz2", archive, c.size, (p) => {
        info.progress = p;
        this.onChange();
      });
      if (!(await this.findModel(path.join(this.root, c.archive)))) throw new Error("archive incomplète");
      Object.assign(info, { status: "ready", progress: 100 });
      this.log("Voix locale installée : " + c.name);
    } catch (e: any) {
      Object.assign(info, { status: "error", error: String(e?.message || e) });
      await fs.rm(archive, { force: true }).catch(() => {});
    }
    this.onChange();
  }

  async remove(id: string) {
    const dir = this.dirOf(id);
    if (this.loaded?.id === id) this.unload();
    await fs.rm(dir, { recursive: true, force: true });
    await this.scan();
  }

  folder() {
    return this.root;
  }

  private unload() {
    try {
      this.loaded?.tts?.free?.();
    } catch {
      /* rien */
    }
    this.loaded = null;
  }

  /** Données de prononciation : celles de la voix, sinon celles partagées (téléchargées au besoin). */
  private async espeakFor(dir: string): Promise<string> {
    const own = path.join(dir, "espeak-ng-data");
    if (existsSync(own)) return own;
    for (const c of CATALOG) {
      const d = path.join(this.root, c.archive, "espeak-ng-data");
      if (existsSync(d)) return d;
    }
    const shared = path.join(this.root, ESPEAK_DIR);
    if (existsSync(path.join(shared, "phontab"))) return shared;
    // archive officielle de sherpa-onnx (7 Mo), décompressée en « espeak-ng-data » puis renommée
    const archive = path.join(this.root, "espeak-ng-data.tar.bz2");
    await this.download(RELEASE + "espeak-ng-data.tar.bz2", archive, 7_252_012, () => {});
    await fs.rm(shared, { recursive: true, force: true });
    await fs.rename(path.join(this.root, "espeak-ng-data"), shared);
    return shared;
  }

  private async load(id: string): Promise<Loaded> {
    if (!sherpa) throw new Error("Moteur de voix locale indisponible sur ce PC.");
    if (this.loaded?.id === id) return this.loaded;
    if (this.loading) {
      const l = await this.loading.catch(() => null);
      if (l?.id === id) return l;
    }
    this.loading = (async () => {
      const dir = this.dirOf(id);
      const m = await this.findModel(dir);
      if (!m) throw new Error("Cette voix n'est pas installée (Paramètres › Voix).");
      const dataDir = await this.espeakFor(dir);
      const tts = await sherpa.OfflineTts.createAsync({
        model: { vits: { model: m.model, tokens: m.tokens, dataDir, noiseScale: 0.667, noiseScaleW: 0.8, lengthScale: 1 }, numThreads: 2, provider: "cpu" },
        maxNumSentences: 1,
      });
      this.unload();
      this.loaded = { id, tts };
      this.log("Voix locale chargée : " + id);
      return this.loaded;
    })();
    try {
      return await this.loading;
    } finally {
      this.loading = null;
    }
  }

  /** Préchargement (au choix de la voix) : la première phrase sort sans attendre. */
  warm(id: string) {
    void this.load(id).catch(() => {});
  }

  /** Synthèse d'une phrase → WAV 16 bits en base64. Une phrase à la fois (le modèle n'est pas réentrant). */
  synth(id: string, text: string, speed = 1, speaker = 0): Promise<string> {
    const run = async () => {
      const { tts } = await this.load(id);
      const sid = Math.max(0, Math.min((tts.numSpeakers || 1) - 1, Math.round(speaker)));
      const audio = await tts.generateAsync({ text: text.slice(0, 2000), sid, speed: Math.max(0.5, Math.min(2, speed)) });
      return wav(audio.samples as Float32Array, audio.sampleRate as number).toString("base64");
    };
    const p = this.queue.then(run, run);
    this.queue = p.catch(() => {});
    return p;
  }
}

function wav(samples: Float32Array, rate: number): Buffer {
  const buf = Buffer.alloc(44 + samples.length * 2);
  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + samples.length * 2, 4);
  buf.write("WAVE", 8);
  buf.write("fmt ", 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20); // PCM
  buf.writeUInt16LE(1, 22); // mono
  buf.writeUInt32LE(rate, 24);
  buf.writeUInt32LE(rate * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write("data", 36);
  buf.writeUInt32LE(samples.length * 2, 40);
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(s < 0 ? s * 0x8000 : s * 0x7fff), 44 + i * 2);
  }
  return buf;
}
