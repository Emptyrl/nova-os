// Garde-fous : ce que Jarvis peut faire seul, et ce pour quoi il doit te demander.
import path from "node:path";

// Commandes sans risque : build, tests, lecture, git en lecture, gestionnaires de paquets.
const SAFE_COMMANDS: RegExp[] = [
  /^(npm|pnpm|yarn|bun)\s+(run|test|t|install|i|ci|add|exec|build|start|dev|lint|outdated|ls|list)\b/i,
  /^npx\s+(tsc|vitest|jest|eslint|prettier|vite|playwright test)\b/i,
  /^(node|deno|tsx|ts-node)\s/i,
  /^(python|python3|py)\s/i,
  /^(pip|pip3|uv|poetry)\s+(install|list|show|freeze|sync|run|add)\b/i,
  /^(pytest|ruff|mypy|black)\b/i,
  /^dotnet\s+(build|run|test|restore|clean|new|add|list|format|--info|--version)\b/i,
  /^(msbuild|nuget\s+restore)\b/i,
  /^cargo\s+(build|run|test|check|clippy|fmt|add|tree)\b/i,
  /^go\s+(build|run|test|vet|fmt|mod|get)\b/i,
  /^(mvn|gradle|gradlew|\.\/gradlew|gradlew\.bat)\s/i,
  /^(java|javac|kotlinc|gcc|g\+\+|clang|cmake|make|ninja)\b/i,
  /^git\s+(status|diff|log|show|branch|add|stash|fetch|checkout|switch|rev-parse|remote\s+-v|blame)\b/i,
  /^(ls|dir|pwd|cd|cat|type|head|tail|echo|where|which|wc|find|findstr|grep|rg|tree|code)\b/i,
  /^(Get-ChildItem|Get-Content|Get-Location|Select-String|Test-Path|Write-Output)\b/i,
];

// Toujours demander, même si le début de la commande paraît sûr.
const DANGEROUS: RegExp[] = [
  /\b(rm|rmdir|del|erase|rd|Remove-Item|unlink|shred)\b/i,
  /\bgit\s+(push|reset\s+--hard|clean|tag\s+-d|branch\s+-D|filter-branch)\b/i,
  /\bformat(\.com)?\s+[a-z]:|\b(diskpart|shutdown|restart-computer|stop-computer|reg\s+(add|delete)|Set-ItemProperty|bcdedit|takeown|icacls)\b/i,
  /\b(curl|wget|Invoke-WebRequest|iwr|irm|Invoke-RestMethod)\b.*\|\s*(sh|bash|iex|powershell|pwsh)/i,
  /\b(npm|pnpm|yarn)\s+(publish|unpublish)\b/i,
  /\bdotnet\s+nuget\s+push\b/i,
  /\bcargo\s+publish\b/i,
  /\b(winget|choco|scoop)\s+(install|uninstall|upgrade)\b/i,
  /\bnpm\s+(install|i)\s+(-g|--global)\b/i,
  /\bsudo\b|\brunas\b/i,
];

/** Suppression, envoi en ligne, installation… : toujours demandé, une commande à la fois. */
export function isDangerousCommand(command: string): boolean {
  return DANGEROUS.some((re) => re.test(command));
}

// Pas dangereux, mais pas « sans risque » non plus : demande l'accord (une fois par tâche).
const NOT_SAFE: RegExp[] = [/(^|[^>])>\s*[^&]/ /* redirection qui écrase un fichier */, /\bgit\s+(commit|merge|rebase)\b/i];

export function isSafeCommand(command: string): boolean {
  const cmd = command.trim();
  if (!cmd) return false;
  if (DANGEROUS.some((re) => re.test(cmd)) || NOT_SAFE.some((re) => re.test(cmd))) return false;
  // Chaque morceau d'une commande enchaînée doit être sûr.
  const parts = cmd.split(/&&|\|\||;|\|/).map((p) => p.trim()).filter(Boolean);
  return parts.every((p) => SAFE_COMMANDS.some((re) => re.test(p)));
}

export type SafetyLevel = "strict" | "normal" | "free";

/**
 * strict : demande pour toute modification de fichier et toute commande.
 * normal : autorise les fichiers du projet et les commandes sûres (build, tests…).
 * free   : autorise tout sauf les actions dangereuses (suppression, push, installation…).
 */
export function decide(level: SafetyLevel, toolName: string, input: Record<string, unknown>, workDirs: string[]): "allow" | "ask" {
  if (level === "strict") return "ask";
  if (toolName === "Bash" || toolName === "PowerShell") {
    const cmd = String(input.command ?? "");
    if (level === "free") return DANGEROUS.some((re) => re.test(cmd)) ? "ask" : "allow";
    return isSafeCommand(cmd) ? "allow" : "ask";
  }
  if (["Edit", "Write", "MultiEdit", "NotebookEdit"].includes(toolName)) {
    const file = String(input.file_path ?? input.notebook_path ?? "");
    return file && isInside(file, workDirs) ? "allow" : "ask";
  }
  return "ask";
}

export function isInside(file: string, dirs: string[]): boolean {
  const target = path.resolve(file).toLowerCase();
  return dirs.some((d) => {
    const base = path.resolve(d).toLowerCase();
    return target === base || target.startsWith(base + path.sep);
  });
}

// Petit résumé lisible d'un appel d'outil, pour l'interface.
export function summarizeTool(name: string, input: Record<string, unknown>): string {
  const s = (v: unknown) => (typeof v === "string" ? v : "");
  switch (name) {
    case "Bash":
    case "PowerShell":
      return s(input.command);
    case "Read":
      return "Lecture de " + s(input.file_path);
    case "Write":
      return "Création de " + s(input.file_path);
    case "Edit":
    case "MultiEdit":
      return "Modification de " + s(input.file_path);
    case "Glob":
      return "Recherche de fichiers " + s(input.pattern);
    case "Grep":
      return "Recherche de « " + s(input.pattern) + " »";
    case "WebSearch":
      return "Recherche web : " + s(input.query);
    case "WebFetch":
      return "Lecture de " + s(input.url);
    case "TodoWrite":
      return "Mise à jour de la liste de tâches";
    case "Agent":
    case "Task":
      return "Met " + (s(input.subagent_type) || "un assistant") + " au travail : " + s(input.description);
    case "mcp__jarvis__generate_image":
      return "Crée une image : " + s(input.prompt).slice(0, 80);
    case "mcp__jarvis__expert_opinion":
      return "Triple vérification avec " + (Array.isArray(input.experts) && input.experts.length ? input.experts.join(" et ") : "GPT et Gemini") + " : " + s(input.question).slice(0, 80);
    case "mcp__jarvis__create_3d_model":
      return "Crée un modèle 3D : " + s(input.name);
    case "mcp__jarvis__create_video":
      return "Crée une vidéo : " + s(input.name);
    case "mcp__jarvis__google_search":
      return "Recherche Google : " + s(input.query);
    case "mcp__jarvis__show_window":
      return "Affiche « " + s(input.title) + " »";
    case "mcp__jarvis__update_window":
      return "Met à jour la fenêtre " + s(input.id);
    case "mcp__jarvis__close_window":
      return "Ferme " + (input.id === "all" ? "toutes les fenêtres" : "la fenêtre " + s(input.id));
    case "mcp__jarvis__play_music":
      return "Lance « " + s(input.title) + " »";
    case "mcp__jarvis__media_control":
      return "Contrôle média : " + s(input.action);
    case "mcp__jarvis__open_url":
      return "Ouvre " + s(input.url);
    case "mcp__jarvis__web_open":
      return "Navigateur : ouvre " + s(input.url);
    case "mcp__jarvis__web_click":
      return "Navigateur : clic sur l'élément " + String(input.index);
    case "mcp__jarvis__web_type":
      return "Navigateur : écrit « " + s(input.text).slice(0, 40) + " »";
    case "mcp__jarvis__web_read":
      return "Navigateur : lit la page";
    case "mcp__jarvis__web_scroll":
      return "Navigateur : défile";
    case "mcp__jarvis__web_back":
      return "Navigateur : page précédente";
    case "mcp__jarvis__web_screenshot":
      return "Navigateur : capture d'écran";
    case "mcp__jarvis__music_play":
      return "Musique : " + (s(input.query) || s(input.url));
    case "mcp__jarvis__music_control":
      return "Musique : " + s(input.action);
    case "mcp__jarvis__remember":
      return "Mémorise : " + s(input.fact);
    default:
      if (name.startsWith("mcp__jarvis__")) return name.replace("mcp__jarvis__", "Nova · ");
      return name;
  }
}
