// Cerveau réfléchi « direct » : l'API Messages d'Anthropic avec les outils de Nova, sans Claude Code.
// Sert quand Claude Code ne peut pas tourner sur le PC : son programme demande un processeur avec SSE4.2 /
// POPCNT, absents des Core 2 Duo (Dell M4400 : « Claude Code process terminated by signal SIGILL »).
// Même outils (voiture, diagnostic, mémoire…), même autorisations, plus la recherche web de l'API.
// Pas d'employés (sous-agents) ni de lecture de fichiers dans ce mode.
import { readFileSync } from "node:fs";
import { z } from "zod";

export interface DirectTool {
  name: string;
  description: string;
  inputSchema: Record<string, z.ZodTypeAny>;
  handler: (args: any, extra: unknown) => Promise<{ content: { type: string; text?: string }[]; isError?: boolean }>;
}

export interface DirectOptions {
  apiKey: string;
  baseUrl: string;
  model: string;
  system: string;
  history: { role: "user" | "assistant"; content: any }[];
  prompt: string;
  tools: DirectTool[];
  /** autorisation d'un outil (même règle que le cerveau Claude Code) */
  permit: (name: string, input: Record<string, unknown>, id: string) => Promise<{ ok: boolean; input: Record<string, unknown>; message?: string }>;
  signal: AbortSignal;
  onTextStart: () => void;
  onText: (t: string) => void;
  onTool: (id: string, name: string, input: Record<string, unknown>) => void;
  onToolResult: (id: string, ok: boolean) => void;
  maxSteps?: number;
}

/** Le processeur peut-il faire tourner le programme Claude Code ? (SSE4.2 et POPCNT, « x86-64-v2 ») */
export function cpuRunsClaudeCode(): boolean {
  if (process.platform !== "linux" || process.arch !== "x64") return true;
  try {
    const flags = /^flags\s*:\s*(.*)$/m.exec(readFileSync("/proc/cpuinfo", "utf8"))?.[1] ?? "";
    return /\bsse4_2\b/.test(flags) && /\bpopcnt\b/.test(flags);
  } catch {
    return true;
  }
}

const schemaCache = new WeakMap<object, unknown>();
export function jsonSchema(t: DirectTool) {
  let s = schemaCache.get(t.inputSchema) as any;
  if (!s) {
    s = z.toJSONSchema(z.object(t.inputSchema), { io: "input", unrepresentable: "any" }) as any;
    delete s.$schema;
    schemaCache.set(t.inputSchema, s);
  }
  return s;
}

/** Outils dont le schéma ne passe pas en JSON Schema (à noter dans le journal au démarrage). */
export function checkSchemas(tools: DirectTool[]): string[] {
  const bad: string[] = [];
  for (const t of tools) {
    try {
      jsonSchema(t);
    } catch (e: any) {
      bad.push(`${t.name} (${String(e?.message || e).slice(0, 80)})`);
    }
  }
  return bad;
}

/** Un tour complet : réponse, outils, réponse… jusqu'à la fin. Renvoie le texte du dernier message. */
export async function runDirect(o: DirectOptions): Promise<{ text: string; inTokens: number; outTokens: number; steps: number }> {
  const tools: unknown[] = [];
  for (const t of o.tools) {
    try {
      tools.push({ name: t.name, description: t.description.slice(0, 1000), input_schema: jsonSchema(t) });
    } catch {
      /* schéma non convertible : outil laissé de côté (voir checkSchemas au démarrage) */
    }
  }
  tools.push({ type: "web_search_20250305", name: "web_search", max_uses: 4 });
  const byName = new Map(o.tools.map((t) => [t.name, t]));
  const messages: any[] = [...o.history, { role: "user", content: o.prompt }];
  let inTokens = 0;
  let outTokens = 0;
  let lastText = "";
  const max = o.maxSteps ?? 12;
  for (let step = 1; step <= max; step++) {
    const { content, stop, usage } = await streamStep(o, tools, messages);
    inTokens += usage.in;
    outTokens += usage.out;
    messages.push({ role: "assistant", content });
    const texts = content.filter((b: any) => b.type === "text").map((b: any) => b.text).join("");
    if (texts.trim()) lastText = texts;
    if (stop === "pause_turn") continue; // recherche web longue : l'API demande de continuer
    const uses = content.filter((b: any) => b.type === "tool_use");
    if (stop !== "tool_use" || !uses.length) return { text: lastText, inTokens, outTokens, steps: step };
    const results: any[] = [];
    for (const u of uses) {
      if (o.signal.aborted) throw new Error("interrompu");
      const t = byName.get(u.name);
      o.onTool(u.id, u.name, u.input ?? {});
      let out = "";
      let isError = false;
      if (!t) {
        out = `Outil inconnu : ${u.name}`;
        isError = true;
      } else {
        const p = await o.permit(u.name, u.input ?? {}, u.id);
        if (!p.ok) {
          out = p.message || "Refusé par le conducteur.";
          isError = true;
        } else {
          try {
            const r = await t.handler(p.input, { signal: o.signal });
            out = (r.content || []).map((c) => (c.type === "text" ? c.text : `[${c.type}]`)).join("\n") || "(vide)";
            isError = !!r.isError;
          } catch (e: any) {
            out = "Erreur : " + String(e?.message || e);
            isError = true;
          }
        }
      }
      o.onToolResult(u.id, !isError);
      results.push({ type: "tool_result", tool_use_id: u.id, content: out.slice(0, 60000), ...(isError ? { is_error: true } : {}) });
    }
    messages.push({ role: "user", content: results });
  }
  return { text: lastText || "J'ai fait beaucoup d'étapes sans conclure : repose-moi la question plus simplement.", inTokens, outTokens, steps: max };
}

/** Une réponse de l'API en flux : le texte part au fil de l'eau, les blocs sont reconstitués. */
async function streamStep(o: DirectOptions, tools: unknown[], messages: unknown[]) {
  const res = await fetch(o.baseUrl.replace(/\/$/, "") + "/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": o.apiKey, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: o.model, max_tokens: 16000, system: o.system, tools, messages, stream: true }),
    signal: AbortSignal.any([o.signal, AbortSignal.timeout(180000)]),
  });
  if (!res.ok || !res.body) {
    let detail = "";
    try {
      detail = (await res.text()).slice(0, 300);
    } catch {}
    throw new Error(`API Anthropic : erreur ${res.status} ${detail}`);
  }
  const blocks: any[] = [];
  const partial: Record<number, string> = {};
  let stop = "";
  const usage = { in: 0, out: 0 };
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i: number;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith("data:")) continue;
      let ev: any;
      try {
        ev = JSON.parse(line.slice(5));
      } catch {
        continue;
      }
      if (ev.type === "message_start") usage.in += ev.message?.usage?.input_tokens ?? 0;
      else if (ev.type === "content_block_start") {
        const b = { ...ev.content_block };
        if (b.type === "text") {
          b.text = b.text || "";
          o.onTextStart();
        }
        if (b.type === "tool_use" || b.type === "server_tool_use") partial[ev.index] = "";
        blocks[ev.index] = b;
      } else if (ev.type === "content_block_delta") {
        const b = blocks[ev.index];
        if (!b) continue;
        if (ev.delta?.type === "text_delta") {
          b.text += ev.delta.text;
          o.onText(ev.delta.text);
        } else if (ev.delta?.type === "input_json_delta") partial[ev.index] += ev.delta.partial_json || "";
        else if (ev.delta?.type === "citations_delta") (b.citations ||= []).push(ev.delta.citation);
        // réflexion d'Opus / Haiku : à renvoyer intacte (texte + signature) à l'étape suivante, sinon erreur 400
        else if (ev.delta?.type === "thinking_delta") b.thinking = (b.thinking || "") + (ev.delta.thinking || "");
        else if (ev.delta?.type === "signature_delta") b.signature = (b.signature || "") + (ev.delta.signature || "");
      } else if (ev.type === "content_block_stop") {
        const b = blocks[ev.index];
        if (b && ev.index in partial) {
          try {
            b.input = partial[ev.index] ? JSON.parse(partial[ev.index]) : {};
          } catch {
            b.input = {};
          }
        }
      } else if (ev.type === "message_delta") {
        stop = ev.delta?.stop_reason || stop;
        usage.out += ev.usage?.output_tokens ?? 0;
      } else if (ev.type === "error") throw new Error("API Anthropic : " + (ev.error?.message || "erreur"));
    }
  }
  // un bloc de réflexion vide (sans texte ni signature) est refusé par l'API : on le retire
  const content = blocks.filter((b) => b && !(b.type === "thinking" && !b.thinking && !b.signature));
  return { content, stop, usage };
}
