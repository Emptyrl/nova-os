// Lecteur YouTube Music dans le navigateur « compte » de l'assistant, en arrière-plan.
// L'état (titre, artiste, pochette, position) est relu chaque seconde pour l'overlay.
import type { Page } from "playwright-core";
import type { Browsers } from "./browser.js";

export interface MusicState {
  title: string;
  artist: string;
  artwork: string;
  position: number; // secondes
  duration: number;
  playing: boolean;
}

export class MusicPlayer {
  private page: Page | null = null;
  private timer: NodeJS.Timeout | null = null;
  private last: MusicState | null = null;

  constructor(
    private browsers: Browsers,
    private onState: (s: MusicState | null) => void,
  ) {}

  get active() {
    return !!this.page && !this.page.isClosed();
  }

  private async tab(): Promise<Page> {
    if (this.page && !this.page.isClosed()) return this.page;
    const ctx = await this.browsers.context("account");
    const page = await ctx.newPage();
    (page as any).__jarvisMusic = true;
    page.on("close", () => {
      if (this.page === page) this.stopPolling(true);
    });
    this.page = page;
    return page;
  }

  /** Cherche et lance un morceau (ou ouvre directement une adresse YouTube Music / YouTube). */
  async play(query?: string, url?: string): Promise<MusicState> {
    const page = await this.tab();
    if (url) {
      await page.goto(url, { waitUntil: "domcontentloaded" });
    } else {
      await page.goto("https://music.youtube.com/search?q=" + encodeURIComponent(query || ""), { waitUntil: "domcontentloaded" });
      await this.ensureAccess(page);
      // premier résultat « titre » de la recherche
      const link = page.locator('a[href*="watch?v="]').first();
      await link.waitFor({ state: "attached", timeout: 15000 });
      const href = await link.getAttribute("href");
      if (!href) throw new Error("Aucun résultat pour « " + query + " ».");
      await page.goto(new URL(href, "https://music.youtube.com/").toString(), { waitUntil: "domcontentloaded" });
    }
    await this.ensureAccess(page);
    await page.waitForSelector("video", { state: "attached", timeout: 20000 });
    await page.evaluate(() => {
      const v = document.querySelector("video") as HTMLVideoElement | null;
      if (v && v.paused) v.play().catch(() => {});
    });
    this.startPolling();
    // laisse le temps aux informations du morceau d'arriver
    for (let i = 0; i < 20; i++) {
      const s = await this.read();
      if (s?.title) return s;
      await page.waitForTimeout(300);
    }
    return (await this.read()) ?? { title: query || "", artist: "", artwork: "", position: 0, duration: 0, playing: true };
  }

  private async ensureAccess(page: Page) {
    const u = page.url();
    if (/consent\.youtube\.com|accounts\.google\.com/.test(u)) {
      throw new Error("Le navigateur de l'assistant n'est pas connecté à YouTube Music. Va dans Paramètres › Navigateur › Connecter mon compte.");
    }
  }

  async control(action: string, value?: number): Promise<MusicState | null> {
    if (!this.active) throw new Error("Aucune musique en cours.");
    const page = this.page!;
    await page.evaluate(
      ([action, value]) => {
        const v = document.querySelector("video") as HTMLVideoElement | null;
        const player = document.querySelector("#movie_player") as any;
        const click = (sel: string) => (document.querySelector(sel) as HTMLElement | null)?.click();
        switch (action) {
          case "play":
            v?.play();
            break;
          case "pause":
            v?.pause();
            break;
          case "play_pause":
          case "toggle":
            if (v) v.paused ? v.play() : v.pause();
            break;
          case "next":
            click("ytmusic-player-bar .next-button, .next-button");
            break;
          case "previous":
            click("ytmusic-player-bar .previous-button, .previous-button");
            break;
          case "volume": {
            const pct = Math.max(0, Math.min(100, Number(value)));
            if (player?.setVolume) player.setVolume(pct);
            else if (v) v.volume = pct / 100;
            break;
          }
          case "volume_up":
          case "volume_down": {
            const cur = player?.getVolume ? player.getVolume() : (v?.volume ?? 1) * 100;
            const next = Math.max(0, Math.min(100, cur + (action === "volume_up" ? 15 : -15)));
            if (player?.setVolume) player.setVolume(next);
            else if (v) v.volume = next / 100;
            break;
          }
          case "seek":
            if (v && Number.isFinite(Number(value))) v.currentTime = Number(value);
            break;
        }
      },
      [action, value ?? 0] as const,
    );
    await page.waitForTimeout(action === "next" || action === "previous" ? 1200 : 200);
    return this.read();
  }

  async stop() {
    if (this.page && !this.page.isClosed()) await this.page.close().catch(() => {});
    this.stopPolling(true);
  }

  async read(): Promise<MusicState | null> {
    if (!this.active) return null;
    try {
      return await this.page!.evaluate(() => {
        const v = document.querySelector("video") as HTMLVideoElement | null;
        const md = (navigator as any).mediaSession?.metadata;
        const text = (sel: string) => (document.querySelector(sel) as HTMLElement | null)?.innerText?.trim() || "";
        const art = md?.artwork?.length ? md.artwork[md.artwork.length - 1].src : (document.querySelector("ytmusic-player-bar img") as HTMLImageElement | null)?.src || "";
        return {
          title: md?.title || text("ytmusic-player-bar .title"),
          artist: md?.artist || text("ytmusic-player-bar .byline").split("•")[0].trim(),
          artwork: art,
          position: v ? v.currentTime : 0,
          duration: v && Number.isFinite(v.duration) ? v.duration : 0,
          playing: v ? !v.paused : false,
        };
      });
    } catch {
      return null;
    }
  }

  private startPolling() {
    if (this.timer) return;
    this.timer = setInterval(async () => {
      const s = await this.read();
      if (!s) return;
      const l = this.last;
      // on ne prévient l'interface que si quelque chose change vraiment (elle anime la progression seule)
      const changed = !l || l.title !== s.title || l.playing !== s.playing || Math.abs(l.duration - s.duration) > 1 || Math.abs(s.position - (l.position + (l.playing ? 1 : 0))) > 2.5;
      this.last = s;
      if (changed) this.onState(s);
    }, 1000);
  }

  private stopPolling(clear: boolean) {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.page = null;
    this.last = null;
    if (clear) this.onState(null);
  }
}
