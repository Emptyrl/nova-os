// Dépense du mois : chaque appel à l'API Anthropic (jetons) et à ElevenLabs (caractères) est compté ici,
// avec les tarifs publics. C'est une estimation (± quelques %) : la vraie facture est sur les consoles.
import { promises as fs } from "node:fs";
import path from "node:path";

/** $ par million de jetons : entrée, sortie. Lecture du cache = 10 % de l'entrée, écriture = 125 %. */
const PRICES: { re: RegExp; name: string; in: number; out: number }[] = [
  { re: /haiku/i, name: "Haiku", in: 0.1, out: 0.5 },
  { re: /sonnet/i, name: "Sonnet", in: 2, out: 10 },
  { re: /opus/i, name: "Opus", in: 4, out: 20 },
];
/** ElevenLabs, $ pour 1000 caractères : modèles rapides (Flash / Turbo) et modèles complets. */
const ELEVEN_FAST = 0.04;
const ELEVEN_FULL = 0.08;
export const USD_TO_EUR = 0.92;

interface Month {
  month: string; // 2026-10
  usd: Record<string, number>; // par poste : Haiku, Opus, Sonnet, Voix
  chars: number;
  warned: number[]; // seuils déjà annoncés (80, 100)
}

/** Point d'accroche : fast.ts et direct.ts y signalent leurs jetons sans dépendre du serveur. */
export const usageHook: { onTokens: (model: string, inp: number, out: number, cacheRead: number, cacheWrite: number) => void } = {
  onTokens: () => {},
};

const monthKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
};

export class Spend {
  private m: Month = { month: monthKey(), usd: {}, chars: 0, warned: [] };
  private file: string;
  private saveTimer: NodeJS.Timeout | null = null;

  constructor(
    dataDir: string,
    private budgetEur: () => number,
    private onThreshold: (pct: number, eur: number, budget: number) => void,
  ) {
    this.file = path.join(dataDir, "depense.json");
  }

  async load() {
    try {
      const all = JSON.parse(await fs.readFile(this.file, "utf8"));
      if (all?.month === monthKey()) this.m = { usd: {}, chars: 0, warned: [], ...all };
    } catch {}
  }

  private roll() {
    if (this.m.month !== monthKey()) this.m = { month: monthKey(), usd: {}, chars: 0, warned: [] };
  }

  private add(post: string, usd: number) {
    this.roll();
    this.m.usd[post] = (this.m.usd[post] ?? 0) + usd;
    this.check();
    if (!this.saveTimer)
      this.saveTimer = setTimeout(() => {
        this.saveTimer = null;
        void fs.writeFile(this.file, JSON.stringify(this.m), "utf8").catch(() => {});
      }, 5000);
  }

  tokens(model: string, inp: number, out: number, cacheRead = 0, cacheWrite = 0) {
    const p = PRICES.find((x) => x.re.test(model)) ?? PRICES[2];
    const usd = (inp * p.in + cacheRead * p.in * 0.1 + cacheWrite * p.in * 1.25 + out * p.out) / 1e6;
    if (usd > 0) this.add(p.name, usd);
  }

  voice(chars: number, model: string) {
    this.roll();
    this.m.chars += chars;
    this.add("Voix", (chars / 1000) * (/flash|turbo/i.test(model) ? ELEVEN_FAST : ELEVEN_FULL));
  }

  get eur() {
    this.roll();
    return Object.values(this.m.usd).reduce((a, b) => a + b, 0) * USD_TO_EUR;
  }

  /** Part du budget consommée (0 à 1+). */
  get ratio() {
    const b = this.budgetEur();
    return b > 0 ? this.eur / b : 0;
  }

  private check() {
    const b = this.budgetEur();
    if (b <= 0) return;
    const pct = (this.eur / b) * 100;
    for (const t of [80, 100]) {
      if (pct >= t && !this.m.warned.includes(t)) {
        this.m.warned.push(t);
        this.onThreshold(t, this.eur, b);
      }
    }
  }

  summary() {
    this.roll();
    const posts = Object.entries(this.m.usd)
      .sort((a, b) => b[1] - a[1])
      .map(([k, v]) => ({ name: k, eur: Math.round(v * USD_TO_EUR * 100) / 100 }));
    const d = new Date();
    const day = d.getDate();
    const days = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    return {
      month: this.m.month,
      eur: Math.round(this.eur * 100) / 100,
      budget: this.budgetEur(),
      // projection fin de mois au rythme actuel
      projection: Math.round((this.eur / Math.max(1, day)) * days * 100) / 100,
      posts,
      voiceChars: this.m.chars,
    };
  }

  /** Une ligne pour les prompts : Nova peut répondre « combien j'ai dépensé ce mois ? ». */
  line() {
    const s = this.summary();
    const eur = (x: number) => x.toFixed(2).replace(".", ",") + " €";
    return `Dépense IA ce mois (estimée) : ${eur(s.eur)}${s.budget ? ` sur un budget de ${s.budget} €` : ""} (${s.posts.map((p) => `${p.name} ${eur(p.eur)}`).join(", ") || "rien"}), projection fin de mois ${eur(s.projection)}`;
  }
}

/** Message clair quand l'API Anthropic refuse pour une limite de dépense ou de crédit. Null sinon. */
export function apiLimitInfo(err: string): { text: string; until: number } | null {
  if (/specified API usage limits|usage limit/i.test(err)) {
    const m = err.match(/regain access on (\d{4}-\d{2}-\d{2}) at (\d{2}):(\d{2}) UTC/);
    let until = Date.now() + 3600_000;
    let when = "au début du mois prochain";
    if (m) {
      until = Date.parse(`${m[1]}T${m[2]}:${m[3]}:00Z`);
      const d = new Date(until);
      const sameDay = d.toDateString() === new Date().toDateString();
      const tomorrow = d.toDateString() === new Date(Date.now() + 86400_000).toDateString();
      const hh = d.getHours();
      const mm = d.getMinutes();
      const h = hh === 0 && mm === 0 ? "minuit" : `${hh} h${mm ? " " + String(mm).padStart(2, "0") : ""}`;
      when = sameDay ? (hh < 6 ? `cette nuit à ${h}` : `à ${h}`) : tomorrow ? (hh < 6 ? `cette nuit à ${h}` : `demain à ${h}`) : `le ${d.toLocaleDateString("fr-FR", { day: "numeric", month: "long" })} à ${h}`;
    }
    return {
      text: `J'ai atteint la limite de dépense que tu as fixée sur ton compte Anthropic, je ne peux plus réfléchir. Je reviens ${when}, ou monte la limite sur platform.claude.com, page Limits.`,
      until,
    };
  }
  if (/credit balance is too low|credit balance/i.test(err)) {
    return { text: "Le compte Anthropic n'a plus de crédit, je ne peux plus réfléchir. Recharge-le sur platform.claude.com, page Billing.", until: Date.now() + 10 * 60_000 };
  }
  return null;
}
