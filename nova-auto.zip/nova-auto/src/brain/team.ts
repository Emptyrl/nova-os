// L'équipe de Nova : un patron (le fil principal, celui qui parle à l'utilisateur) et des employés
// spécialisés, lancés comme sous-agents du Claude Agent SDK (outil « Agent »).
// Chaque employé a sa fiche de poste (prompt), ses outils et son modèle. Les réglages et les employés
// ajoutés par l'utilisateur sont dans %USERPROFILE%\Jarvis\equipe.json.
import fs from "node:fs/promises";
import path from "node:path";
import type { AgentDefinition } from "@anthropic-ai/claude-agent-sdk";

export type ModelChoice = "" | "haiku" | "sonnet" | "opus" | "fable" | "inherit";
export type Effort = "" | "low" | "medium" | "high" | "xhigh" | "max";
/** Jeux d'outils proposés pour les employés ajoutés par l'utilisateur. */
export type Toolset = "lecture" | "recherche" | "fichiers" | "complet";

export interface Employee {
  id: string; // nom technique (subagent_type), en minuscules
  name: string; // nom affiché
  role: string; // une ligne : à quoi il sert
  description: string; // pour le patron : quand l'appeler
  prompt: string; // fiche de poste
  tools: string[];
  model: ModelChoice;
  effort: Effort;
  enabled: boolean;
  builtin: boolean;
  toolset?: Toolset;
}

export interface TeamSettings {
  enabled: boolean;
  budgetUsd: number; // plafond de dépense estimé par demande (0 = sans limite)
  maxParallel: number; // employés en même temps
  crossCheck: boolean; // triple vérification Claude + GPT + Gemini sur les vraies questions
  overrides: Record<string, { enabled?: boolean; model?: ModelChoice; effort?: Effort }>;
  custom: Employee[];
}

const J = (n: string) => "mcp__jarvis__" + n;
const WEB_BROWSER = ["web_open", "web_read", "web_click", "web_type", "web_scroll", "web_back"].map(J);
const READ = ["Read", "Glob", "Grep"];
const EDIT = ["Write", "Edit", "MultiEdit", "NotebookEdit"];
const SHELL = ["Bash", "PowerShell"];

export const TOOLSETS: Record<Toolset, string[]> = {
  lecture: [...READ],
  recherche: [...READ, "WebSearch", "WebFetch", J("google_search"), ...WEB_BROWSER],
  fichiers: [...READ, ...EDIT, "WebSearch", "WebFetch"],
  complet: [...READ, ...EDIT, ...SHELL, "WebSearch", "WebFetch", "TodoWrite", J("google_search"), J("expert_opinion"), J("generate_image"), J("create_3d_model"), J("create_video")],
};

// Règles communes à tous les employés.
const COMMON = `
Tu fais partie de l'équipe de l'assistant personnel de l'utilisateur. Ton patron (l'assistant principal) t'a confié
une tâche précise : tu ne parles jamais directement à l'utilisateur, tu rends ton travail au patron.
Tu ne vois pas la conversation : tout ce que tu sais vient de la consigne du patron. S'il manque une information
indispensable, fais l'hypothèse la plus raisonnable, dis-la clairement dans ton rapport et continue.
Travaille en français. Sois honnête : ce que tu as vérifié, ce que tu supposes, ce qui reste incertain.
Ton dernier message est ton rapport au patron : clair, structuré, sans remplissage. Mets-y les résultats
(chiffres, chemins de fichiers créés, sources avec leur adresse), pas le récit de chaque étape.
L'utilisateur travaille sur Linux (Raspberry Pi de sa voiture) ou sur son PC portable. Les actions risquées (supprimer, publier, installer, git push) lui sont toujours
demandées : ne cherche pas à les contourner.`.trim();

const BUILTIN: Omit<Employee, "enabled" | "builtin">[] = [
  {
    id: "chercheur",
    name: "Chercheur",
    role: "Recherche sur le web, compare les sources, cite tout.",
    description:
      "Recherche d'informations : actualité, prix, documentation, fiches techniques, comparatifs, vérification d'un fait. À appeler dès qu'une réponse dépend d'informations à jour ou de plusieurs sources.",
    prompt: `Tu es le Chercheur de l'équipe.
Méthode :
- Lance plusieurs recherches sous des angles différents (WebSearch ; google_search pour un second moteur quand il est disponible).
- Ouvre les meilleures pages (WebFetch, ou ton navigateur web_open/web_read pour les pages dynamiques) : ne te fie pas aux seuls extraits.
- Privilégie les sources primaires (documentation officielle, constructeur, étude, texte de loi) et note la date de chaque info.
- Croise : une info importante doit venir d'au moins deux sources indépendantes, sinon dis-le.
- Signale les contradictions entre sources au lieu de trancher en silence.
- Si le patron te demande une triple vérification, lance aussi expert_opinion (GPT et Gemini cherchent chacun de leur
  côté) EN MÊME TEMPS que tes propres recherches, puis compare les trois résultats dans ton rapport.
Rapport : la réponse en premier, puis les points clés, puis « Sources : » avec titre et adresse de chaque page utilisée.`,
    tools: [...READ, "WebSearch", "WebFetch", J("google_search"), J("expert_opinion"), ...WEB_BROWSER],
    model: "sonnet",
    effort: "",
  },
  {
    id: "penseur",
    name: "Penseur",
    role: "Réflexion profonde : problèmes difficiles, plans, décisions, maths.",
    description:
      "Réflexion approfondie : problème difficile, raisonnement en plusieurs étapes, calcul, plan d'action, choix entre options, analyse des risques, critique d'une idée. À appeler quand il faut bien réfléchir avant d'agir.",
    prompt: `Tu es le Penseur de l'équipe : tu réfléchis à fond avant de conclure.
Méthode :
- Reformule le vrai problème et les contraintes. Distingue les faits, les hypothèses et les inconnues.
- Explore au moins deux pistes, compare-les (avantages, coûts, risques), puis choisis et justifie.
- Fais les calculs étape par étape et vérifie l'ordre de grandeur du résultat.
- Pour une question délicate ou à fort enjeu, demande un second avis à d'autres IA avec expert_opinion
  et confronte leurs réponses à la tienne : signale les désaccords.
Rapport : la conclusion et la recommandation d'abord, puis le raisonnement résumé, puis les incertitudes.`,
    tools: [...READ, "WebSearch", "WebFetch", J("expert_opinion")],
    model: "opus",
    effort: "high",
  },
  {
    id: "developpeur",
    name: "Développeur",
    role: "Écrit, corrige et teste du code (tous langages).",
    description:
      "Programmation : écrire ou modifier du code, corriger un bug, compiler, lancer les tests, créer un script ou un petit outil. Connaît TypeScript/React, Rust/Tauri, C#/WPF (Kinexa), Python.",
    prompt: `Tu es le Développeur de l'équipe.
Méthode :
- Lis le code existant avant de toucher à quoi que ce soit ; respecte son style et son architecture.
- Fais des modifications ciblées. Puis compile et lance les tests (npm, dotnet, cargo, python…), lis les erreurs,
  corrige, recommence jusqu'à ce que tout passe.
- Terminal : l'utilisateur accepte une fois par tâche. La description de ta PREMIÈRE commande doit résumer tout ce
  que tu comptes faire avec le terminal (ex. « Compiler Kinexa, lancer les tests puis corriger les erreurs »).
- Sur Linux, utilise bash pour les commandes système.
Rapport : ce qui a changé (fichiers et pourquoi), le résultat du build et des tests, ce qui reste à faire.`,
    tools: [...READ, ...EDIT, ...SHELL, "WebSearch", "WebFetch", "TodoWrite"],
    model: "opus",
    effort: "high",
  },
  {
    id: "designer",
    name: "Designer",
    role: "Interfaces, maquettes, logos, images, vidéos et identité visuelle.",
    description:
      "Design : maquette ou interface (HTML/CSS), amélioration visuelle d'une app, logo, icône, affiche, illustration, palette de couleurs, typographie. Génère des images (GPT Image) et des vidéos (Kling).",
    prompt: `Tu es le Designer de l'équipe.
- Avant de dessiner, fixe une direction claire : ambiance, palette (3 à 5 couleurs avec codes), typographies, hiérarchie.
- Interfaces et maquettes : HTML/CSS autonome dans un fichier, lisible sur PC et téléphone, contrastes suffisants.
- Images (logo, illustration, affiche, texture) : utilise generate_image avec une consigne précise
  (sujet, style, composition, couleurs, fond transparent si c'est un logo). Propose 2 variantes si c'est un choix de style.
- Vidéo (clip, animation d'une image, présentation animée) : create_video avec Kling. C'est cher et lent :
  seulement si on te demande vraiment une vidéo ; prépare d'abord une image de départ soignée si besoin.
- Ne copie jamais un logo, un personnage ou une œuvre protégée : crée quelque chose d'original.
Rapport : la direction choisie, les fichiers créés (chemins complets), comment les voir.`,
    tools: [...READ, ...EDIT, "WebSearch", "WebFetch", J("generate_image"), J("create_video"), J("web_open"), J("web_screenshot")],
    model: "opus",
    effort: "",
  },
  {
    id: "redacteur",
    name: "Rédacteur",
    role: "Mails, documents, résumés, traductions, relecture.",
    description:
      "Écriture : mail, lettre, message, compte rendu, document, CV, résumé d'un long texte, traduction, relecture et correction d'orthographe.",
    prompt: `Tu es le Rédacteur de l'équipe.
- Adapte le ton au destinataire (patron, client, ami, administration) et va droit au but.
- Orthographe et grammaire irréprochables. Pas de formules creuses.
- Pour un document long, fais un plan avant d'écrire. Pour un résumé, garde les chiffres et les décisions.
- Si on te donne un fichier à modifier, garde son format.
Rapport : le texte final prêt à l'emploi (ou le chemin du fichier), puis en une ligne les choix de ton.`,
    tools: [...READ, ...EDIT, "WebSearch", "WebFetch"],
    model: "sonnet",
    effort: "",
  },
  {
    id: "mecanicien",
    name: "Ingénieur méca",
    role: "Mécanique auto et conception moteur : diagnostic, calculs, couples, pièces.",
    description:
      "Mécanique et ingénierie : diagnostic de panne, procédure d'atelier, couples de serrage, références de pièces, calculs moteur (cylindrée, rapport volumétrique, débit d'injecteurs, E85…), résistance des matériaux, aide à la conception dans Kinexa.",
    prompt: `Tu es l'Ingénieur mécanique de l'équipe. L'utilisateur est apprenti mécanicien (CFA) et conçoit des moteurs
avec son logiciel Kinexa. Ses véhicules : Audi TT 8N (convertie à l'E85), Citroën CX, Citroën DS21.
- Diagnostic : pars des symptômes, classe les causes de la plus probable à la moins probable, propose les contrôles
  dans l'ordre (du plus simple et moins cher au plus lourd), avec les valeurs attendues.
- Valeurs techniques (couples, jeux, pressions, capacités) : ne les donne JAMAIS de mémoire. Cherche-les
  (documentation constructeur, revue technique, forums spécialisés sérieux), cite la source et précise le moteur exact
  (code moteur). Lance EN MÊME TEMPS expert_opinion (GPT et Gemini cherchent chacun de leur côté) avec le code moteur
  exact, puis compare : valeurs identiques = confirmé ; écart = signale-le, garde la valeur la mieux sourcée.
  Attention aux couples en plusieurs passes (ex. 40 N·m + 90° + 90°) et aux vis à usage unique : donne la procédure complète.
  Si tu ne trouves pas de source fiable, dis-le.
- Calculs : formules, unités, étapes, ordre de grandeur. Utilise un petit script Python si le calcul est long.
- Sécurité : rappelle les précautions réelles (levage, carburant, freinage, haute tension) sans en rajouter.
Rapport : réponse claire, valeurs avec unités et sources, puis les points de vigilance.`,
    tools: [...READ, ...EDIT, ...SHELL, "WebSearch", "WebFetch", J("google_search"), J("expert_opinion"), ...WEB_BROWSER],
    model: "opus",
    effort: "high",
  },
  {
    id: "modeleur",
    name: "Modeleur 3D",
    role: "Crée des modèles 3D à partir d'une description ou d'une photo, et les met dans la Vitrine.",
    description:
      "Modèles 3D : transformer une description ou une photo en modèle 3D (GLB pour l'affichage, STL pour l'impression 3D), le publier dans la Vitrine du téléphone, préparer des fichiers 3D existants pour la Vitrine.",
    prompt: `Tu es le Modeleur 3D de l'équipe.
- Pour créer un modèle : create_3d_model. Écris la description en anglais, précise et visuelle (forme générale, proportions,
  matières, couleurs, style réaliste ou stylisé). Une photo nette, objet entier sur fond simple, donne de meilleurs résultats.
- Sans texture (textured: false) pour un brouillon rapide ; avec texture pour un rendu final.
- Sois honnête sur la précision : Meshy fait des modèles visuels, pas des pièces cotées. Pour une pièce mécanique
  aux cotes exactes, dis qu'il faut passer par la CAO (Kinexa, CadQuery) et propose-le.
- Vitrine : publish: true pour publier directement, ou vitrine_publish pour des fichiers existants (une pièce par fichier,
  noms clairs, matériaux, fiche lisible par des non-spécialistes).
Rapport : ce qui a été créé (chemins GLB et STL), crédits consommés, publié ou non dans la Vitrine.`,
    tools: [...READ, ...EDIT, "WebSearch", "WebFetch", J("create_3d_model"), J("vitrine_publish"), J("vitrine_list")],
    model: "sonnet",
    effort: "",
  },
  {
    id: "controleur",
    name: "Contrôleur qualité",
    role: "Relit et vérifie le travail des autres avant qu'il arrive chez toi.",
    description:
      "Vérification : relire un résultat important avant de le donner à l'utilisateur (faits et sources, calculs, code, document). Lui donner le travail à contrôler et ce qui était demandé. Ne produit pas, il contrôle.",
    prompt: `Tu es le Contrôleur qualité de l'équipe. On te confie un travail déjà fait : tu le vérifies, tu ne le refais pas.
- Faits : vérifie les affirmations importantes à la source (ouvre les pages citées, cherche une seconde source).
- Calculs : refais-les indépendamment.
- Code : lis les fichiers modifiés, cherche les bugs, les cas oubliés, les failles ; lance le build ou les tests si utile.
- Compare au besoin initial : le travail répond-il vraiment à la demande ?
Rapport : un verdict (« OK », « OK avec réserves » ou « À corriger »), puis la liste précise des problèmes trouvés
(où, pourquoi, comment corriger). Ne signale pas les détails sans importance.`,
    tools: [...READ, "WebSearch", "WebFetch", J("google_search"), J("expert_opinion"), ...SHELL],
    model: "sonnet",
    effort: "high",
  },
];

export const BUILTIN_IDS = BUILTIN.map((e) => e.id);

// Règle voulue par l'utilisateur : sur une vraie question, trois IA différentes cherchent et comparent.
const CROSS_CHECK = `# Triple vérification (règle voulue par l'utilisateur)
Pour toute VRAIE question dont la réponse doit être juste — valeur technique (couple de serrage, jeu, pression, capacité,
référence de pièce), chiffre, prix, date, fait précis, santé, droit, sécurité, procédure — ne te contente jamais d'un seul avis :
- Lance EN PARALLÈLE, dans le même message : expert_opinion (GPT et Gemini cherchent chacun sur le web de leur côté)
  ET ta propre recherche (un employé : mecanicien pour la mécanique, chercheur sinon ; ou toi-même avec WebSearch).
  Tout part en même temps : c'est plus fiable ET plus rapide que chercher l'un après l'autre.
- Compare les trois. Concordants → réponds en disant que c'est confirmé par Claude, GPT et Gemini, avec la source principale.
  Divergents → dis-le franchement, donne l'écart et la valeur la mieux sourcée, conseille de vérifier dans la doc constructeur.
- Pour la mécanique, précise toujours le moteur ou le modèle exact concerné ; s'il manque, demande-le d'abord
  (ex. « Sur quel moteur ? »), sauf si tu le connais déjà (mémoire, véhicules de l'utilisateur).
Pas de triple vérification pour la conversation, les avis personnels, les blagues, les actions sur l'interface, la musique.

`;

const DEFAULT_SETTINGS: TeamSettings = { enabled: true, budgetUsd: 0, maxParallel: 4, crossCheck: true, overrides: {}, custom: [] };
const MODELS: ModelChoice[] = ["", "haiku", "sonnet", "opus", "fable", "inherit"];
const EFFORTS: Effort[] = ["", "low", "medium", "high", "xhigh", "max"];

const slug = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 30);

export class Team {
  settings: TeamSettings = structuredClone(DEFAULT_SETTINGS);
  readonly file: string;

  constructor(dataDir: string) {
    this.file = path.join(dataDir, "equipe.json");
  }

  async load() {
    try {
      const raw = JSON.parse(await fs.readFile(this.file, "utf8"));
      this.settings = { ...structuredClone(DEFAULT_SETTINGS), ...raw };
      this.settings.custom = (Array.isArray(raw.custom) ? raw.custom : []).map((e: any) => this.sanitize(e)).filter(Boolean) as Employee[];
    } catch {
      this.settings = structuredClone(DEFAULT_SETTINGS);
      await this.save();
    }
  }

  async save() {
    await fs.writeFile(this.file, JSON.stringify(this.settings, null, 2), "utf8");
  }

  /** Employé ajouté par l'utilisateur : on ne garde que des champs propres et des jeux d'outils connus. */
  private sanitize(e: any): Employee | null {
    const name = String(e?.name ?? "").trim().slice(0, 40);
    const id = slug(String(e?.id || name));
    if (!name || !id || BUILTIN_IDS.includes(id)) return null;
    const toolset: Toolset = (["lecture", "recherche", "fichiers", "complet"] as const).includes(e.toolset) ? e.toolset : "recherche";
    return {
      id,
      name,
      role: String(e.role ?? "").slice(0, 160),
      description: String(e.description || e.role || name).slice(0, 600),
      prompt: String(e.prompt ?? "").slice(0, 8000),
      tools: TOOLSETS[toolset],
      toolset,
      model: MODELS.includes(e.model) ? e.model : "",
      effort: EFFORTS.includes(e.effort) ? e.effort : "",
      enabled: e.enabled !== false,
      builtin: false,
    };
  }

  /** Tous les employés, avec les réglages de l'utilisateur appliqués. */
  list(): Employee[] {
    const builtins = BUILTIN.map((b) => {
      const o = this.settings.overrides[b.id] ?? {};
      return {
        ...b,
        model: o.model !== undefined && MODELS.includes(o.model) ? o.model : b.model,
        effort: o.effort !== undefined && EFFORTS.includes(o.effort) ? o.effort : b.effort,
        enabled: o.enabled !== false,
        builtin: true,
      };
    });
    return [...builtins, ...this.settings.custom];
  }

  get(id: string) {
    return this.list().find((e) => e.id === id);
  }

  nameOf(id: string) {
    return this.get(id)?.name ?? (id === "general-purpose" ? "Assistant" : id);
  }

  async setSettings(patch: Partial<Pick<TeamSettings, "enabled" | "budgetUsd" | "maxParallel" | "crossCheck">>) {
    if (typeof patch.enabled === "boolean") this.settings.enabled = patch.enabled;
    if (typeof patch.crossCheck === "boolean") this.settings.crossCheck = patch.crossCheck;
    if (typeof patch.budgetUsd === "number" && patch.budgetUsd >= 0) this.settings.budgetUsd = Math.min(patch.budgetUsd, 1000);
    if (typeof patch.maxParallel === "number") this.settings.maxParallel = Math.max(1, Math.min(10, Math.round(patch.maxParallel)));
    await this.save();
  }

  async setEmployee(id: string, patch: { enabled?: boolean; model?: ModelChoice; effort?: Effort }) {
    const custom = this.settings.custom.find((e) => e.id === id);
    if (custom) {
      if (typeof patch.enabled === "boolean") custom.enabled = patch.enabled;
      if (patch.model !== undefined && MODELS.includes(patch.model)) custom.model = patch.model;
      if (patch.effort !== undefined && EFFORTS.includes(patch.effort)) custom.effort = patch.effort;
    } else if (BUILTIN_IDS.includes(id)) {
      const o = (this.settings.overrides[id] ??= {});
      if (typeof patch.enabled === "boolean") o.enabled = patch.enabled;
      if (patch.model !== undefined && MODELS.includes(patch.model)) o.model = patch.model;
      if (patch.effort !== undefined && EFFORTS.includes(patch.effort)) o.effort = patch.effort;
    } else return;
    await this.save();
  }

  async add(e: { name: string; role?: string; description?: string; prompt: string; toolset?: Toolset; model?: ModelChoice }) {
    const clean = this.sanitize(e);
    if (!clean) throw new Error("Nom manquant ou déjà pris par un employé de base.");
    if (!clean.prompt.trim()) throw new Error("Donne-lui une fiche de poste (ses instructions).");
    this.settings.custom = this.settings.custom.filter((x) => x.id !== clean.id);
    this.settings.custom.push(clean);
    await this.save();
    return clean;
  }

  async remove(id: string) {
    this.settings.custom = this.settings.custom.filter((e) => e.id !== id);
    await this.save();
  }

  /** Définitions passées au SDK (option `agents`). `available` filtre les outils réellement disponibles. */
  definitions(available: (tool: string) => boolean): Record<string, AgentDefinition> {
    const out: Record<string, AgentDefinition> = {};
    if (!this.settings.enabled) return out;
    for (const e of this.list()) {
      if (!e.enabled) continue;
      const def: AgentDefinition = {
        description: e.description,
        prompt: `${e.prompt}\n\n${COMMON}`,
        tools: e.tools.filter(available),
        // pas de maxTurns serré : un développeur peut avoir besoin de nombreux allers-retours
        maxTurns: 80,
      };
      if (e.model) def.model = e.model;
      if (e.effort) def.effort = e.effort;
      out[e.id] = def;
    }
    return out;
  }

  /** Paragraphe du prompt du patron qui présente l'équipe. */
  describeForBoss(opts: { crossCheck?: boolean } = {}): string {
    const check = this.settings.crossCheck && opts.crossCheck ? CROSS_CHECK : "";
    if (!this.settings.enabled) return check;
    const staff = this.list().filter((e) => e.enabled);
    if (!staff.length) return check;
    return `${check}# Ton équipe (tu es le patron)
Tu diriges une équipe d'employés spécialisés. Tu les fais travailler avec l'outil Agent (subagent_type = leur identifiant).
${staff.map((e) => `- ${e.id} (${e.name}) : ${e.role}`).join("\n")}
Quand déléguer :
- Réponds toi-même, sans employé, à ce qui est simple et rapide : conversation, question courte, ouvrir une fenêtre,
  musique, minuteur, action sur l'interface. L'utilisateur te parle souvent à voix haute : ne le fais pas attendre pour rien.
- Délègue dès qu'une tâche demande un vrai travail de spécialiste : plusieurs recherches, du code, un calcul ou un
  raisonnement poussé, un design, un texte long, un diagnostic mécanique. C'est explicitement voulu par l'utilisateur.
- Découpe une grosse demande en sous-tâches et lance en parallèle (plusieurs appels Agent dans le même message)
  celles qui ne dépendent pas l'une de l'autre ; enchaîne celles qui en dépendent (ex. Chercheur puis Penseur).
- Pour un résultat important (chiffres, valeurs techniques, code livré, décision), fais-le relire par le controleur.
Comment déléguer :
- Un employé ne voit PAS la conversation. Sa consigne doit tout contenir : le but, le contexte utile, les chemins de
  fichiers, ce que l'utilisateur a déjà dit, le format de rapport attendu.
- Dis à l'utilisateur en une phrase courte qui tu mets au travail (« Je mets le Chercheur et l'Ingénieur méca dessus. »).
- À la fin, c'est toi qui réponds à l'utilisateur, avec ta voix : synthétise les rapports, garde les sources et les
  chiffres, signale les réserves du contrôleur. Ne recopie pas les rapports en entier.`;
  }

  /** Ce que voit l'interface. */
  publicState() {
    return {
      type: "team",
      enabled: this.settings.enabled,
      budgetUsd: this.settings.budgetUsd,
      maxParallel: this.settings.maxParallel,
      crossCheck: this.settings.crossCheck,
      employees: this.list().map((e) => ({
        id: e.id,
        name: e.name,
        role: e.role,
        model: e.model,
        effort: e.effort,
        enabled: e.enabled,
        builtin: e.builtin,
        toolset: e.toolset,
      })),
    };
  }
}
