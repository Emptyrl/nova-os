// Audio local : mot d'activation + reconnaissance vocale, entièrement sur le PC.
// - « rapide »  : Kroko français en flux (≈ 70 Mo, CC-BY-SA, https://huggingface.co/Banafo/Kroko-ASR)
//                 → texte en direct pendant que tu parles + détection du nom de l'assistant.
// - « précise » : Parakeet TDT 0.6B v3 de NVIDIA (≈ 670 Mo, CC-BY-4.0), facultatif
//                 → relit toute ta phrase à la fin pour un texte bien plus juste.
import { createRequire } from "node:module";
import { promises as fs, createWriteStream } from "node:fs";
import { spawn } from "node:child_process";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import path from "node:path";
import { WakeListener, type Sensitivity } from "./wake.js";

const require = createRequire(import.meta.url);
let sherpa: any = null;
try {
  sherpa = require("sherpa-onnx-node");
} catch {
  /* moteur indisponible : seule la voix cloud fonctionnera */
}

export type ModelName = "fr" | "precise";
export type ModelStatus = "absent" | "downloading" | "ready" | "error";

const MODELS: Record<ModelName, { dir: string; check: string; size: number }> = {
  fr: { dir: "sherpa-onnx-streaming-zipformer-fr-kroko-2025-08-06", check: "encoder.onnx", size: 57_220_361 },
  precise: { dir: "sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8", check: "encoder.int8.onnx", size: 487_170_055 },
};
const urlFor = (n: ModelName) => `https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/${MODELS[n].dir}.tar.bz2`;

interface ModelInfo {
  status: ModelStatus;
  progress: number;
  error: string;
}

export class LocalModels {
  info: Record<ModelName, ModelInfo> = {
    fr: { status: "absent", progress: 0, error: "" },
    precise: { status: "absent", progress: 0, error: "" },
  };
  private root: string;
  private recognizers = new Map<number, any>();
  private offline: any = null;

  constructor(
    dataDir: string,
    private onChange: () => void,
  ) {
    this.root = path.join(dataDir, "modeles");
  }

  private dir(n: ModelName) {
    return path.join(this.root, MODELS[n].dir);
  }

  async init() {
    for (const n of Object.keys(MODELS) as ModelName[]) {
      if (!sherpa) {
        this.info[n] = { status: "error", progress: 0, error: "moteur audio local indisponible" };
        continue;
      }
      try {
        await fs.access(path.join(this.dir(n), MODELS[n].check));
        this.info[n].status = "ready";
      } catch {
        this.info[n].status = "absent";
      }
    }
  }

  ready(n: ModelName) {
    return this.info[n].status === "ready";
  }

  /** Télécharge et décompresse un modèle (une seule fois). */
  async download(n: ModelName) {
    const info = this.info[n];
    if (!sherpa || info.status === "downloading" || info.status === "ready") return;
    Object.assign(info, { status: "downloading", progress: 0, error: "" });
    this.onChange();
    const archive = path.join(this.root, MODELS[n].dir + ".tar.bz2");
    try {
      await fs.mkdir(this.root, { recursive: true });
      const res = await fetch(urlFor(n));
      if (!res.ok || !res.body) throw new Error("téléchargement impossible (" + res.status + ")");
      const total = Number(res.headers.get("content-length")) || MODELS[n].size;
      let received = 0;
      let last = -1;
      const body = Readable.fromWeb(res.body as any);
      body.on("data", (chunk: Buffer) => {
        received += chunk.length;
        const pct = Math.min(99, Math.floor((received / total) * 100));
        if (pct !== last) {
          last = pct;
          info.progress = pct;
          this.onChange();
        }
      });
      await pipeline(body, createWriteStream(archive));
      // tar est fourni avec Windows 10/11 et sait lire le .bz2
      await new Promise<void>((resolve, reject) => {
        const p = spawn("tar", ["-xjf", archive, "-C", this.root], { windowsHide: true });
        p.on("error", reject);
        p.on("exit", (code) => (code === 0 ? resolve() : reject(new Error("décompression impossible (" + code + ")"))));
      });
      await fs.rm(archive, { force: true });
      await fs.access(path.join(this.dir(n), MODELS[n].check));
      Object.assign(info, { status: "ready", progress: 100 });
    } catch (e: any) {
      Object.assign(info, { status: "error", error: String(e?.message || e) });
      await fs.rm(archive, { force: true }).catch(() => {});
    }
    this.onChange();
  }

  /** Reconnaissance en flux ; un recognizer par durée de silence de fin de phrase. */
  recognizer(silence: number): any {
    if (!this.ready("fr")) return null;
    const key = Math.round(silence * 10);
    let r = this.recognizers.get(key);
    if (!r) {
      const d = this.dir("fr");
      r = new sherpa.OnlineRecognizer({
        featConfig: { sampleRate: 16000, featureDim: 80 },
        modelConfig: {
          transducer: { encoder: path.join(d, "encoder.onnx"), decoder: path.join(d, "decoder.onnx"), joiner: path.join(d, "joiner.onnx") },
          tokens: path.join(d, "tokens.txt"),
          numThreads: 2,
          provider: "cpu",
          debug: 0,
        },
        decodingMethod: "greedy_search",
        enableEndpoint: true,
        rule1MinTrailingSilence: 6, // rien dit du tout
        rule2MinTrailingSilence: Math.max(0.5, silence), // fin de phrase après avoir parlé
        rule3MinUtteranceLength: 40,
      });
      this.recognizers.set(key, r);
    }
    return r;
  }

  /** Relecture précise d'une phrase complète (null si le modèle n'est pas installé). */
  transcribePrecise(samples: Float32Array, sampleRate: number): string | null {
    if (!this.ready("precise")) return null;
    if (!this.offline) {
      const d = this.dir("precise");
      this.offline = new sherpa.OfflineRecognizer({
        featConfig: { sampleRate: 16000, featureDim: 80 },
        modelConfig: {
          transducer: { encoder: path.join(d, "encoder.int8.onnx"), decoder: path.join(d, "decoder.int8.onnx"), joiner: path.join(d, "joiner.int8.onnx") },
          tokens: path.join(d, "tokens.txt"),
          numThreads: 4,
          provider: "cpu",
          debug: 0,
          modelType: "nemo_transducer",
        },
      });
    }
    const s = this.offline.createStream();
    s.acceptWaveform({ samples, sampleRate });
    this.offline.decode(s);
    return String(this.offline.getResult(s).text || "").trim();
  }
}

// ---------- reconnaissance du nom de l'assistant ----------
export function normalize(t: string) {
  return t
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z' ]+/g, " ")
    .replace(/'/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Clé phonétique simple pour le français : « Jarvisse », « jarvis », « djarvis » → même clé. */
function phonetic(w: string) {
  return w
    .replace(/^dj/, "j")
    .replace(/ph/g, "f")
    .replace(/qu/g, "k")
    .replace(/c(?=[eiy])/g, "s")
    .replace(/[ckq]/g, "k")
    .replace(/g(?=[eiy])/g, "j")
    .replace(/y/g, "i")
    .replace(/z/g, "s")
    .replace(/ss/g, "s")
    .replace(/(au|eau|o)/g, "o")
    .replace(/(ai|ei|e[st]$)/g, "e")
    .replace(/h/g, "")
    .replace(/(.)\1+/g, "$1")
    .replace(/e$/, "")
    .replace(/[sxt]$/, "");
}

function distance(a: string, b: string) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}

export class NameMatcher {
  private targets: { words: number; key: string; tolerance: number }[] = [];

  constructor(name: string, variants: string[]) {
    for (const v of [name, ...variants]) {
      const n = normalize(v);
      if (!n) continue;
      const key = phonetic(n.replace(/ /g, ""));
      this.targets.push({ words: n.split(" ").length, key, tolerance: key.length >= 5 ? 1 : 0 });
    }
  }

  /** Cherche le nom dans un texte ; renvoie ce qui suit (la demande), ou null. */
  find(text: string): string | null {
    const words = normalize(text).split(" ").filter(Boolean);
    for (let i = 0; i < words.length; i++) {
      for (const t of this.targets) {
        for (const span of new Set([t.words, 1, 2])) {
          if (i + span > words.length) continue;
          const key = phonetic(words.slice(i, i + span).join(""));
          if (!key) continue;
          if (key === t.key || (t.tolerance && Math.abs(key.length - t.key.length) <= 1 && distance(key, t.key) <= t.tolerance)) {
            return words.slice(i + span).join(" ");
          }
        }
      }
    }
    return null;
  }
}

// ---------- session audio (une par connexion de l'interface) ----------
export interface SessionEvents {
  wake: (command: string) => void;
  partial: (text: string) => void;
  final: (text: string) => void;
  heard: (text: string) => void; // calibrage : phrase entendue
}

const PREROLL_SECONDS = 2.5; // son gardé en mémoire avant le début de l'écoute

/**
 * open      : micro ouvert en permanence : chaque phrase est une demande (pas besoin de dire « Nova ») ;
 * wake      : on attend le nom de l'assistant ;
 * listen    : on transcrit la demande jusqu'au silence ;
 * calibrate : on écoute l'utilisateur dire le nom pour apprendre sa prononciation.
 */
import os from "node:os";

// Petit processeur (2 cœurs, ex. Core 2 Duo) : en veille, seul le détecteur de mot-clé écoute « Nova ».
// La transcription complète en continu bloquait Nova plusieurs dizaines de millisecondes à chaque morceau de son.
const LIGHT_WAKE = process.env.NOVA_WAKE_FULL !== "1" && (process.env.NOVA_WAKE_LIGHT === "1" || os.cpus().length <= 2);

export class AudioSession {
  mode: "off" | "open" | "wake" | "listen" | "calibrate" = "off";
  private continuous = false;
  private openActive = false;
  private lastVoice = 0;
  private floor = 0.004;
  private resumeTimer: NodeJS.Timeout | undefined;
  private kws: WakeListener | null = null;
  private recognizer: any = null;
  private stream: any = null;
  private sampleRate = 48000;
  private lastPartial = "";
  private prefix = "";
  private listenStarted = 0;
  private wakeArmedAt = 0;
  private matcher = new NameMatcher("Nova", []);
  private preroll: Float32Array[] = [];
  private prerollLen = 0;
  private utterance: Float32Array[] = [];
  private wakeEnabled = false;
  private lazyMake: (() => void) | null = null;
  private lazyTimer: NodeJS.Timeout | undefined;

  constructor(
    private models: LocalModels,
    private dataDir: string,
    private events: SessionEvents,
  ) {}

  async configure(opts: { sampleRate: number; wake: boolean; sensitivity: Sensitivity; silence: number; localStt: boolean; name: string; variants: string[]; continuous?: boolean }) {
    this.sampleRate = opts.sampleRate || 48000;
    this.continuous = !!opts.continuous;
    // micro ouvert : pas de détecteur de mot-clé (moins de calcul), la transcription écoute tout
    if (this.continuous) opts = { ...opts, wake: false, localStt: true };
    this.wakeEnabled = opts.wake;
    this.matcher = new NameMatcher(opts.name, opts.variants);
    this.kws = opts.wake ? await WakeListener.create(opts.name, this.sampleRate, opts.sensitivity, this.dataDir).catch(() => null) : null;
    const make = () => {
      this.recognizer = this.models.recognizer(opts.silence);
      this.stream = this.recognizer ? this.recognizer.createStream() : null;
    };
    this.recognizer = null;
    this.stream = null;
    if (opts.localStt || opts.wake) {
      // petit processeur avec détecteur de mot-clé : la transcription n'est chargée qu'après le démarrage
      if (LIGHT_WAKE && this.kws && !this.continuous) {
        this.lazyMake = make;
        clearTimeout(this.lazyTimer);
        this.lazyTimer = setTimeout(() => {
          if (!this.recognizer) make();
        }, 25000);
      } else make();
    }
    this.openActive = false;
    this.mode = this.idleMode();
    this.wakeArmedAt = Date.now();
  }

  /** Ce que fait le micro quand Nova ne parle pas. */
  private idleMode(): "open" | "wake" | "off" {
    if (this.continuous && this.recognizer) return "open";
    return this.wakeEnabled ? "wake" : "off";
  }

  hasLocalStt() {
    return !!this.recognizer || !!this.lazyMake;
  }

  startListening(prefix = "", fromWake = false) {
    if (!this.recognizer && this.lazyMake) this.lazyMake();
    if (!this.recognizer) return false;
    this.recognizer.reset(this.stream);
    this.mode = "listen";
    this.prefix = prefix;
    this.lastPartial = "";
    this.listenStarted = Date.now();
    // on garde la fin du son déjà entendu : le premier mot n'est pas coupé
    this.utterance = tail(this.preroll, this.sampleRate * (fromWake ? PREROLL_SECONDS : 0.35));
    if (prefix) this.events.partial(prefix);
    return true;
  }

  stopListening(send = true) {
    if (this.mode !== "listen") return;
    let text = this.currentText();
    const audio = this.utterance;
    this.utterance = [];
    this.mode = this.idleMode();
    this.wakeArmedAt = Date.now() + 800;
    if (this.stream) this.recognizer.reset(this.stream);
    if (!send) return;
    // relecture précise de toute la phrase, si le modèle est installé
    if (text && audio.length) {
      try {
        const precise = this.models.transcribePrecise(concat(audio), this.sampleRate);
        if (precise) {
          const afterName = this.matcher.find(precise);
          text = (afterName ?? precise).trim() || text;
        }
      } catch {
        /* on garde le texte rapide */
      }
    }
    this.events.final(text);
  }

  startCalibration() {
    if (!this.recognizer && this.lazyMake) this.lazyMake();
    if (!this.recognizer) return false;
    this.recognizer.reset(this.stream);
    this.mode = "calibrate";
    return true;
  }

  stopCalibration() {
    if (this.mode !== "calibrate") return;
    this.mode = this.idleMode();
    this.recognizer.reset(this.stream);
  }

  pauseWake(paused: boolean) {
    if (this.mode === "listen" || this.mode === "calibrate") return;
    clearTimeout(this.resumeTimer);
    this.openActive = false;
    this.utterance = [];
    this.mode = paused ? "off" : this.idleMode();
    if (!paused) {
      // la fin de la voix de l'assistant résonne encore un peu dans la pièce
      this.wakeArmedAt = Date.now() + 1500;
      if (this.stream) this.recognizer.reset(this.stream);
    }
  }

  private currentText() {
    const t = this.recognizer ? String(this.recognizer.getResult(this.stream).text || "").trim() : "";
    return (this.prefix + " " + t).trim();
  }

  private remember(samples: Float32Array) {
    this.preroll.push(samples);
    this.prerollLen += samples.length;
    while (this.prerollLen - this.preroll[0].length > this.sampleRate * PREROLL_SECONDS) this.prerollLen -= this.preroll.shift()!.length;
  }

  feed(samples: Float32Array) {
    this.remember(samples);
    if (this.mode === "off") return;

    if (this.mode === "calibrate") {
      this.stream.acceptWaveform({ samples, sampleRate: this.sampleRate });
      while (this.recognizer.isReady(this.stream)) this.recognizer.decode(this.stream);
      if (this.recognizer.isEndpoint(this.stream)) {
        const t = String(this.recognizer.getResult(this.stream).text || "").trim();
        this.recognizer.reset(this.stream);
        if (t) this.events.heard(t);
      }
      return;
    }

    if (this.mode === "open") return this.feedOpen(samples);

    if (this.mode === "wake") {
      if (Date.now() < this.wakeArmedAt) return;
      // 1) détecteur de mot-clé
      if (this.kws && this.kws.feed(samples)) {
        this.triggerWake("");
        return;
      }
      // 2) transcription française : on cherche le nom dans le texte (sauf sur petit processeur)
      if (this.stream && !(LIGHT_WAKE && this.kws)) {
        this.stream.acceptWaveform({ samples, sampleRate: this.sampleRate });
        while (this.recognizer.isReady(this.stream)) this.recognizer.decode(this.stream);
        const after = this.matcher.find(this.recognizer.getResult(this.stream).text || "");
        if (after !== null) {
          this.triggerWake(after);
          return;
        }
        if (this.recognizer.isEndpoint(this.stream)) this.recognizer.reset(this.stream);
      }
      return;
    }

    // écoute de la demande
    if (!this.stream) return;
    this.utterance.push(samples);
    this.stream.acceptWaveform({ samples, sampleRate: this.sampleRate });
    while (this.recognizer.isReady(this.stream)) this.recognizer.decode(this.stream);
    const text = this.currentText();
    if (text !== this.lastPartial) {
      this.lastPartial = text;
      this.events.partial(text);
    }
    const tooLong = Date.now() - this.listenStarted > 45_000;
    if (this.recognizer.isEndpoint(this.stream) || tooLong) this.stopListening(true);
  }

  /**
   * Micro ouvert. Pour ménager le petit processeur, la transcription ne tourne que quand quelqu'un parle
   * (le son dépasse nettement le bruit de fond : moteur, route), avec un peu de son d'avant pour ne pas
   * couper le premier mot. Fin de phrase = silence détecté par la transcription.
   */
  private feedOpen(samples: Float32Array) {
    const now = Date.now();
    if (now < this.wakeArmedAt || !this.stream) return;
    let sum = 0;
    for (let i = 0; i < samples.length; i += 2) sum += samples[i] * samples[i];
    const r = Math.sqrt(sum / Math.ceil(samples.length / 2));
    const loud = r > Math.max(0.012, this.floor * 3);
    if (!this.openActive) {
      this.floor = this.floor * 0.97 + Math.min(r, 0.05) * 0.03; // bruit de fond, appris en continu
      if (!loud) return;
      this.openActive = true;
      this.lastVoice = now;
      this.listenStarted = now;
      this.prefix = "";
      this.lastPartial = "";
      this.recognizer.reset(this.stream);
      this.utterance = tail(this.preroll, this.sampleRate * 0.4); // contient déjà ce morceau
      for (const c of this.utterance) this.stream.acceptWaveform({ samples: c, sampleRate: this.sampleRate });
    } else {
      this.utterance.push(samples);
      this.stream.acceptWaveform({ samples, sampleRate: this.sampleRate });
      if (loud) this.lastVoice = now;
    }
    while (this.recognizer.isReady(this.stream)) this.recognizer.decode(this.stream);
    const text = this.currentText();
    if (text && text !== this.lastPartial) {
      this.lastPartial = text;
      this.events.partial(text);
    }
    const ended = this.recognizer.isEndpoint(this.stream) || now - this.lastVoice > 2500 || now - this.listenStarted > 45_000;
    if (!ended) return;
    const audio = this.utterance;
    this.utterance = [];
    this.openActive = false;
    this.recognizer.reset(this.stream);
    if (!meaningful(text)) {
      if (this.lastPartial) this.events.final(""); // l'écran revient au repos
      return;
    }
    let out = text;
    try {
      const precise = this.models.transcribePrecise(concat(audio), this.sampleRate);
      if (precise && meaningful(precise)) out = precise.trim();
    } catch {
      /* on garde le texte rapide */
    }
    const afterName = this.matcher.find(out); // « Nova, … » : on retire le nom
    if (afterName !== null && afterName.trim()) out = afterName.trim();
    // le temps que Nova réponde, le micro se repose (il reprend quand Nova a fini de parler)
    this.mode = "off";
    clearTimeout(this.resumeTimer);
    this.resumeTimer = setTimeout(() => {
      if (this.mode === "off" && this.continuous) this.pauseWake(false);
    }, 30_000);
    this.events.final(out);
  }

  private triggerWake(after: string) {
    this.events.wake(after);
    if (this.recognizer) this.startListening(after, true);
    else this.mode = "off"; // l'interface prend le relais (enregistrement + transcription cloud)
  }
}

/** Une vraie phrase, pas un bruit ou un « euh ». */
function meaningful(t: string) {
  const s = t.trim().toLowerCase();
  if (!/[\p{L}\p{N}]/u.test(s)) return false;
  const words = s.match(/[\p{L}\p{N}']+/gu) || [];
  if (words.length === 1 && (words[0].length < 2 || /^(euh+|hum+|hm+|mm+|heu+|ah+|oh+|eh+|bah|ben|hein|pff+)$/.test(words[0]))) return false;
  return true;
}

function concat(chunks: Float32Array[]) {
  const total = chunks.reduce((n, c) => n + c.length, 0);
  const out = new Float32Array(total);
  let o = 0;
  for (const c of chunks) {
    out.set(c, o);
    o += c.length;
  }
  return out;
}

/** Les dernières `n` valeurs d'une liste de morceaux audio. */
function tail(chunks: Float32Array[], n: number) {
  const out: Float32Array[] = [];
  let len = 0;
  for (let i = chunks.length - 1; i >= 0 && len < n; i--) {
    out.unshift(chunks[i]);
    len += chunks[i].length;
  }
  return out;
}
