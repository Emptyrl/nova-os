// Coût réel de chaque tâche.
// Le SDK renvoie un coût CUMULÉ quand une conversation est reprise (resume) : il inclut tous les échanges
// précédents de cette conversation. On garde donc le dernier total connu par conversation et on fait la différence.
import { promises as fs } from "node:fs";
import path from "node:path";

interface Snapshot {
  total: number;
  models: Record<string, number>;
}
export interface TurnCost {
  usd: number | null; // coût de cette tâche ; null si on ne connaissait pas le total précédent
  cumulative: number; // total de la conversation
  byModel: { model: string; usd: number }[];
}

export class Costs {
  private data: Record<string, Snapshot> = {};
  private file: string;
  constructor(dataDir: string) {
    this.file = path.join(dataDir, "couts.json");
  }
  async load() {
    try {
      this.data = JSON.parse(await fs.readFile(this.file, "utf8"));
    } catch {
      this.data = {};
    }
  }
  /** À appeler avec le résultat de fin de tâche. `known` : la conversation existait déjà avant cette tâche. */
  async record(sessionId: string, total: number, modelUsage: Record<string, { costUSD?: number }> | undefined, resumed: boolean): Promise<TurnCost> {
    const prev = this.data[sessionId];
    const models: Record<string, number> = {};
    for (const [m, u] of Object.entries(modelUsage ?? {})) models[m] = Number(u?.costUSD ?? 0);
    // conversation neuve : tout est pour cette tâche ; reprise sans total connu : impossible de séparer
    const base: Snapshot | null = prev ?? (resumed ? null : { total: 0, models: {} });
    const byModel = Object.entries(models)
      .map(([model, usd]) => ({ model, usd: base ? Math.max(0, usd - (base.models[model] ?? 0)) : usd }))
      .filter((x) => x.usd > 0.0005)
      .sort((a, b) => b.usd - a.usd);
    this.data[sessionId] = { total, models };
    await fs.writeFile(this.file, JSON.stringify(this.data), "utf8").catch(() => {});
    return { usd: base ? Math.max(0, total - base.total) : null, cumulative: total, byModel };
  }
}

export const formatUsd = (n: number) => (n < 0.01 ? "< 0,01 $" : n.toFixed(2).replace(".", ",") + " $");
