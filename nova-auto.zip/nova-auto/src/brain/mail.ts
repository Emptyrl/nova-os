// Envoi d'e-mails avec pièces jointes (journaux, logs) par SMTP, sans dépendance.
// Gmail : smtp.gmail.com port 465 (TLS direct), identifiant = l'adresse Gmail, mot de passe = « mot de passe
// d'application » (compte Google → Sécurité → Validation en deux étapes → Mots de passe des applications).
import tls from "node:tls";
import { promises as fs } from "node:fs";
import path from "node:path";

export interface MailConfig {
  host: string;
  port: number;
  user: string;
  pass: string;
}

const b64 = (s: string | Buffer) => Buffer.from(s).toString("base64");
const wrap = (s: string) => s.replace(/.{1,76}/g, "$&\r\n");
const hdr = (s: string) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`);

export async function sendMail(cfg: MailConfig, to: string, subject: string, text: string, files: string[] = []): Promise<string> {
  if (!cfg.user || !cfg.pass) throw new Error("e-mail pas configuré : Réglages › Cerveau › adresse Gmail et mot de passe d'application");
  const boundary = "nova_" + Date.now().toString(36);
  let body = `From: Nova <${cfg.user}>\r\nTo: ${to}\r\nSubject: ${hdr(subject)}\r\nDate: ${new Date().toUTCString()}\r\nMIME-Version: 1.0\r\n`;
  body += `Content-Type: multipart/mixed; boundary="${boundary}"\r\n\r\n`;
  body += `--${boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrap(b64(text))}`;
  let total = 0;
  for (const f of files) {
    const data = await fs.readFile(f);
    total += data.length;
    if (total > 20 * 1024 * 1024) throw new Error("pièces jointes trop lourdes (plus de 20 Mo)");
    const name = path.basename(f);
    body += `--${boundary}\r\nContent-Type: ${/\.csv$/i.test(name) ? "text/csv" : "text/plain"}; charset=UTF-8; name="${name}"\r\nContent-Disposition: attachment; filename="${name}"\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrap(b64(data))}`;
  }
  body += `--${boundary}--\r\n`;
  // une ligne commençant par « . » doit être doublée (le base64 n'en contient jamais, le reste si)
  body = body.replace(/\r\n\./g, "\r\n..");

  const sock = tls.connect({ host: cfg.host, port: cfg.port, servername: cfg.host });
  sock.setTimeout(30000, () => sock.destroy(new Error("le serveur e-mail ne répond pas")));
  let buf = "";
  const waiters: ((l: string) => void)[] = [];
  const ready: string[] = [];
  sock.on("data", (d) => {
    buf += d.toString("utf8");
    // réponse complète : dernière ligne « 250 texte » (sans tiret après le code)
    const m = /(^|\r\n)(\d{3}) [^\r\n]*\r\n$/.exec(buf);
    if (m) {
      const all = buf;
      buf = "";
      const w = waiters.shift();
      if (w) w(all);
      else ready.push(all); // réponse arrivée avant qu'on l'attende (accueil du serveur)
    }
  });
  const errors = new Promise<never>((_, rej) => sock.on("error", rej));
  errors.catch(() => {}); // une erreur après la fin ne doit pas faire planter Nova
  const read = () => Promise.race([ready.length ? Promise.resolve(ready.shift()!) : new Promise<string>((r) => waiters.push(r)), errors]);
  const cmd = async (line: string | null, expect: number, what: string) => {
    if (line !== null) sock.write(line + "\r\n");
    const r = await read();
    const code = Number(r.trim().split("\r\n").pop()!.slice(0, 3));
    if (code !== expect) throw new Error(`${what} refusé : ${r.trim().split("\r\n").pop()}`);
    return r;
  };
  try {
    await cmd(null, 220, "connexion");
    await cmd("EHLO nova", 250, "EHLO");
    await cmd("AUTH LOGIN", 334, "authentification");
    await cmd(b64(cfg.user), 334, "identifiant");
    await cmd(b64(cfg.pass), 235, "mot de passe (mot de passe d'application Gmail ?)");
    await cmd(`MAIL FROM:<${cfg.user}>`, 250, "expéditeur");
    await cmd(`RCPT TO:<${to}>`, 250, "destinataire");
    await cmd("DATA", 354, "envoi");
    sock.write(body);
    await cmd(".", 250, "message");
    sock.write("QUIT\r\n");
    return `E-mail envoyé à ${to}${files.length ? ` avec ${files.length} fichier${files.length > 1 ? "s" : ""}` : ""}.`;
  } finally {
    setTimeout(() => sock.destroy(), 500);
  }
}
