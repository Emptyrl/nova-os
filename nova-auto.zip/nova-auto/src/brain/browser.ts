// Navigateurs de l'assistant, pilotés en arrière-plan (playwright-core + Edge ou Chrome déjà installé).
// - « clean »   : navigateur vierge, sans compte ni historique, effacé à chaque lancement.
// - « account » : profil persistant, connecté au compte YouTube Music de l'utilisateur.
//                 Pour autre chose que la musique, l'app demande l'accord de l'utilisateur.
import { chromium, type BrowserContext, type Page } from "playwright-core";
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";

export type Profile = "clean" | "account";
export type Channel = "msedge" | "chrome" | "chromium";

export interface BrowserOptions {
  channel: Channel;
  visible: boolean;
  dataDir: string;
}

export class Browsers {
  private contexts: Partial<Record<Profile, Promise<BrowserContext>>> = {};
  private working: Partial<Record<Profile, Page>> = {};

  constructor(private opts: () => BrowserOptions) {}

  accountDir() {
    return path.join(this.opts().dataDir, "navigateur-compte");
  }

  private launchOptions() {
    const o = this.opts();
    const exe = process.env.JARVIS_BROWSER_PATH;
    const args = [
      "--autoplay-policy=no-user-gesture-required",
      "--disable-blink-features=AutomationControlled",
      "--no-first-run",
      "--no-default-browser-check",
      "--lang=fr-FR",
    ];
    // Hors de l'écran quand il est invisible : il joue la musique sans te gêner.
    if (!o.visible) args.push("--window-position=-32000,-32000", "--window-size=1280,860");
    // Proxy système éventuel (réseaux d'entreprise)
    const proxy = process.env.HTTPS_PROXY || process.env.https_proxy;
    return {
      headless: process.env.JARVIS_BROWSER_HEADLESS === "1",
      ...(proxy ? { proxy: { server: proxy, bypass: "localhost,127.0.0.1" } } : {}),
      args,
      ignoreDefaultArgs: ["--enable-automation"],
      ...(exe ? { executablePath: exe } : process.platform === "win32" ? { channel: o.channel === "chromium" ? "chrome" : o.channel } : { executablePath: findBrowser(o.channel) ?? undefined }),
    };
  }

  context(profile: Profile): Promise<BrowserContext> {
    let ctx = this.contexts[profile];
    if (!ctx) {
      ctx = (async () => {
        const options = this.launchOptions();
        let c: BrowserContext;
        if (profile === "account") {
          c = await chromium.launchPersistentContext(this.accountDir(), { ...options, viewport: null, locale: "fr-FR", ignoreHTTPSErrors: !!process.env.JARVIS_BROWSER_INSECURE });
        } else {
          const browser = await chromium.launch(options);
          c = await browser.newContext({ viewport: null, locale: "fr-FR", ignoreHTTPSErrors: !!process.env.JARVIS_BROWSER_INSECURE });
          c.on("close", () => browser.close().catch(() => {}));
        }
        c.on("close", () => {
          delete this.contexts[profile];
          delete this.working[profile];
        });
        return c;
      })();
      this.contexts[profile] = ctx;
      ctx.catch(() => delete this.contexts[profile]);
    }
    return ctx;
  }

  /** L'onglet de travail d'un profil (distinct de l'onglet musique). */
  async page(profile: Profile): Promise<Page> {
    const existing = this.working[profile];
    if (existing && !existing.isClosed()) return existing;
    const ctx = await this.context(profile);
    const blank = ctx.pages().find((p) => p.url() === "about:blank" && !(p as any).__jarvisMusic);
    const page = blank ?? (await ctx.newPage());
    this.working[profile] = page;
    return page;
  }

  async close(profile?: Profile) {
    const list = profile ? [profile] : (Object.keys(this.contexts) as Profile[]);
    for (const p of list) {
      const ctx = this.contexts[p];
      delete this.contexts[p];
      delete this.working[p];
      if (ctx) await ctx.then((c) => c.close()).catch(() => {});
    }
  }

  isOpen(profile: Profile) {
    return !!this.contexts[profile];
  }

  /**
   * Connexion au compte : ouvre le vrai navigateur (non piloté) sur le profil de l'assistant,
   * car Google refuse les connexions depuis un navigateur automatisé. Se termine quand tu le fermes.
   */
  async login(url: string): Promise<void> {
    await this.close("account");
    const exe = process.env.JARVIS_BROWSER_PATH || findBrowser(this.opts().channel);
    if (!exe) throw new Error("Navigateur introuvable. Installe Microsoft Edge ou Google Chrome, ou change de navigateur dans Paramètres.");
    await new Promise<void>((resolve, reject) => {
      const p = spawn(exe, [`--user-data-dir=${this.accountDir()}`, "--no-first-run", "--no-default-browser-check", "--new-window", url], { stdio: "ignore" });
      p.on("error", reject);
      p.on("exit", () => resolve());
    });
  }
}

function findBrowser(channel: Channel): string | null {
  if (process.platform !== "win32") {
    const linux = ["/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/microsoft-edge", "/snap/bin/chromium"];
    return linux.find((c) => existsSync(c)) ?? null;
  }
  const pf = process.env["ProgramFiles"] || "C:\\Program Files";
  const pf86 = process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)";
  const local = process.env["LOCALAPPDATA"] || "";
  const candidates =
    channel === "msedge"
      ? [path.join(pf86, "Microsoft\\Edge\\Application\\msedge.exe"), path.join(pf, "Microsoft\\Edge\\Application\\msedge.exe")]
      : [path.join(pf, "Google\\Chrome\\Application\\chrome.exe"), path.join(pf86, "Google\\Chrome\\Application\\chrome.exe"), path.join(local, "Google\\Chrome\\Application\\chrome.exe")];
  return candidates.find((c) => existsSync(c)) ?? null;
}

// ---------- lecture d'une page pour l'assistant ----------
/** Résumé texte d'une page + éléments cliquables numérotés. */
export async function snapshot(page: Page): Promise<string> {
  await page.waitForLoadState("domcontentloaded").catch(() => {});
  await page.waitForTimeout(600);
  const data = await page.evaluate(() => {
    const visible = (el: Element) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 2 && r.height > 2 && s.visibility !== "hidden" && s.display !== "none";
    };
    const items: string[] = [];
    let n = 0;
    document.querySelectorAll("[data-jarvis-id]").forEach((el) => el.removeAttribute("data-jarvis-id"));
    const els = document.querySelectorAll("a[href], button, input:not([type=hidden]), textarea, select, [role=button], [role=link], [role=tab], [role=menuitem], [role=checkbox], [contenteditable=true]");
    for (const el of Array.from(els)) {
      if (n >= 150 || !visible(el)) continue;
      const tag = el.tagName.toLowerCase();
      const label = (
        (el as HTMLElement).innerText ||
        el.getAttribute("aria-label") ||
        el.getAttribute("title") ||
        (el as HTMLInputElement).placeholder ||
        (el as HTMLInputElement).value ||
        el.getAttribute("name") ||
        ""
      )
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 80);
      if (!label && tag === "a") continue;
      el.setAttribute("data-jarvis-id", String(n));
      const kind = tag === "a" ? "lien" : tag === "input" || tag === "textarea" ? "champ" : tag === "select" ? "liste" : "bouton";
      const href = tag === "a" ? " → " + (el as HTMLAnchorElement).href.slice(0, 120) : "";
      items.push(`[${n}] ${kind} « ${label} »${href}`);
      n++;
    }
    const text = (document.body?.innerText || "").replace(/\n{3,}/g, "\n\n").slice(0, 12000);
    return { title: document.title, url: location.href, text, items };
  });
  return `Page : ${data.title}\nAdresse : ${data.url}\n\n--- Texte ---\n${data.text}\n\n--- Éléments (utilise leur numéro) ---\n${data.items.join("\n")}`;
}
