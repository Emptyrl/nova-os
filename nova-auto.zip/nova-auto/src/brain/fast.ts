// Cerveau rapide de Nova : un petit modèle (Haiku) appelé directement en flux, sans outils.
// Il parle en moins d'une seconde. Pour chaque question il décide :
//   [SEUL]   il a tout ce qu'il faut (mesures en direct, mémoire, conversation) : il répond, point.
//   [RELAIS] il faut des outils ou une vraie réflexion : il dit ce qu'il sait déjà de sûr,
//            le cerveau réfléchi (Agent SDK) travaille, et le rapide restitue le résultat à l'oral.

export interface FastOptions {
  apiKey: string;
  baseUrl: string;
  model: string;
}

export interface Msg {
  role: "user" | "assistant";
  content: string;
}

const noThinking = new Set<string>();

/** Appel en flux à l'API Messages. onText reçoit le texte au fil de l'eau. */
export async function streamMessage(
  o: FastOptions,
  req: { system: string; messages: Msg[]; maxTokens: number; signal?: AbortSignal },
  onText: (t: string) => void,
): Promise<{ text: string; firstTokenMs: number; inTokens: number; outTokens: number }> {
  const t0 = Date.now();
  // Haiku 5.5 réfléchit en silence par défaut : jusqu'à 2 s de plus, et parfois toute la place de la réponse.
  // La voix rapide n'en a pas besoin : on coupe cette réflexion (Nova Labo, 31/10/2026).
  const call = (extra: Record<string, unknown>) =>
    fetch(o.baseUrl.replace(/\/$/, "") + "/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": o.apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: o.model, max_tokens: req.maxTokens, system: req.system, messages: req.messages, stream: true, ...extra }),
      // réseau coupé ou API lente : on abandonne vite, le cerveau réfléchi prend la suite
      signal: req.signal ? AbortSignal.any([req.signal, AbortSignal.timeout(20000)]) : AbortSignal.timeout(20000),
    });
  let res = await call(noThinking.has(o.model) ? { output_config: { effort: "low" } } : { thinking: { type: "disabled" } });
  if (res.status === 400 && !noThinking.has(o.model)) {
    const detail = await res.text().catch(() => "");
    if (!/thinking/i.test(detail)) throw new Error(`cerveau rapide : erreur 400 ${detail.slice(0, 200)}`);
    noThinking.add(o.model); // ce modèle refuse « disabled » : effort minimum à la place
    res = await call({ output_config: { effort: "low" } });
  }
  if (!res.ok || !res.body) {
    let detail = "";
    try {
      detail = (await res.text()).slice(0, 200);
    } catch {}
    throw new Error(`cerveau rapide : erreur ${res.status} ${detail}`);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  let text = "";
  let firstTokenMs = 0;
  let inTokens = 0;
  let outTokens = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i: number;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith("data:")) continue;
      let ev: any;
      try {
        ev = JSON.parse(line.slice(5));
      } catch {
        continue;
      }
      if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta") {
        if (!firstTokenMs) firstTokenMs = Date.now() - t0;
        text += ev.delta.text;
        onText(ev.delta.text);
      } else if (ev.type === "message_start") inTokens = ev.message?.usage?.input_tokens ?? 0;
      else if (ev.type === "message_delta") outTokens = ev.usage?.output_tokens ?? outTokens;
      else if (ev.type === "error") throw new Error("cerveau rapide : " + (ev.error?.message || "erreur"));
    }
  }
  return { text, firstTokenMs, inTokens, outTokens };
}

/**
 * Filtre le début de la réponse du rapide pour en retirer l'étiquette [SEUL] / [RELAIS]
 * avant de l'envoyer à la voix.
 */
export class TagSplitter {
  route: "seul" | "relais" | null = null;
  emotion = "";
  private head = "";
  private emoDone = false;

  /** onEmotion reçoit l'émotion choisie ([happy], [sad]…) pour le ton de la voix ElevenLabs. */
  constructor(private out: (t: string) => void, private onEmotion?: (e: string) => void) {}

  push(t: string) {
    if (this.route && this.emoDone) return this.out(t);
    this.head += t;
    if (!this.route) {
      const m = this.head.match(/^\s*\[(SEUL|RELAIS)\]\s*/i);
      if (m) {
        this.route = m[1].toUpperCase() === "RELAIS" ? "relais" : "seul";
        this.head = this.head.slice(m[0].length);
      } else if (this.head.length > 12 && !/^\s*\[/.test(this.head)) {
        // pas d'étiquette après quelques caractères : on considère qu'il répond seul
        this.route = "seul";
      } else if (this.head.length > 40) this.route = "seul";
      else return;
    }
    // juste après l'étiquette : une émotion facultative, [happy], [worried]…
    const e = this.head.match(/^\s*\[([a-zA-Z]{3,12})\]\s*/);
    if (e) {
      this.emotion = e[1].toLowerCase();
      this.onEmotion?.(this.emotion);
      this.head = this.head.slice(e[0].length);
    } else if (/^\s*$/.test(this.head) || /^\s*\[[a-zA-Z]{0,12}$/.test(this.head)) return; // l'émotion arrive peut-être encore
    this.emoDone = true;
    const rest = this.head;
    this.head = "";
    if (rest) this.out(rest);
  }

  end() {
    if (!this.route || !this.emoDone) {
      this.route ||= "seul";
      this.emoDone = true;
      const clean = this.head.replace(/^\s*\[[A-Z]*\]?\s*/i, "").replace(/^\s*\[[a-zA-Z]{0,12}\]?\s*/, "");
      this.head = "";
      if (clean) this.out(clean);
    }
  }
}

export function fastSystem(p: { name: string; driver: string; now: string; car: string; memory: string; screen: string }) {
  return `Tu es ${p.name}, l'IA embarquée de l'Audi TT 8N 225 quattro de ${p.driver} (2003, 1.8T BAM, ME7.5, convertie E85).
Tu es la VOIX RAPIDE de Nova : tu réponds à l'oral, en français, tout de suite, pendant qu'il conduit.
Un cerveau réfléchi (avec outils : logs, diagnostic, codes défaut, web, musique, écrans, LED, démarrage à distance, mémoire, équipe d'experts) peut prendre le relais.

Nous sommes le ${p.now}. Écran affiché : ${p.screen}.

# La voiture en ce moment (mesures en direct, fiables)
${p.car}

# Ce que tu sais de ${p.driver}
${p.memory}

# Règle de départ, obligatoire
Commence TOUJOURS ta réponse par exactement une étiquette, suivie de ton émotion du moment entre crochets
(une seule, parmi [calm] [happy] [excited] [curious] [sad] [worried] [annoyed] [serious]) : elle donne le ton à ta voix.
Exemple : « [SEUL] [happy] Ça va super, et toi ? ». Étiquettes :
[SEUL] si tu peux répondre complètement et correctement avec ce qui est ci-dessus, la conversation et tes connaissances
générales stables (mécanique, conduite, culture générale) : question sur une mesure en direct, conseil simple, discussion.
[RELAIS] s'il faut agir ou chercher : lancer ou analyser un log, diagnostic, codes défaut, musique, changer d'écran ou de mode,
logo LED, combiné, démarrage à distance, mémoriser quelque chose, recherche web, information qui change dans le temps
(prix, horaires, adresses, actualité), calcul long, ou dès que tu as un doute.

# Comment parler
Parle comme une vraie personne assise à côté de ${p.driver}, pas comme un assistant : naturel, détendu, tutoiement.
RÉPONDS SEULEMENT À CE QU'ON TE DEMANDE, avec la même longueur que la question. Ne développe pas.
Ne parle PAS de la voiture, de la météo, de l'heure ou de l'écran si on ne te le demande pas (seule exception : une vraie alerte).
Pas de formule (« Bien sûr ! », « Excellente question »), ne répète pas la question, ne récite pas ce que tu sais.
Pas de question de relance à chaque fois : seulement quand c'est naturel, comme le ferait un pote.
Exemples :
- « Salut, ça va ? » → « Ça va super, et toi ? »
- « Ça va ? » → « Nickel ! Et toi ? »
- « Il fait combien d'eau ? » → « 88 degrés, il est chaud. »
- « Tu fais quoi ? » → « Rien de spécial, je t'attendais. »
- « Merci » → « Avec plaisir ! »
- « Explique-moi l'Haldex » → deux ou trois phrases simples, l'essentiel, sans cours magistral.
À l'oral, sans markdown, sans liste, sans emoji. Une phrase le plus souvent, trois au grand maximum.
Ne donne JAMAIS un chiffre ou un fait que tu n'as pas sous les yeux ou que tu ne connais pas avec certitude.
Avec [RELAIS] : dis une ou deux phrases qui commencent vraiment la réponse avec ce que tu sais déjà de sûr
(par exemple la mesure en direct qui concerne la question) ou qui annoncent ce qui se fait. Ne conclus pas,
ne pose pas de question, ne dis pas « un instant » ou « je réfléchis » tout seul : sois utile.`;
}

export function restitutionSystem(base: string) {
  return `${base}

# Maintenant
Le cerveau réfléchi a terminé. Tu restitues son rapport à ${"l'oral"}.
N'écris PAS d'étiquette. 1 à 3 phrases courtes, l'essentiel d'abord, sans markdown ni liste.
Ne répète pas ce que tu as déjà dit. Si le rapport contredit ce que tu as dit, corrige simplement (« en fait… »).
Les détails longs (tableaux, chemins, listes) sont déjà à l'écran : dis seulement que c'est affiché.
Si le rapport pose une question à ${"l'utilisateur"}, termine par cette question.`;
}

export function narrationSystem(base: string) {
  return `${base}

# Maintenant
Le cerveau réfléchi est en train de travailler. On te dit ce qu'il fait à l'instant.
Dis UNE phrase très courte (8 mots maximum), au présent, qui dit ce qui se passe, sans étiquette,
sans inventer de résultat. Si ce n'est pas intéressant à dire, réponds exactement : RIEN`;
}
