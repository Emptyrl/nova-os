// Connexions gardées ouvertes vers Claude et ElevenLabs.
// fetch() de Node referme une connexion inutilisée au bout de 4 s : à chaque question, Nova refaisait
// la poignée de main TLS (0,3 à 1 s sur un vieux PC en 4G). Ici les connexions restent ouvertes et sont
// entretenues (warm) : la demande part tout de suite.
import https from "node:https";
import http from "node:http";

const httpsAgent = new https.Agent({ keepAlive: true, keepAliveMsecs: 15_000, maxSockets: 12, maxFreeSockets: 6, timeout: 120_000 });
const httpAgent = new http.Agent({ keepAlive: true, keepAliveMsecs: 15_000, maxSockets: 12 });

export interface KaResponse {
  status: number;
  ok: boolean;
  /** le corps, morceau par morceau, dès qu'il arrive */
  stream: AsyncIterable<Buffer>;
  text(): Promise<string>;
}

export function kaRequest(method: "GET" | "POST", url: string, headers: Record<string, string>, body?: string, signal?: AbortSignal, timeoutMs = 60_000): Promise<KaResponse> {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const mod = u.protocol === "http:" ? http : https;
    const req = mod.request(
      { method, hostname: u.hostname, port: u.port || undefined, path: u.pathname + u.search, headers: body ? { ...headers, "content-length": Buffer.byteLength(body) } : headers, agent: u.protocol === "http:" ? httpAgent : httpsAgent },
      (res) => {
        const status = res.statusCode || 0;
        resolve({
          status,
          ok: status >= 200 && status < 300,
          stream: res,
          text: async () => {
            const parts: Buffer[] = [];
            for await (const c of res) parts.push(c as Buffer);
            return Buffer.concat(parts).toString("utf8");
          },
        });
      },
    );
    const timer = setTimeout(() => req.destroy(new Error("délai dépassé")), timeoutMs);
    req.on("close", () => clearTimeout(timer));
    req.on("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
    if (signal) {
      if (signal.aborted) req.destroy(new Error("interrompu"));
      else signal.addEventListener("abort", () => req.destroy(new Error("interrompu")), { once: true });
    }
    if (body) req.write(body);
    req.end();
  });
}

/** Petite demande sans effet, juste pour ouvrir (ou garder ouverte) la connexion. */
export async function kaWarm(url: string, headers: Record<string, string>) {
  try {
    const r = await kaRequest("GET", url, headers, undefined, undefined, 8000);
    await r.text();
  } catch {
    /* pas de réseau : tant pis */
  }
}
