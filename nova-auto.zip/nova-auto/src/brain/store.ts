// Mémoire et projets de Nova, stockés en clair dans ~/Nova (dossier NOVA_HOME)
// (lisibles et modifiables à la main).
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";

export interface Project {
  id: string;
  name: string;
  path: string;
  notes: string[];
  sessionId?: string;
  lastSummary?: string;
  lastUsed: string;
}

export interface MemoryItem {
  category: string;
  text: string;
}

export const DATA_DIR = process.env.NOVA_HOME || process.env.JARVIS_HOME || path.join(os.homedir(), "Nova");
const PROJECTS_FILE = path.join(DATA_DIR, "projects.json");
const MEMORY_FILE = path.join(DATA_DIR, "memoire.md");
const STATE_FILE = path.join(DATA_DIR, "etat.json");

interface State {
  activeProjectId: string | null;
  generalSessionId?: string;
}

async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    return JSON.parse(await fs.readFile(file, "utf8")) as T;
  } catch {
    return fallback;
  }
}

async function writeAtomic(file: string, content: string) {
  const tmp = file + ".tmp";
  await fs.writeFile(tmp, content, "utf8");
  await fs.rename(tmp, file);
}

export class Store {
  projects: Project[] = [];
  memory: MemoryItem[] = [];
  state: State = { activeProjectId: null };

  async load() {
    await fs.mkdir(DATA_DIR, { recursive: true });
    this.projects = await readJson<Project[]>(PROJECTS_FILE, []);
    this.state = await readJson<State>(STATE_FILE, { activeProjectId: null });
    this.memory = await this.readMemory();
  }

  // memoire.md : une ligne par fait, au format "- [Catégorie] texte"
  private async readMemory(): Promise<MemoryItem[]> {
    let raw = "";
    try {
      raw = await fs.readFile(MEMORY_FILE, "utf8");
    } catch {
      return [];
    }
    const items: MemoryItem[] = [];
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^\s*-\s*(?:\[([^\]]+)\]\s*)?(.+)$/);
      if (m) items.push({ category: (m[1] || "Général").trim(), text: m[2].trim() });
    }
    return items;
  }

  private async saveMemory() {
    const body =
      "# Ce que Nova sait de toi\n\n" +
      "Une ligne par fait. Tu peux modifier ce fichier à la main.\n\n" +
      this.memory.map((m) => `- [${m.category}] ${m.text}`).join("\n") +
      "\n";
    await writeAtomic(MEMORY_FILE, body);
  }

  private async saveProjects() {
    await writeAtomic(PROJECTS_FILE, JSON.stringify(this.projects, null, 2));
  }

  async saveState() {
    await writeAtomic(STATE_FILE, JSON.stringify(this.state, null, 2));
  }

  get activeProject(): Project | null {
    return this.projects.find((p) => p.id === this.state.activeProjectId) ?? null;
  }

  async remember(category: string, text: string) {
    const exists = this.memory.some((m) => m.text.toLowerCase() === text.toLowerCase());
    if (!exists) {
      this.memory.push({ category, text });
      await this.saveMemory();
    }
  }

  async forget(index: number) {
    if (index >= 0 && index < this.memory.length) {
      this.memory.splice(index, 1);
      await this.saveMemory();
    }
  }

  async createProject(name: string, dir: string): Promise<Project> {
    const resolved = path.resolve(dir);
    await fs.mkdir(resolved, { recursive: true });
    const existing = this.projects.find((p) => path.resolve(p.path).toLowerCase() === resolved.toLowerCase());
    if (existing) return existing;
    const project: Project = { id: randomUUID(), name, path: resolved, notes: [], lastUsed: new Date().toISOString() };
    this.projects.push(project);
    await this.saveProjects();
    return project;
  }

  async deleteProject(id: string) {
    this.projects = this.projects.filter((p) => p.id !== id);
    if (this.state.activeProjectId === id) this.state.activeProjectId = null;
    await this.saveProjects();
    await this.saveState();
  }

  async selectProject(id: string | null) {
    this.state.activeProjectId = id;
    const p = this.activeProject;
    if (p) {
      p.lastUsed = new Date().toISOString();
      await this.saveProjects();
    }
    await this.saveState();
  }

  findProject(query: string): Project | null {
    const q = query.trim().toLowerCase();
    return (
      this.projects.find((p) => p.name.toLowerCase() === q) ??
      this.projects.find((p) => p.name.toLowerCase().includes(q)) ??
      null
    );
  }

  async updateProject(id: string, patch: Partial<Project>) {
    const p = this.projects.find((x) => x.id === id);
    if (!p) return;
    Object.assign(p, patch);
    await this.saveProjects();
  }

  async addProjectNote(id: string, note: string) {
    const p = this.projects.find((x) => x.id === id);
    if (!p || p.notes.includes(note)) return;
    p.notes.push(note);
    await this.saveProjects();
  }

  snapshot() {
    return {
      projects: [...this.projects].sort((a, b) => b.lastUsed.localeCompare(a.lastUsed)),
      memory: this.memory,
      activeProjectId: this.state.activeProjectId,
      dataDir: DATA_DIR,
    };
  }
}
