// Détecteur de mot-clé local (sherpa-onnx, Apache 2.0, modèle anglais de 5 Mo dans agent/models/kws).
// Il complète la détection par transcription française (voir audio.ts) pour le nom de l'assistant.
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { promises as fs, readFileSync } from "node:fs";

const require = createRequire(import.meta.url);
const MODEL_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "models", "kws");

export type Sensitivity = "low" | "normal" | "high";
const THRESHOLDS: Record<Sensitivity, number> = { low: 0.3, normal: 0.2, high: 0.12 };

let sherpa: any = null;
let loadError = "";
try {
  sherpa = require("sherpa-onnx-node");
} catch (e: any) {
  loadError = String(e?.message || e);
}

// Vocabulaire du modèle, pour découper un nom en morceaux qu'il connaît.
let vocab: Set<string> | null = null;
function loadVocab() {
  if (vocab) return vocab;
  vocab = new Set(
    readFileSync(path.join(MODEL_DIR, "tokens.txt"), "utf8")
      .split(/\r?\n/)
      .map((l) => l.split(" ")[0])
      .filter(Boolean),
  );
  return vocab;
}

/** Découpe un mot en morceaux du vocabulaire (plus long morceau d'abord). */
export function tokenize(word: string): string | null {
  const v = loadVocab();
  const w = word.toUpperCase().replace(/[^A-Z]/g, "");
  if (!w) return null;
  const out: string[] = [];
  let i = 0;
  let first = true;
  while (i < w.length) {
    let found = "";
    for (let j = w.length; j > i; j--) {
      const piece = (first ? "▁" : "") + w.slice(i, j);
      if (v.has(piece)) {
        found = piece;
        break;
      }
    }
    if (!found) {
      if (first && v.has("▁")) {
        out.push("▁");
        first = false;
        continue;
      }
      return null;
    }
    out.push(found);
    i += found.replace("▁", "").length;
    first = false;
  }
  return out.join(" ");
}

function keywordsFor(name: string): string {
  const words = name
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .split(/\s+/)
    .map(tokenize);
  if (words.some((w) => !w)) return "";
  const body = words.join(" ");
  return [`▁O K ${body} @WAKE`, `▁OKAY ${body} @WAKE`, `▁HE Y ${body} @WAKE`, `${body} @WAKE`].join("\n");
}

const spotters = new Map<string, any>();

async function getSpotter(name: string, sensitivity: Sensitivity, dataDir: string) {
  if (!sherpa) throw new Error("Moteur audio indisponible : " + loadError);
  const key = name.toLowerCase() + "|" + sensitivity;
  const existing = spotters.get(key);
  if (existing) return existing;
  const keywords = keywordsFor(name);
  if (!keywords) return null; // nom impossible à découper : la transcription française suffira
  const kwFile = path.join(dataDir, "mots-activation.txt");
  await fs.writeFile(kwFile, keywords + "\n", "utf8");
  const spotter = new sherpa.KeywordSpotter({
    featConfig: { sampleRate: 16000, featureDim: 80 },
    modelConfig: {
      transducer: {
        encoder: path.join(MODEL_DIR, "encoder.int8.onnx"),
        decoder: path.join(MODEL_DIR, "decoder.int8.onnx"),
        joiner: path.join(MODEL_DIR, "joiner.int8.onnx"),
      },
      tokens: path.join(MODEL_DIR, "tokens.txt"),
      numThreads: 1,
      provider: "cpu",
      debug: 0,
    },
    keywordsFile: kwFile,
    keywordsScore: 2.0,
    keywordsThreshold: THRESHOLDS[sensitivity],
    maxActivePaths: 4,
    numTrailingBlanks: 1,
  });
  spotters.set(key, spotter);
  return spotter;
}

/** Un détecteur par connexion de l'interface. */
export class WakeListener {
  private stream: any;
  private cooldownUntil = 0;

  private constructor(
    private spotter: any,
    private sampleRate: number,
  ) {
    this.stream = spotter.createStream();
  }

  static async create(name: string, sampleRate: number, sensitivity: Sensitivity, dataDir: string) {
    const spotter = await getSpotter(name, sensitivity, dataDir);
    return spotter ? new WakeListener(spotter, sampleRate) : null;
  }

  /** Renvoie true quand le nom vient d'être entendu. */
  feed(samples: Float32Array): boolean {
    this.stream.acceptWaveform({ samples, sampleRate: this.sampleRate });
    let detected = false;
    while (this.spotter.isReady(this.stream)) {
      this.spotter.decode(this.stream);
      const r = this.spotter.getResult(this.stream);
      if (r.keyword) {
        this.spotter.reset(this.stream);
        if (Date.now() > this.cooldownUntil) {
          detected = true;
          this.cooldownUntil = Date.now() + 1500;
        }
      }
    }
    return detected;
  }
}

export const wakeAvailable = () => !!sherpa;
