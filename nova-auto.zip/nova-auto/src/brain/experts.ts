// Experts extérieurs : les meilleures IA d'autres maisons, appelées comme des outils par l'équipe.
// - generate_image : génération d'images OpenAI (GPT Image, n°1 des classements d'images en octobre 2026)
// - expert_opinion : second avis de GPT (OpenAI) et Gemini (Google) sur une question difficile
// - google_search  : recherche Google via Gemini (« grounding »), avec ses sources
// Chaque outil n'est proposé que si la clé correspondante est enregistrée.
import fs from "node:fs/promises";
import path from "node:path";
import { tool } from "@anthropic-ai/claude-agent-sdk";
import { z } from "zod";
import type { Workspace } from "./ui.js";

export interface ExpertConfig {
  openaiKey: string;
  geminiKey: string;
  imageModel: string;
  gptModel: string;
  geminiModel: string;
}

const text = (t: string) => ({ content: [{ type: "text" as const, text: t }] });
const fail = (t: string) => ({ content: [{ type: "text" as const, text: t }], isError: true });

// Modèles de secours si le modèle réglé n'existe pas (encore ou plus) sur le compte.
const IMAGE_FALLBACKS = ["gpt-image-2", "gpt-image-1.5", "gpt-image-1"];

async function readError(res: Response, who: string): Promise<string> {
  let message = "";
  try {
    const body: any = await res.json();
    message = body?.error?.message || body?.error?.status || "";
  } catch {
    /* corps illisible */
  }
  if (res.status === 401 || res.status === 403) return `${who} : clé refusée. Vérifie-la dans Paramètres › Équipe.`;
  if (res.status === 429 || /quota|billing|credit/i.test(message)) return `${who} : plus de crédits ou trop de requêtes (${message || res.status}).`;
  if (res.status === 404) return `${who} : modèle introuvable (${message || "404"}). Change le modèle dans Paramètres › Équipe.`;
  return `${who} : erreur ${res.status}${message ? " — " + message : ""}`;
}

const isModelError = (status: number, msg: string) => status === 404 || (status === 400 && /model/i.test(msg));

type Sourced = { answer: string; sources: { title: string; uri: string }[]; queries: string[]; web: boolean };

async function askGpt(cfg: ExpertConfig, prompt: string, opts: { web?: boolean; signal?: AbortSignal } = {}): Promise<Sourced> {
  const call = (web: boolean) =>
    fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.openaiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: cfg.gptModel,
        reasoning: { effort: "high" },
        input: prompt,
        ...(web ? { tools: [{ type: "web_search", search_context_size: "high" }] } : {}),
      }),
      signal: opts.signal,
    });
  let web = !!opts.web;
  let res = await call(web);
  // modèle sans recherche web : on redemande sans, plutôt que d'échouer
  if (!res.ok && web && res.status === 400 && /web_search|tool/i.test(await res.clone().text())) {
    web = false;
    res = await call(false);
  }
  if (!res.ok) throw new Error(await readError(res, "GPT"));
  const body: any = await res.json();
  const parts: string[] = [];
  const sources: Sourced["sources"] = [];
  const queries: string[] = [];
  for (const item of body.output ?? []) {
    if (item.type === "web_search_call" && item.action?.query) queries.push(String(item.action.query));
    if (item.type !== "message") continue;
    for (const c of item.content ?? []) {
      if (c.type !== "output_text" || !c.text) continue;
      parts.push(c.text);
      for (const a of c.annotations ?? [])
        if (a.type === "url_citation" && a.url && !sources.some((x) => x.uri === a.url)) sources.push({ title: String(a.title || a.url), uri: String(a.url) });
    }
  }
  const answer = parts.join("\n").trim() || (typeof body.output_text === "string" ? body.output_text.trim() : "");
  if (!answer && body.status === "incomplete") throw new Error("GPT : réponse incomplète (" + (body.incomplete_details?.reason || "?") + ").");
  return { answer: answer || "(réponse vide)", sources, queries, web };
}

async function askGemini(cfg: ExpertConfig, prompt: string, opts: { search?: boolean; signal?: AbortSignal } = {}): Promise<Sourced> {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.geminiModel)}:generateContent`, {
    method: "POST",
    headers: { "x-goog-api-key": cfg.geminiKey, "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      ...(opts.search ? { tools: [{ google_search: {} }] } : {}),
      generationConfig: { thinkingConfig: { thinkingLevel: opts.search ? "medium" : "high" } },
    }),
    signal: opts.signal,
  });
  if (!res.ok) throw new Error(await readError(res, "Gemini"));
  const body: any = await res.json();
  const cand = body.candidates?.[0];
  const answer = (cand?.content?.parts ?? [])
    .filter((p: any) => typeof p.text === "string" && !p.thought)
    .map((p: any) => p.text)
    .join("")
    .trim();
  const meta = cand?.groundingMetadata ?? {};
  const sources: { title: string; uri: string }[] = (meta.groundingChunks ?? [])
    .map((c: any) => c.web)
    .filter((w: any) => w?.uri)
    .map((w: any) => ({ title: String(w.title || w.uri), uri: String(w.uri) }));
  const queries: string[] = meta.webSearchQueries ?? [];
  if (!answer) throw new Error("Gemini : réponse vide" + (cand?.finishReason ? ` (${cand.finishReason})` : "") + ".");
  return { answer, sources, queries, web: !!opts.search };
}

const slug = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40) || "image";

export const EXPERT_TOOL_NAMES = ["generate_image", "expert_opinion", "google_search"];

/** Quels outils d'experts sont utilisables avec les clés actuelles. */
export function expertAvailable(cfg: ExpertConfig, name: string): boolean {
  if (name === "generate_image") return !!cfg.openaiKey;
  if (name === "expert_opinion") return !!(cfg.openaiKey || cfg.geminiKey);
  if (name === "google_search") return !!cfg.geminiKey;
  return true;
}

export function expertTools(deps: { config: () => ExpertConfig; workDir: () => string; workspace: Workspace }) {
  return [
    tool(
      "generate_image",
      "Génère une image avec GPT Image (OpenAI) : logo, illustration, affiche, icône, texture, maquette visuelle. Consigne précise en français ou en anglais (sujet, style, composition, couleurs). L'image est enregistrée en PNG et affichée à l'utilisateur.",
      {
        prompt: z.string().describe("Description détaillée de l'image"),
        name: z.string().optional().describe("Nom court du fichier (sans extension)"),
        size: z.string().optional().describe("1024x1024 (carré, défaut), 1536x1024 (paysage), 1024x1536 (portrait)"),
        quality: z.enum(["low", "medium", "high", "auto"]).optional(),
        transparent: z.boolean().optional().describe("Fond transparent (logos, icônes)"),
      },
      async ({ prompt, name, size, quality, transparent }) => {
        const cfg = deps.config();
        if (!cfg.openaiKey) return fail("Pas de clé OpenAI : l'utilisateur doit l'ajouter dans Paramètres › Cerveau.");
        const models = [cfg.imageModel, ...IMAGE_FALLBACKS].filter((m, i, a) => m && a.indexOf(m) === i);
        let lastError = "";
        for (const model of models) {
          try {
            const res = await fetch("https://api.openai.com/v1/images/generations", {
              method: "POST",
              headers: { Authorization: `Bearer ${cfg.openaiKey}`, "Content-Type": "application/json" },
              body: JSON.stringify({
                model,
                prompt,
                n: 1,
                size: size && /^\d{3,4}x\d{3,4}$/.test(size) ? size : "1024x1024",
                quality: quality ?? "auto",
                output_format: "png",
                ...(transparent ? { background: "transparent" } : {}),
              }),
            });
            if (!res.ok) {
              const raw = await res.clone().text();
              lastError = await readError(res, "Images");
              if (isModelError(res.status, raw)) continue; // on essaie le modèle suivant
              return fail(lastError);
            }
            const body: any = await res.json();
            const b64 = body.data?.[0]?.b64_json;
            if (!b64) return fail("Images : aucune image renvoyée.");
            const dir = path.join(deps.workDir(), "images");
            await fs.mkdir(dir, { recursive: true });
            const file = path.join(dir, `${slug(name || prompt)}-${Date.now().toString(36)}.png`);
            await fs.writeFile(file, Buffer.from(b64, "base64"));
            deps.workspace.open({
              id: "image-" + path.basename(file, ".png"),
              title: name || "Image générée",
              kind: "image",
              mode: "window",
              size: "large",
              url: "data:image/png;base64," + b64,
              createdAt: Date.now(),
            });
            return text(`Image créée avec ${model} et affichée à l'utilisateur : ${file}`);
          } catch (e: any) {
            return fail("Images : " + (e?.message || e));
          }
        }
        return fail(lastError || "Images : aucun modèle disponible.");
      },
    ),
    tool(
      "expert_opinion",
      "Triple vérification : pose la même question, en parallèle, à GPT (OpenAI) et Gemini (Google). Par défaut chacun fait SES PROPRES recherches web (GPT avec sa recherche web, Gemini avec Google) et cite ses sources. Toi (Claude) tu es le troisième avis : fais ta propre recherche en même temps, puis compare les trois. Donne une question complète et autonome (ils ne voient rien d'autre), avec le contexte exact (ex. code moteur, année, version).",
      {
        question: z.string().describe("Question complète, avec tout le contexte nécessaire"),
        experts: z.array(z.enum(["gpt", "gemini"])).optional().describe("Par défaut : tous ceux disponibles"),
        web: z.boolean().optional().describe("Recherche web par chaque expert (défaut : oui). Non pour un pur raisonnement ou calcul."),
      },
      async ({ question, experts, web }, extra: any) => {
        const cfg = deps.config();
        const search = web !== false;
        const want = experts?.length ? experts : (["gpt", "gemini"] as const);
        const ask = `${question}

Consignes : réponds en français. ${search ? "Cherche sur le web et appuie-toi sur des sources fiables (constructeur, documentation officielle, revue technique). " : ""}Donne la réponse exacte (valeurs avec unités, conditions d'application, étapes s'il y en a). Indique ton niveau de confiance (élevé, moyen, faible) et ce qui pourrait faire varier la réponse. Si tu ne sais pas ou si les sources se contredisent, dis-le clairement au lieu d'inventer.`;
        const format = (who: string, model: string, r: Sourced) =>
          `## ${who} (${model}${r.web ? ", avec recherche web" : ", sans recherche web"})\n${r.answer}` +
          (r.sources.length ? "\nSources :\n" + r.sources.slice(0, 10).map((x, i) => `[${i + 1}] ${x.title} — ${x.uri}`).join("\n") : search ? "\n(aucune source citée)" : "");
        const jobs: Promise<string>[] = [];
        if (want.includes("gpt") && cfg.openaiKey)
          jobs.push(askGpt(cfg, ask, { web: search, signal: extra?.signal }).then((r) => format("Avis de GPT", cfg.gptModel, r), (e) => `## GPT\nIndisponible : ${e.message || e}`));
        if (want.includes("gemini") && cfg.geminiKey)
          jobs.push(askGemini(cfg, ask, { search, signal: extra?.signal }).then((r) => format("Avis de Gemini", cfg.geminiModel, r), (e) => `## Gemini\nIndisponible : ${e.message || e}`));
        if (!jobs.length) return fail("Aucun expert disponible : ajoute une clé OpenAI ou Gemini dans les Paramètres.");
        const answers = await Promise.all(jobs);
        return text(
          answers.join("\n\n") +
            "\n\n---\nCompare ces avis au tien : s'ils concordent, dis que la réponse est confirmée par plusieurs IA ; s'ils divergent, dis-le, explique l'écart, privilégie la réponse la mieux sourcée et conseille de vérifier dans la documentation constructeur.",
        );
      },
    ),
    tool(
      "google_search",
      "Recherche Google (via Gemini) : renvoie une synthèse et la liste des pages sources. Complète WebSearch avec un second moteur, utile pour l'actualité, les prix, les références locales.",
      { query: z.string().describe("Ce qu'il faut chercher, formulé comme une question précise") },
      async ({ query }, extra: any) => {
        const cfg = deps.config();
        if (!cfg.geminiKey) return fail("Pas de clé Gemini : l'utilisateur peut l'ajouter dans Paramètres › Équipe.");
        try {
          const r = await askGemini(cfg, query, { search: true, signal: extra?.signal });
          const src = r.sources.length ? r.sources.map((s, i) => `[${i + 1}] ${s.title} — ${s.uri}`).join("\n") : "(aucune source renvoyée)";
          return text(`${r.answer}\n\nRequêtes Google : ${r.queries.join(" · ") || "?"}\nSources :\n${src}\n(Les liens passent par une redirection Google ; ouvre-les avec WebFetch pour lire la page.)`);
        } catch (e: any) {
          return fail(String(e?.message || e));
        }
      },
    ),
  ];
}
