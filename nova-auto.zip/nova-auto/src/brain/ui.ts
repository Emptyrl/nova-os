// Plan de travail de Jarvis : fenêtres et overlays qu'il ouvre dans son interface,
// plus la musique et les touches multimédia de Windows.
import { spawn } from "node:child_process";
import { tool } from "@anthropic-ai/claude-agent-sdk";
import { z } from "zod";

export type WinKind = "markdown" | "log" | "activity" | "list" | "checklist" | "table" | "code" | "clock" | "timer" | "music" | "image" | "progress";

export interface Win {
  id: string;
  title: string;
  kind: WinKind;
  mode: "window" | "overlay";
  size: "auto" | "small" | "medium" | "large" | "wide";
  corner?: "top-left" | "top-right" | "bottom-left" | "bottom-right";
  content?: string;
  lines?: string[];
  items?: { text: string; done?: boolean }[];
  columns?: string[];
  rows?: string[][];
  language?: string;
  seconds?: number;
  endsAt?: number;
  url?: string;
  artist?: string;
  percent?: number;
  // musique en cours
  artwork?: string;
  position?: number;
  duration?: number;
  playing?: boolean;
  updatedAt?: number;
  createdAt: number;
}

type Broadcast = (msg: Record<string, unknown>) => void;

export class Workspace {
  windows = new Map<string, Win>();
  constructor(private broadcast: Broadcast) {}

  snapshot() {
    return { type: "ui.snapshot", windows: [...this.windows.values()] };
  }

  open(w: Win) {
    this.windows.set(w.id, w);
    this.broadcast({ type: "ui.open", win: w });
  }

  update(id: string, patch: Partial<Win>, appendLines?: string[]) {
    const w = this.windows.get(id);
    if (!w) return false;
    Object.assign(w, patch);
    if (appendLines?.length) w.lines = [...(w.lines ?? []), ...appendLines].slice(-400);
    this.broadcast({ type: "ui.update", id, win: w });
    return true;
  }

  close(id: string) {
    if (id === "all") {
      for (const k of [...this.windows.keys()]) this.close(k);
      return;
    }
    if (this.windows.delete(id)) this.broadcast({ type: "ui.close", id });
  }

  /** Journal automatique : chaque action de Jarvis s'ajoute aux fenêtres « activity ». */
  logActivity(line: string) {
    const stamp = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    for (const w of this.windows.values()) if (w.kind === "activity") this.update(w.id, {}, [`${stamp}  ${line}`]);
  }

  describe(): string {
    if (!this.windows.size) return "(aucune fenêtre ouverte)";
    return [...this.windows.values()].map((w) => `- ${w.id} : « ${w.title} » (${w.kind}, ${w.mode})`).join("\n");
  }
}

// ---------- ouvrir une URL dans le navigateur par défaut ----------
export function openUrl(url: string) {
  if (!/^https?:\/\//i.test(url)) throw new Error("Adresse non autorisée (http/https uniquement).");
  const child =
    process.platform === "win32"
      ? spawn("rundll32", ["url.dll,FileProtocolHandler", url], { detached: true, stdio: "ignore", windowsHide: true })
      : spawn(process.platform === "darwin" ? "open" : "xdg-open", [url], { detached: true, stdio: "ignore" });
  child.on("error", () => {});
  child.unref();
}

// ---------- touches multimédia de Windows (contrôlent le lecteur actif : navigateur, Spotify…) ----------
const MEDIA_KEYS: Record<string, number> = {
  play_pause: 0xb3,
  next: 0xb0,
  previous: 0xb1,
  volume_up: 0xaf,
  volume_down: 0xae,
  mute: 0xad,
};

export function mediaKey(action: string, times = 1) {
  const vk = MEDIA_KEYS[action];
  if (vk === undefined) throw new Error("Action inconnue : " + action);
  if (process.platform !== "win32") {
    // Linux : lecteurs MPRIS (téléphone en Bluetooth via mpris-proxy, navigateur…) avec playerctl
    const map: Record<string, string[]> = { play_pause: ["play-pause"], next: ["next"], previous: ["previous"], volume_up: ["volume", "0.05+"], volume_down: ["volume", "0.05-"], mute: ["volume", "0"] };
    const args = map[action];
    if (!args) return;
    for (let i = 0; i < Math.max(1, Math.min(20, times)); i++) {
      const p = spawn("playerctl", args, { stdio: "ignore" });
      p.on("error", () => {});
    }
    return;
  }
  const n = Math.max(1, Math.min(20, times));
  const script =
    `$s='[DllImport("user32.dll")] public static extern void keybd_event(byte b,byte s,uint f,UIntPtr e);';` +
    `Add-Type -MemberDefinition $s -Name K -Namespace W;` +
    `for($i=0;$i -lt ${n};$i++){[W.K]::keybd_event(${vk},0,0,[UIntPtr]::Zero);[W.K]::keybd_event(${vk},0,2,[UIntPtr]::Zero);Start-Sleep -Milliseconds 40}`;
  const p = spawn("powershell", ["-NoProfile", "-NonInteractive", "-Command", script], { windowsHide: true, stdio: "ignore" });
  p.on("error", () => {});
}

// ---------- outils donnés à Jarvis ----------
const text = (t: string) => ({ content: [{ type: "text" as const, text: t }] });
const slug = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 32) || "fenetre";

const kinds = ["markdown", "log", "activity", "list", "checklist", "table", "code", "clock", "timer", "music", "image", "progress"] as const;

export function workspaceTools(ws: Workspace) {
  return [
    tool(
      "show_window",
      `Ouvre (ou remplace) une fenêtre sur le plan de travail de Jarvis, à l'écran de l'utilisateur.
Types : markdown (texte riche, résultats de recherche, résumé), log (lignes ajoutées au fil de l'eau), activity (journal automatique : chaque action de Jarvis s'y ajoute toute seule pendant qu'il travaille),
list, checklist (tâches cochables), table (colonnes + lignes), code (avec language), clock (heure en direct), timer (minuteur : seconds), music (titre en cours : title, artist), image (url), progress (percent).
mode "overlay" = petit widget dans un coin (horloge, musique, minuteur) ; "window" = fenêtre du plan de travail.
size : auto (s'adapte au contenu), small, medium, large, wide.`,
      {
        id: z.string().optional().describe("Identifiant court ; réutilise-le pour mettre à jour. Par défaut dérivé du titre."),
        title: z.string(),
        kind: z.enum(kinds),
        mode: z.enum(["window", "overlay"]).optional(),
        size: z.enum(["auto", "small", "medium", "large", "wide"]).optional(),
        corner: z.enum(["top-left", "top-right", "bottom-left", "bottom-right"]).optional(),
        content: z.string().optional().describe("Texte markdown ou code"),
        lines: z.array(z.string()).optional(),
        items: z.array(z.string()).optional().describe("Éléments de liste ou de checklist"),
        columns: z.array(z.string()).optional(),
        rows: z.array(z.array(z.string())).optional(),
        language: z.string().optional(),
        seconds: z.number().optional().describe("Durée du minuteur"),
        url: z.string().optional(),
        artist: z.string().optional(),
        percent: z.number().optional(),
      },
      async (a) => {
        const id = a.id ? slug(a.id) : slug(a.title);
        const overlayKinds = ["clock", "timer", "music"];
        const w: Win = {
          id,
          title: a.title,
          kind: a.kind,
          mode: a.mode ?? (overlayKinds.includes(a.kind) ? "overlay" : "window"),
          size: a.size ?? "auto",
          corner: a.corner,
          content: a.content,
          lines: a.lines ?? (a.kind === "activity" ? [] : undefined),
          items: a.items?.map((t) => ({ text: t })),
          columns: a.columns,
          rows: a.rows,
          language: a.language,
          seconds: a.seconds,
          endsAt: a.kind === "timer" && a.seconds ? Date.now() + a.seconds * 1000 : undefined,
          url: a.url,
          artist: a.artist,
          percent: a.percent,
          createdAt: Date.now(),
        };
        ws.open(w);
        return text(`Fenêtre « ${w.title} » affichée (id : ${id}).`);
      },
    ),
    tool(
      "update_window",
      "Met à jour une fenêtre existante : nouveau titre/contenu, lignes à ajouter à un log, éléments cochés, progression…",
      {
        id: z.string(),
        title: z.string().optional(),
        content: z.string().optional(),
        append_lines: z.array(z.string()).optional(),
        items: z.array(z.string()).optional(),
        done_items: z.array(z.number()).optional().describe("Index (0, 1, 2…) des éléments de checklist à cocher"),
        rows: z.array(z.array(z.string())).optional(),
        percent: z.number().optional(),
      },
      async (a) => {
        const w = ws.windows.get(a.id);
        if (!w) return text("Fenêtre introuvable. Ouvertes : " + ws.describe());
        const patch: Partial<Win> = {};
        if (a.title) patch.title = a.title;
        if (a.content !== undefined) patch.content = a.content;
        if (a.rows) patch.rows = a.rows;
        if (a.percent !== undefined) patch.percent = a.percent;
        let items = a.items ? a.items.map((t) => ({ text: t })) : w.items;
        if (items && a.done_items) items = items.map((it, i) => (a.done_items!.includes(i) ? { ...it, done: true } : it));
        if (items) patch.items = items;
        ws.update(a.id, patch, a.append_lines);
        return text("Fenêtre mise à jour.");
      },
    ),
    tool("close_window", "Ferme une fenêtre (par son id) ou toutes (id = \"all\").", { id: z.string() }, async ({ id }) => {
      ws.close(id);
      return text("Fermé.");
    }),
    tool(
      "media_control",
      "Contrôle un lecteur EXTERNE à l'assistant (Spotify, autre logiciel…) avec les touches multimédia de Windows. Pour la musique lancée par music_play, utilise music_control.",
      { action: z.enum(["play_pause", "next", "previous", "volume_up", "volume_down", "mute"]), times: z.number().optional().describe("Répétitions (volume)") },
      async ({ action, times }) => {
        mediaKey(action, times ?? (action.startsWith("volume") ? 5 : 1));
        return text("Fait.");
      },
    ),
    tool("open_url", "Ouvre une page dans le navigateur PERSONNEL de l'utilisateur (à éviter : demande son accord). Préfère web_open, ton propre navigateur.", { url: z.string() }, async ({ url }) => {
      openUrl(url);
      return text("Page ouverte.");
    }),
  ];
}

export const WORKSPACE_TOOL_NAMES = ["show_window", "update_window", "close_window", "media_control"];

// ---------- navigateurs et musique ----------
import { snapshot, type Browsers, type Profile } from "./browser.js";
import type { MusicPlayer } from "./music.js";

const profileArg = z
  .enum(["clean", "account"])
  .optional()
  .describe("clean (par défaut) : navigateur vierge, sans compte. account : navigateur connecté aux comptes de l'utilisateur — l'app lui demande son accord.");

export function browserTools(browsers: Browsers, music: MusicPlayer, ws: Workspace) {
  const pageOf = (p?: Profile) => browsers.page(p ?? "clean");
  const fail = (e: any) => text("Erreur du navigateur : " + String(e?.message || e).split("\n")[0]);
  return [
    tool(
      "web_open",
      "Ouvre une adresse dans TON navigateur intégré (en arrière-plan) et renvoie le texte de la page et ses éléments cliquables numérotés. Utilise-le pour naviguer, remplir des formulaires, consulter des pages interactives.",
      { url: z.string(), profile: profileArg },
      async ({ url, profile }) => {
        try {
          const page = await pageOf(profile);
          await page.goto(/^https?:/i.test(url) ? url : "https://" + url, { waitUntil: "domcontentloaded", timeout: 30000 });
          return text(await snapshot(page));
        } catch (e) {
          return fail(e);
        }
      },
    ),
    tool("web_read", "Relit la page actuelle de ton navigateur (texte + éléments numérotés).", { profile: profileArg }, async ({ profile }) => {
      try {
        return text(await snapshot(await pageOf(profile)));
      } catch (e) {
        return fail(e);
      }
    }),
    tool(
      "web_click",
      "Clique sur un élément de la page (numéro donné par web_open / web_read).",
      { index: z.number(), profile: profileArg },
      async ({ index, profile }) => {
        try {
          const page = await pageOf(profile);
          await page.locator(`[data-jarvis-id="${index}"]`).first().click({ timeout: 8000 });
          await page.waitForTimeout(800);
          return text(await snapshot(page));
        } catch (e) {
          return fail(e);
        }
      },
    ),
    tool(
      "web_type",
      "Écrit dans un champ (numéro donné par web_open / web_read), et appuie sur Entrée si submit est vrai.",
      { index: z.number(), text: z.string(), submit: z.boolean().optional(), profile: profileArg },
      async ({ index, text: value, submit, profile }) => {
        try {
          const page = await pageOf(profile);
          const el = page.locator(`[data-jarvis-id="${index}"]`).first();
          await el.fill(value, { timeout: 8000 });
          if (submit) await el.press("Enter");
          await page.waitForTimeout(submit ? 1200 : 200);
          return text(await snapshot(page));
        } catch (e) {
          return fail(e);
        }
      },
    ),
    tool(
      "web_scroll",
      "Fait défiler la page (down / up) puis la relit.",
      { direction: z.enum(["down", "up"]), profile: profileArg },
      async ({ direction, profile }) => {
        try {
          const page = await pageOf(profile);
          await page.mouse.wheel(0, direction === "down" ? 900 : -900);
          await page.waitForTimeout(500);
          return text(await snapshot(page));
        } catch (e) {
          return fail(e);
        }
      },
    ),
    tool("web_back", "Revient à la page précédente.", { profile: profileArg }, async ({ profile }) => {
      try {
        const page = await pageOf(profile);
        await page.goBack({ waitUntil: "domcontentloaded" });
        return text(await snapshot(page));
      } catch (e) {
        return fail(e);
      }
    }),
    tool(
      "web_screenshot",
      "Montre à l'utilisateur ce que tu vois dans ton navigateur : capture affichée dans une fenêtre de son plan de travail.",
      { title: z.string().optional(), profile: profileArg },
      async ({ title, profile }) => {
        try {
          const page = await pageOf(profile);
          const png = await page.screenshot({ type: "jpeg", quality: 70 });
          ws.open({
            id: "capture-navigateur",
            title: title || "Navigateur · " + (await page.title()).slice(0, 60),
            kind: "image",
            mode: "window",
            size: "large",
            url: "data:image/jpeg;base64," + png.toString("base64"),
            createdAt: Date.now(),
          });
          return text("Capture affichée.");
        } catch (e) {
          return fail(e);
        }
      },
    ),
    tool(
      "music_play",
      "Lance de la musique sur YouTube Music, dans le navigateur de l'assistant connecté au compte de l'utilisateur (en arrière-plan, rien ne s'ouvre chez lui). Donne une recherche (« titre artiste », album, playlist…) ou une adresse music.youtube.com. L'overlay musique s'affiche tout seul.",
      { query: z.string().optional(), url: z.string().optional() },
      async ({ query, url }) => {
        try {
          const s = await music.play(query, url);
          return text(`Lecture : ${s.title}${s.artist ? " — " + s.artist : ""}.`);
        } catch (e) {
          return fail(e);
        }
      },
    ),
    tool(
      "music_control",
      "Contrôle la musique lancée par music_play : play, pause, toggle, next, previous, volume (value 0-100), volume_up, volume_down, seek (value en secondes), stop.",
      { action: z.enum(["play", "pause", "toggle", "next", "previous", "volume", "volume_up", "volume_down", "seek", "stop"]), value: z.number().optional() },
      async ({ action, value }) => {
        try {
          if (action === "stop") {
            await music.stop();
            return text("Musique arrêtée.");
          }
          const s = await music.control(action, value);
          return text(s ? `${s.playing ? "En lecture" : "En pause"} : ${s.title} — ${s.artist}` : "Fait.");
        } catch (e) {
          return fail(e);
        }
      },
    ),
    tool("music_status", "Dit ce qui est en train de jouer.", {}, async () => {
      const s = await music.read();
      return text(s ? `${s.playing ? "En lecture" : "En pause"} : ${s.title} — ${s.artist} (${Math.round(s.position)} s / ${Math.round(s.duration)} s)` : "Aucune musique.");
    }),
  ];
}

export const BROWSER_TOOL_NAMES = ["music_play", "music_control", "music_status"]; // autorisés d'office
export const ASKING_TOOL_NAMES = ["web_open", "web_read", "web_click", "web_type", "web_scroll", "web_back", "web_screenshot", "open_url"]; // passent par l'autorisation
