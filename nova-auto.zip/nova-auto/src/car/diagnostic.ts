// Diagnostic moteur guidé, à l'arrêt : ralenti, régime stable, coup de gaz.
// Nova mesure à chaque étape et compare à ce qu'on attend d'un 1.8T 225 en bonne santé.
import { promises as fs } from "node:fs";
import path from "node:path";
import type { SignalStore } from "./signals.js";
import type { Dtc } from "./sources/types.js";

const OK = "ok", WARN = "warn", BAD = "bad", NA = "na";
type Grade = typeof OK | typeof WARN | typeof BAD | typeof NA;

export interface DiagResult {
  name: string;
  hint: string;
  val: string;
  grade: Grade;
}

export interface DiagState {
  step: number; // -1 prêt, 0 préparation, 1 ralenti, 2 régime stable, 3 coup de gaz, 4 résultats
  hold: number; // 0 à 1 : progression de l'étape
  peak: number;
  zone: [number, number] | null;
  say: string;
  zoneTxt: string;
  checks: { name: string; ok: boolean | null; val: string }[];
  results: DiagResult[];
  summary: string;
  file: string;
}

const f = (x: number, d = 1) => x.toFixed(d).replace(".", ",");

export class Diagnostic {
  st: DiagState = this.fresh();
  private timer: NodeJS.Timeout | null = null;
  private acc: Record<string, number[]> = {};
  private snapT0 = 0;
  private snapPeakT = 0;
  private snapBackT = 0;
  private sub = 0;

  constructor(
    private store: SignalStore,
    private dir: string,
    private readDtc: () => Promise<Dtc[] | null>,
    private onChange: () => void,
    private onDone: (st: DiagState) => void,
    private hasInput: (name: "handbrake") => boolean | null,
  ) {}

  private fresh(): DiagState {
    return {
      step: -1, hold: 0, peak: 0, zone: null, zoneTxt: "", checks: [], results: [], summary: "", file: "",
      say: "Je vais vérifier ton moteur à l’arrêt. Mets-toi au point mort, frein à main serré, moteur chaud.",
    };
  }

  get running() {
    return this.st.step >= 0 && this.st.step < 4;
  }

  start() {
    this.cancel();
    this.st = { ...this.fresh(), step: 0, say: "Je vérifie que tout est prêt…" };
    this.acc = {};
    this.sub = 0;
    this.timer = setInterval(() => this.tick(), 100);
    this.onChange();
  }

  cancel() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.running) {
      this.st = this.fresh();
      this.onChange();
    }
  }

  private push(key: string, v: number | undefined) {
    if (v === undefined) return;
    (this.acc[key] ??= []).push(v);
  }

  private tick() {
    const s = this.st;
    const g = (k: string) => this.store.get(k);
    const rpm = g("rpm") ?? 0;
    this.sub++;
    if (s.step === 0) {
      const water = g("water");
      const hb = this.hasInput("handbrake");
      s.checks = [
        { name: water !== undefined ? `Moteur à ${Math.round(water)} °C` : "Température moteur", ok: water === undefined ? null : water >= 75, val: water === undefined ? "?" : water >= 75 ? "OK" : "froid" },
        { name: "Moteur tournant", ok: rpm > 500, val: rpm > 500 ? "OK" : "démarre-le" },
        { name: "À l’arrêt", ok: (g("speed") ?? 0) < 1, val: (g("speed") ?? 0) < 1 ? "OK" : "arrête-toi" },
        { name: "Frein à main serré", ok: hb, val: hb === null ? "je te fais confiance" : hb ? "OK" : "serre-le" },
      ];
      s.hold = Math.min(1, this.sub / 30);
      const blocking = s.checks.slice(1, 3).some((c) => !c.ok) || s.checks[0].ok === false;
      if (blocking) {
        s.say = s.checks[0].ok === false ? "Le moteur est encore froid. Laisse-le chauffer jusqu’à 75 °C au moins, je reprends tout seul." : "Démarre le moteur et reste à l’arrêt, je reprends tout seul.";
        this.sub = Math.min(this.sub, 10);
      } else s.say = "Je vérifie que tout est prêt…";
      if (this.sub > 30 && !blocking) this.next(1);
    } else if (s.step === 1) {
      s.say = "Laisse le moteur au ralenti, ne touche à rien.";
      s.zone = [650, 1000];
      s.zoneTxt = "Ralenti en cours";
      s.hold = Math.min(1, this.sub / 300); // 30 s
      if (this.sub > 30) {
        this.push("idleRpm", g("rpm"));
        this.push("idleMaf", g("maf"));
        this.push("idleTrim", (g("stft") ?? 0) + (g("ltft") ?? 0));
        if (g("stft") === undefined && g("ltft") === undefined && g("lambda") !== undefined) this.push("idleTrim", ((g("lambda") ?? 1) - 1) * 100);
        this.push("idleTiming", g("timing"));
        this.push("volt", g("volt"));
      }
      if (s.hold >= 1) this.next(2);
    } else if (s.step === 2) {
      s.say = "Monte doucement à 3 000 tr/min et tiens-les.";
      s.zone = [2800, 3200];
      const inZ = rpm >= 2800 && rpm <= 3200;
      s.zoneTxt = inZ ? "Parfait, tiens comme ça" : rpm < 2800 ? "Monte encore un peu" : "Un peu trop, redescends";
      if (inZ) {
        s.hold += 1 / 50; // 5 s dans la zone
        this.push("midMaf", g("maf"));
        this.push("midTrim", (g("stft") ?? 0) + (g("ltft") ?? 0));
        this.push("midRpm", rpm);
      }
      if (s.hold >= 1) {
        this.next(3);
        s.peak = 0;
        this.snapT0 = 0;
      }
    } else if (s.step === 3) {
      s.say = "Donne un coup d’accélérateur franc, puis relâche tout de suite.";
      s.zone = [4500, 6500];
      if (!this.snapT0 && rpm > 1300) this.snapT0 = Date.now();
      if (rpm > s.peak) {
        s.peak = rpm;
        this.snapPeakT = Date.now();
      }
      s.zoneTxt = s.peak > 4500 ? "Bien, relâche" : "Vas-y, un coup franc";
      if (s.peak > 4500 && rpm < 1100) {
        if (!this.snapBackT) this.snapBackT = Date.now();
        s.hold += 1 / 8;
      }
      this.push("snapKnock", g("knock"));
      if (s.hold >= 1) void this.finish();
    }
    this.onChange();
  }

  private next(step: number) {
    this.st.step = step;
    this.st.hold = 0;
    this.sub = 0;
    if (step === 3) this.snapBackT = 0;
  }

  private async finish() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    const s = this.st;
    s.step = 4;
    s.zone = null;
    const avg = (k: string) => {
      const a = this.acc[k] ?? [];
      return a.length ? a.reduce((x, y) => x + y, 0) / a.length : undefined;
    };
    const sd = (k: string) => {
      const a = this.acc[k] ?? [];
      const m = avg(k);
      if (m === undefined || a.length < 3) return undefined;
      return Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / a.length);
    };
    const R: DiagResult[] = [];
    const idle = avg("idleRpm"), idleSd = sd("idleRpm");
    if (idle !== undefined) {
      const grade: Grade = idle < 700 || idle > 1000 || (idleSd ?? 0) > 60 ? BAD : (idleSd ?? 0) > 25 ? WARN : OK;
      R.push({ name: "Ralenti", hint: `${grade === OK ? "Stable" : "Instable"}, écart ±${Math.round(idleSd ?? 0)} tr/min`, val: String(Math.round(idle)), grade });
    }
    const maf = avg("idleMaf");
    R.push(maf === undefined
      ? { name: "Débit d’air (ralenti)", hint: "Non lu par ce câble", val: "—", grade: NA }
      : { name: "Débit d’air (ralenti)", hint: maf < 2.5 ? "Faible : débitmètre fatigué ou prise d’air après lui" : maf > 5 ? "Élevé pour un ralenti" : "Dans la plage normale", val: `${f(maf)} g/s`, grade: maf < 2.5 || maf > 5 ? WARN : OK });
    const it = avg("idleTrim"), mt = avg("midTrim");
    if (it !== undefined) {
      let hint = "Dans la norme";
      let grade: Grade = OK;
      if (Math.abs(it) > 10) {
        grade = BAD;
        hint = it > 0 ? "Très pauvre : prise d’air, débitmètre ou carburant" : "Très riche : injecteur, pression d’essence";
      } else if (Math.abs(it) > 5) {
        grade = WARN;
        hint = it > 0 && mt !== undefined && mt < it - 3 ? "Élevée au ralenti seulement : possible prise d’air (durites de dépression)" : it > 0 ? "Un peu pauvre" : "Un peu riche";
      }
      R.push({ name: "Correction de richesse", hint, val: `${it >= 0 ? "+" : ""}${f(it)} %`, grade });
    }
    const kn = this.acc.snapKnock?.length ? Math.max(...this.acc.snapKnock) : undefined;
    R.push(kn === undefined
      ? { name: "Recul d’allumage", hint: "Mesuré avec le câble KKL seulement", val: "—", grade: NA }
      : { name: "Recul d’allumage", hint: kn > 2 ? "Cliquetis détecté" : "Aucun cliquetis détecté", val: `${f(kn)}°`, grade: kn > 2 ? WARN : OK });
    if (this.snapBackT && this.snapPeakT) {
      const back = (this.snapBackT - this.snapPeakT) / 1000;
      R.push({ name: "Réponse au coup de gaz", hint: back > 2.5 ? "Retour au ralenti lent (papillon encrassé, prise d’air)" : "Montée et retour au ralenti normaux", val: `${f(back)} s`, grade: back > 2.5 ? WARN : OK });
    }
    let dtcs: Dtc[] | null = null;
    try {
      dtcs = await this.readDtc();
    } catch {
      dtcs = null;
    }
    R.push(dtcs === null
      ? { name: "Codes défaut", hint: "Lecture impossible avec cette source", val: "—", grade: NA }
      : { name: "Codes défaut", hint: dtcs.length ? dtcs.map((d) => `${d.code} ${d.text}`).join(" · ") : "Calculateur moteur", val: dtcs.length ? String(dtcs.length) : "Aucun", grade: dtcs.length ? WARN : OK });
    const v = avg("volt");
    if (v !== undefined) R.push({ name: "Charge batterie", hint: "Alternateur", val: `${f(v)} V`, grade: v < 13.3 || v > 15 ? WARN : OK });
    s.results = R;

    const warns = R.filter((r) => r.grade === WARN || r.grade === BAD);
    const low = (t: string) => t.charAt(0).toLowerCase() + t.slice(1);
    s.summary = warns.length === 0
      ? "Diagnostic terminé. Le moteur est en bonne santé, rien à signaler."
      : `Diagnostic terminé. ${warns.length === 1 ? "Une chose à surveiller" : ["", "", "Deux", "Trois", "Quatre", "Cinq"][warns.length] + " choses à surveiller"}. ` +
        warns.map((w) => `${w.name}\u00a0: ${low(w.hint)}.`).join(" ");
    s.say = s.summary;
    // sauvegarde
    try {
      await fs.mkdir(this.dir, { recursive: true });
      const name = `diagnostic_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.json`;
      await fs.writeFile(path.join(this.dir, name), JSON.stringify({ date: new Date().toISOString(), resultats: R, resume: s.summary, mesures: Object.fromEntries(Object.entries(this.acc).map(([k, a]) => [k, a.length])) }, null, 2));
      s.file = name;
    } catch {
      /* pas grave */
    }
    this.onChange();
    this.onDone(s);
  }
}
