// Le PC lui-même : batterie, Wi-Fi (NetworkManager), Bluetooth (BlueZ), téléphone (KDE Connect),
// résolution de l'écran (xrandr). Sur Nova OS tout est piloté depuis l'écran de Nova, sans bureau.
// Sous Windows, seule la batterie est lue.
import { spawn, execFile } from "node:child_process";
import { promises as fs } from "node:fs";
import path from "node:path";
import os from "node:os";

const LINUX = process.platform === "linux";

const run = (cmd: string, args: string[], timeout = 4000) =>
  new Promise<{ ok: boolean; out: string; err: string }>((resolve) => {
    execFile(cmd, args, { timeout, maxBuffer: 4 << 20, env: { ...process.env, LC_ALL: "C" } }, (e, out, err) =>
      resolve({ ok: !e, out: String(out ?? ""), err: String(err ?? (e as any)?.message ?? "") }),
    );
  });

/** Découpe une ligne « nmcli -t » (les « : » des valeurs sont échappés en « \: »). */
function nmFields(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === "\\" && i + 1 < line.length) {
      cur += line[++i];
    } else if (c === ":") {
      out.push(cur);
      cur = "";
    } else cur += c;
  }
  out.push(cur);
  return out;
}

export interface WifiNet {
  ssid: string;
  signal: number;
  secure: boolean;
  inUse: boolean;
  known: boolean;
}
export interface BtDevice {
  mac: string;
  name: string;
  paired: boolean;
  connected: boolean;
  phone: boolean;
}
export interface KdeDevice {
  id: string;
  name: string;
  paired: boolean;
  reachable: boolean;
}

export interface SysState {
  platform: string;
  battery: { present: boolean; pct: number | null; charging: boolean; minutes: number | null };
  wifi: { device: string; radio: boolean; ssid: string; signal: number | null; state: string; hardware: boolean };
  ethernet: boolean;
  online: boolean;
  networks: WifiNet[];
  scanning: boolean;
  connecting: string;
  bt: { present: boolean; powered: boolean; visible: boolean; scanning: boolean; pairing: string; devices: BtDevice[] };
  kde: { available: boolean; devices: KdeDevice[] };
  display: { output: string; current: string; modes: string[]; saved: string };
  tools: Record<string, boolean>;
  gpuMode: string;
}

export class SystemInfo {
  st: SysState = {
    platform: process.platform,
    battery: { present: false, pct: null, charging: false, minutes: null },
    wifi: { device: "", radio: false, ssid: "", signal: null, state: "", hardware: false },
    ethernet: false,
    online: false,
    networks: [],
    scanning: false,
    connecting: "",
    bt: { present: false, powered: false, visible: false, scanning: false, pairing: "", devices: [] },
    kde: { available: false, devices: [] },
    display: { output: "", current: "", modes: [], saved: "" },
    tools: {},
    gpuMode: "auto",
  };
  private timers: NodeJS.Timeout[] = [];
  private agent: ReturnType<typeof spawn> | null = null;

  constructor(
    private dataDir: string,
    private log: (t: string) => void,
    private onChange: () => void,
  ) {}

  async start() {
    if (LINUX) {
      for (const t of ["nmcli", "bluetoothctl", "kdeconnect-cli", "xrandr", "scrcpy", "adb", "playerctl", "lspci"]) {
        this.st.tools[t] = (await run("sh", ["-c", "command -v " + t])).ok;
      }
    }
    await this.pollBattery();
    await this.pollNet();
    await this.pollBt();
    await this.pollKde();
    await this.pollDisplay();
    this.onChange();
    this.timers.push(setInterval(() => void this.pollBattery().then(() => this.onChange()), LINUX ? 15000 : 60000));
    if (LINUX) {
      this.timers.push(setInterval(() => void this.pollNet().then(() => this.onChange()), 5000));
      this.timers.push(setInterval(() => void this.pollBt().then(() => this.onChange()), 6000));
      this.timers.push(setInterval(() => void this.pollKde().then(() => this.onChange()), 10000));
    }
  }

  stop() {
    for (const t of this.timers) clearInterval(t);
    this.agent?.kill();
  }

  // ---------- batterie du PC ----------
  async pollBattery() {
    const b = this.st.battery;
    if (LINUX) {
      const base = "/sys/class/power_supply";
      const names = await fs.readdir(base).catch(() => [] as string[]);
      let found = false;
      for (const n of names) {
        const read = (f: string) => fs.readFile(path.join(base, n, f), "utf8").then((x) => x.trim()).catch(() => "");
        if ((await read("type")) !== "Battery") continue;
        if ((await read("scope")) === "Device") continue; // souris, manette…
        const cap = Number(await read("capacity"));
        const status = await read("status");
        found = true;
        b.present = true;
        b.pct = Number.isFinite(cap) ? cap : null;
        b.charging = status === "Charging" || status === "Full" || status === "Not charging";
        // autonomie estimée
        const now = Number((await read("energy_now")) || (await read("charge_now")));
        const rate = Number((await read("power_now")) || (await read("current_now")));
        b.minutes = !b.charging && now > 0 && rate > 0 ? Math.round((now / rate) * 60) : null;
        break;
      }
      if (!found) b.present = false;
    } else if (process.platform === "win32") {
      const r = await run("powershell", ["-NoProfile", "-Command", "$b=Get-CimInstance Win32_Battery; if($b){\"$($b.EstimatedChargeRemaining)|$($b.BatteryStatus)|$($b.EstimatedRunTime)\"}"], 8000);
      const [pct, status, run_] = r.out.trim().split("|");
      if (pct) {
        b.present = true;
        b.pct = Number(pct);
        b.charging = status !== "1"; // 1 = sur batterie
        const m = Number(run_);
        b.minutes = !b.charging && m > 0 && m < 10000 ? m : null;
      } else b.present = false;
    }
  }

  // ---------- réseau (NetworkManager) ----------
  async pollNet() {
    if (!this.st.tools.nmcli) {
      // sans NetworkManager : on regarde juste si une interface a une adresse
      const ifs = os.networkInterfaces();
      this.st.online = Object.entries(ifs).some(([n, a]) => n !== "lo" && a?.some((x) => !x.internal && x.family === "IPv4"));
      return;
    }
    const dev = await run("nmcli", ["-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"]);
    const w = this.st.wifi;
    w.hardware = false;
    this.st.ethernet = false;
    for (const line of dev.out.split("\n").filter(Boolean)) {
      const [name, type, state, conn] = nmFields(line);
      if (type === "wifi") {
        w.hardware = true;
        w.device = name;
        w.state = state;
        w.ssid = state.startsWith("connected") ? conn : "";
      } else if (type === "ethernet" && state.startsWith("connected")) this.st.ethernet = true;
    }
    w.radio = (await run("nmcli", ["radio", "wifi"])).out.trim() === "enabled";
    if (w.ssid) {
      const l = await run("nmcli", ["-t", "-f", "IN-USE,SIGNAL", "device", "wifi", "list", "--rescan", "no"]);
      const cur = l.out.split("\n").map(nmFields).find((f) => f[0] === "*");
      w.signal = cur ? Number(cur[1]) : null;
    } else w.signal = null;
    const c = (await run("nmcli", ["networking", "connectivity"])).out.trim();
    this.st.online = c === "full" || c === "limited" || c === "portal";
  }

  async wifiScan() {
    if (!this.st.tools.nmcli) throw new Error("NetworkManager absent : le Wi-Fi ne se règle pas depuis Nova sur cet appareil.");
    this.st.scanning = true;
    this.onChange();
    try {
      if (!this.st.wifi.radio) await run("nmcli", ["radio", "wifi", "on"]);
      const known = new Set((await run("nmcli", ["-t", "-f", "NAME,TYPE", "connection", "show"])).out.split("\n").map(nmFields).filter((f) => f[1]?.includes("wireless")).map((f) => f[0]));
      const r = await run("nmcli", ["-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list", "--rescan", "yes"], 20000);
      const best = new Map<string, WifiNet>();
      for (const f of r.out.split("\n").filter(Boolean).map(nmFields)) {
        const [use, ssid, sig, sec] = f;
        if (!ssid) continue;
        const n: WifiNet = { ssid, signal: Number(sig) || 0, secure: !!sec && sec !== "--", inUse: use === "*", known: known.has(ssid) };
        const prev = best.get(ssid);
        if (!prev || n.signal > prev.signal || n.inUse) best.set(ssid, { ...n, inUse: n.inUse || !!prev?.inUse });
      }
      this.st.networks = [...best.values()].sort((a, b) => Number(b.inUse) - Number(a.inUse) || b.signal - a.signal).slice(0, 14);
      await this.pollNet();
    } finally {
      this.st.scanning = false;
      this.onChange();
    }
  }

  async wifiConnect(ssid: string, password: string) {
    this.st.connecting = ssid;
    this.onChange();
    try {
      // réseau déjà connu : on le relance ; sinon on le crée avec le mot de passe
      const known = (await run("nmcli", ["-t", "-f", "NAME", "connection", "show"])).out.split("\n").map((l) => nmFields(l)[0]);
      let r;
      if (known.includes(ssid) && !password) r = await run("nmcli", ["connection", "up", "id", ssid], 45000);
      else {
        if (known.includes(ssid)) await run("nmcli", ["connection", "delete", "id", ssid]);
        const args = ["device", "wifi", "connect", ssid];
        if (password) args.push("password", password);
        r = await run("nmcli", args, 45000);
      }
      if (!r.ok) {
        const why = (r.err || r.out).trim().split("\n").pop() || "";
        this.log("Wi-Fi « " + ssid + " » : " + why);
        if (/secrets|password|802-11-wireless-security/i.test(why)) throw new Error("Mot de passe refusé par « " + ssid + " ».");
        throw new Error("Connexion à « " + ssid + " » impossible : " + why);
      }
      this.log("Wi-Fi connecté à " + ssid);
      await this.pollNet();
      return "Connecté à " + ssid;
    } finally {
      this.st.connecting = "";
      this.onChange();
    }
  }

  async wifiForget(ssid: string) {
    await run("nmcli", ["connection", "delete", "id", ssid]);
    await this.wifiScan();
  }

  async wifiRadio(on: boolean) {
    await run("nmcli", ["radio", "wifi", on ? "on" : "off"]);
    await this.pollNet();
    this.onChange();
  }

  // ---------- Bluetooth (BlueZ) ----------
  async pollBt() {
    const bt = this.st.bt;
    if (!this.st.tools.bluetoothctl) return;
    const show = await run("bluetoothctl", ["show"], 3000);
    bt.present = show.ok && /Controller/.test(show.out);
    bt.powered = /Powered: yes/.test(show.out);
    bt.visible = /Discoverable: yes/.test(show.out);
    if (!bt.present) {
      bt.devices = [];
      return;
    }
    const list = await run("bluetoothctl", ["devices"], 3000);
    const devs: BtDevice[] = [];
    for (const m of list.out.matchAll(/^Device ([0-9A-F:]{17}) (.+)$/gim)) {
      const info = (await run("bluetoothctl", ["info", m[1]], 3000)).out;
      const paired = /Paired: yes/.test(info);
      const connected = /Connected: yes/.test(info);
      const icon = /Icon: (\S+)/.exec(info)?.[1] || "";
      // pendant une recherche on montre tout ; sinon seulement les appareils associés
      if (!paired && !bt.scanning) continue;
      if (!paired && /^([0-9A-F]{2}-){5}[0-9A-F]{2}$/i.test(m[2].trim())) continue; // appareils sans nom
      devs.push({ mac: m[1], name: m[2].trim(), paired, connected, phone: icon.startsWith("phone") });
    }
    bt.devices = devs.sort((a, b) => Number(b.connected) - Number(a.connected) || Number(b.paired) - Number(a.paired) || Number(b.phone) - Number(a.phone)).slice(0, 12);
  }

  async btPower(on: boolean) {
    await run("rfkill", ["unblock", "bluetooth"]);
    await run("bluetoothctl", ["power", on ? "on" : "off"], 5000);
    await this.pollBt();
    this.onChange();
  }

  /** Cherche les appareils autour pendant 20 s et rend Nova visible : le téléphone peut aussi l'ajouter de son côté. */
  async btScan() {
    const bt = this.st.bt;
    if (!bt.present) throw new Error("Pas d'adaptateur Bluetooth détecté sur ce PC.");
    if (!bt.powered) await this.btPower(true);
    bt.scanning = true;
    this.onChange();
    this.startAgent(90);
    const scan = run("bluetoothctl", ["--timeout", "20", "scan", "on"], 25000);
    const tick = setInterval(() => void this.pollBt().then(() => this.onChange()), 2500);
    await scan;
    clearInterval(tick);
    bt.scanning = false;
    await this.pollBt();
    this.onChange();
  }

  /**
   * Agent d'association : répond « oui » tout seul aux demandes (code affiché sur le téléphone),
   * rend Nova visible et accepte les connexions du téléphone. S'arrête au bout de `seconds`.
   */
  private startAgent(seconds: number) {
    this.agent?.kill();
    const p = spawn("bluetoothctl", [], { stdio: ["pipe", "pipe", "pipe"] });
    this.agent = p;
    const w = (s: string) => p.stdin?.write(s + "\n");
    p.on("error", () => {});
    let buf = "";
    p.stdout?.on("data", (d: Buffer) => {
      buf += d.toString();
      const lines = buf.split(/\r?\n/);
      buf = lines.pop() || "";
      for (const raw of lines.concat(buf)) {
        // eslint-disable-next-line no-control-regex
        const l = raw.replace(/\x1b\[[0-9;]*m/g, "");
        if (/Confirm passkey|Request confirmation|Authorize service|Accept pairing|\(yes\/no\)/i.test(l)) {
          w("yes");
          buf = "";
        }
        const paired = /Device ([0-9A-F:]{17}) (?:Paired|Bonded): yes/i.exec(l);
        if (paired) {
          w("trust " + paired[1]);
          this.log("Bluetooth : " + paired[1] + " associé");
          void this.pollBt().then(() => this.onChange());
        }
      }
    });
    w("power on");
    w("agent NoInputNoOutput");
    w("default-agent");
    w("pairable on");
    w("discoverable-timeout " + seconds);
    w("discoverable on");
    const t = setTimeout(() => {
      w("discoverable off");
      w("quit");
      setTimeout(() => p.kill(), 1500);
    }, seconds * 1000);
    p.on("exit", () => {
      clearTimeout(t);
      if (this.agent === p) this.agent = null;
    });
    return { write: w, proc: p };
  }

  async btPair(mac: string) {
    const bt = this.st.bt;
    bt.pairing = mac;
    this.onChange();
    try {
      const a = this.startAgent(60);
      a.write("pair " + mac);
      // on attend « Paired: yes » (le téléphone demande de confirmer le code)
      for (let i = 0; i < 40; i++) {
        await new Promise((r) => setTimeout(r, 1000));
        const info = (await run("bluetoothctl", ["info", mac], 3000)).out;
        if (/Paired: yes/.test(info)) {
          await run("bluetoothctl", ["trust", mac], 4000);
          await run("bluetoothctl", ["connect", mac], 15000);
          await this.pollBt();
          return "Téléphone associé. Accepte aussi le partage des contacts et des notifications sur le téléphone si on te le demande.";
        }
      }
      throw new Error("Association non confirmée : accepte la demande sur le téléphone, puis réessaie.");
    } finally {
      bt.pairing = "";
      this.onChange();
    }
  }

  async btConnect(mac: string, on: boolean) {
    const r = await run("bluetoothctl", [on ? "connect" : "disconnect", mac], 15000);
    await this.pollBt();
    this.onChange();
    if (on && !/successful/i.test(r.out)) throw new Error("Le téléphone ne répond pas : vérifie que son Bluetooth est allumé.");
    return on ? "Connecté" : "Déconnecté";
  }

  async btRemove(mac: string) {
    await run("bluetoothctl", ["remove", mac], 5000);
    await this.pollBt();
    this.onChange();
  }

  // ---------- KDE Connect (notifications, batterie du téléphone) ----------
  async pollKde() {
    const k = this.st.kde;
    k.available = !!this.st.tools["kdeconnect-cli"];
    if (!k.available) return;
    const r = await run("kdeconnect-cli", ["-l"], 4000);
    const devs: KdeDevice[] = [];
    for (const m of r.out.matchAll(/^- (.+): (\S+) \((.+)\)$/gm)) {
      devs.push({ name: m[1], id: m[2], paired: /paired/.test(m[3]) && !/unpaired|not paired/.test(m[3]), reachable: /reachable/.test(m[3]) && !/unreachable|not reachable/.test(m[3]) });
    }
    k.devices = devs.filter((d) => d.paired || d.reachable);
  }

  async kdeRefresh() {
    await run("kdeconnect-cli", ["--refresh"], 5000);
    await new Promise((r) => setTimeout(r, 2500));
    await this.pollKde();
    this.onChange();
  }

  async kdePair(id: string) {
    const r = await run("kdeconnect-cli", ["-d", id, "--pair"], 8000);
    if (!r.ok) throw new Error("Demande refusée : " + (r.err || r.out).trim());
    return "Demande envoyée : accepte-la dans l'application KDE Connect du téléphone.";
  }

  // ---------- écran (xrandr) ----------
  /** Accélération graphique de l'écran de Nova (lu par la session Nova OS au lancement de l'écran). */
  async setGpu(mode: string) {
    const m = ["auto", "force", "off"].includes(mode) ? mode : "auto";
    await fs.writeFile(path.join(this.dataDir, "ecran-gpu.conf"), m + "\n");
    this.st.gpuMode = m;
    // « désactivée » coupe aussi l'accélération de l'affichage (Xorg) : utile si l'écran plante (écran noir)
    if (LINUX) {
      const conf = "/etc/X11/xorg.conf.d/20-nova-sans-acceleration.conf";
      const body = 'Section "Device"\n  Identifier "nova"\n  Driver "modesetting"\n  Option "AccelMethod" "none"\nEndSection\n';
      const r = m === "off"
        ? await run("sudo", ["-n", "sh", "-c", `mkdir -p /etc/X11/xorg.conf.d && printf '%s' '${body}' > ${conf}`])
        : await run("sudo", ["-n", "rm", "-f", conf]);
      this.log(`Accélération graphique : ${m}${r.ok ? "" : " (réglage de l'affichage impossible : " + r.err.trim() + ")"}${m === "off" ? " — effet complet au prochain démarrage" : ""}`);
    }
    this.onChange();
  }

  async pollDisplay() {
    this.st.gpuMode = (await fs.readFile(path.join(this.dataDir, "ecran-gpu.conf"), "utf8").catch(() => "auto")).trim() || "auto";
    const d = this.st.display;
    d.saved = (await fs.readFile(path.join(this.dataDir, "ecran.conf"), "utf8").catch(() => "")).trim();
    if (!LINUX || !this.st.tools.xrandr || !process.env.DISPLAY) return;
    const r = await run("xrandr", ["--query"], 4000);
    let cur: string | null = null;
    const modes: Record<string, string[]> = {};
    for (const line of r.out.split("\n")) {
      const o = /^(\S+) connected(?: primary)?(?: (\d+x\d+)\+)?/.exec(line);
      if (o) {
        cur = o[1];
        modes[cur] = [];
        if (!d.output || line.includes("primary")) {
          d.output = cur;
          d.current = o[2] || "";
        }
        continue;
      }
      if (/^\S/.test(line)) {
        cur = null;
        continue;
      }
      const m = /^\s+(\d+x\d+)\S*\s/.exec(line);
      if (cur && m && !modes[cur].includes(m[1])) modes[cur].push(m[1]);
    }
    d.modes = modes[d.output] || [];
  }

  async displaySet(mode: string) {
    const d = this.st.display;
    if (!d.output) throw new Error("Résolution réglable seulement sur Nova OS.");
    const conf = path.join(this.dataDir, "ecran.conf");
    if (mode === "auto") {
      await run("xrandr", ["--output", d.output, "--auto"], 6000);
      await fs.rm(conf, { force: true });
    } else {
      if (!/^\d+x\d+$/.test(mode)) throw new Error("Résolution invalide");
      const r = await run("xrandr", ["--output", d.output, "--mode", mode], 6000);
      if (!r.ok) throw new Error("L'écran refuse " + mode + " : " + r.err.trim());
      await fs.writeFile(conf, `${d.output} ${mode}\n`);
    }
    // la fenêtre de Nova suit la nouvelle taille
    await run("sh", ["-c", "command -v xdotool >/dev/null && xdotool search --class chromium windowsize %@ $(xrandr | awk '/\\*/{print $1; exit}' | tr x ' ')"], 4000);
    await this.pollDisplay();
    this.onChange();
    return "Écran en " + (mode === "auto" ? d.current : mode);
  }

  // ---------- rapport matériel (pour comprendre une carte réseau non reconnue) ----------
  async report() {
    const parts: string[] = [`Nova : rapport matériel du ${new Date().toLocaleString("fr-FR")}`, ""];
    const add = async (title: string, cmd: string) => {
      const r = await run("sh", ["-c", cmd], 8000);
      parts.push("### " + title, (r.out || r.err || "(rien)").trim(), "");
    };
    if (LINUX) {
      await add("Cartes réseau (PCI)", "lspci -nnk | grep -A3 -Ei 'network|ethernet|wireless|wi-fi'");
      await add("Appareils USB", "lsusb");
      await add("Interfaces", "ip -br link");
      await add("NetworkManager", "nmcli device");
      await add("Blocages radio", "rfkill list");
      await add("Bluetooth", "bluetoothctl show");
      await add("Noyau : microprogrammes manquants", "journalctl -k -b --no-pager 2>/dev/null | grep -Ei 'firmware|iwlwifi|rtw|ath|brcm|mt7' | tail -40");
      await add("Carte graphique", "lspci -nnk | grep -A3 -Ei 'vga|3d|display'");
      await add("Rendu graphique", "glxinfo -B 2>/dev/null | head -20 || echo 'glxinfo absent'");
      await add("Écran", "xrandr --query | head -30");
    }
    const file = path.join(this.dataDir, "materiel.txt");
    await fs.writeFile(file, parts.join("\n"));
    return { file, text: parts.join("\n") };
  }
}
