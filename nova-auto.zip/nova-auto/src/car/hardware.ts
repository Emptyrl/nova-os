// Matériel de la NovaHAT : relais (contact, démarreur), entrées (contact, phares, marche arrière,
// frein à main), tension batterie (ADS1115), logo LED (WS2812) et écran FIS du combiné (3 fils).
// Sur le Raspberry Pi, un petit programme Python (scripts/novahat.py) pilote les broches.
// Sans la carte (PC), rien n'est piloté : Nova le dit au lieu de faire semblant.
import { spawn, type ChildProcess } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import type { CarFiles } from "./config.js";

export type Output = "ignition" | "starter" | "aux";
export type Input = "ignition" | "lights" | "reverse" | "handbrake";

export interface LedState {
  effect: "off" | "solid" | "breathe" | "pulse" | "scan" | "speak" | "rainbow";
  color: string; // #rrggbb
  brightness: number; // 0 à 1
}

export class Hardware {
  mode: "pi" | "absent" = "absent";
  outputs: Record<Output, boolean> = { ignition: false, starter: false, aux: false };
  inputs: Partial<Record<Input, boolean>> = {};
  batteryV: number | null = null;
  led: LedState = { effect: "breathe", color: "#F1F3F5", brightness: 0.6 };
  fis = { l1: "", l2: "", until: 0 };
  private helper: ChildProcess | null = null;
  private partial = "";
  onOutput: (o: Output, on: boolean) => void = () => {};
  onInput: (i: Input, on: boolean) => void = () => {};

  constructor(
    private files: CarFiles,
    private appRoot: string,
    private log: (t: string) => void,
    private onChange: () => void,
  ) {}

  static isPi() {
    try {
      return /raspberry pi/i.test(readFileSync("/proc/device-tree/model", "utf8"));
    } catch {
      return false;
    }
  }

  start() {
    const c = this.files.config;
    this.mode = c.hardware === "pi" || (c.hardware === "auto" && Hardware.isPi()) ? "pi" : "absent";
    if (this.mode === "absent") {
      this.log("Matériel : pas de NovaHAT sur cet appareil (relais, logo LED et combiné indisponibles)");
      return;
    }
    const script = path.join(this.appRoot, "scripts", "novahat.py");
    if (!existsSync(script)) {
      this.log("Matériel : scripts/novahat.py introuvable");
      this.mode = "absent";
      return;
    }
    const child = spawn("python3", [script], { stdio: ["pipe", "pipe", "pipe"] });
    this.helper = child;
    child.stdout!.on("data", (b: Buffer) => this.onText(b.toString()));
    child.stderr!.on("data", (b: Buffer) => this.log("NovaHAT : " + b.toString().trim().slice(0, 300)));
    child.on("exit", (code) => {
      this.log(`NovaHAT : le programme s'est arrêté (code ${code}), relance dans 3 s`);
      this.helper = null;
      setTimeout(() => this.mode === "pi" && this.start(), 3000);
    });
    this.send({
      cmd: "init",
      outputs: { ignition: c.outIgnition, starter: c.outStarter, aux: c.outAux },
      inputs: { ignition: c.inIgnition, lights: c.inLights, reverse: c.inReverse, handbrake: c.inHandbrake },
      led: { pin: c.ledPin, count: c.ledCount },
      fis: { ena: c.fisEna, clk: c.fisClk, data: c.fisData, invert: c.fisInvert },
      adc: { channel: c.adcChannel, ratio: c.adcRatio },
    });
    this.setLed(this.led);
  }

  private send(m: Record<string, unknown>) {
    if (this.helper?.stdin?.writable) this.helper.stdin.write(JSON.stringify(m) + "\n");
  }

  private onText(t: string) {
    this.partial += t;
    const lines = this.partial.split("\n");
    this.partial = lines.pop() ?? "";
    for (const l of lines) {
      let m: any;
      try {
        m = JSON.parse(l);
      } catch {
        continue;
      }
      if (m.ev === "in") {
        const name = m.name as Input;
        const v = !!m.v;
        if (this.inputs[name] !== v) {
          this.inputs[name] = v;
          this.onInput(name, v);
          this.onChange();
        }
      } else if (m.ev === "adc") {
        this.batteryV = Number(m.volt);
      } else if (m.ev === "ready") {
        this.log("NovaHAT prête : " + JSON.stringify(m.features));
      } else if (m.ev === "err") {
        this.log("NovaHAT : " + m.msg);
      }
    }
  }

  setOutput(o: Output, on: boolean) {
    if (this.mode !== "pi") return;
    if (this.outputs[o] === on) return;
    this.outputs[o] = on;
    this.log(`Relais ${o === "ignition" ? "contact (15)" : o === "starter" ? "démarreur (50)" : "auxiliaire"} : ${on ? "COLLÉ" : "relâché"}`);
    this.send({ cmd: "out", name: o, on });
    this.onOutput(o, on);
    this.onChange();
  }

  setLed(l: Partial<LedState>) {
    this.led = { ...this.led, ...l };
    const hex = this.led.color.replace("#", "");
    const rgb = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16) || 0);
    this.send({ cmd: "led", effect: this.led.effect, rgb, brightness: this.led.brightness });
    this.onChange();
  }

  /** Niveau sonore de la voix de Nova (fait vibrer le logo LED quand elle parle). */
  ledLevel(level: number) {
    if (this.led.effect === "speak") this.send({ cmd: "level", v: Math.round(level * 100) / 100 });
  }

  /** Deux lignes de 8 caractères sur l'écran central du combiné (mode radio). */
  setFis(l1: string, l2: string, seconds = 0) {
    const clean = (s: string) =>
      s.normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/[^A-Z0-9 .:\-+/%°]/g, " ").slice(0, 8).padEnd(8, " ");
    this.fis = { l1: clean(l1), l2: clean(l2), until: seconds ? Date.now() + seconds * 1000 : 0 };
    this.send({ cmd: "fis", l1: this.fis.l1, l2: this.fis.l2 });
    this.onChange();
  }

  stop() {
    this.helper?.kill();
    this.helper = null;
  }
}
