// Outils de Nova pour la voiture : elle lit les mesures, enregistre et analyse les logs,
// lance le diagnostic, pilote le logo LED, l'écran du combiné, les relais du démarrage à distance.
import { tool } from "@anthropic-ai/claude-agent-sdk";
import { z } from "zod";
import type { Car } from "./index.js";
import { MODES } from "./config.js";
import { SIGNALS } from "./signals.js";
import { decodeFault } from "./vag/modules.js";

const text = (t: string) => ({ content: [{ type: "text" as const, text: t }] });
const json = (o: unknown) => text(JSON.stringify(o, null, 1));

export const SCREENS = ["veille", "tableau", "media", "diagnostic", "calculateurs", "rapports", "apprentissage"] as const;

export function carTools(car: Car, deps: { screen: (s: string) => void; confirm: (title: string, summary: string) => Promise<boolean> }) {
  return [
    tool("car_status", "Toutes les mesures actuelles de la voiture (régime, vitesse, températures, turbo, richesse, batterie, carburant, alertes, source des données, relais).", {}, async () => {
      const v: Record<string, unknown> = {};
      for (const s of SIGNALS) {
        const x = car.store.get(s.key);
        if (x !== undefined) v[`${s.label}${s.unit ? " (" + s.unit + ")" : ""}`] = +x.toFixed(s.dec);
      }
      return json({
        resume: car.describe(),
        mesures: v,
        alertes: car.alerts.all().map((a) => ({ niveau: a.level, titre: a.title, valeur: a.value, limite: a.limit })),
        sources: car.sourceStatus(),
      });
    }),
    tool(
      "car_history",
      "Statistiques d'une mesure sur les dernières minutes (mini, maxi, moyenne). Mesures : " + SIGNALS.map((s) => s.key).join(", "),
      { signal: z.string(), minutes: z.number().min(0.1).max(5).optional() },
      async ({ signal, minutes }) => {
        const st = car.store.stats(signal, Math.round((minutes ?? 3) * 60));
        return st ? json(st) : text("Pas de valeurs pour " + signal + " (non lue par la source actuelle ?).");
      },
    ),
    tool("show_screen", "Affiche un écran de Nova sur l'écran de la voiture : " + SCREENS.join(", ") + ".", { screen: z.enum(SCREENS) }, async ({ screen }) => {
      deps.screen(screen);
      return text("Écran affiché : " + screen);
    }),
    tool("set_drive_mode", "Change le mode de conduite (Normal, Sport, Attack) : shift light, conseils de passage, couleur du logo.", { mode: z.enum(["Normal", "Sport", "Attack"]) }, async ({ mode }) => {
      car.setMode(MODES.findIndex((m) => m.name === mode));
      return text("Mode " + mode + ".");
    }),
    tool("log_start", "Démarre l'enregistrement d'un log CSV des mesures (10 Hz par défaut, jusqu'à 50).", { hz: z.number().min(1).max(50).optional(), reason: z.string().optional() }, async ({ hz, reason }) => {
      const f = await car.logger.start(reason || "demande", hz ?? car.files.config.logHz);
      return text("Log en cours : " + f);
    }),
    tool("log_stop", "Arrête l'enregistrement du log en cours.", {}, async () => {
      const f = await car.logger.stop();
      return text(f ? "Log arrêté : " + f : "Aucun log en cours.");
    }),
    tool("log_list", "Liste les logs enregistrés (les plus récents d'abord).", {}, async () => json(await car.logger.list())),
    tool(
      "log_analyze",
      "Analyse un log : durée, mini/maxi/moyenne de chaque mesure, cliquetis, mélange pauvre en charge, km. Le chemin complet des logs est dans le dossier logs de Nova (tu peux aussi le lire avec Read pour une analyse fine).",
      { file: z.string().describe("nom du fichier, ex. log_2026-10-25_143200.csv") },
      async ({ file }) => {
        try {
          return json(await car.logger.analyze(file));
        } catch (e: any) {
          return text("Impossible de lire ce log : " + (e?.message || e));
        }
      },
    ),
    tool("read_dtc", "Lit les codes défaut du calculateur moteur.", {}, async () => {
      const s = car.sources.find((x) => x.readDtc && x.status.state === "ok");
      if (!s?.readDtc) return text("La source actuelle ne lit pas les codes défaut (il faut l'ELM327).");
      const l = await s.readDtc();
      car.alerts.dtcs = l;
      return l.length ? json(l) : text("Aucun code défaut.");
    }),
    tool("clear_dtc", "Efface les codes défaut du calculateur moteur (demande l'accord de Joan).", {}, async () => {
      if (!(await deps.confirm("Effacer les codes défaut ?", "Nova veut effacer les codes défaut du calculateur moteur. Note-les avant si besoin."))) return text("Joan a refusé.");
      try {
        await car.clearDtc();
        return text("Codes effacés.");
      } catch (e: any) {
        return text("Échec : " + (e?.message || e));
      }
    }),
    tool("diagnostic_start", "Lance le diagnostic moteur guidé à l'arrêt (ralenti, 3000 tr/min, coup de gaz) et affiche l'écran Diagnostic.", {}, async () => {
      car.diag.start();
      deps.screen("diagnostic");
      return text("Diagnostic lancé. L'écran guide Joan ; les résultats arriveront à la fin (diagnostic_status).");
    }),
    tool("diagnostic_status", "État ou résultats du dernier diagnostic moteur.", {}, async () => json(car.diag.st)),
    tool("shift_points", "Régimes de passage conseillés (performance et économie) pour chaque rapport, calculés avec la courbe de couple et les rapports mesurés si Nova les a appris.", {}, async () => json(car.rapports())),
    tool("learning_status", "Ce que Nova a appris de la voiture : rapports mesurés, tirages, courbe de couple, consommation par régime.", {}, async () => {
      const st = car.learning.state();
      return json({ rapports: st.gears, tirages: st.pulls, courbe: car.files.learned.torque, verdict: car.learning.verdict(), conso: car.learning.consoSummary(), km_conso: Math.round(st.consoKm) });
    }),
    tool(
      "show_alert",
      "Affiche une alerte plein écran et la dit à voix haute (pour prévenir Joan de quelque chose d'important).",
      { level: z.enum(["Critique", "Attention", "Info"]), title: z.string(), message: z.string(), value: z.string().optional() },
      async ({ level, title, message, value }) => {
        car.alerts.custom({ level, title, say: message, value });
        return text("Alerte affichée.");
      },
    ),
    tool(
      "led_logo",
      "Pilote le logo LED à l'avant de la voiture.",
      {
        effect: z.enum(["off", "solid", "breathe", "pulse", "scan", "speak", "rainbow"]),
        color: z.string().optional().describe("#rrggbb"),
        brightness: z.number().min(0).max(1).optional(),
      },
      async ({ effect, color, brightness }) => {
        car.hw.setLed({ effect, ...(color ? { color } : {}), ...(brightness !== undefined ? { brightness } : {}) });
        return text(`Logo : ${effect}${car.hw.mode !== "pi" ? " — attention : pas de NovaHAT sur cet appareil, rien n'a été envoyé" : ""}`);
      },
    ),
    tool(
      "fis_text",
      "Écrit deux lignes de 8 caractères sur l'écran central du combiné (sans accents).",
      { line1: z.string(), line2: z.string().optional(), seconds: z.number().min(0).max(600).optional().describe("0 = permanent") },
      async ({ line1, line2, seconds }) => {
        car.hw.setFis(line1, line2 ?? "", seconds ?? 10);
        return text(`Combiné : « ${car.hw.fis.l1} / ${car.hw.fis.l2} »${car.hw.mode !== "pi" ? " — attention : pas de NovaHAT sur cet appareil, rien n'a été envoyé" : ""}`);
      },
    ),
    tool(
      "remote_start",
      "Démarre le moteur à distance. Uniquement si Joan le demande explicitement. Nova vérifie sur le CAN que le moteur est arrêté et que les roues ne bougent pas, et coupe tout si une roue bouge.",
      {},
      async () => text(await car.remote.start()),
    ),
    tool("remote_stop", "Coupe le moteur démarré à distance.", {}, async () => text(car.remote.stop())),
    tool("trip_reset", "Remet à zéro le trajet et la consommation moyenne.", {}, async () => {
      car.store.resetTrip();
      return text("Trajet remis à zéro.");
    }),
    tool(
      "set_fuel",
      "Indique le carburant dans le réservoir après un plein (Nova le suit ensuite avec la consommation).",
      { liters: z.number().min(0).max(80) },
      async ({ liters }) => {
        car.files.learned.fuelL = liters;
        car.files.saveLearnedSoon();
        return text(`Réservoir : ${liters} L.`);
      },
    ),
    tool(
      "connection_test",
      "Teste la connexion à la voiture par le câble branché (KKL ou ELM327) : port, type de câble, écho de la ligne K, réveil du calculateur moteur, protocole, identification, groupe 001, codes défaut. Donne la cause et le remède en cas d'échec.",
      {},
      async () => {
        deps.screen("calculateurs");
        return json(await car.vag.test());
      },
    ),
    tool(
      "vag_scan",
      "Scanne tous les calculateurs de la TT par le câble KKL (moteur, ABS, airbags, combiné, Haldex, clim, confort…) : présence, identification et codes défaut. Rapport enregistré dans le dossier diagnostics.",
      {},
      async () => {
        deps.screen("calculateurs");
        const r = await car.vag.scan();
        const mods = [...car.vag.modules.values()].filter((m) => m.status === "ok" || m.status === "defauts");
        return json({ ...r, calculateurs: mods.map((m) => ({ adresse: m.hex, nom: m.name, protocole: m.protocol, reference: m.ident?.partNumber, designation: m.ident?.component, codage: m.ident?.coding, defauts: m.faults })) });
      },
    ),
    tool(
      "vag_module",
      "Identification et codes défaut d'un calculateur (adresse VAG hexadécimale : 01 moteur, 03 ABS, 08 clim, 15 airbags, 17 combiné, 22 Haldex, 35 verrouillage, 46 confort, 56 radio…).",
      { address: z.string().describe("ex. 01, 17") },
      async ({ address }) => {
        const addr = parseInt(address, 16);
        await car.vag.ident(addr);
        const faults = await car.vag.faults(addr);
        const m = car.vag.modules.get(addr)!;
        return json({ adresse: m.hex, nom: m.name, protocole: m.protocol, identification: m.ident, defauts: faults });
      },
    ),
    tool(
      "vag_group",
      "Lit un groupe de mesure (001 à 255) d'un calculateur : chaque champ avec libellé, valeur, unité et formule brute.",
      { address: z.string(), group: z.number().int().min(0).max(255) },
      async ({ address, group }) => {
        const f = await car.vag.group(parseInt(address, 16), group);
        return f ? json(f.map((x) => ({ libelle: x.label, valeur: x.text, unite: x.unit, specification: x.spec, dans_la_spec: x.inSpec, bits: x.bitsText, aide: x.help, type: x.type, a: x.a, b: x.b }))) : text("Ce groupe n'existe pas dans ce calculateur.");
      },
    ),
    tool(
      "dtc_lookup",
      "Explique un code défaut : code VAG à 5 chiffres (17608) ou code OBD (P1200). Renvoie la pièce en cause, et une piste de réparation quand Nova en connaît une.",
      { code: z.string() },
      async ({ code }) => {
        const c = code.trim().toUpperCase();
        let n: number | null = null;
        if (/^\d{4,5}$/.test(c)) n = Number(c);
        else {
          const m = /^P([0-3])(\d{3})$/.exec(c);
          if (m) n = 16384 + Number(m[1]) * 1024 + Number(m[2]);
        }
        if (n == null) return text("Code non reconnu : donne un code VAG à 5 chiffres ou un code OBD (P0102).");
        const f = decodeFault(n >> 8, n & 0xff, 0);
        return json({ vag: f.vag, obd: f.obd, texte: f.text, piste: f.tip, en_anglais: f.english });
      },
    ),
    tool(
      "vag_catalog",
      "Ce que la base de libellés (base_diagnostic.sqlite de l'utilisateur) sait d'un calculateur déjà connecté : groupes de mesure nommés, réglages de base, canaux d'adaptation, codage décodé option par option, codes d'accès.",
      { address: z.string() },
      async ({ address }) => {
        const m = car.vag.modules.get(parseInt(address, 16));
        if (!car.vag.labels.ready) return text("Pas de base de libellés : l'utilisateur doit poser base_diagnostic.sqlite dans son dossier Nova ou à la racine de la clé Nova OS.");
        if (!m?.ident) return text("Connecte d'abord ce calculateur (vag_module) pour connaître son numéro de pièce.");
        return m.catalog ? json(m.catalog) : text("Aucun fichier de libellés pour " + m.ident.partNumber);
      },
    ),
    tool(
      "vag_basic_setting",
      "Lance le réglage de base d'un groupe (ex. moteur 01, groupe 060 = adaptation du papillon ; contact mis, moteur arrêté, pédale relâchée) et renvoie les valeurs. Appelle-le plusieurs fois de suite pendant la procédure (2 à 3 fois par seconde), puis vag_group pour terminer.",
      { address: z.string(), group: z.number().int().min(1).max(255) },
      async ({ address, group }) => {
        const ok = await deps.confirm("Réglage de base", `Lancer le réglage de base du groupe ${String(group).padStart(3, "0")} sur le calculateur ${address} (contact mis, moteur arrêté) ?`);
        if (!ok) return text("Joan refuse le réglage de base.");
        deps.screen("calculateurs");
        const f = await car.vag.basicSetting(parseInt(address, 16), group);
        return f ? json(f.map((x) => ({ libelle: x.label, valeur: x.text, unite: x.unit, specification: x.spec, dans_la_spec: x.inSpec }))) : text("Pas de réglage de base pour ce groupe.");
      },
    ),
    tool(
      "vag_output_test",
      "Test des actionneurs (KW1281) : chaque appel fait fonctionner l'actionneur suivant (électrovannes, injecteurs, ventilateur…). Moteur arrêté, contact mis. Demande l'accord de Joan au premier appel.",
      { address: z.string(), first: z.boolean().optional().describe("true au premier actionneur de la séquence") },
      async ({ address, first }) => {
        if (first !== false) {
          const ok = await deps.confirm("Test des actionneurs", `Faire fonctionner les actionneurs du calculateur ${address} un par un ? Moteur arrêté, contact mis : des bruits de claquement sont normaux.`);
          if (!ok) return text("Joan refuse le test des actionneurs.");
        }
        deps.screen("calculateurs");
        const r = await car.vag.outputTest(parseInt(address, 16));
        return json(r);
      },
    ),
    tool(
      "vag_read_all",
      "Lit tous les groupes de mesure d'un calculateur (1 à 255, plusieurs minutes) et enregistre un rapport CSV complet.",
      { address: z.string(), from: z.number().int().min(1).max(255).optional(), to: z.number().int().min(1).max(255).optional() },
      async ({ address, from, to }) => {
        deps.screen("calculateurs");
        const r = await car.vag.readAll(parseInt(address, 16), from ?? 1, to ?? 255);
        return text(`${r.found} groupes lus. Rapport : ${r.file} (dossier diagnostics).`);
      },
    ),
    tool("vag_clear_faults", "Efface les codes défaut d'un calculateur (demande l'accord de Joan).", { address: z.string() }, async ({ address }) => {
      if (!(await deps.confirm("Effacer les codes défaut ?", `Nova veut effacer les codes défaut du calculateur ${address.toUpperCase()}.`))) return text("Joan a refusé.");
      const f = await car.vag.clear(parseInt(address, 16));
      return text(f.length ? `Effacés, mais ${f.length} code(s) reviennent tout de suite : le défaut est toujours présent.` : "Codes effacés.");
    }),
    tool("car_settings", "Réglages de la voiture (source, carburant, seuils, broches…), lecture seule.", {}, async () => json(car.files.config)),
  ];
}

export const CAR_TOOL_NAMES = [
  "car_status", "car_history", "show_screen", "set_drive_mode", "log_start", "log_stop", "log_list", "log_analyze", "read_dtc", "clear_dtc",
  "diagnostic_start", "diagnostic_status", "shift_points", "learning_status", "show_alert", "led_logo", "fis_text", "remote_start", "remote_stop",
  "trip_reset", "set_fuel", "car_settings", "connection_test", "vag_scan", "vag_module", "vag_group", "dtc_lookup", "vag_catalog", "vag_read_all", "vag_clear_faults",
];
