// La voiture vue par Nova : assemble les sources, le store, les logs, la surveillance,
// le diagnostic, l'apprentissage, le matériel et le téléphone. Le serveur n'a qu'à brancher
// `send` (vers les écrans) et `say` (Nova parle).
import path from "node:path";
import { spawn } from "node:child_process";
import { CarFiles, MODES, type SourceName } from "./config.js";
import { SignalStore } from "./signals.js";
import { CarLogger } from "./logger.js";
import { AlertManager, type Alert } from "./alerts.js";
import { Diagnostic } from "./diagnostic.js";
import { Learning } from "./learning.js";
import { Hardware } from "./hardware.js";
import { RemoteStart } from "./remote.js";
import { Phone } from "./phone.js";
import { recommendedShift, shiftTable, wheelCurves } from "./shift.js";
import { Elm327Source } from "./sources/elm327.js";
import { Me7LoggerSource } from "./sources/me7logger.js";
import { VagSource } from "./sources/vag.js";
import { VagManager } from "./vag/manager.js";
import { detectCable, listCablePorts, describePort } from "./cables.js";
import { jlog } from "./journaux.js";
import { CanSource, canInterfaces } from "./sources/can.js";
import { ElmCanSource } from "./sources/elmcan.js";
import { bindRfcomm } from "./btserial.js";
import { CanFinder, loadCustom, listCustom, addCustom, removeCustom, type CanHistory } from "./canfind.js";
import type { Dtc, Source } from "./sources/types.js";

export interface CarDeps {
  dataDir: string;
  appRoot: string;
  log: (t: string) => void;
  send: (m: Record<string, unknown>) => void;
  say: (text: string, from: string) => void;
  ask: (prompt: string) => void; // pose une question au cerveau (ex. « garage proche »)
  screen: (name: string) => void;
}

export interface CarOptions {
  source?: string;
  port?: string;
}

const r = (x: number | undefined, d = 0) => (x === undefined ? null : Math.round(x * 10 ** d) / 10 ** d);

export interface InitStep {
  id: string;
  label: string;
  state: "attente" | "en cours" | "ok" | "erreur";
  detail: string;
}
export interface DashInit {
  at: number;
  running: boolean;
  ok: boolean;
  text: string;
  fuelOhm: number | null;
  fuelL: number | null;
  clusterL: number | null;
  steps: InitStep[];
}

export class Car {
  files: CarFiles;
  store!: SignalStore;
  logger!: CarLogger;
  alerts!: AlertManager;
  diag!: Diagnostic;
  learning!: Learning;
  hw!: Hardware;
  remote!: RemoteStart;
  phone!: Phone;
  sources: Source[] = [];
  vag!: VagManager;
  night = false;
  private stoppedSince = 0;
  private lowSince = 0;
  private wasRunning = false;
  private dirty = { diag: false, phone: false, hw: false, vag: false };

  constructor(private d: CarDeps) {
    this.files = new CarFiles(d.dataDir);
  }

  get logDir() {
    return path.join(this.d.dataDir, "logs");
  }

  async init(opts: CarOptions) {
    await this.files.load();
    if (opts.source) this.files.config.source = opts.source;
    if (opts.port) this.files.config.serialPort = opts.port;
    const { log } = this.d;
    this.store = new SignalStore(this.files);
    this.logger = new CarLogger(this.logDir, this.store, log);
    this.hw = new Hardware(this.files, this.d.appRoot, log, () => (this.dirty.hw = true));
    this.alerts = new AlertManager(
      this.store,
      this.files,
      (a) => this.onAlert(a),
      (id) => this.d.send({ type: "alert.clear", id }),
    );
    this.diag = new Diagnostic(
      this.store,
      path.join(this.d.dataDir, "diagnostics"),
      () => this.readDtc(),
      () => (this.dirty.diag = true),
      (st) => {
        log("Diagnostic : " + st.summary);
        // Opus prend le relais : il analyse les résultats et les explique
        this.d.ask("Le diagnostic guidé vient de se terminer. Analyse ses résultats (diagnostic_status) et dis-moi en 3 phrases ce qui va, ce qui ne va pas et quoi faire.");
      },
      (n) => (this.hw.mode === "pi" ? this.hw.inputs[n] ?? null : null),
    );
    this.learning = new Learning(this.store, this.files, log, (what) => {
      this.d.send({ type: "rapports", ...this.rapports() });
      if (what === "courbe moteur") this.d.say(this.learning.verdict(), "apprentissage");
    });
    this.remote = new RemoteStart(this.hw, this.store, this.files, () => this.sources.some((s) => s.hasWheelSpeeds && s.status.state === "ok"), log, () => (this.dirty.hw = true));
    this.phone = new Phone(log, () => (this.dirty.phone = true));
    this.vag = new VagManager(this.files, this.store, this.d.dataDir, log, () => (this.dirty.vag = true));
    loadCustom(this.d.dataDir);
    this.finder = new CanFinder(
      () => (this.sources.find((x) => (x instanceof CanSource || x instanceof ElmCanSource) && x.status.state === "ok") as CanSource | ElmCanSource | undefined)?.history ?? null,
      () => this.d.send({ type: "can.find", ...this.finder.st, customs: listCustom() }),
    );
    this.vag.onGroup = (a, g, v) => this.finder.onGroup(a, g, v);
    this.vag.busyPort = () => {
      const e = this.sources.find((s) => (s instanceof Elm327Source || s instanceof ElmCanSource) && s.status.state !== "off");
      return e ? (e as Elm327Source | ElmCanSource).portPath : "";
    };

    // sources
    this.deps = { store: this.store, files: this.files, log, onStatus: () => this.d.send({ type: "sources", items: this.sourceStatus() }) };
    const names = this.files.config.source.split(/[+,\s]+/).filter(Boolean);
    for (const n of names.length ? names : ["auto"]) {
      if (n === "auto") await this.autoSource();
      else this.addSource(n);
    }
    // source automatique + adaptateur CAN branché (CANable) : on l'écoute aussi, en plus du câble trouvé
    if ((names.length ? names : ["auto"]).includes("auto") && !this.sources.some((x) => x instanceof CanSource)) {
      const ifcs = await canInterfaces().catch(() => []);
      if (ifcs.length) {
        log("Adaptateur CAN détecté (" + ifcs.join(", ") + ") : écoute du bus CAN");
        this.addSource("can");
      }
    }
    this.hw.onInput = (i, on) => {
      if (i === "ignition" && on && this.remote.st.state === "running") this.remote.handOver();
      if (i === "lights") this.setNight(on);
    };
    this.hw.start();
    for (const s of this.sources) if (s.status.state === "off") await s.start();
    this.phone.start();

    setInterval(() => this.tick(), 100);
    setInterval(() => this.frame(), 66);
    setInterval(() => this.slowFrame(), 500);
    log(`Voiture : source ${names.join(" + ")}, carburant ${this.files.config.fuelType} (AFR ${this.files.config.afr})`);
  }

  private deps!: { store: SignalStore; files: CarFiles; log: (t: string) => void; onStatus: () => void };

  private addSource(n: string, port?: string): Source | null {
    let s: Source | null = null;
    if (n === "elm327") s = new Elm327Source(this.deps, port);
    else if (n === "kkl") s = new VagSource(this.deps, this.vag);
    else if (n === "me7logger") s = new Me7LoggerSource(this.deps);
    else if (n === "can") s = new CanSource(this.deps, this.logDir);
    else if (n === "elmcan") s = new ElmCanSource(this.deps, this.logDir, port, () => this.vag.st.port);
    else this.d.log("Source inconnue : " + n);
    if (s) this.sources.push(s);
    return s;
  }

  /**
   * Source « auto » : Nova cherche le câble branché (ELM327 ou KKL), le réessaie toutes les 5 s s'il n'y en a
   * pas, et recommence si le câble est débranché ou remplacé par un autre.
   */
  private autoChosen: { path: string; kind: string; src: Source } | null = null;
  private async autoSource() {
    const clog = (t: string) => jlog("cables.log", t);
    const waiting: Source = {
      status: { name: "Câble", state: "connecting", detail: "recherche du câble…", hz: 0 },
      hasWheelSpeeds: false,
      start: async () => {},
      stop: async () => {},
    };
    this.sources.push(waiting);
    let current: Source = waiting;
    let lastPorts = "";
    let lastNone = "";
    let busy = false;
    const extra = () => [this.files.config.serialPort].filter(Boolean);
    const tryOnce = async () => {
      // ELM327 Bluetooth choisi : on le lie à son port série avant de chercher les câbles
      if (this.files.config.elmBt) await bindRfcomm(this.files.config.elmBt).catch(() => null);
      const det = await detectCable(clog, extra());
      lastPorts = det.ports.map((p) => p.path).join(",");
      if (det.kind === "aucun") {
        waiting.status.state = "error";
        waiting.status.detail = det.ports.length ? "câble non reconnu (voir Réglages → Journaux → Câbles)" : "aucun câble branché (ELM327 ou KKL)";
        if (det.detail !== lastNone) clog("Aucun câble : " + det.detail);
        lastNone = det.detail;
        this.deps.onStatus();
        return;
      }
      lastNone = "";
      this.d.log(`Câble détecté : ${det.kind === "elm327" ? "ELM327" : "KKL"} (${det.detail})`);
      clog(`→ ${det.kind === "elm327" ? "ELM327" : "KKL"} : ${det.detail}`);
      if (det.kind === "kkl") this.vag.autoPort = det.path;
      const kind = det.kind === "elm327" && this.files.config.elmMode === "can" ? "elmcan" : det.kind;
      const src = this.swap(current, kind, det.kind === "elm327" ? det.path : undefined);
      if (src) {
        current = src;
        this.autoChosen = { path: det.path, kind: det.kind, src };
      }
    };
    // pas d'attente : Nova démarre tout de suite, la détection se fait à côté
    let first = true;
    void tryOnce().finally(() => (first = false));
    // surveillance : branchement / débranchement
    setInterval(async () => {
      if (busy || first) return;
      busy = true;
      try {
        const ports = await listCablePorts(extra());
        const now = ports.map((p) => p.path).join(",");
        if (this.autoChosen && !ports.some((p) => p.path === this.autoChosen!.path)) {
          clog(`Câble débranché (${this.autoChosen.path}) : retour à la recherche`);
          this.d.log("Câble débranché : Nova recherche le câble");
          this.vag.autoPort = "";
          await this.autoChosen.src.stop().catch(() => {});
          this.sources = this.sources.filter((s) => s !== this.autoChosen!.src);
          this.autoChosen = null;
          waiting.status.state = "connecting";
          waiting.status.detail = "recherche du câble…";
          this.sources.push(waiting);
          current = waiting;
          this.deps.onStatus();
          lastPorts = now;
          return;
        }
        if (!this.autoChosen && now !== lastPorts) {
          if (now) clog("Nouveau port : " + ports.map(describePort).join(" | "));
          await tryOnce();
        } else if (!this.autoChosen && Date.now() % 30000 < 5000) await tryOnce(); // nouvel essai de temps en temps
      } catch (e: any) {
        clog("Erreur de détection : " + (e?.message || e));
      } finally {
        busy = false;
      }
    }, 5000);
  }

  private swap(old: Source, n: string, port?: string): Source | null {
    this.sources = this.sources.filter((s) => s !== old);
    const s = this.addSource(n, port);
    void s?.start().catch((e: any) => this.d.log("Source " + n + " : " + (e?.message || e)));
    this.deps.onStatus();
    return s;
  }

  private replace(old: Source, n: string, port?: string) {
    this.sources = this.sources.filter((s) => s !== old);
    const s = this.addSource(n, port);
    void s?.start();
    this.deps.onStatus();
  }

  finder!: CanFinder;
  canFindView() {
    return { ...this.finder.st, customs: listCustom() };
  }
  async canSave(i: number, key: string) {
    const r = this.finder.st.results[i];
    if (!r) throw new Error("candidat introuvable");
    const st = this.finder.st;
    const k = key || "can_" + st.label.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 30);
    await addCustom({ id: r.id, kind: r.kind, at: r.at, a: r.a, b: r.b, key: k, label: st.label, unit: st.unit, r: r.r, savedAt: Date.now() });
    this.d.send({ type: "can.find", ...this.finder.st, customs: listCustom() });
    return `« ${st.label} » sera lu sur le CAN (0x${r.idHex}, ${r.kind} octet ${r.at + 1}) → ${k}`;
  }
  async canForget(key: string) {
    await removeCustom(key);
    this.d.send({ type: "can.find", ...this.finder.st, customs: listCustom() });
  }

  /** Écran « Bus CAN » : identifiants vus et leurs octets (ELM327 en écoute). */
  canView() {
    const s = this.sources.find((x) => x instanceof ElmCanSource || x instanceof CanSource) as ElmCanSource | CanSource | undefined;
    return s ? s.view() : null;
  }

  sourceStatus() {
    return this.sources.map((s) => s.status);
  }

  private async readDtc(): Promise<Dtc[] | null> {
    const s = this.sources.find((x) => x.readDtc && x.status.state === "ok");
    if (!s?.readDtc) return null;
    const list = await s.readDtc();
    this.alerts.dtcs = list;
    return list;
  }

  async clearDtc() {
    const s = this.sources.find((x) => x.clearDtc && x.status.state === "ok");
    if (!s?.clearDtc) throw new Error("aucune source ne sait effacer les codes (il faut l'ELM327 ou le câble KKL)");
    await s.clearDtc();
    this.alerts.dtcs = [];
    this.d.log("Codes défaut effacés");
  }

  private tick() {
    this.store.derive();
    // logs automatiques : moteur tournant
    // « moteur arrêté » seulement si une mesure récente le dit : un trou de lecture (diagnostic, ligne K lente)
    // ne doit pas faire croire à un arrêt, ni relancer la lecture des codes défaut à chaque reprise
    const running = this.store.engineRunning || (this.wasRunning && !this.store.fresh("rpm", 3000) && this.store.fresh("rpm", 30000));
    const c = this.files.config;
    if (running && !this.wasRunning) {
      this.d.log("Moteur démarré");
      if (c.autoLog) void this.logger.start("automatique", c.logHz);
      if (c.autoDashboard) this.d.screen("tableau");
      void this.readDtc().then((l) => l?.length && this.d.log("Codes défaut : " + l.map((x) => x.code).join(", "))).catch(() => {});
      this.hw.setLed({ effect: "breathe", color: "#F1F3F5" });
    }
    if (!running && this.wasRunning) {
      this.d.log("Moteur arrêté");
      this.stoppedSince = Date.now();
    }
    if (!running && this.stoppedSince && Date.now() - this.stoppedSince > 30000) {
      this.stoppedSince = 0;
      if (this.logger.info.on && this.logger.info.reason === "automatique") void this.logger.stop();
    }
    this.wasRunning = running;
    // tension batterie de la NovaHAT si la source ne la donne pas
    if (this.hw.batteryV !== null && !this.store.fresh("volt", 5000)) this.store.set({ volt: this.hw.batteryV });
    // batterie trop basse, contact coupé (pas de mainteneur de charge) : Nova éteint proprement le Pi
    const vb = this.hw.batteryV;
    if (this.hw.mode === "pi" && c.autoShutdown && vb !== null && vb < c.shutdownVolt && !running && !this.hw.inputs.ignition && this.remote.st.state !== "running") {
      if (!this.lowSince) this.lowSince = Date.now();
      if (Date.now() - this.lowSince > 60000) {
        this.lowSince = Infinity;
        this.d.log(`Batterie à ${vb.toFixed(1)} V, contact coupé : arrêt du Raspberry Pi`);
        void this.stop().finally(() => spawn("sudo", ["systemctl", "poweroff"], { stdio: "ignore" }).on("error", () => {}));
      }
    } else if (this.lowSince !== Infinity) this.lowSince = 0;
    // FIS : texte temporaire terminé
    if (this.hw.fis.until && Date.now() > this.hw.fis.until) this.hw.setFis("", "");
  }

  private onAlert(a: Alert) {
    this.d.log(`Alerte ${a.level} : ${a.title} (${a.value})`);
    this.d.send({ type: "alert", alert: this.alertView(a) });
    this.d.say(a.say, "alerte");
    if (a.level === "Critique") this.hw.setLed({ effect: "pulse", color: "#FF4D2E" });
    else if (a.level === "Attention") this.hw.setLed({ effect: "pulse", color: "#F5B841" });
    this.hw.setFis(a.level === "Critique" ? "!ALERTE!" : "ATTENTION", a.title, 15);
  }

  alertView(a: Alert) {
    const hist = a.signal ? this.store.history(a.signal, 180).filter((x) => Number.isFinite(x)) : [];
    const n = 27;
    const spark = hist.length ? Array.from({ length: n }, (_, i) => hist[Math.floor((i / (n - 1)) * (hist.length - 1))]) : [];
    return { ...a, spark, index: this.alerts.pending().findIndex((x) => x.id === a.id) + 1, count: this.alerts.pending().length };
  }

  /** Action d'un bouton d'alerte ou d'écran. */
  action(a: string) {
    if (a.startsWith("mode:")) this.setMode(Number(a.slice(5)));
    else if (a.startsWith("ask:")) this.d.ask(a.slice(4));
    else if (a.startsWith("screen:")) this.d.screen(a.slice(7));
  }

  ackAlert(id: string) {
    this.alerts.ack(id);
    this.alerts.ackCustom(id);
    if (!this.alerts.pending().length) this.hw.setLed({ effect: "breathe", color: "#F1F3F5" });
  }

  // ---------------- initialisation du tableau de bord ----------------
  /** Dernière initialisation : résultat lisible + quand. */
  dashInit: DashInit = { at: 0, running: false, ok: false, text: "", fuelOhm: null, fuelL: null, clusterL: null, steps: [] };

  /** Litres d'après la résistance de la sonde (plus la résistance est haute, plus il y a de carburant). */
  fuelFromOhm(ohm: number) {
    const c = this.files.config;
    const lo = Math.min(c.fuelOhmEmpty, c.fuelOhmFull);
    const hi = Math.max(c.fuelOhmEmpty, c.fuelOhmFull);
    const k = (Math.min(hi, Math.max(lo, ohm)) - c.fuelOhmEmpty) / (c.fuelOhmFull - c.fuelOhmEmpty);
    return Math.max(0, Math.min(c.tankLiters, k * c.tankLiters));
  }

  private initStep(id: string, state: InitStep["state"], detail: string) {
    const st = this.dashInit.steps.find((x) => x.id === id);
    if (st) Object.assign(st, { state, detail });
    this.d.send({ type: "dashinit", ...this.dashInit });
  }

  /**
   * Initialisation du tableau de bord : 1) le compteur (adresse 17) pour la sonde de carburant,
   * 2) retour au calculateur moteur, 3) lecture en continu de ce dont le tableau a besoin.
   * L'écran « Initialisation » suit chaque étape (message « dashinit »).
   */
  async dashboardInit(progress: (t: string) => void = () => {}): Promise<string> {
    if (this.dashInit.running) return "Initialisation déjà en cours.";
    const kkl = this.sources.find((s) => s instanceof VagSource);
    if (!kkl) return "Pas de câble KKL : le tableau de bord se remplit avec la source actuelle, sans initialisation.";
    this.dashInit = {
      at: 0, running: true, ok: false, text: "", fuelOhm: null, fuelL: null, clusterL: null,
      steps: [
        { id: "compteur", label: "Compteur : jauge de carburant", state: "attente", detail: "" },
        { id: "moteur", label: "Calculateur moteur", state: "attente", detail: "" },
        { id: "continu", label: "Lecture en continu", state: "attente", detail: "" },
      ],
    };
    const parts: string[] = [];
    try {
      // 1) compteur
      this.initStep("compteur", "en cours", "Réveil du compteur (adresse 17)…");
      progress("Initialisation : connexion au compteur…");
      let ohm: number | null = null;
      let clusterL: number | null = null;
      let err = "";
      for (const n of [1, 2, 3]) {
        let fields: any[] | null = null;
        try {
          fields = await this.vag.group(0x17, n, 0);
        } catch (e: any) {
          err = String(e?.message || e).slice(0, 80);
          break;
        }
        for (const f of fields || []) {
          if (f.value === null || !Number.isFinite(f.value)) continue;
          if (/ohm|Ω/i.test(f.unit) && ohm === null) ohm = f.value;
          else if (/^l$/i.test(f.unit) && clusterL === null) clusterL = f.value;
        }
        if (ohm !== null) break;
      }
      if (ohm !== null) {
        const L = this.fuelFromOhm(ohm);
        this.files.learned.fuelL = L;
        this.store.set({ fuel: L, fuelOhm: ohm });
        Object.assign(this.dashInit, { fuelOhm: ohm, fuelL: L, clusterL });
        const c = this.files.config;
        const txt = `${Math.round(ohm)} Ω → ${L.toFixed(0)} L sur ${c.tankLiters}${clusterL !== null ? ` (le compteur affiche ${clusterL} L)` : ""}`;
        parts.push("jauge " + txt);
        this.initStep("compteur", "ok", txt);
      } else {
        const why = err ? "compteur injoignable : " + err : "résistance de la jauge introuvable (groupes 1 à 3)";
        parts.push(why);
        this.initStep("compteur", "erreur", why + " · Nova garde l'estimation de carburant");
      }
      // 2) moteur
      this.initStep("moteur", "en cours", "Réveil du calculateur moteur (adresse 01)…");
      progress("Initialisation : calculateur moteur…");
      this.vag.startLive();
      const t0 = Date.now();
      while (Date.now() - t0 < 15000 && !this.store.fresh("rpm", 3000)) await new Promise((r) => setTimeout(r, 300));
      const engineOk = this.store.fresh("rpm", 3000);
      this.initStep("moteur", engineOk ? "ok" : "erreur", engineOk ? `connecté · ${this.vag.st.protocol || "KW1281"}` : "pas de réponse : contact mis ? câble branché ?");
      // 3) lecture en continu : on mesure le rythme pendant 4 s
      if (engineOk) {
        this.initStep("continu", "en cours", "Mesure du rythme de lecture…");
        let n = 0;
        let last = this.store.stamp.rpm ?? 0;
        const t1 = Date.now();
        while (Date.now() - t1 < 4000) {
          await new Promise((r) => setTimeout(r, 100));
          const s2 = this.store.stamp.rpm ?? 0;
          if (s2 !== last) {
            n++;
            last = s2;
          }
        }
        const rate = n / 4;
        this.initStep("continu", rate > 0 ? "ok" : "erreur", rate > 0 ? `régime mis à jour ${rate.toFixed(1)} fois/s · eau, turbo, air, lambda en rotation` : "aucune nouvelle mesure en 4 s");
        parts.push(`moteur lu en continu (${rate.toFixed(1)}/s)`);
        this.dashInit.ok = rate > 0;
      } else {
        this.initStep("continu", "erreur", "en attente du calculateur moteur");
        parts.push("calculateur moteur sans réponse");
      }
      this.dashInit.text = (this.dashInit.ok ? "Tableau de bord initialisé : " : "Initialisation incomplète : ") + parts.join(" · ");
      this.dashInit.at = Date.now();
      this.d.log(this.dashInit.text);
      progress(this.dashInit.text);
      return this.dashInit.text;
    } finally {
      this.dashInit.running = false;
      this.d.send({ type: "dashinit", ...this.dashInit });
    }
  }

  /** Calibre la jauge : « plein » ou « vide » maintenant (lecture de la sonde au compteur). */
  async fuelCalibrate(point: "plein" | "vide") {
    let ohm: number | null = null;
    for (const n of [1, 2, 3]) {
      const fields = await this.vag.group(0x17, n, 0);
      for (const f of fields || []) if (f.value !== null && /ohm|Ω/i.test(f.unit)) ohm = f.value;
      if (ohm !== null) break;
    }
    this.vag.startLive();
    if (ohm === null) throw new Error("résistance de la jauge introuvable au compteur (adresse 17, groupes 1 à 3)");
    const c = this.files.config;
    if (point === "plein") c.fuelOhmFull = ohm;
    else c.fuelOhmEmpty = ohm;
    c.fuelOhmCalibrated = true;
    await this.files.saveConfig();
    const L = this.fuelFromOhm(ohm);
    this.files.learned.fuelL = L;
    this.store.set({ fuel: L, fuelOhm: ohm });
    this.d.log(`Jauge calibrée : ${point} = ${Math.round(ohm)} Ω`);
    return `Jauge calibrée : réservoir ${point} = ${Math.round(ohm)} Ω (vide ${Math.round(c.fuelOhmEmpty)} Ω, plein ${Math.round(c.fuelOhmFull)} Ω).`;
  }

  setMode(m: number) {
    this.store.mode = (Math.max(0, Math.min(2, m)) as 0 | 1 | 2);
    this.d.log("Mode " + MODES[this.store.mode].name);
    const col = ["#F1F3F5", "#4FD1E8", "#FF4D2E"][this.store.mode];
    if (!this.alerts.pending().length) this.hw.setLed({ effect: this.store.mode === 2 ? "solid" : "breathe", color: col });
    this.hw.setFis("MODE", MODES[this.store.mode].name, 4);
  }

  setNight(on: boolean) {
    this.night = on;
    this.d.send({ type: "night", on });
  }

  /** Données temps réel pour les écrans (15 fois par seconde). */
  private frame() {
    const s = this.store;
    const v = (k: string, d = 0) => r(s.get(k), d);
    const gear = s.get("gear") ?? 0;
    const mode = s.mode;
    this.d.send({
      type: "car",
      v: {
        rpm: v("rpm"), speed: v("speed"), gear, throttle: v("throttle"), pedal: v("pedal"), load: v("load", 1), maf: v("maf", 1), iat: v("iat"),
        water: v("water"), oil: v("oil"), boost: v("boost", 2), boostReq: v("boostReq", 2), timing: v("timing", 1), knock: v("knock", 1),
        knock1: v("knock1", 1), knock2: v("knock2", 1), knock3: v("knock3", 1), knock4: v("knock4", 1),
        lambda: v("lambda", 2), stft: v("stft", 1), ltft: v("ltft", 1), volt: v("volt", 1), ext: v("ext"), fuelRate: v("fuelRate", 1), l100: v("l100", 1),
        fuel: v("fuel", 1), glong: v("glong", 2), glat: v("glat", 2), haldex: v("haldex"), tripKm: v("tripKm", 1),
      },
      mode,
      shiftAt: recommendedShift(this.files, mode, gear || 1),
      odo: Math.round(s.odometer),
      avgL100: Math.round(s.avgL100 * 10) / 10,
      running: s.engineRunning,
      moving: s.moving,
      rec: { on: this.logger.info.on, file: this.logger.info.file, kb: Math.round(this.logger.info.bytes / 1024), since: this.logger.info.startedAt },
    });
    if (this.dirty.diag) {
      this.dirty.diag = false;
      this.d.send({ type: "diag", ...this.diag.st, running: this.diag.running });
    }
    if (this.dirty.hw) {
      this.dirty.hw = false;
      this.d.send({ type: "hw", mode: this.hw.mode, outputs: this.hw.outputs, inputs: this.hw.inputs, led: this.hw.led, fis: this.hw.fis, remote: this.remote.st });
    }
    if (this.dirty.vag) {
      this.dirty.vag = false;
      this.d.send({ type: "vag", ...this.vag.view() });
    }
    if (this.dirty.phone) {
      this.dirty.phone = false;
      this.d.send({ type: "phone", ...this.phoneView() });
    }
  }

  private slowFrame() {
    this.d.send({ type: "learn", ...this.learning.state() });
    // valeurs des alertes actives (la courbe avance)
    for (const a of this.alerts.pending()) this.d.send({ type: "alert.update", alert: this.alertView(a) });
  }

  phoneView() {
    return { name: this.phone.name, battery: this.phone.battery, track: this.phone.track, notifs: this.phone.notifs, nav: this.phone.nav, navRunning: this.phone.navRunning };
  }

  rapports() {
    return { rows: shiftTable(this.files), ...wheelCurves(this.files) };
  }

  /** État complet envoyé à un écran qui se connecte. */
  snapshot() {
    return [
      { type: "sources", items: this.sourceStatus() },
      { type: "rapports", ...this.rapports() },
      { type: "diag", ...this.diag.st, running: this.diag.running },
      { type: "hw", mode: this.hw.mode, outputs: this.hw.outputs, inputs: this.hw.inputs, led: this.hw.led, fis: this.hw.fis, remote: this.remote.st },
      { type: "phone", ...this.phoneView() },
      { type: "night", on: this.night },
      { type: "vag", ...this.vag.view() },
      ...this.alerts.pending().map((a) => ({ type: "alert", alert: this.alertView(a) })),
    ];
  }

  /** Résumé lisible pour le prompt de Nova. */
  describe(): string {
    const s = this.store;
    const g = (k: string, d = 0, u = "") => {
      const x = s.get(k);
      return x === undefined ? "?" : x.toFixed(d) + u;
    };
    const src = this.sources.map((x) => `${x.status.name} (${x.status.state}${x.status.detail ? ", " + x.status.detail : ""})`).join(" + ");
    const al = this.alerts.all();
    return [
      `Source des données : ${src}`,
      s.engineRunning ? `Moteur tournant : ${g("rpm")} tr/min, ${g("speed")} km/h, rapport ${s.get("gear") || "N"}, eau ${g("water")} °C, huile ${g("oil")} °C, turbo ${g("boost", 2)} bar, batterie ${g("volt", 1)} V` : `Moteur arrêté. Batterie ${g("volt", 1)} V, eau ${g("water")} °C.`,
      `Carburant ≈ ${g("fuel", 1)} L (${this.files.config.fuelType}), conso moyenne du trajet ${s.avgL100.toFixed(1)} L/100, trajet ${g("tripKm", 1)} km, compteur ≈ ${Math.round(s.odometer)} km`,
      `Mode de conduite : ${MODES[s.mode].name}. Log : ${this.logger.info.on ? "en cours (" + this.logger.info.file + ")" : "arrêté"}.`,
      al.length ? `Alertes actives : ${al.map((a) => `${a.level} ${a.title} ${a.value}`).join(" ; ")}` : "Aucune alerte.",
      `Démarrage à distance : ${this.remote.st.state}${this.remote.st.message ? " (" + this.remote.st.message + ")" : ""}. Matériel : ${this.hw.mode === "pi" ? "NovaHAT" : "pas de NovaHAT sur cet appareil"}.`,
    ].join("\n");
  }

  async stop() {
    await this.logger.stop();
    for (const s of this.sources) await s.stop().catch(() => {});
    this.hw.stop();
    this.phone.stop();
    await this.files.saveLearned().catch(() => {});
  }
}
