// Mises à jour de Nova sans refaire l'image Nova OS.
// Nova récupère le nova-auto.zip du dépôt GitHub (celui qu'on y dépose déjà pour construire l'image),
// ou celui posé sur la clé depuis Windows, et la session Nova OS l'installe au redémarrage de l'écran.
// Les modules (700 Mo) restent ceux de l'image : seul le programme de Nova (≈ 5 Mo) change.
// L'image n'est à refaire que si le système change (pilotes, paquets) ou si Nova a besoin d'un nouveau module.
import { promises as fs, existsSync } from "node:fs";
import { execFile, spawn } from "node:child_process";
import path from "node:path";
import { jlog } from "./journaux.js";

const run = (cmd: string, args: string[], timeout = 20000) =>
  new Promise<{ ok: boolean; out: string; err: string }>((resolve) => {
    execFile(cmd, args, { timeout, maxBuffer: 8 << 20 }, (e, out, err) => resolve({ ok: !e, out: String(out ?? ""), err: String(err ?? (e as any)?.message ?? "") }));
  });

const vcmp = (a: string, b: string) => {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
};

export interface MajState {
  current: string;
  available: string;
  source: string;
  status: "idle" | "checking" | "downloading" | "ready" | "installing" | "uptodate" | "error";
  text: string;
  progress: number | null;
  repo: string;
  hasToken: boolean;
  checkedAt: number;
}

export class Updater {
  st: MajState;
  private dir: string;
  private zip: string;

  constructor(
    private dataDir: string,
    current: string,
    private cfg: () => { repo: string; token: string; branch: string },
    private onChange: () => void,
  ) {
    this.dir = path.join(dataDir, "maj");
    this.zip = path.join(this.dir, "nova-auto.zip");
    this.st = { current, available: "", source: "", status: "idle", text: "", progress: null, repo: cfg().repo, hasToken: !!cfg().token, checkedAt: 0 };
  }

  private set(p: Partial<MajState>) {
    Object.assign(this.st, p);
    this.st.repo = this.cfg().repo;
    this.st.hasToken = !!this.cfg().token;
    this.onChange();
  }

  private async zipVersion(file: string): Promise<string> {
    const r = await run("unzip", ["-p", file, "nova-auto/package.json"]);
    try {
      return String(JSON.parse(r.out).version || "");
    } catch {
      return "";
    }
  }

  private headers(raw: boolean) {
    const h: Record<string, string> = { "User-Agent": "Nova", "X-GitHub-Api-Version": "2022-11-28", Accept: raw ? "application/vnd.github.raw" : "application/vnd.github+json" };
    const t = this.cfg().token;
    if (t) h.Authorization = "Bearer " + t;
    return h;
  }

  /** Cherche une version plus récente : sur la clé d'abord, puis sur GitHub (téléchargée si plus récente). */
  async check() {
    this.set({ status: "checking", text: "Recherche d'une mise à jour…", progress: null });
    try {
      // 1. posée sur la clé depuis Windows
      for (const f of ["/run/live/medium/nova-auto.zip", "/run/live/medium/nova-maj/nova-auto.zip"]) {
        if (!existsSync(f)) continue;
        const v = await this.zipVersion(f);
        if (v && vcmp(v, this.st.current) > 0) {
          await fs.mkdir(this.dir, { recursive: true });
          await fs.copyFile(f, this.zip);
          this.set({ status: "ready", available: v, source: "clé USB", text: `Nova ${v} trouvée sur la clé : prête à installer.`, checkedAt: Date.now() });
          return this.st;
        }
      }
      // 2. sur GitHub
      const { repo, branch } = this.cfg();
      if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) throw new Error("dépôt GitHub invalide : " + repo);
      const api = process.env.NOVA_UPDATE_API || "https://api.github.com";
      const url = `${api}/repos/${repo}/contents/nova-auto.zip?ref=${encodeURIComponent(branch)}`;
      const meta = await fetch(url, { headers: this.headers(false), signal: AbortSignal.timeout(20000) });
      if (meta.status === 404) throw new Error(this.cfg().token ? `nova-auto.zip introuvable dans ${repo}` : `dépôt ${repo} privé ou introuvable : ajoute un jeton GitHub (lecture seule) ou rends le dépôt public`);
      if (meta.status === 401 || meta.status === 403) {
        const why = await meta.json().then((j: any) => String(j?.message || "")).catch(() => "");
        throw new Error("GitHub refuse l'accès" + (/rate limit/i.test(why) ? " : trop de demandes, réessaie dans une heure" : meta.status === 401 ? " : jeton invalide" : why ? " : " + why.slice(0, 160) : ""));
      }
      if (!meta.ok) throw new Error("GitHub répond " + meta.status);
      const info = (await meta.json()) as { sha: string; size: number };
      // même fichier qu'au dernier téléchargement : rien à faire
      const shaFile = path.join(this.dir, "nova-auto.sha");
      const lastSha = (await fs.readFile(shaFile, "utf8").catch(() => "")).trim();
      if (lastSha === info.sha && existsSync(this.zip)) {
        const v = await this.zipVersion(this.zip);
        if (v && vcmp(v, this.st.current) > 0) this.set({ status: "ready", available: v, source: "GitHub", text: `Nova ${v} déjà téléchargée : prête à installer.`, checkedAt: Date.now() });
        else this.set({ status: "uptodate", available: v, source: "GitHub", text: `Nova est à jour (${this.st.current}).`, checkedAt: Date.now() });
        return this.st;
      }
      this.set({ status: "downloading", text: `Téléchargement (${(info.size / 1048576).toFixed(1)} Mo)…`, progress: 0 });
      const res = await fetch(url, { headers: this.headers(true), signal: AbortSignal.timeout(180000) });
      if (!res.ok || !res.body) throw new Error("téléchargement refusé (" + res.status + ")");
      await fs.mkdir(this.dir, { recursive: true });
      const part = this.zip + ".part";
      const fh = await fs.open(part, "w");
      let got = 0;
      try {
        const reader = res.body.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          await fh.write(value);
          got += value.length;
          const pct = info.size ? Math.round((got / info.size) * 100) : null;
          if (pct !== this.st.progress) this.set({ progress: pct });
        }
      } finally {
        await fh.close();
      }
      const v = await this.zipVersion(part);
      if (!v) throw new Error("archive téléchargée illisible");
      await fs.rename(part, this.zip);
      await fs.writeFile(shaFile, info.sha);
      jlog("nova.log", `Mise à jour : Nova ${v} téléchargée depuis ${repo}`);
      if (vcmp(v, this.st.current) > 0) this.set({ status: "ready", available: v, source: "GitHub", progress: null, text: `Nova ${v} téléchargée : prête à installer.`, checkedAt: Date.now() });
      else this.set({ status: "uptodate", available: v, source: "GitHub", progress: null, text: `Nova est à jour (${this.st.current}).`, checkedAt: Date.now() });
    } catch (e: any) {
      const msg = String(e?.name === "TimeoutError" ? "pas de réponse de GitHub (Internet ?)" : e?.message || e);
      jlog("nova.log", "Mise à jour : " + msg);
      this.set({ status: "error", text: msg, progress: null, checkedAt: Date.now() });
    }
    return this.st;
  }

  /**
   * Installe : la session Nova OS déploie l'archive au relancement (programme dans ~/Nova/app, modules de
   * l'image). Une copie va aussi sur la clé : la mise à jour tient même sans sauvegarde des réglages.
   */
  async install() {
    if (this.st.status !== "ready" || !existsSync(this.zip)) throw new Error("rien à installer : cherche d'abord une mise à jour");
    if (process.platform !== "linux" || !existsSync("/opt/nova")) {
      throw new Error("installation automatique seulement sur Nova OS. Sous Windows, décompresse nova-auto.zip à la place de l'ancien dossier.");
    }
    this.set({ status: "installing", text: `Installation de Nova ${this.st.available}… l'écran va se relancer.` });
    const med = "/run/live/medium";
    if (existsSync(med)) {
      const r = await run("sudo", ["-n", "sh", "-c", `fs=$(findmnt -rn -o FSTYPE ${med}); case "$fs" in vfat|exfat|ntfs|ntfs3|fuseblk) mount -o remount,rw ${med} && mkdir -p ${med}/nova-maj && cp "${this.zip}" ${med}/nova-maj/nova-auto.zip && sync; r=$?; mount -o remount,ro ${med}; exit $r;; *) exit 0;; esac`], 60000);
      if (!r.ok) jlog("nova.log", "Mise à jour : copie sur la clé impossible : " + r.err.trim());
    }
    jlog("nova.log", `Mise à jour : installation de Nova ${this.st.available} (relance de la session)`);
    // relance de la session graphique : nova-session.sh installe la nouvelle version et la démarre
    setTimeout(() => {
      spawn("sh", ["-c", "sync; sudo -n systemctl restart lightdm || pkill -f 'nova-session.sh --session'"], { stdio: "ignore", detached: true }).unref();
    }, 1500);
    return `Nova ${this.st.available} s'installe : l'écran se relance dans quelques secondes.`;
  }
}
