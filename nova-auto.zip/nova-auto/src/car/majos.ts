// Mises à jour du SYSTÈME Nova OS installé sur disque (noyau, pilotes, paquets), en plus de celles de Nova.
// Tout le travail est fait par /usr/local/sbin/nova-os-maj (dans l'image) : deux emplacements A et B, la
// nouvelle version s'installe dans celui qui ne tourne pas, s'essaie une fois au démarrage suivant et ne
// devient la version habituelle que si elle a tenu ; sinon le PC revient tout seul sur l'ancienne.
import { existsSync } from "node:fs";
import { execFile, spawn } from "node:child_process";
import { jlog } from "./journaux.js";

const SCRIPT = "/usr/local/sbin/nova-os-maj";

export interface OsState {
  present: boolean; // nova-os-maj existe (image Nova OS assez récente)
  mode: "disque" | "cle" | "";
  version: string;
  slot: string;
  autreVersion: string;
  attente: string;
  echecVersion: string;
  libreMo: number;
  disponible: string;
  source: string;
  status: "idle" | "checking" | "uptodate" | "available" | "installing" | "ready" | "error";
  text: string;
  progress: number | null;
}

function parse(out: string) {
  const etat: Record<string, string> = {};
  let ok = "";
  let err = "";
  for (const line of out.split("\n")) {
    const m = /^(ETAT|OK|ERREUR|MESSAGE|PROGRES) ?(.*)$/.exec(line.trim());
    if (!m) continue;
    if (m[1] === "ETAT") {
      const i = m[2].indexOf("=");
      if (i > 0) etat[m[2].slice(0, i)] = m[2].slice(i + 1);
    } else if (m[1] === "OK") ok = m[2];
    else if (m[1] === "ERREUR") err = m[2];
  }
  return { etat, ok, err };
}

export class OsUpdater {
  st: OsState = {
    present: existsSync(SCRIPT),
    mode: "",
    version: "",
    slot: "",
    autreVersion: "",
    attente: "",
    echecVersion: "",
    libreMo: 0,
    disponible: "",
    source: "",
    status: "idle",
    text: "",
    progress: null,
  };
  private running = false;

  constructor(private onChange: () => void) {}

  private set(p: Partial<OsState>) {
    Object.assign(this.st, p);
    this.onChange();
  }

  private exec(args: string[], timeout = 120000) {
    return new Promise<ReturnType<typeof parse>>((resolve) => {
      execFile("sudo", ["-n", SCRIPT, ...args], { timeout, maxBuffer: 4 << 20 }, (e, out, er) => {
        const r = parse(String(out ?? ""));
        if (e && !r.err) r.err = String(er || e.message || e).trim().slice(0, 300);
        resolve(r);
      });
    });
  }

  async refresh() {
    if (!this.st.present) return this.st;
    const { etat, err } = await this.exec(["etat"], 20000);
    this.set({
      mode: (etat.mode as OsState["mode"]) || "",
      version: etat.version || "",
      slot: etat.slot || "",
      autreVersion: etat.autre_version || "",
      attente: etat.attente || "",
      echecVersion: etat.echec_version || "",
      libreMo: Number(etat.libre_mo || 0),
      ...(err && !this.running ? { status: "error" as const, text: err } : {}),
    });
    if (!this.running && this.st.status === "idle") {
      if (this.st.mode === "cle") this.set({ text: "Nova OS tourne depuis la clé USB. Pour l'installer sur le disque : Menu Nova OS → Bureau Linux → « Installer Nova OS sur le disque »." });
      else if (this.st.echecVersion) this.set({ status: "error", text: `La version ${this.st.echecVersion} n'a pas démarré : le PC est revenu tout seul sur la ${this.st.version}.` });
      else if (this.st.attente) this.set({ status: "ready", text: `Nova OS ${this.st.autreVersion} est prêt : il sera essayé au prochain démarrage.` });
    }
    return this.st;
  }

  async check() {
    if (!this.st.present || this.running) return this.st;
    this.running = true;
    this.set({ status: "checking", text: "Recherche d'une nouvelle version du système (clé USB, puis GitHub)…", progress: null });
    try {
      const { etat, ok, err } = await this.exec(["chercher"], 90000);
      if (err) {
        this.set({ status: "error", text: err });
      } else {
        const dispo = etat.disponible || "";
        this.set({ disponible: dispo, source: etat.source || "", status: dispo && etat.a_jour !== "1" ? "available" : "uptodate", text: ok });
      }
    } finally {
      this.running = false;
    }
    return this.st;
  }

  /** Télécharge ou copie la nouvelle version (≈ 2 Go) : la progression arrive ligne par ligne. */
  install() {
    if (!this.st.present || this.running) throw new Error("une opération sur le système est déjà en cours");
    if (this.st.status !== "available") throw new Error("cherche d'abord une nouvelle version du système");
    this.running = true;
    this.set({ status: "installing", progress: 0, text: `Installation de Nova OS ${this.st.disponible}… (Nova reste utilisable pendant ce temps)` });
    jlog("nova.log", `Système : installation de Nova OS ${this.st.disponible} (${this.st.source})`);
    const child = spawn("sudo", ["-n", SCRIPT, "installer"], { stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    let last = { ok: "", err: "" };
    child.stdout.on("data", (d: Buffer) => {
      buf += d.toString();
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        const p = /^PROGRES (\d+)/.exec(line);
        if (p) {
          if (Number(p[1]) !== this.st.progress) this.set({ progress: Math.min(100, Number(p[1])) });
        } else if (line.startsWith("MESSAGE ")) this.set({ text: line.slice(8) });
        else if (line.startsWith("OK ")) last.ok = line.slice(3);
        else if (line.startsWith("ERREUR ")) last.err = line.slice(7);
      }
    });
    child.stderr.on("data", (d: Buffer) => jlog("nova.log", "Système : " + d.toString().trim().slice(0, 300)));
    child.on("close", (code) => {
      this.running = false;
      if (code === 0 && !last.err) {
        jlog("nova.log", "Système : " + last.ok);
        this.set({ status: "ready", progress: null, text: last.ok || "Nouvelle version prête : redémarre pour l'essayer." });
      } else {
        const msg = last.err || `installation interrompue (code ${code})`;
        jlog("nova.log", "Système : " + msg);
        this.set({ status: "error", progress: null, text: msg });
      }
      void this.refresh();
    });
    return `Installation de Nova OS ${this.st.disponible} lancée.`;
  }

  /** essai = démarrer une fois sur l'autre version ; garder = en faire la version habituelle. */
  async other(kind: "essai" | "garder") {
    if (this.running) throw new Error("une opération sur le système est déjà en cours");
    const { ok, err } = await this.exec([kind === "essai" ? "precedente" : "revenir"], 20000);
    if (err) throw new Error(err);
    await this.refresh();
    return ok;
  }

  reboot() {
    jlog("nova.log", "Système : redémarrage demandé");
    setTimeout(() => spawn("sh", ["-c", "sync; sudo -n systemctl reboot"], { stdio: "ignore", detached: true }).unref(), 1500);
    return "Redémarrage du PC…";
  }
}
