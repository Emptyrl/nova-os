// Fichiers entre le PC de Nova et le téléphone, par KDE Connect (même Wi-Fi ou partage de connexion).
//  - téléphone → PC : « Partager » → KDE Connect → Nova ; le fichier arrive dans ~/Nova/Fichiers
//    (Nova règle le dossier de réception de KDE Connect) ;
//  - PC → téléphone : Réglages → Fichiers, on touche un fichier puis « Envoyer au téléphone » ; il arrive
//    dans le dossier Téléchargements du téléphone.
// Dossiers proposés : les fichiers reçus, les journaux de Nova et les clés USB (montées en lecture seule).
import { promises as fs, existsSync } from "node:fs";
import { execFile } from "node:child_process";
import os from "node:os";
import path from "node:path";
import { jlog } from "./journaux.js";

const run = (cmd: string, args: string[], timeout = 15000) =>
  new Promise<{ ok: boolean; out: string; err: string }>((resolve) =>
    execFile(cmd, args, { timeout, maxBuffer: 4 << 20 }, (e, out, err) => resolve({ ok: !e, out: String(out ?? ""), err: String(err ?? (e as any)?.message ?? "") })),
  );

export interface Racine {
  id: string;
  label: string;
  path: string;
  usb?: boolean;
}
export interface Entree {
  name: string;
  dir: boolean;
  size: number;
  at: number;
}
export interface FichiersState {
  racines: Racine[];
  racine: string;
  chemin: string; // relatif à la racine
  entrees: Entree[];
  recus: { name: string; size: number; at: number }[]; // derniers reçus du téléphone
  envoi: { name: string; state: "en cours" | "envoyé" | "erreur"; text: string } | null;
  error: string;
}

const USB_MNT = "/run/nova-usb";

export class Fichiers {
  readonly recusDir: string;
  st: FichiersState = { racines: [], racine: "recus", chemin: "", entrees: [], recus: [], envoi: null, error: "" };
  private connus = new Set<string>();
  private premier = true;

  constructor(
    private dataDir: string,
    private onChange: () => void,
    private onRecu: (name: string) => void,
  ) {
    this.recusDir = path.join(dataDir, "Fichiers");
  }

  async start() {
    await fs.mkdir(this.recusDir, { recursive: true }).catch(() => {});
    await this.reglerReception();
    await this.surveiller();
    setInterval(() => void this.surveiller(), 4000);
    // un téléphone associé après le démarrage : son dossier de réception est réglé dans la minute
    setInterval(() => void this.reglerReception(), 60000);
    await this.ouvrir("recus", "");
  }

  /**
   * KDE Connect enregistre ce qu'il reçoit dans le dossier « Téléchargements » du système (XDG_DOWNLOAD_DIR) :
   * on le fait pointer sur ~/Nova/Fichiers, et on règle aussi chaque téléphone déjà associé.
   */
  private async reglerReception() {
    if (process.platform !== "linux") return;
    const home = os.homedir();
    const ud = path.join(home, ".config", "user-dirs.dirs");
    try {
      let txt = await fs.readFile(ud, "utf8").catch(() => "");
      const ligne = `XDG_DOWNLOAD_DIR="${this.recusDir.startsWith(home) ? "$HOME" + this.recusDir.slice(home.length) : this.recusDir}"`;
      if (!txt.includes(ligne)) {
        txt = /^XDG_DOWNLOAD_DIR=.*$/m.test(txt) ? txt.replace(/^XDG_DOWNLOAD_DIR=.*$/m, ligne) : txt + (txt && !txt.endsWith("\n") ? "\n" : "") + ligne + "\n";
        await fs.mkdir(path.dirname(ud), { recursive: true });
        await fs.writeFile(ud, txt);
      }
      // réglage propre à chaque appareil KDE Connect (il prime sur le dossier du système)
      const kdir = path.join(home, ".config", "kdeconnect");
      for (const id of await fs.readdir(kdir).catch(() => [] as string[])) {
        const d = path.join(kdir, id);
        // un sous-dossier par téléphone associé (les autres fichiers sont les clés de KDE Connect)
        if (!(await fs.stat(d).catch(() => null))?.isDirectory()) continue;
        const f = path.join(d, "kdeconnect_share", "config");
        const cur = await fs.readFile(f, "utf8").catch(() => "");
        if (cur.includes(`incoming_path=${this.recusDir}`)) continue;
        await fs.mkdir(path.dirname(f), { recursive: true });
        const body = /^incoming_path=.*$/m.test(cur) ? cur.replace(/^incoming_path=.*$/m, `incoming_path=${this.recusDir}`) : (cur.includes("[General]") ? cur.replace("[General]", `[General]\nincoming_path=${this.recusDir}`) : `[General]\nincoming_path=${this.recusDir}\n` + cur);
        await fs.writeFile(f, body);
      }
    } catch (e: any) {
      jlog("nova.log", "Fichiers : réglage de la réception impossible : " + (e?.message || e));
    }
  }

  /** Nouveaux fichiers reçus : dans ~/Nova/Fichiers, et dans l'ancien dossier Téléchargements au cas où. */
  private async surveiller() {
    const home = os.homedir();
    const dirs = [this.recusDir, path.join(home, "Téléchargements"), path.join(home, "Downloads")];
    const vus: { name: string; size: number; at: number; full: string }[] = [];
    for (const d of dirs) {
      for (const n of await fs.readdir(d).catch(() => [] as string[])) {
        if (n.startsWith(".") || n.endsWith(".part")) continue;
        const full = path.join(d, n);
        const s = await fs.stat(full).catch(() => null);
        if (!s?.isFile()) continue;
        vus.push({ name: n, size: s.size, at: s.mtimeMs, full });
      }
    }
    let change = false;
    for (const v of vus) {
      if (this.connus.has(v.full)) continue;
      this.connus.add(v.full);
      // un fichier rangé ailleurs que dans ~/Nova/Fichiers y est déplacé, pour tout retrouver au même endroit
      if (!this.premier && path.dirname(v.full) !== this.recusDir) {
        const dest = await this.libre(path.join(this.recusDir, v.name));
        if (await fs.rename(v.full, dest).then(() => true).catch(() => false)) {
          this.connus.add(dest);
          v.name = path.basename(dest);
        }
      }
      if (!this.premier) {
        jlog("nova.log", `Fichiers : reçu du téléphone : ${v.name} (${v.size} octets)`);
        this.onRecu(v.name);
      }
      change = true;
    }
    this.premier = false;
    if (change) {
      const liste = (await fs.readdir(this.recusDir).catch(() => [] as string[])).filter((n) => !n.startsWith("."));
      const recus = [];
      for (const n of liste) {
        const s = await fs.stat(path.join(this.recusDir, n)).catch(() => null);
        if (s?.isFile()) recus.push({ name: n, size: s.size, at: s.mtimeMs });
      }
      this.st.recus = recus.sort((a, b) => b.at - a.at).slice(0, 8);
      if (this.st.racine === "recus" && !this.st.chemin) await this.ouvrir("recus", "", false);
      this.onChange();
    }
  }

  private async libre(p: string) {
    if (!existsSync(p)) return p;
    const ext = path.extname(p);
    const base = p.slice(0, p.length - ext.length);
    for (let i = 2; ; i++) if (!existsSync(`${base} (${i})${ext}`)) return `${base} (${i})${ext}`;
  }

  /** Clés USB : chaque partition branchée à chaud est montée en lecture seule dans /run/nova-usb. */
  private async cles(): Promise<Racine[]> {
    if (process.platform !== "linux") return [];
    const r = await run("lsblk", ["-J", "-p", "-o", "NAME,FSTYPE,LABEL,HOTPLUG,MOUNTPOINT,SIZE"]);
    const out: Racine[] = [];
    let j: any;
    try {
      j = JSON.parse(r.out);
    } catch {
      return out;
    }
    const parts: any[] = [];
    const walk = (n: any, hot: boolean) => {
      const h = hot || n.hotplug === true || n.hotplug === "1";
      if (h && n.fstype && /^(vfat|exfat|ntfs|ntfs3|ext[234])$/.test(n.fstype)) parts.push(n);
      for (const c of n.children || []) walk(c, h);
    };
    for (const d of j.blockdevices || []) walk(d, false);
    for (const p of parts) {
      let mp: string = p.mountpoint || "";
      // la clé Nova OS elle-même (système) n'est pas proposée
      if (mp.startsWith("/run/live")) continue;
      if (!mp) {
        mp = path.join(USB_MNT, path.basename(p.name));
        const m = await run("sudo", ["-n", "sh", "-c", `mkdir -p '${mp}' && (mount -o ro,uid=$(id -u ${os.userInfo().username}) '${p.name}' '${mp}' 2>/dev/null || mount -o ro '${p.name}' '${mp}')`]);
        if (!m.ok) continue;
      }
      out.push({ id: "usb:" + path.basename(p.name), label: `Clé USB ${p.label || path.basename(p.name)} (${p.size})`, path: mp, usb: true });
    }
    return out;
  }

  async racines() {
    const list: Racine[] = [
      { id: "recus", label: "Fichiers (reçus du téléphone)", path: this.recusDir },
      { id: "journaux", label: "Journaux de Nova", path: path.join(this.dataDir, "journaux") },
      ...(await this.cles()),
    ];
    this.st.racines = list;
    return list;
  }

  /** Chemin absolu sûr (jamais en dehors de la racine). */
  private resoudre(racine: string, rel: string) {
    const r = this.st.racines.find((x) => x.id === racine);
    if (!r) throw new Error("dossier inconnu");
    const full = path.resolve(r.path, rel || ".");
    if (full !== r.path && !full.startsWith(r.path + path.sep)) throw new Error("chemin refusé");
    return full;
  }

  async ouvrir(racine: string, rel: string, refresh = true) {
    if (refresh || !this.st.racines.length) await this.racines();
    if (!this.st.racines.some((x) => x.id === racine)) {
      racine = "recus";
      rel = "";
    }
    try {
      const dir = this.resoudre(racine, rel);
      const names = await fs.readdir(dir).catch(() => [] as string[]);
      const entrees: Entree[] = [];
      for (const n of names) {
        if (n.startsWith(".")) continue;
        const s = await fs.stat(path.join(dir, n)).catch(() => null);
        if (s) entrees.push({ name: n, dir: s.isDirectory(), size: s.size, at: s.mtimeMs });
      }
      entrees.sort((a, b) => Number(b.dir) - Number(a.dir) || b.at - a.at);
      Object.assign(this.st, { racine, chemin: path.relative(this.st.racines.find((x) => x.id === racine)!.path, dir), entrees: entrees.slice(0, 200), error: "" });
    } catch (e: any) {
      this.st.error = String(e?.message || e);
    }
    this.onChange();
    return this.st;
  }

  private async telephone() {
    const r = await run("kdeconnect-cli", ["-a", "--id-only"], 6000);
    const id = r.out.split("\n").map((s) => s.trim()).find(Boolean);
    if (!id) throw new Error("téléphone introuvable : ouvre KDE Connect sur le téléphone, sur le même Wi-Fi que Nova (ou son partage de connexion), puis Réglages → Téléphone → Chercher");
    return id;
  }

  /** Envoie un fichier au téléphone (il arrive dans son dossier Téléchargements). */
  async envoyer(racine: string, rel: string) {
    const full = this.resoudre(racine, rel);
    const s = await fs.stat(full).catch(() => null);
    if (!s?.isFile()) throw new Error("ce n'est pas un fichier");
    const name = path.basename(full);
    const id = await this.telephone();
    this.st.envoi = { name, state: "en cours", text: `Envoi de ${name} au téléphone…` };
    this.onChange();
    const r = await run("kdeconnect-cli", ["-d", id, "--share", full], 30000);
    if (r.ok) {
      this.st.envoi = { name, state: "envoyé", text: `${name} est parti vers le téléphone : il arrive dans Téléchargements.` };
      jlog("nova.log", `Fichiers : envoyé au téléphone : ${name} (${s.size} octets)`);
    } else {
      this.st.envoi = { name, state: "erreur", text: `${name} n'a pas pu partir : ${(r.err || r.out).trim().slice(0, 200)}` };
      jlog("nova.log", "Fichiers : " + this.st.envoi.text);
    }
    this.onChange();
    return this.st.envoi.text;
  }

  /** Supprime un fichier reçu (seulement dans ~/Nova/Fichiers). */
  async supprimer(rel: string) {
    const full = this.resoudre("recus", rel);
    await fs.rm(full, { force: true });
    this.connus.delete(full);
    await this.ouvrir(this.st.racine, this.st.chemin);
    return `${path.basename(full)} supprimé.`;
  }

  /** Démonte les clés USB montées par Nova (avant de les retirer). */
  async ejecter() {
    await run("sudo", ["-n", "sh", "-c", `for m in ${USB_MNT}/*; do [ -d "$m" ] && umount "$m" && rmdir "$m"; done; true`]);
    await this.ouvrir("recus", "");
    return "Clés USB démontées : tu peux les retirer.";
  }
}
