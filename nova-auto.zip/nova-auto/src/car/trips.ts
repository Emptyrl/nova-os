// Résumé de fin de trajet : Nova suit chaque trajet (du démarrage à l'arrêt du moteur) et, à la fin,
// dit en une ou deux phrases ce qui s'est passé. Les trajets sont gardés dans trajets.json pour voir l'évolution.
import { promises as fs } from "node:fs";
import path from "node:path";
import type { SignalStore } from "./signals.js";
import type { CarFiles } from "./config.js";

export interface Trip {
  start: string; // ISO
  end: string;
  minutes: number;
  km: number;
  fuelL: number;
  l100: number | null; // null si trop court pour être juste
  vmax: number | null;
  waterMax: number | null;
  oilMax: number | null;
  boostMax: number | null;
  voltMin: number | null;
  knockEvents: number;
  knockMax: number | null;
  alerts: string[];
}

const fr = (x: number, d = 1) => x.toFixed(d).replace(".", ",");

export class TripRecorder {
  private cur: (Omit<Trip, "end" | "minutes" | "km" | "fuelL" | "l100"> & { t0: number; km0: number; fuel0: number; knockOn: boolean }) | null = null;
  private trips: Trip[] = [];
  private file: string;
  private lastSample = 0;

  constructor(
    private store: SignalStore,
    private files: CarFiles,
    dataDir: string,
  ) {
    this.file = path.join(dataDir, "trajets.json");
    void fs
      .readFile(this.file, "utf8")
      .then((t) => (this.trips = JSON.parse(t)))
      .catch(() => {});
  }

  get active() {
    return !!this.cur;
  }

  begin() {
    const L = this.files.learned;
    this.cur = {
      start: new Date().toISOString(),
      t0: Date.now(),
      km0: L.tripKm,
      fuel0: L.tripFuelL,
      vmax: null,
      waterMax: null,
      oilMax: null,
      boostMax: null,
      voltMin: null,
      knockEvents: 0,
      knockMax: null,
      knockOn: false,
      alerts: [],
    };
  }

  /** Appelé souvent (10 Hz) : on échantillonne une fois par seconde. */
  sample() {
    const c = this.cur;
    if (!c || Date.now() - this.lastSample < 1000) return;
    this.lastSample = Date.now();
    const g = (k: string) => this.store.get(k);
    const max = (a: number | null, b: number | undefined) => (b === undefined ? a : a === null ? b : Math.max(a, b));
    c.vmax = max(c.vmax, g("speed"));
    c.waterMax = max(c.waterMax, g("water"));
    c.oilMax = max(c.oilMax, g("oil"));
    c.boostMax = max(c.boostMax, g("boost"));
    const v = g("volt");
    if (v !== undefined && this.store.engineRunning) c.voltMin = c.voltMin === null ? v : Math.min(c.voltMin, v);
    const k = g("knock");
    if (k !== undefined) {
      c.knockMax = max(c.knockMax, k);
      // un « épisode » de cliquetis = recul ≥ 2° après être retombé sous 1°
      if (k >= 2 && !c.knockOn) {
        c.knockEvents++;
        c.knockOn = true;
      } else if (k < 1) c.knockOn = false;
    }
  }

  noteAlert(title: string) {
    if (this.cur && !this.cur.alerts.includes(title)) this.cur.alerts.push(title);
  }

  /** Fin du trajet (moteur arrêté depuis 30 s). Renvoie le résumé à dire, ou null si ce n'était pas un trajet. */
  async end(): Promise<{ trip: Trip; say: string } | null> {
    const c = this.cur;
    this.cur = null;
    if (!c) return null;
    const L = this.files.learned;
    const km = Math.max(0, L.tripKm - c.km0);
    const fuelL = Math.max(0, L.tripFuelL - c.fuel0);
    const minutes = Math.round((Date.now() - c.t0 - 30000) / 60000);
    if (km < 0.3 && minutes < 3) return null; // démarrage au garage, rien à raconter
    const { t0, km0, fuel0, knockOn, ...rest } = c;
    const trip: Trip = { ...rest, end: new Date().toISOString(), minutes, km: Math.round(km * 10) / 10, fuelL: Math.round(fuelL * 100) / 100, l100: km >= 2 ? Math.round((fuelL / km) * 1000) / 10 : null };
    this.trips.push(trip);
    if (this.trips.length > 300) this.trips.splice(0, this.trips.length - 300);
    await fs.writeFile(this.file, JSON.stringify(this.trips), "utf8").catch(() => {});
    return { trip, say: this.describe(trip) };
  }

  describe(t: Trip) {
    const parts: string[] = [];
    if (t.km >= 0.3) parts.push(`Trajet terminé : ${fr(t.km)} kilomètres en ${t.minutes} minute${t.minutes > 1 ? "s" : ""}`);
    else parts.push(`Moteur coupé après ${t.minutes} minutes sur place, ${fr(t.fuelL, 2)} litre d'E85`);
    if (t.l100 !== null) {
      const avg = this.average();
      parts[0] += `, ${fr(t.l100)} litres aux cent`;
      if (avg !== null && Math.abs(t.l100 - avg) / avg > 0.15) parts[0] += t.l100 > avg ? `, plus que ta moyenne de ${fr(avg)}` : `, mieux que ta moyenne de ${fr(avg)}`;
    }
    parts[0] += ".";
    const notes: string[] = [];
    if (t.waterMax !== null) notes.push(`eau maxi ${Math.round(t.waterMax)} degrés`);
    if (t.boostMax !== null && t.boostMax > 0.3) notes.push(`turbo maxi ${fr(t.boostMax)} bar`);
    notes.push(t.knockEvents ? `${t.knockEvents} épisode${t.knockEvents > 1 ? "s" : ""} de cliquetis, jusqu'à ${fr(t.knockMax ?? 0)} degrés` : "aucun cliquetis");
    if (t.alerts.length) notes.push(`alerte${t.alerts.length > 1 ? "s" : ""} : ${t.alerts.join(", ")}`);
    return `${parts[0]} ${notes.join(", ").replace(/^./, (x) => x.toUpperCase())}.`;
  }

  /** Conso moyenne des 10 derniers trajets assez longs (hors le dernier). */
  average(): number | null {
    const l = this.trips.slice(0, -1).filter((t) => t.l100 !== null && t.km >= 5).slice(-10);
    return l.length >= 3 ? l.reduce((a, t) => a + t.l100!, 0) / l.length : null;
  }

  list(n = 20) {
    return this.trips.slice(-n).reverse();
  }

  stats() {
    const l = this.trips.filter((t) => t.km >= 1);
    const km = l.reduce((a, t) => a + t.km, 0);
    const fuel = l.reduce((a, t) => a + t.fuelL, 0);
    return { trajets: l.length, km: Math.round(km), litres: Math.round(fuel * 10) / 10, moyenne: km > 5 ? Math.round((fuel / km) * 1000) / 10 : null };
  }
}
