// Téléphone : musique du téléphone (Bluetooth, via MPRIS/playerctl), notifications et batterie
// (KDE Connect), navigation Waze / Maps affichée par scrcpy. Fonctionne sous Linux (le Pi) ;
// sur un PC Windows ces fonctions ne sont pas disponibles.
import { spawn, execFile, type ChildProcess } from "node:child_process";

export interface Notif {
  id: string;
  from: string;
  app: string;
  text: string;
  at: number;
}

export interface PhoneTrack {
  title: string;
  artist: string;
  album: string;
  artwork: string;
  position: number;
  duration: number;
  playing: boolean;
}

const run = (cmd: string, args: string[], timeout = 3000) =>
  new Promise<string>((resolve) => {
    execFile(cmd, args, { timeout }, (err, out) => resolve(err ? "" : String(out).trim()));
  });

export class Phone {
  notifs: Notif[] = [];
  battery: number | null = null;
  name = "";
  track: PhoneTrack | null = null;
  nav: "waze" | "maps" = "waze";
  navRunning = false;
  private scrcpy: ChildProcess | null = null;
  private dbus: ChildProcess | null = null;
  private device = "";

  constructor(
    private log: (t: string) => void,
    private onChange: () => void,
  ) {}

  start() {
    if (process.platform !== "linux") return;
    setInterval(() => void this.pollMusic(), 1000);
    setInterval(() => void this.pollPhone(), 30000);
    void this.pollPhone();
    this.watchNotifications();
  }

  // ---------- musique du téléphone (AVRCP → MPRIS) ----------
  private async pollMusic() {
    const out = await run("playerctl", ["metadata", "--format", "{{status}}|{{title}}|{{artist}}|{{album}}|{{mpris:length}}|{{position}}|{{mpris:artUrl}}"]);
    if (!out) {
      if (this.track) {
        this.track = null;
        this.onChange();
      }
      return;
    }
    const [status, title, artist, album, len, pos, art] = out.split("|");
    this.track = { title, artist, album, artwork: art?.startsWith("http") ? art : "", duration: Number(len) / 1e6 || 0, position: Number(pos) / 1e6 || 0, playing: status === "Playing" };
    this.onChange();
  }

  control(action: "toggle" | "next" | "previous") {
    const arg = action === "toggle" ? "play-pause" : action;
    spawn("playerctl", [arg], { stdio: "ignore" }).on("error", () => {});
  }

  // ---------- KDE Connect ----------
  private async pollPhone() {
    const id = (await run("kdeconnect-cli", ["-a", "--id-only"])).split("\n")[0];
    this.device = id;
    if (!id) return;
    this.name = (await run("kdeconnect-cli", ["-d", id, "--name"])) || "Téléphone";
    const charge = await run("busctl", ["--user", "get-property", "org.kde.kdeconnect", `/modules/kdeconnect/devices/${id}/battery`, "org.kde.kdeconnect.device.battery", "charge"]);
    const n = parseInt(charge.replace(/^\D+/, ""), 10);
    if (Number.isFinite(n)) this.battery = n;
    this.onChange();
  }

  private watchNotifications() {
    const child = spawn("dbus-monitor", ["--session", "type='signal',interface='org.kde.kdeconnect.device.notifications',member='notificationPosted'"]);
    this.dbus = child;
    child.on("error", () => {});
    child.stdout.on("data", async (b: Buffer) => {
      const ids = [...b.toString().matchAll(/string "([^"]+)"/g)].map((m) => m[1]);
      for (const nid of ids) {
        if (!this.device) continue;
        const base = `/modules/kdeconnect/devices/${this.device}/notifications/${nid}`;
        const get = async (p: string) => (await run("busctl", ["--user", "get-property", "org.kde.kdeconnect", base, "org.kde.kdeconnect.device.notifications.notification", p])).replace(/^s\s+"?|"$/g, "");
        const [app, title, text] = await Promise.all([get("appName"), get("title"), get("text")]);
        if (!app && !text) continue;
        this.add({ id: nid, app, from: title || app, text, at: Date.now() });
      }
    });
  }

  add(n: Notif) {
    this.notifs = [n, ...this.notifs.filter((x) => x.id !== n.id)].slice(0, 10);
    this.onChange();
  }

  // ---------- navigation : Waze ou Maps du téléphone, affiché par scrcpy ----------
  async openNav(app: "waze" | "maps", rect: { x: number; y: number; w: number; h: number } | null) {
    this.nav = app;
    if (process.platform === "win32" && !(await run("where", ["scrcpy"]))) {
      this.onChange();
      return "scrcpy n'est pas installé sur ce PC";
    }
    // le téléphone doit être branché en USB avec le débogage USB autorisé
    const devs = (await run("adb", ["devices"], 6000)).split("\n").slice(1).filter((l) => l.trim());
    if (!devs.length) {
      this.onChange();
      return process.platform === "linux" && !(await run("sh", ["-c", "command -v adb"]))
        ? "adb absent : mets à jour Nova OS"
        : "Téléphone non détecté : branche-le en USB et active le débogage USB (Réglages → Téléphone)";
    }
    if (devs.every((l) => /unauthorized/.test(l))) {
      this.onChange();
      return "Accepte « Autoriser le débogage USB » sur l'écran du téléphone, puis réessaie";
    }
    const pkg = app === "waze" ? "com.waze" : "com.google.android.apps.maps";
    await run("adb", ["shell", "monkey", "-p", pkg, "-c", "android.intent.category.LAUNCHER", "1"], 8000);
    this.scrcpy?.kill();
    const args = ["--no-audio", "--stay-awake", "--window-title=Nova-Nav", "--max-size=1024"];
    if (rect) args.push("--window-borderless", "--always-on-top", `--window-x=${rect.x}`, `--window-y=${rect.y}`, `--window-width=${rect.w}`, `--window-height=${rect.h}`);
    else args.push("--fullscreen");
    const child = spawn("scrcpy", args, { stdio: "ignore" });
    this.scrcpy = child;
    this.navRunning = true;
    child.on("error", (e) => {
      this.navRunning = false;
      this.log("scrcpy : " + e.message);
      this.onChange();
    });
    child.on("exit", () => {
      if (this.scrcpy === child) {
        this.navRunning = false;
        this.onChange();
      }
    });
    this.onChange();
    return `${app === "waze" ? "Waze" : "Google Maps"} ouvert sur le téléphone et affiché`;
  }

  closeNav() {
    this.scrcpy?.kill();
    this.scrcpy = null;
    this.navRunning = false;
    this.onChange();
  }

  stop() {
    this.scrcpy?.kill();
    this.dbus?.kill();
  }
}
