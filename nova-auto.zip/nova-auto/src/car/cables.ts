// Détection du câble de diagnostic branché : ELM327 (USB ou Bluetooth) ou KKL (VAG-COM 409.1).
// Chaque étape est notée dans journaux/cables.log, pour comprendre pourquoi un câble n'est pas vu.
//
// - On ne garde que les vrais ports de câble : ttyUSB*, ttyACM* et rfcomm* sous Linux, COMx sous Windows.
//   Les ttyS* (ports série internes, souvent fantômes) sont ignorés.
// - ELM327 : on essaie les vitesses courantes (38400, 115200, 9600, 230400, 500000) avec ATZ puis ATI.
//   Il répond « ELM327 v1.5 » (ou STN…, OBDII…) suivi de l'invite « > ».
// - Sinon, une puce USB-série connue (FTDI, CH340, PL2303, CP210x) est un câble KKL.
//   Un ttyACM inconnu (modem 4G intégré, GPS…) n'est pas pris pour un câble.
import { SerialPort } from "serialport";
import { existsSync, promises as fs } from "node:fs";
import path from "node:path";

/**
 * Linux : liste lue directement dans /sys (instantané). SerialPort.list() lance « udevadm », qui prenait
 * jusqu'à 60 % du processeur à chaque recherche de câble (toutes les 5 s) sur un petit PC.
 */
async function listLinux(): Promise<any[]> {
  const names = (await fs.readdir("/sys/class/tty").catch(() => [] as string[])).filter((n) => /^(ttyUSB|ttyACM|rfcomm)\d+$/.test(n));
  const out: any[] = [];
  for (const n of names) {
    let dir = await fs.realpath(path.join("/sys/class/tty", n, "device")).catch(() => "");
    const read = (d: string, f: string) => fs.readFile(path.join(d, f), "utf8").then((x) => x.trim()).catch(() => "");
    let vendorId = "", productId = "", manufacturer = "", serialNumber = "";
    for (let i = 0; dir && i < 6; i++) {
      vendorId = await read(dir, "idVendor");
      if (vendorId) {
        productId = await read(dir, "idProduct");
        manufacturer = await read(dir, "manufacturer");
        serialNumber = await read(dir, "serial");
        break;
      }
      dir = path.dirname(dir);
    }
    out.push({ path: "/dev/" + n, vendorId, productId, manufacturer, serialNumber });
  }
  return out;
}

export interface PortInfo {
  path: string;
  vid: string;
  pid: string;
  manufacturer: string;
  serial: string;
  chip: string;
}

export interface Detection {
  kind: "elm327" | "kkl" | "aucun";
  path: string;
  detail: string;
  ports: PortInfo[];
}

// puces USB-série connues
const CHIPS: Record<string, string> = {
  "0403": "FTDI",
  "1a86": "CH340 (WCH)",
  "067b": "Prolific PL2303",
  "10c4": "Silicon Labs CP210x",
  "0483": "STMicro (OBDLink)",
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function listCablePorts(extra: string[] = []): Promise<PortInfo[]> {
  let list: any[] = [];
  try {
    list = process.platform === "linux" ? await listLinux() : await SerialPort.list();
  } catch {
    list = [];
  }
  const out: PortInfo[] = [];
  for (const p of list) {
    const path = String(p.path || "");
    const isCable = process.platform === "win32" ? /^COM\d+$/i.test(path) : /tty(USB|ACM)\d+$|rfcomm\d+$/.test(path);
    if (!isCable) continue;
    const vid = String(p.vendorId || "").toLowerCase();
    out.push({
      path,
      vid,
      pid: String(p.productId || "").toLowerCase(),
      manufacturer: String(p.manufacturer || (p as any).friendlyName || ""),
      serial: String(p.serialNumber || ""),
      chip: CHIPS[vid] || (/rfcomm/.test(path) ? "Bluetooth" : ""),
    });
  }
  // ports réglés à la main (et ports de test) : on les essaie aussi, même s'ils n'apparaissent pas
  for (const e of extra) {
    if (e && !out.some((p) => p.path === e) && (process.platform === "win32" || existsSync(e))) {
      out.push({ path: e, vid: "", pid: "", manufacturer: "réglé à la main", serial: "", chip: "" });
    }
  }
  return out;
}

export const describePort = (p: PortInfo) =>
  `${p.path}${p.chip ? " · " + p.chip : ""}${p.vid ? ` ${p.vid}:${p.pid}` : ""}${p.manufacturer ? " · " + p.manufacturer : ""}${p.serial ? " · n° " + p.serial : ""}`;

/** Interroge le port comme un ELM327, à plusieurs vitesses. Rend la version, ou null. */
export async function probeElm(path: string, log: (t: string) => void = () => {}, bauds = [38400, 115200, 9600, 230400, 500000]): Promise<string | null> {
  const tried: string[] = [];
  for (const baud of bauds) {
    const port = new SerialPort({ path, baudRate: baud, autoOpen: false });
    try {
      await new Promise<void>((res, rej) => port.open((e) => (e ? rej(e) : res())));
    } catch (e: any) {
      log(`  ${path} : ouverture impossible (${e?.message || e})`);
      return null; // port occupé ou inaccessible : inutile d'essayer d'autres vitesses
    }
    let rx = "";
    port.on("data", (b: Buffer) => (rx += b.toString("latin1")));
    port.on("error", () => {});
    try {
      port.set?.({ dtr: true, rts: true }, () => {});
      // \r\r vide la ligne de commande d'un ELM déjà réveillé
      port.write("\r\rATZ\r");
      let end = Date.now() + 2500;
      while (Date.now() < end && !/ELM|STN|OBD/i.test(rx)) await sleep(40);
      if (!/ELM|STN|OBD/i.test(rx)) {
        port.write("ATI\r");
        end = Date.now() + 900;
        while (Date.now() < end && !/ELM|STN|OBD/i.test(rx)) await sleep(40);
      }
      const m = rx.match(/(ELM\s*327[^\r\n>]*|STN\d+[^\r\n>]*|OBD[^\r\n>]*)/i);
      const clean = rx.replace(/[^\x20-\x7e]/g, ".").slice(0, 40);
      const echo = !m && /ATZ/.test(rx) && !/OK|\?/.test(rx);
      tried.push(`${baud}: ${m ? "« " + m[1].trim() + " »" : echo ? "écho de ce qui est envoyé (câble KKL relié à une ligne K alimentée)" : rx ? "réponse illisible « " + clean + " »" : "rien"}`);
      if (echo) break; // c'est un KKL : inutile d'essayer les autres vitesses
      if (m) {
        log(`  ${path} : ELM327 trouvé à ${baud} bauds (${tried.join(" ; ")})`);
        return m[1].trim();
      }
    } finally {
      if (port.isOpen) await new Promise<void>((r) => port.close(() => r()));
    }
    await sleep(80);
  }
  log(`  ${path} : pas un ELM327 (${tried.join(" ; ")})`);
  return null;
}

/** Cherche le câble branché. `skip` : ports déjà ouverts par Nova (on ne les dérange pas). */
export async function detectCable(log: (t: string) => void, extra: string[] = [], skip: string[] = []): Promise<Detection> {
  const ports = await listCablePorts(extra);
  if (!ports.length) return { kind: "aucun", path: "", detail: "aucun port USB-série (câble non branché ?)", ports };
  log(`Détection : ${ports.length} port(s) : ${ports.map(describePort).join(" | ")}`);
  const kklCandidates: PortInfo[] = [];
  for (const p of ports) {
    if (skip.includes(p.path)) continue;
    const elm = await probeElm(p.path, log);
    if (elm) return { kind: "elm327", path: p.path, detail: `${elm} sur ${describePort(p)}`, ports };
    // KKL : puce USB-série connue, ou ttyUSB, ou port réglé à la main ; un ttyACM inconnu est un modem
    const known = !!CHIPS[p.vid] && p.chip !== "STMicro (OBDLink)";
    if (known || /ttyUSB|COM\d/i.test(p.path) || p.manufacturer === "réglé à la main") kklCandidates.push(p);
    else log(`  ${p.path} : ignoré (ni ELM327, ni puce de câble KKL connue : modem ou autre appareil)`);
  }
  // FTDI d'abord (les KKL VAG-COM sont presque toujours en FTDI), puis CH340, puis le reste
  kklCandidates.sort((a, b) => Number(b.vid === "0403") - Number(a.vid === "0403") || Number(b.vid === "1a86") - Number(a.vid === "1a86"));
  const k = kklCandidates[0];
  if (k) return { kind: "kkl", path: k.path, detail: `câble KKL sur ${describePort(k)}`, ports };
  return { kind: "aucun", path: "", detail: "port(s) trouvé(s) mais aucun câble de diagnostic reconnu", ports };
}
