// Journaux de Nova, rangés dans <données>/journaux/ et lisibles dans Réglages → Journaux.
//   nova.log       tout ce que fait le cerveau et la voiture (copie de journal.log)
//   demarrage.log  temps de démarrage de chaque allumage (noyau, services, Nova, premier écran)
//   ecran.log      l'écran : erreurs JavaScript, images par seconde, carte graphique, changements d'écran
//   systeme.log    mémoire, processeur, températures, processus gourmands, erreurs du noyau, plantages
//   cables.log     détection des câbles KKL / ELM327, pas à pas
//   session.log    la session Nova OS : lancements et arrêts de l'écran, du bureau, du cerveau
// Chaque fichier est limité à 3 Mo (l'ancien est gardé en .1).
import { promises as fs, existsSync, mkdirSync, statSync, renameSync, appendFileSync } from "node:fs";
import path from "node:path";
import { DATA_DIR } from "../brain/store.js";

export const LOG_DIR = path.join(DATA_DIR, "journaux");
const MAX = 3 * 1024 * 1024;

try {
  mkdirSync(LOG_DIR, { recursive: true });
} catch {}

export const LOG_FILES: Record<string, string> = {
  "nova.log": "Cerveau et voiture",
  "demarrage.log": "Temps de démarrage",
  "ecran.log": "Écran : erreurs, fluidité",
  "systeme.log": "Système : mémoire, processeur, plantages",
  "cables.log": "Câbles KKL / ELM327",
  "ligne-k.log": "Dialogue ligne K (calculateurs)",
  "session.log": "Session Nova OS",
  "chromium.log": "Navigateur de l'écran",
  "nova-console.log": "Sortie brute du cerveau",
};

const ts = () => {
  const d = new Date();
  const p = (n: number, w = 2) => String(n).padStart(w, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}`;
};

function rotate(file: string) {
  try {
    if (existsSync(file) && statSync(file).size > MAX) renameSync(file, file + ".1");
  } catch {}
}

/** Écrit une ligne horodatée (synchrone : rien n'est perdu si Nova plante juste après). */
export function jlog(name: string, text: string) {
  const file = path.join(LOG_DIR, name);
  rotate(file);
  const lines = String(text)
    .split("\n")
    .map((l, i) => (i === 0 ? `[${ts()}] ${l}` : `    ${l}`))
    .join("\n");
  try {
    appendFileSync(file, lines + "\n");
  } catch {}
}

export async function listLogs() {
  const out: { name: string; label: string; size: number; at: number }[] = [];
  for (const [name, label] of Object.entries(LOG_FILES)) {
    const file = path.join(LOG_DIR, name);
    try {
      const st = await fs.stat(file);
      out.push({ name, label, size: st.size, at: st.mtimeMs });
    } catch {
      out.push({ name, label, size: 0, at: 0 });
    }
  }
  return out;
}

/** Les `lines` dernières lignes d'un journal (les plus récentes à la fin). */
export async function tailLog(name: string, lines = 300): Promise<string> {
  if (!(name in LOG_FILES)) throw new Error("journal inconnu : " + name);
  const file = path.join(LOG_DIR, name);
  let txt = "";
  try {
    const st = await fs.stat(file);
    const fh = await fs.open(file, "r");
    const len = Math.min(st.size, 400 * 1024);
    const buf = Buffer.alloc(len);
    await fh.read(buf, 0, len, st.size - len);
    await fh.close();
    txt = buf.toString("utf8");
  } catch {
    return "(vide)";
  }
  const all = txt.split("\n");
  return all.slice(-lines - 1).join("\n").trim() || "(vide)";
}

export async function clearLogs() {
  for (const name of Object.keys(LOG_FILES)) {
    if (name === "session.log" || name === "chromium.log" || name === "nova-console.log") {
      await fs.writeFile(path.join(LOG_DIR, name), "").catch(() => {}); // fichiers tenus ouverts par la session : vidés
      continue;
    }
    await fs.rm(path.join(LOG_DIR, name), { force: true });
    await fs.rm(path.join(LOG_DIR, name + ".1"), { force: true });
  }
}
