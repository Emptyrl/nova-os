// Points de passage : à partir de la courbe de couple (référence 225 ou mesurée par Nova)
// et des rapports de boîte (référence ou mesurés). Même calcul que l'écran Rapports.
import { interp, LIMIT_RPM, type CarFiles } from "./config.js";

export interface ShiftRow {
  gear: number; // 1 = passage 1 → 2
  perf: number;
  cut: boolean; // en perf : tirer jusqu'au rupteur
  eco: number;
  landPerf: number;
  landEco: number;
}

export function shiftTable(files: CarFiles): ShiftRow[] {
  const K = files.ratios();
  const TQ = files.torque();
  const T = (r: number) => interp(TQ, r);
  const rows: ShiftRow[] = [];
  for (let g = 0; g < 5; g++) {
    let perf = LIMIT_RPM;
    let cut = true;
    // on passe quand la force à la roue du rapport suivant devient plus grande
    for (let r = 3000; r <= LIMIT_RPM; r += 25) {
      if (T(r) / K[g] <= T((r * K[g]) / K[g + 1]) / K[g + 1]) {
        perf = r;
        cut = false;
        break;
      }
    }
    const eco = Math.max(2200, Math.round((1700 * K[g + 1]) / K[g] / 50) * 50);
    rows.push({
      gear: g + 1,
      perf,
      cut,
      eco,
      landPerf: Math.round((perf * K[g]) / K[g + 1] / 10) * 10,
      landEco: Math.round((eco * K[g]) / K[g + 1] / 10) * 10,
    });
  }
  return rows;
}

/** Régime conseillé pour passer le rapport suivant, selon le mode (shift light). */
export function recommendedShift(files: CarFiles, mode: number, gear: number): number {
  const rows = shiftTable(files);
  const row = rows[Math.max(0, Math.min(4, (gear || 1) - 1))];
  if (mode === 0) return row.eco + 300;
  // un peu d'avance pour le temps de réaction
  return mode === 1 ? row.perf - 400 : row.perf - 150;
}

/** Courbes de force à la roue (pour l'écran Rapports). */
export function wheelCurves(files: CarFiles) {
  const K = files.ratios();
  const TQ = files.torque();
  return {
    ratios: K,
    torque: TQ,
    limit: LIMIT_RPM,
    learnedTorque: !!(files.learned.torque && files.learned.torque.length >= 4),
    learnedRatios: files.learned.ratios.filter((x) => x !== null).length,
  };
}
