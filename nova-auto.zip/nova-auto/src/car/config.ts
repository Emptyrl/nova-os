// Réglages de la voiture (voiture.json) et ce que Nova a appris d'elle (voiture-appris.json).
// Les deux fichiers sont lisibles et modifiables à la main dans le dossier de Nova.
import { promises as fs } from "node:fs";
import path from "node:path";

export type SourceName = "auto" | "elm327" | "kkl" | "me7logger" | "can" | "elmcan";
/** Une ou plusieurs sources : « auto », « elm327 », « kkl », « me7logger », « can », ou combinées : « can+kkl ». */
export type SourceSpec = string;
export type DriveMode = 0 | 1 | 2; // Normal, Sport, Attack

export interface CarConfig {
  source: SourceSpec;
  /** Port série : COM3 sous Windows, /dev/ttyUSB0 sous Linux. Vide = recherche automatique. */
  serialPort: string;
  baudRate: number; // ELM327 : 38400 la plupart du temps
  elmProtocol: string; // 0 = auto, 5 = KWP2000 rapide, 4 = KWP2000 lent, 3 = ISO 9141
  canInterface: string; // can0
  canRawLog: boolean; // garder toutes les trames CAN (pour décoder de nouveaux messages)
  /** ELM327 : « obd » = sur la prise OBD (ligne K), « can » = branché sur le bus CAN propulsion (écoute) */
  elmMode: "obd" | "can";
  /** ELM327 Wi-Fi : adresse:port (192.168.0.10:35000) ; vide = USB */
  elmHost: string;
  /** ELM327 Bluetooth : adresse de l'appareil associé (00:1D:A5:…) ; vide = USB */
  elmBt: string;
  kklCommand: string; // commande ME7Logger complète (optionnelle)
  kklCsvFile: string; // ou fichier CSV écrit par ME7Logger, lu au fil de l'eau
  // carburant
  fuelType: "E85" | "SP98";
  afr: number; // stœchiométrie : 9,8 en E85, 14,7 en SP98
  fuelDensity: number; // kg/L : 0,785 en E85, 0,745 en SP98
  tankLiters: number;
  // voiture
  massKg: number; // voiture + conducteur
  cdA: number; // m²
  odometerKm: number; // kilométrage au dernier réglage
  lastServiceKm: number;
  serviceIntervalKm: number;
  // logs
  logHz: number;
  autoLog: boolean; // enregistrer dès que le moteur tourne
  // seuils d'alerte
  waterWarn: number;
  waterCrit: number;
  oilWarn: number;
  oilCrit: number;
  boostMax: number; // bar relatifs
  voltLow: number;
  fuelLowL: number;
  // matériel (Raspberry Pi + NovaHAT)
  hardware: "auto" | "pi" | "absent";
  outIgnition: number; // GPIO du relais contact (borne 15)
  outStarter: number; // GPIO du relais démarreur (borne 50)
  outAux: number;
  inIgnition: number;
  inLights: number;
  inReverse: number;
  inHandbrake: number;
  ledPin: number;
  ledCount: number;
  fisEna: number;
  fisClk: number;
  fisData: number;
  fisInvert: boolean; // adaptateur à transistors : le niveau est inversé
  adcChannel: number; // ADS1115 : entrée de la tension batterie
  adcRatio: number; // pont diviseur (à étalonner au multimètre)
  // démarrage à distance
  remoteCrankMs: number;
  remoteTries: number;
  remoteStartRpm: number;
  remoteRunMinutes: number; // le moteur se coupe tout seul au bout de ce temps
  remoteRequireCan: boolean; // exige les vitesses de roue lues sur le CAN
  // alimentation
  autoShutdown: boolean;
  shutdownVolt: number;
  // affichage
  autoDashboard: boolean; // passe au tableau de bord quand le moteur démarre
  voiceFullscreen: boolean; // l'écran de veille s'affiche pendant que Nova parle ou écoute
  driverName: string;
}

export const DEFAULT_CAR: CarConfig = {
  source: "auto",
  serialPort: "",
  baudRate: 38400,
  elmProtocol: "0",
  canInterface: "can0",
  canRawLog: false,
  elmMode: "obd",
  elmHost: "",
  elmBt: "",
  kklCommand: "",
  kklCsvFile: "",
  fuelType: "E85",
  afr: 9.8,
  fuelDensity: 0.785,
  tankLiters: 62,
  massKg: 1480,
  cdA: 0.68,
  odometerKm: 214380,
  lastServiceKm: 0, // 0 = inconnu : pas de rappel de vidange
  serviceIntervalKm: 15000,
  logHz: 10,
  autoLog: true,
  waterWarn: 100,
  waterCrit: 105,
  oilWarn: 120,
  oilCrit: 135,
  boostMax: 1.3,
  voltLow: 12.2,
  fuelLowL: 8,
  hardware: "auto",
  outIgnition: 22,
  outStarter: 27,
  outAux: 4,
  inIgnition: 5,
  inLights: 26,
  inReverse: 13,
  inHandbrake: 19,
  ledPin: 18,
  ledCount: 30,
  fisEna: 23,
  fisClk: 24,
  fisData: 6,
  fisInvert: true,
  adcChannel: 0,
  adcRatio: 5.7,
  remoteCrankMs: 3000,
  remoteTries: 2,
  remoteStartRpm: 500,
  remoteRunMinutes: 10,
  remoteRequireCan: true,
  autoShutdown: true,
  shutdownVolt: 12.2,
  autoDashboard: true,
  voiceFullscreen: true,
  driverName: "Joan",
};

/** Ce que Nova apprend en roulant. */
export interface Learned {
  ratios: (number | null)[]; // km/h pour 1000 tr/min, rapports 1 à 6
  torque: [number, number][] | null; // courbe mesurée [tr/min, N·m]
  pulls: number;
  consoKm: number;
  consoBins: Record<string, { l: number; km: number }>; // "rapport:tranche" → litres, km
  fuelL: number; // carburant estimé dans le réservoir
  tripKm: number;
  tripFuelL: number;
  totalKm: number; // km parcourus depuis le réglage du compteur
}

export const DEFAULT_LEARNED: Learned = {
  ratios: [null, null, null, null, null, null],
  torque: null,
  pulls: 0,
  consoKm: 0,
  consoBins: {},
  fuelL: 38,
  tripKm: 0,
  tripFuelL: 0,
  totalKm: 0,
};

// Valeurs de référence du 1.8T 225 (BAM, boîte 6 vitesses 02M) en km/h pour 1000 tr/min.
export const REF_RATIOS = [8.0, 13.5, 19.5, 26, 32, 38];
export const REF_TORQUE: [number, number][] = [
  [1000, 150], [1800, 235], [2200, 280], [5500, 280], [5900, 267], [6500, 232], [7000, 195],
];
export const LIMIT_RPM = 6800;

export const MODES = [
  { name: "Normal", dot: "#D6DBE1", strat: "éco" as const, hal: 0.35, susp: "0 mm", wing: "rentré" },
  { name: "Sport", dot: "#4FD1E8", strat: "perf" as const, hal: 0.6, susp: "−20 mm", wing: "rentré" },
  { name: "Attack", dot: "#FF4D2E", strat: "perf" as const, hal: 0.9, susp: "−45 mm", wing: "sorti" },
];

async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    return { ...fallback, ...JSON.parse(await fs.readFile(file, "utf8")) };
  } catch {
    return { ...fallback };
  }
}

export class CarFiles {
  config: CarConfig = { ...DEFAULT_CAR };
  learned: Learned = { ...DEFAULT_LEARNED };
  private saveTimer: NodeJS.Timeout | null = null;

  constructor(private dir: string) {}

  get configFile() {
    return path.join(this.dir, "voiture.json");
  }
  get learnedFile() {
    return path.join(this.dir, "voiture-appris.json");
  }

  async load() {
    this.config = await readJson(this.configFile, DEFAULT_CAR);
    this.learned = await readJson(this.learnedFile, DEFAULT_LEARNED);
    await this.saveConfig();
  }

  async saveConfig() {
    await fs.writeFile(this.configFile, JSON.stringify(this.config, null, 2), "utf8");
  }

  /** Sauvegarde différée (le carburant et les km changent en permanence). */
  saveLearnedSoon() {
    if (this.saveTimer) return;
    this.saveTimer = setTimeout(() => {
      this.saveTimer = null;
      void this.saveLearned();
    }, 5000);
  }

  async saveLearned() {
    const tmp = this.learnedFile + ".tmp";
    await fs.writeFile(tmp, JSON.stringify(this.learned, null, 2), "utf8");
    await fs.rename(tmp, this.learnedFile);
  }

  async patch(p: Partial<CarConfig>) {
    for (const [k, v] of Object.entries(p)) {
      if (!(k in DEFAULT_CAR)) continue;
      const def = (DEFAULT_CAR as any)[k];
      if (typeof def === "number") {
        const n = Number(v);
        if (Number.isFinite(n)) (this.config as any)[k] = n;
      } else if (typeof def === "boolean") (this.config as any)[k] = !!v;
      else (this.config as any)[k] = String(v);
    }
    if (p.fuelType === "E85" && p.afr === undefined) {
      this.config.afr = 9.8;
      this.config.fuelDensity = 0.785;
    } else if (p.fuelType === "SP98" && p.afr === undefined) {
      this.config.afr = 14.7;
      this.config.fuelDensity = 0.745;
    }
    await this.saveConfig();
  }

  /** Rapports utilisés pour les calculs : appris quand c'est fait, sinon référence. */
  ratios(): number[] {
    return REF_RATIOS.map((r, i) => this.learned.ratios[i] ?? r);
  }

  torque(): [number, number][] {
    return this.learned.torque && this.learned.torque.length >= 4 ? this.learned.torque : REF_TORQUE;
  }
}

export function interp(table: [number, number][], x: number): number {
  if (x <= table[0][0]) return table[0][1];
  for (let i = 1; i < table.length; i++) {
    if (x <= table[i][0]) {
      const [a, b] = table[i - 1];
      const [c, d] = table[i];
      return b + ((d - b) * (x - a)) / (c - a);
    }
  }
  return table[table.length - 1][1];
}
