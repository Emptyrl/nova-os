// Gestion du câble KKL : un seul calculateur à la fois sur la ligne K.
// Sert à la fois au diagnostic (écran Calculateurs, outils de Nova) et à la lecture du moteur en direct
// (source « kkl »). Le diagnostic est prioritaire ; la lecture en direct reprend après.
import { promises as fs } from "node:fs";
import path from "node:path";
import { SerialPort } from "serialport";
import { KLine, Timeout, sleep } from "./link.js";
import { openSession, type Ident, type Session } from "./session.js";
import { MODULES, fieldLabel, hexAddr, type Fault } from "./modules.js";
import type { Field } from "./formulas.js";
import type { SignalStore } from "../signals.js";
import type { CarFiles } from "../config.js";

export interface LabeledField extends Field {
  label: string;
}

export interface ModuleState {
  addr: number;
  hex: string;
  name: string;
  short: string;
  status: "inconnu" | "absent" | "ok" | "defauts" | "erreur";
  protocol: string;
  ident: Ident | null;
  faults: Fault[] | null;
  groups: Record<number, { fields: LabeledField[]; at: number }>;
  error: string;
  at: number;
}

export interface TestStep {
  name: string;
  ok: boolean | null;
  detail: string;
}

export interface VagState {
  port: string;
  connected: number | null; // adresse du calculateur en dialogue
  protocol: string;
  busy: string; // opération en cours
  progress: { done: number; total: number } | null;
  live: boolean;
  liveError: string;
  test: { running: boolean; steps: TestStep[]; summary: string; advice: string; at: number } | null;
  echo: boolean | null;
}

const FTDI = /ftdi|ft232|prolific|ch34|wch|silicon|cp210|usb.?serial|kkl|vag/i;

export async function listPorts() {
  try {
    return await SerialPort.list();
  } catch {
    return [];
  }
}

/** Le câble répond-il comme un ELM327 ? */
export async function probeElm(path: string): Promise<string | null> {
  const port = new SerialPort({ path, baudRate: 38400, autoOpen: false });
  try {
    await new Promise<void>((res, rej) => port.open((e) => (e ? rej(e) : res())));
    let rx = "";
    port.on("data", (b: Buffer) => (rx += b.toString("latin1")));
    port.write("ATZ\r");
    const end = Date.now() + 1800;
    while (Date.now() < end && !/ELM/i.test(rx)) await sleep(50);
    const m = rx.match(/ELM\S*\s*v?[\d.]+/i);
    return m ? m[0].trim() : null;
  } catch {
    return null;
  } finally {
    if (port.isOpen) await new Promise<void>((r) => port.close(() => r()));
  }
}

export class VagManager {
  k = new KLine();
  private session: Session | null = null;
  private lastUse = 0;
  private chain: Promise<unknown> = Promise.resolve();
  private liveOn = false;
  private holdLiveUntil = 0;
  modules = new Map<number, ModuleState>();
  st: VagState = { port: "", connected: null, protocol: "", busy: "", progress: null, live: false, liveError: "", test: null, echo: null };
  /** Port ELM327 occupé par une autre source (impossible de l'ouvrir ici). */
  busyPort: () => string = () => "";

  constructor(
    private files: CarFiles,
    private store: SignalStore,
    private dataDir: string,
    private log: (t: string) => void,
    private onChange: () => void,
  ) {
    for (const m of MODULES) this.modules.set(m.addr, { ...m, hex: hexAddr(m.addr), status: "inconnu", protocol: "", ident: null, faults: null, groups: {}, error: "", at: 0 });
    // maintien de la communication (le calculateur raccroche après ~1 s de silence) et fin après 2 min d'inactivité
    setInterval(() => {
      if (!this.session || this.st.busy) return;
      const idle = Date.now() - this.lastUse;
      if (!this.liveOn && idle > 120000) void this.run("", () => this.endSession());
      else if (idle > 500) void this.run("", async () => this.session?.keepAlive().catch((e) => this.lost(e)));
    }, 600);
  }

  /** Les opérations passent une par une sur la ligne K. */
  private run<T>(label: string, fn: () => Promise<T>): Promise<T> {
    const go = async () => {
      if (label) {
        this.st.busy = label;
        this.onChange();
      }
      try {
        return await fn();
      } finally {
        if (label) {
          this.st.busy = "";
          this.st.progress = null;
          this.onChange();
        }
        this.lastUse = Date.now();
      }
    };
    const p = this.chain.then(go, go);
    this.chain = p.catch(() => {});
    return p;
  }

  private lost(e: any) {
    this.k.log("liaison perdue : " + (e?.message || e));
    this.session = null;
    this.st.connected = null;
    this.st.protocol = "";
    this.onChange();
  }

  async choosePort(): Promise<string> {
    const cfg = this.files.config.serialPort;
    if (cfg && /kkl|auto/.test(this.files.config.source)) return cfg;
    const list = await listPorts();
    const busy = this.busyPort();
    const free = list.filter((p) => p.path !== busy);
    const good = free.find((p) => FTDI.test(`${p.manufacturer ?? ""} ${(p as any).friendlyName ?? ""} ${p.pnpId ?? ""}`)) ?? free.find((p) => /ttyUSB|ttyACM|COM\d/i.test(p.path));
    if (!good) throw new Error(list.length ? "aucun câble KKL libre (le port est pris par l'ELM327 ?)" : "aucun câble détecté : branche le câble KKL et installe son pilote (FTDI ou CH340)");
    return good.path;
  }

  private async ensurePort() {
    if (this.k.isOpen) return;
    const p = await this.choosePort();
    await this.k.open(p, 10400);
    this.st.port = p;
  }

  private async endSession() {
    const s = this.session;
    this.session = null;
    this.st.connected = null;
    this.st.protocol = "";
    if (s) {
      await s.end();
      await sleep(1000); // le calculateur libère la ligne
    }
  }

  private async connect(addr: number, tries = 2): Promise<Session> {
    if (this.session?.addr === addr) return this.session;
    await this.endSession();
    await this.ensurePort();
    let last: any;
    for (let i = 0; i < tries; i++) {
      try {
        const { session, wake } = await openSession(this.k, addr);
        this.session = session;
        this.st.connected = addr;
        this.st.protocol = session.protocol;
        const m = this.modules.get(addr);
        if (m) {
          m.protocol = session.protocol;
          m.ident = session.ident;
          if (m.status === "inconnu" || m.status === "absent" || m.status === "erreur") m.status = "ok";
          m.error = "";
        }
        this.log(`Ligne K : ${hexAddr(addr)} connecté en ${session.protocol} (${wake.ms} ms) · ${session.ident.partNumber} ${session.ident.component}`);
        this.onChange();
        return session;
      } catch (e: any) {
        last = e;
        this.k.log(`essai ${i + 1} sur ${hexAddr(addr)} : ${e.message}`);
        await sleep(1200);
      }
    }
    throw last;
  }

  private mod(addr: number) {
    let m = this.modules.get(addr);
    if (!m) {
      m = { addr, hex: hexAddr(addr), name: `Calculateur ${hexAddr(addr)}`, short: hexAddr(addr), status: "inconnu", protocol: "", ident: null, faults: null, groups: {}, error: "", at: 0 };
      this.modules.set(addr, m);
    }
    return m;
  }

  private fail(addr: number, e: any) {
    const m = this.mod(addr);
    m.status = e instanceof Timeout ? "absent" : "erreur";
    m.error = e instanceof Timeout ? "ne répond pas" : String(e?.message || e);
    m.at = Date.now();
    this.session = null;
    this.st.connected = null;
    this.onChange();
  }

  private label(addr: number, group: number, fields: Field[]): LabeledField[] {
    return fields.map((f, i) => ({ ...f, label: fieldLabel(addr, group, i, f.unit) }));
  }

  // ---------------- opérations de diagnostic ----------------
  private hold() {
    this.holdLiveUntil = Date.now() + 20000;
  }

  ident(addr: number) {
    this.hold();
    return this.run(`Identification ${hexAddr(addr)}`, async () => {
      try {
        const s = await this.connect(addr);
        const m = this.mod(addr);
        m.ident = await s.readIdent();
        m.at = Date.now();
        this.onChange();
        return m;
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  faults(addr: number) {
    this.hold();
    return this.run(`Codes défaut ${hexAddr(addr)}`, async () => {
      try {
        const s = await this.connect(addr);
        const m = this.mod(addr);
        m.faults = await s.readFaults();
        m.status = m.faults.length ? "defauts" : "ok";
        m.at = Date.now();
        this.log(`Codes défaut ${hexAddr(addr)} : ${m.faults.length ? m.faults.map((f) => f.vag + (f.obd ? "/" + f.obd : "")).join(", ") : "aucun"}`);
        this.onChange();
        return m.faults;
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  clear(addr: number) {
    this.hold();
    return this.run(`Effacement ${hexAddr(addr)}`, async () => {
      const s = await this.connect(addr);
      await s.clearFaults();
      this.log(`Codes défaut effacés : ${hexAddr(addr)}`);
      const m = this.mod(addr);
      m.faults = await s.readFaults();
      m.status = m.faults.length ? "defauts" : "ok";
      this.onChange();
      return m.faults;
    });
  }

  group(addr: number, n: number) {
    this.hold();
    return this.run(this.session?.addr === addr ? "" : `Connexion ${hexAddr(addr)}`, async () => {
      try {
        const s = await this.connect(addr);
        const f = await s.readGroup(n);
        const m = this.mod(addr);
        if (f) m.groups[n] = { fields: this.label(addr, n, f), at: Date.now() };
        else delete m.groups[n];
        this.onChange();
        return f ? m.groups[n].fields : null;
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  /** Lit tous les groupes de mesure d'un calculateur (1 à 255) et enregistre un rapport. */
  readAll(addr: number, from = 1, to = 255) {
    this.hold();
    return this.run(`Lecture complète ${hexAddr(addr)}`, async () => {
      const m = this.mod(addr);
      try {
        const s = await this.connect(addr);
        this.st.progress = { done: 0, total: to - from + 1 };
        let found = 0;
        for (let n = from; n <= to; n++) {
          this.hold();
          const f = await s.readGroup(n);
          if (f && f.length) {
            m.groups[n] = { fields: this.label(addr, n, f), at: Date.now() };
            found++;
          }
          this.st.progress = { done: n - from + 1, total: to - from + 1 };
          if (n % 4 === 0) this.onChange();
        }
        this.log(`Lecture complète ${hexAddr(addr)} : ${found} groupes`);
        const file = await this.saveReport([m], `groupes_${m.hex}`);
        this.onChange();
        return { found, file };
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  /** Scan de tous les calculateurs : identification et codes défaut. */
  scan() {
    this.hold();
    return this.run("Scan de tous les calculateurs", async () => {
      const list = [...this.modules.values()];
      this.st.progress = { done: 0, total: list.length };
      for (let i = 0; i < list.length; i++) {
        const m = list[i];
        this.hold();
        try {
          const s = await this.connect(m.addr, m.addr === 0x01 ? 2 : 1);
          m.faults = await s.readFaults();
          m.status = m.faults.length ? "defauts" : "ok";
          m.at = Date.now();
          await this.endSession();
        } catch (e) {
          this.fail(m.addr, e);
          await sleep(500);
        }
        this.st.progress = { done: i + 1, total: list.length };
        this.onChange();
      }
      const present = list.filter((m) => m.status === "ok" || m.status === "defauts");
      const nf = present.reduce((a, m) => a + (m.faults?.length ?? 0), 0);
      this.log(`Scan : ${present.length} calculateurs, ${nf} code(s) défaut`);
      const file = await this.saveReport(present, "scan");
      return { present: present.length, faults: nf, file };
    });
  }

  async saveReport(mods: ModuleState[], prefix: string) {
    const dir = path.join(this.dataDir, "diagnostics");
    await fs.mkdir(dir, { recursive: true });
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
    const base = path.join(dir, `${prefix}_${stamp}`);
    await fs.writeFile(base + ".json", JSON.stringify(mods, null, 1));
    const rows = ["calculateur;adresse;groupe;champ;libelle;valeur;unite;type;a;b"];
    for (const m of mods)
      for (const [g, v] of Object.entries(m.groups))
        v.fields.forEach((f, i) => rows.push([m.name, m.hex, g.padStart(3, "0"), i + 1, f.label, f.text, f.unit, f.type, f.a, f.b].join(";")));
    for (const m of mods) for (const f of m.faults ?? []) rows.push([m.name, m.hex, "défaut", f.vag, `${f.obd} ${f.text}`.trim(), f.elaboration + (f.sporadic ? " (sporadique)" : ""), "", "", "", ""].join(";"));
    await fs.writeFile(base + ".csv", rows.join("\n"), "utf8");
    return path.basename(base) + ".csv";
  }

  // ---------------- test de connexion ----------------
  test() {
    this.hold();
    return this.run("Test de connexion", async () => {
      const steps: TestStep[] = [];
      const t = { running: true, steps, summary: "", advice: "", at: Date.now() };
      this.st.test = t;
      const step = (name: string, ok: boolean | null, detail: string) => {
        steps.push({ name, ok, detail });
        this.k.log(`test · ${name} : ${ok === null ? "…" : ok ? "OK" : "ÉCHEC"} ${detail}`);
        this.onChange();
      };
      const finish = (summary: string, advice = "") => {
        t.running = false;
        t.summary = summary;
        t.advice = advice;
        this.log(`Test de connexion : ${summary}${advice ? " — " + advice : ""}`);
        this.onChange();
        return t;
      };
      await this.endSession();
      await this.k.close();
      const ports = await listPorts();
      const forced = /kkl|auto/.test(this.files.config.source) ? this.files.config.serialPort : "";
      step("Ports série", ports.length > 0 || !!forced, [...ports.map((p) => `${p.path}${p.manufacturer ? " (" + p.manufacturer + ")" : ""}`), ...(forced && !ports.some((p) => p.path === forced) ? [forced + " (réglé à la main)"] : [])].join(", ") || "aucun");
      if (!ports.length && !forced) return finish("Aucun câble détecté.", "Branche le câble sur le PC. Sous Windows, vérifie dans le Gestionnaire de périphériques qu'il apparaît dans « Ports (COM et LPT) » ; sinon installe le pilote FTDI ou CH340.");
      const busy = this.busyPort();
      let portPath: string;
      try {
        portPath = await this.choosePort();
      } catch (e: any) {
        if (busy) {
          step("Câble ELM327", true, `${busy} : utilisé en ce moment par la lecture OBD`);
          return finish("L'ELM327 est connecté et lu par Nova.", "Le diagnostic complet des calculateurs (ABS, airbags, combiné…) demande le câble KKL : branche-le à la place de l'ELM327, source « KKL » ou « Auto ».");
        }
        return finish(e.message, "Indique le port du câble dans Réglages → Voiture.");
      }
      const info = ports.find((p) => p.path === portPath);
      step("Câble choisi", true, `${portPath}${info?.manufacturer ? " · " + info.manufacturer : ""}`);
      const elm = this.k.testMode ? null : await probeElm(portPath);
      if (elm) {
        step("Type de câble", true, `ELM327 (${elm})`);
        return finish("C'est un ELM327 : il lit les données OBD du moteur, pas les autres calculateurs.", "Mets la source sur « ELM327 » ou « Auto ». Pour le diagnostic complet, utilise le câble KKL.");
      }
      step("Type de câble", true, "KKL (ligne K directe)");
      try {
        await this.k.open(portPath, 10400);
        this.st.port = portPath;
      } catch (e: any) {
        step("Ouverture du port à 10 400 bauds", false, e.message);
        return finish("Impossible d'ouvrir le port.", "Ferme VCDS, ME7Logger ou tout autre logiciel qui utilise le câble, puis réessaie.");
      }
      step("Ouverture du port à 10 400 bauds", true, "");
      // écho : le câble doit renvoyer ce qu'il émet quand la prise OBD est alimentée
      this.k.flush();
      let echo = false;
      if (this.k.testMode) echo = true;
      else {
        await new Promise<void>((res) => this.k.port!.write(Buffer.from([0x55]), () => res()));
        try {
          echo = (await this.k.readByte(300, "écho")) === 0x55;
        } catch {
          echo = false;
        }
      }
      this.st.echo = echo;
      step("Écho de la ligne K", echo, echo ? "le câble est alimenté par la prise OBD" : "rien reçu");
      if (!echo) return finish("Le câble ne reçoit pas son propre écho.", "Vérifie qu'il est bien enfoncé dans la prise OBD (sous le volant) et que la prise a du 12 V (broche 16, fusible). Sans 12 V, l'interface du câble ne fonctionne pas.");
      try {
        const { session, wake } = await openSession(this.k, 0x01);
        this.session = session;
        this.st.connected = 1;
        this.st.protocol = session.protocol;
        step("Réveil du calculateur moteur (adresse 01, 5 bauds)", true, `réponse en ${wake.ms} ms`);
        step("Synchro et mots-clés", true, `55 · ${wake.kw1.toString(16).toUpperCase()} ${wake.kw2.toString(16).toUpperCase()} → ${session.protocol}`);
        const m = this.mod(1);
        m.protocol = session.protocol;
        m.ident = session.ident;
        step("Identification", !!session.ident.partNumber, `${session.ident.partNumber} ${session.ident.component}`.trim() || "vide");
        const g = await session.readGroup(1);
        if (g) m.groups[1] = { fields: this.label(1, 1, g), at: Date.now() };
        step("Lecture du groupe 001", !!g, g ? g.map((f) => `${f.text} ${f.unit}`.trim()).join(" · ") : "refusée");
        const f = await session.readFaults();
        m.faults = f;
        m.status = f.length ? "defauts" : "ok";
        step("Codes défaut moteur", true, f.length ? `${f.length} : ${f.map((x) => x.obd || x.vag).join(", ")}` : "aucun");
        return finish(`Connexion à la voiture réussie (${session.protocol}).`);
      } catch (e: any) {
        step("Réveil du calculateur moteur (adresse 01, 5 bauds)", false, e.message);
        return finish("Le calculateur moteur ne répond pas.", "Mets le contact (moteur tournant ou non). Ferme VCDS ou ME7Logger. Dans le Gestionnaire de périphériques, mets la « latence » du port FTDI à 1 ms. Les câbles à puce CH340 gèrent mal les 10 400 bauds : un câble FTDI est plus sûr.");
      }
    });
  }

  // ---------------- lecture du moteur en direct (source « kkl ») ----------------
  private static LIVE = [3, 115, 2, 4, 3, 115, 5, 20, 3, 115, 31, 1, 3, 115, 32];

  startLive() {
    if (this.liveOn) return;
    this.liveOn = true;
    void this.liveLoop();
  }

  stopLive() {
    this.liveOn = false;
    this.st.live = false;
  }

  private async liveLoop() {
    let i = 0;
    let fails = 0;
    while (this.liveOn) {
      if (Date.now() < this.holdLiveUntil || this.st.busy) {
        if (this.st.live) {
          this.st.live = false;
          this.onChange();
        }
        await sleep(500);
        continue;
      }
      const g = VagManager.LIVE[i++ % VagManager.LIVE.length];
      try {
        await this.run("", async () => {
          const s = await this.connect(0x01);
          const f = await s.readGroup(g);
          if (f) {
            this.applyEngine(g, f);
            this.mod(1).groups[g] = { fields: this.label(1, g, f), at: Date.now() };
          }
        });
        fails = 0;
        if (!this.st.live || this.st.liveError) {
          this.st.live = true;
          this.st.liveError = "";
          this.onChange();
        }
      } catch (e: any) {
        fails++;
        this.st.live = false;
        this.st.liveError = e instanceof Timeout ? "le calculateur moteur ne répond pas (contact coupé ?)" : String(e?.message || e);
        this.session = null;
        this.st.connected = null;
        this.onChange();
        await sleep(Math.min(10000, 1500 * fails));
      }
    }
  }

  /** Groupes du ME7.5 → mesures de Nova (seulement si l'unité est celle attendue). */
  private applyEngine(g: number, f: Field[]) {
    const v: Record<string, number> = {};
    const take = (i: number, key: string, unit: string | RegExp, conv = (x: number) => x) => {
      const x = f[i];
      if (!x || x.value === null) return;
      if (typeof unit === "string" ? x.unit === unit : unit.test(x.unit)) v[key] = conv(x.value);
    };
    take(0, "rpm", "tr/min");
    if (g === 1) take(1, "water", "°C");
    if (g === 2) {
      take(1, "load", "%");
      take(3, "maf", "g/s");
    }
    if (g === 3) {
      take(1, "maf", "g/s");
      take(2, "throttle", /^(%|°)$/);
      take(3, "timing", "°");
    }
    if (g === 4) {
      take(1, "volt", "V");
      take(2, "water", "°C");
      take(3, "iat", "°C");
    }
    if (g === 5) {
      take(1, "load", "%");
      take(2, "speed", "km/h");
    }
    if (g === 20) {
      for (let k = 0; k < 4; k++) take(k, "knock" + (k + 1), /°/, (x) => Math.abs(x));
      const ks = [v.knock1, v.knock2, v.knock3, v.knock4].filter((x) => x !== undefined);
      if (ks.length) v.knock = Math.max(...ks);
    }
    if (g === 31) take(0, "lambda", /^$/);
    if (g === 32) take(1, "ltft", "%");
    if (g === 115) {
      take(1, "load", "%");
      take(2, "boostReq", "mbar", (x) => (x - 1013) / 1000);
      take(3, "boost", "mbar", (x) => (x - 1013) / 1000);
    }
    this.store.set(v);
  }

  view() {
    return {
      ...this.st,
      modules: [...this.modules.values()],
      trace: this.k.trace.slice(-40),
    };
  }
}
