// Gestion du câble KKL : un seul calculateur à la fois sur la ligne K.
// Sert à la fois au diagnostic (écran Calculateurs, outils de Nova) et à la lecture du moteur en direct
// (source « kkl »). Le diagnostic est prioritaire ; la lecture en direct reprend après.
import { promises as fs } from "node:fs";
import path from "node:path";
import { listCablePorts, probeElm as probeElmFull, describePort } from "../cables.js";
import { KLine, Timeout, sleep } from "./link.js";
import { openSession, type Ident, type Session } from "./session.js";
import { MODULES, fieldLabel, hexAddr, VAG_TEXT, type Fault } from "./modules.js";
import { Labels, checkSpec, decodeCoding, type ModuleLabels } from "./labels.js";
import type { Field } from "./formulas.js";
import type { SignalStore } from "../signals.js";
import type { CarFiles } from "../config.js";

export interface LabeledField extends Field {
  label: string;
  /** texte complet du fichier de libellés (plage, spécification) */
  help?: string;
  spec?: string;
  inSpec?: boolean | null;
  bitsText?: string[];
}

export interface ModuleCatalog {
  lbl: ModuleLabels;
  measuring: { grp: number; title: string }[];
  basic: { grp: number; title: string }[];
  adaptation: { channel: number; title: string; lines: string[] }[];
  coding: ReturnType<typeof decodeCoding> | null;
  login: string[];
}

export interface ModuleState {
  addr: number;
  hex: string;
  name: string;
  short: string;
  status: "inconnu" | "absent" | "ok" | "defauts" | "erreur";
  protocol: string;
  ident: Ident | null;
  faults: Fault[] | null;
  groups: Record<number, { fields: LabeledField[]; at: number; title?: string }>;
  basic?: Record<number, { fields: LabeledField[]; at: number; title?: string }>;
  outputs?: { code: number; text: string; at: number }[];
  catalog?: ModuleCatalog | null;
  error: string;
  at: number;
}

export interface TestStep {
  name: string;
  ok: boolean | null;
  detail: string;
}

export interface VagState {
  port: string;
  connected: number | null; // adresse du calculateur en dialogue
  protocol: string;
  busy: string; // opération en cours
  progress: { done: number; total: number } | null;
  live: boolean;
  liveError: string;
  test: { running: boolean; steps: TestStep[]; summary: string; advice: string; at: number } | null;
  echo: boolean | null;
  reconnecting?: boolean;
  drops?: number;
}

// la détection des câbles est commune à toutes les sources (voir cables.ts)
export async function listPorts() {
  return listCablePorts();
}
export const probeElm = (path: string) => probeElmFull(path);

export class VagManager {
  k = new KLine();
  private session: Session | null = null;
  private lastUse = 0;
  private chain: Promise<unknown> = Promise.resolve();
  private liveOn = false;
  private holdLiveUntil = 0;
  modules = new Map<number, ModuleState>();
  st: VagState = { port: "", connected: null, protocol: "", busy: "", progress: null, live: false, liveError: "", test: null, echo: null };
  /** Port ELM327 occupé par une autre source (impossible de l'ouvrir ici). */
  busyPort: () => string = () => "";

  constructor(
    private files: CarFiles,
    private store: SignalStore,
    private dataDir: string,
    private log: (t: string) => void,
    private onChange: () => void,
  ) {
    this.labels = new Labels(this.dataDir);
    void this.labels.load();
    for (const m of MODULES) this.modules.set(m.addr, { ...m, hex: hexAddr(m.addr), status: "inconnu", protocol: "", ident: null, faults: null, groups: {}, error: "", at: 0 });
    // maintien de la communication (le calculateur raccroche après ~1 s de silence) et fin après 2 min d'inactivité
    // vérifié toutes les 100 ms : jamais plus de ~0,45 s de silence (avant : jusqu'à 1,1 s, et le calculateur
    // raccrochait de temps en temps pendant la lecture en direct)
    setInterval(() => {
      if (!this.session || this.st.busy || this.queued > 0) return;
      const idle = Date.now() - this.lastUse;
      if (!this.liveOn && idle > 120000 && Date.now() > this.holdLiveUntil) void this.run("", () => this.endSession());
      else if (idle > 350) {
        this.lastUse = Date.now(); // évite un second maintien en file
        void this.run("", async () => this.session?.keepAlive().catch((e) => this.lost(e)));
      }
    }, 100);
  }

  /** Les opérations passent une par une sur la ligne K. */
  private queued = 0;
  private run<T>(label: string, fn: () => Promise<T>): Promise<T> {
    this.queued++;
    const go = async () => {
      this.queued--;
      if (label) {
        this.st.busy = label;
        this.onChange();
      }
      try {
        return await fn();
      } finally {
        if (label) {
          this.st.busy = "";
          this.st.progress = null;
          this.onChange();
        }
        this.lastUse = Date.now();
      }
    };
    const p = this.chain.then(go, go);
    this.chain = p.catch(() => {});
    return p;
  }

  private lost(e: any) {
    this.k.log("liaison perdue : " + (e?.message || e));
    this.lossAt = Date.now();
    this.session = null;
    this.st.connected = null;
    this.st.protocol = "";
    this.onChange();
  }

  /** Port trouvé par la détection automatique (source « auto »). */
  autoPort = "";

  async choosePort(): Promise<string> {
    const cfg = this.files.config.serialPort;
    if (cfg && /kkl/.test(this.files.config.source)) return cfg;
    if (this.autoPort) return this.autoPort;
    if (cfg && /auto/.test(this.files.config.source)) return cfg;
    const list = await listPorts();
    const busy = this.busyPort();
    const free = list.filter((p) => p.path !== busy);
    // FTDI d'abord (câbles VAG-COM 409.1), puis CH340 / PL2303 / CP210x, puis tout ttyUSB
    const good = free.find((p) => p.vid === "0403") ?? free.find((p) => !!p.chip && p.chip !== "Bluetooth") ?? free.find((p) => /ttyUSB|COM\d/i.test(p.path));
    if (!good) throw new Error(list.length ? "aucun câble KKL libre (le port est pris par l'ELM327 ?)" : "aucun câble détecté : branche le câble KKL et installe son pilote (FTDI ou CH340)");
    return good.path;
  }

  private async ensurePort() {
    if (this.k.isOpen) return;
    const p = await this.choosePort();
    await this.k.open(p, 10400);
    this.st.port = p;
  }

  private async endSession() {
    const s = this.session;
    this.session = null;
    this.st.connected = null;
    this.st.protocol = "";
    if (s) {
      await s.end();
      await sleep(1000); // le calculateur libère la ligne
    }
  }

  private async connect(addr: number, tries = 2): Promise<Session> {
    if (this.session?.addr === addr) return this.session;
    await this.endSession();
    await this.ensurePort();
    // après une liaison perdue, le calculateur attend ~2,5 s de silence avant d'accepter un nouveau réveil
    const quiet = 2600 - (Date.now() - this.lossAt);
    if (quiet > 0) await sleep(quiet);
    this.k.flush();
    let last: any;
    for (let i = 0; i < tries; i++) {
      try {
        const { session, wake } = await openSession(this.k, addr);
        this.session = session;
        this.st.connected = addr;
        this.st.protocol = session.protocol;
        const m = this.modules.get(addr);
        if (m) {
          m.protocol = session.protocol;
          m.ident = session.ident;
          if (m.status === "inconnu" || m.status === "absent" || m.status === "erreur") m.status = "ok";
          m.error = "";
          this.catalog(addr);
          if (m.catalog) this.k.log(`libellés de ${hexAddr(addr)} : ${m.catalog.lbl.file} (${m.catalog.lbl.via})`);
        }
        this.log(`Ligne K : ${hexAddr(addr)} connecté en ${session.protocol} (${wake.ms} ms) · ${session.ident.partNumber} ${session.ident.component}`);
        this.onChange();
        return session;
      } catch (e: any) {
        last = e;
        this.k.log(`essai ${i + 1} sur ${hexAddr(addr)} : ${e.message}`);
        await sleep(1200);
      }
    }
    throw last;
  }

  private mod(addr: number) {
    let m = this.modules.get(addr);
    if (!m) {
      m = { addr, hex: hexAddr(addr), name: `Calculateur ${hexAddr(addr)}`, short: hexAddr(addr), status: "inconnu", protocol: "", ident: null, faults: null, groups: {}, error: "", at: 0 };
      this.modules.set(addr, m);
    }
    return m;
  }

  private lossAt = 0;
  private fail(addr: number, e: any) {
    this.k.log(`erreur avec ${hexAddr(addr)} : ${e?.message || e}`);
    // un calculateur absent (pas de synchro au réveil) laisse la ligne libre ; sinon on attend qu'il raccroche
    if (!/synchro/i.test(String(e?.message || ""))) this.lossAt = Date.now();
    const m = this.mod(addr);
    m.status = e instanceof Timeout ? "absent" : "erreur";
    m.error = e instanceof Timeout ? "ne répond pas" : String(e?.message || e);
    m.at = Date.now();
    this.session = null;
    this.st.connected = null;
    this.onChange();
  }

  /** Base de libellés (base_diagnostic.sqlite posée par l'utilisateur), facultative. */
  labels!: Labels;

  /** Fichier de libellés du calculateur, d'après son identification. */
  private lblOf(addr: number): ModuleLabels | null {
    const m = this.modules.get(addr);
    if (!this.labels.ready || !m?.ident?.partNumber) return null;
    return this.labels.find(m.ident.partNumber, addr, "8N", m.ident.component);
  }

  /** Remplit le catalogue d'un calculateur : groupes nommés, réglages de base, adaptation, codage décodé. */
  private catalog(addr: number) {
    const m = this.mod(addr);
    const l = this.lblOf(addr);
    if (!l) {
      m.catalog = null;
      return;
    }
    const codingLines = this.labels.text(l.file, "coding");
    m.catalog = {
      lbl: l,
      measuring: this.labels.groups(l.file, "measuring_block"),
      basic: this.labels.groups(l.file, "basic_setting"),
      adaptation: this.labels.adaptation(l.file),
      coding: codingLines.length ? decodeCoding(codingLines, m.ident?.coding ?? null) : null,
      login: this.labels.text(l.file, "prefix_L"),
    };
  }

  refreshCatalogs() {
    for (const m of this.modules.values()) if (m.ident) this.catalog(m.addr);
    this.onChange();
  }

  private context(): string[] {
    const rpm = this.store.get("rpm") ?? 0;
    const water = this.store.get("water") ?? 0;
    const c: string[] = [];
    if (rpm > 0 && rpm < 1100) c.push("idle", "ralenti");
    if (water >= 80) c.push("warm");
    if (rpm > 2500) c.push("load");
    return c;
  }

  private label(addr: number, group: number, fields: Field[], type: "measuring_block" | "basic_setting" = "measuring_block"): LabeledField[] {
    const l = this.lblOf(addr);
    const g = l ? this.labels.group(l.file, type, group) ?? (type === "basic_setting" ? this.labels.group(l.file, "measuring_block", group) : null) : null;
    const ctx = this.context();
    return fields.map((f, i) => {
      const base: LabeledField = { ...f, label: fieldLabel(addr, group, i, f.unit) };
      const fl = g?.fields.find((x) => x.field === i + 1);
      if (!fl) return base;
      base.label = [fl.name, fl.sub].filter(Boolean).join(" ") || base.label;
      base.help = fl.description;
      const chk = checkSpec(f.value, fl.specs, ctx);
      if (chk) {
        base.inSpec = chk.ok;
        base.spec = (chk.spec.when ? chk.spec.when + " : " : "") + chk.spec.text;
      } else if (fl.specs[0]) base.spec = (fl.specs[0].when ? fl.specs[0].when + " : " : "") + fl.specs[0].text;
      // champs en bits : signification des bits à 1
      if (fl.bits.length && /^[01]{8}$/.test(f.text)) {
        base.bitsText = fl.bits.filter((b) => b.mask.length === f.text.length && [...b.mask].every((c, k) => c === "x" || c === f.text[k])).map((b) => b.text);
      }
      return base;
    });
  }

  private groupTitle(addr: number, n: number, type: "measuring_block" | "basic_setting" = "measuring_block") {
    const l = this.lblOf(addr);
    return l ? this.labels.group(l.file, type, n)?.title || "" : "";
  }

  // ---------------- opérations de diagnostic ----------------
  private hold() {
    this.holdLiveUntil = Date.now() + 20000;
  }

  ident(addr: number) {
    this.hold();
    return this.run(`Identification ${hexAddr(addr)}`, async () => {
      try {
        const s = await this.connect(addr);
        const m = this.mod(addr);
        m.ident = await s.readIdent();
        m.at = Date.now();
        this.onChange();
        return m;
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  faults(addr: number) {
    this.hold();
    return this.run(`Codes défaut ${hexAddr(addr)}`, async () => {
      try {
        const s = await this.connect(addr);
        const m = this.mod(addr);
        m.faults = await s.readFaults();
        m.status = m.faults.length ? "defauts" : "ok";
        m.at = Date.now();
        this.log(`Codes défaut ${hexAddr(addr)} : ${m.faults.length ? m.faults.map((f) => f.vag + (f.obd ? "/" + f.obd : "")).join(", ") : "aucun"}`);
        this.onChange();
        return m.faults;
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  clear(addr: number) {
    this.hold();
    return this.run(`Effacement ${hexAddr(addr)}`, async () => {
      const s = await this.connect(addr);
      await s.clearFaults();
      this.log(`Codes défaut effacés : ${hexAddr(addr)}`);
      const m = this.mod(addr);
      m.faults = await s.readFaults();
      m.status = m.faults.length ? "defauts" : "ok";
      this.onChange();
      return m.faults;
    });
  }

  private groupPending = "";
  group(addr: number, n: number) {
    this.hold();
    // l'écran redemande la mesure toutes les 0,7 s : on ne garde qu'une demande en attente
    const key = addr + ":" + n;
    if (this.groupPending === key) return Promise.resolve(this.mod(addr).groups[n]?.fields ?? null);
    this.groupPending = key;
    return this.run(this.session?.addr === addr ? "" : `Connexion ${hexAddr(addr)}`, async () => {
      try {
        let f;
        try {
          const s = await this.connect(addr);
          f = await s.readGroup(n);
        } catch (e: any) {
          // liaison coupée : on se reconnecte et on relit une fois, sans faire clignoter l'écran
          if (/synchro/i.test(String(e?.message || ""))) throw e;
          this.k.log(`lecture du groupe ${n} sur ${hexAddr(addr)} interrompue (${e?.message || e}) : reconnexion`);
          this.session = null;
          this.st.connected = null;
          this.lossAt = Date.now();
          this.st.reconnecting = true;
          this.onChange();
          try {
            const s = await this.connect(addr);
            f = await s.readGroup(n);
          } finally {
            this.st.reconnecting = false;
          }
        }
        const m = this.mod(addr);
        if (f) m.groups[n] = { fields: this.label(addr, n, f), at: Date.now(), title: this.groupTitle(addr, n) };
        else delete m.groups[n];
        this.onChange();
        return f ? m.groups[n].fields : null;
      } catch (e) {
        this.fail(addr, e);
        throw e;
      } finally {
        if (this.groupPending === key) this.groupPending = "";
      }
    });
  }

  /**
   * Réglage de base (KW1281, titre 0x28) : le calculateur lance la procédure du groupe (ex. 060 : adaptation
   * du papillon du ME7.5) tant qu'on le lui redemande, et renvoie les valeurs du groupe à chaque fois.
   */
  basicSetting(addr: number, n: number) {
    this.hold();
    if (this.store.moving) return Promise.reject(new Error("Réglage de base : à l'arrêt seulement."));
    const key = "b" + addr + ":" + n;
    if (this.groupPending === key) return Promise.resolve(this.mod(addr).basic?.[n]?.fields ?? null);
    this.groupPending = key;
    return this.run(this.session?.addr === addr ? "" : `Connexion ${hexAddr(addr)}`, async () => {
      try {
        const s = await this.connect(addr);
        if (!s.basicSetting) throw new Error(`réglage de base pas encore géré en ${s.protocol} (seulement KW1281)`);
        const f = await s.basicSetting(n);
        const m = this.mod(addr);
        m.basic ??= {};
        if (f) {
          if (!m.basic[n]) this.log(`Réglage de base ${hexAddr(addr)} groupe ${String(n).padStart(3, "0")} lancé`);
          m.basic[n] = { fields: this.label(addr, n, f, "basic_setting"), at: Date.now(), title: this.groupTitle(addr, n, "basic_setting") || this.groupTitle(addr, n) };
        } else delete m.basic[n];
        this.onChange();
        return f ? m.basic[n].fields : null;
      } catch (e) {
        this.fail(addr, e);
        throw e;
      } finally {
        if (this.groupPending === key) this.groupPending = "";
      }
    });
  }

  /** Fin du réglage de base : on revient en lecture normale du même groupe (le calculateur arrête la procédure). */
  basicStop(addr: number, n: number) {
    return this.group(addr, n).catch(() => null);
  }

  /**
   * Test des actionneurs (KW1281, titre 0x04) : chaque appel fait fonctionner l'actionneur suivant
   * (injecteurs, électrovannes, ventilateur…). Moteur arrêté, contact mis.
   */
  outputTest(addr: number) {
    this.hold();
    if ((this.store.get("rpm") ?? 0) > 50) return Promise.reject(new Error("Test des actionneurs : moteur arrêté seulement (contact mis)."));
    if (this.store.moving) return Promise.reject(new Error("Test des actionneurs : à l'arrêt seulement."));
    return this.run(`Test des actionneurs ${hexAddr(addr)}`, async () => {
      const m = this.mod(addr);
      try {
        const s = await this.connect(addr);
        if (!s.outputTest) throw new Error(`test des actionneurs pas encore géré en ${s.protocol} (seulement KW1281)`);
        const r = await s.outputTest();
        m.outputs ??= [];
        if (!r) {
          m.outputs.push({ code: 0, text: "Fin du test des actionneurs", at: Date.now() });
          this.log(`Test des actionneurs ${hexAddr(addr)} terminé`);
          // le calculateur termine la séquence : on repart d'une session propre
          await this.endSession();
        } else {
          const text = VAG_TEXT[r.code] || "Actionneur " + String(r.code).padStart(5, "0");
          m.outputs.push({ code: r.code, text, at: Date.now() });
          this.log(`Test des actionneurs ${hexAddr(addr)} : ${String(r.code).padStart(5, "0")} ${text}`);
        }
        if (m.outputs.length > 30) m.outputs.splice(0, m.outputs.length - 30);
        this.onChange();
        return m.outputs[m.outputs.length - 1];
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  /** Lit tous les groupes de mesure d'un calculateur (1 à 255) et enregistre un rapport. */
  readAll(addr: number, from = 1, to = 255) {
    this.hold();
    return this.run(`Lecture complète ${hexAddr(addr)}`, async () => {
      const m = this.mod(addr);
      try {
        const s = await this.connect(addr);
        this.st.progress = { done: 0, total: to - from + 1 };
        let found = 0;
        for (let n = from; n <= to; n++) {
          this.hold();
          const f = await s.readGroup(n);
          if (f && f.length) {
            m.groups[n] = { fields: this.label(addr, n, f), at: Date.now(), title: this.groupTitle(addr, n) };
            found++;
          }
          this.st.progress = { done: n - from + 1, total: to - from + 1 };
          if (n % 4 === 0) this.onChange();
        }
        this.log(`Lecture complète ${hexAddr(addr)} : ${found} groupes`);
        const file = await this.saveReport([m], `groupes_${m.hex}`);
        this.onChange();
        return { found, file };
      } catch (e) {
        this.fail(addr, e);
        throw e;
      }
    });
  }

  /** Scan de tous les calculateurs : identification et codes défaut. */
  scan() {
    this.hold();
    return this.run("Scan de tous les calculateurs", async () => {
      const list = [...this.modules.values()];
      this.st.progress = { done: 0, total: list.length };
      for (let i = 0; i < list.length; i++) {
        const m = list[i];
        this.hold();
        try {
          const s = await this.connect(m.addr, m.addr === 0x01 ? 2 : 1);
          m.faults = await s.readFaults();
          m.status = m.faults.length ? "defauts" : "ok";
          m.at = Date.now();
          await this.endSession();
        } catch (e) {
          this.fail(m.addr, e);
          await sleep(500);
        }
        this.st.progress = { done: i + 1, total: list.length };
        this.onChange();
      }
      const present = list.filter((m) => m.status === "ok" || m.status === "defauts");
      const nf = present.reduce((a, m) => a + (m.faults?.length ?? 0), 0);
      this.log(`Scan : ${present.length} calculateurs, ${nf} code(s) défaut`);
      const file = await this.saveReport(present, "scan");
      return { present: present.length, faults: nf, file };
    });
  }

  async saveReport(mods: ModuleState[], prefix: string) {
    const dir = path.join(this.dataDir, "diagnostics");
    await fs.mkdir(dir, { recursive: true });
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
    const base = path.join(dir, `${prefix}_${stamp}`);
    await fs.writeFile(base + ".json", JSON.stringify(mods, null, 1));
    const rows = ["calculateur;adresse;groupe;champ;libelle;valeur;unite;type;a;b"];
    for (const m of mods)
      for (const [g, v] of Object.entries(m.groups))
        v.fields.forEach((f, i) => rows.push([m.name, m.hex, g.padStart(3, "0"), i + 1, f.label, f.text, f.unit, f.type, f.a, f.b].join(";")));
    for (const m of mods) for (const f of m.faults ?? []) rows.push([m.name, m.hex, "défaut", f.vag, `${f.obd} ${f.text}`.trim(), f.elaboration + (f.sporadic ? " (sporadique)" : ""), "", "", "", ""].join(";"));
    await fs.writeFile(base + ".csv", rows.join("\n"), "utf8");
    return path.basename(base) + ".csv";
  }

  // ---------------- test de connexion ----------------
  test() {
    this.hold();
    return this.run("Test de connexion", async () => {
      const steps: TestStep[] = [];
      const t = { running: true, steps, summary: "", advice: "", at: Date.now() };
      this.st.test = t;
      const step = (name: string, ok: boolean | null, detail: string) => {
        steps.push({ name, ok, detail });
        this.k.log(`test · ${name} : ${ok === null ? "…" : ok ? "OK" : "ÉCHEC"} ${detail}`);
        this.onChange();
      };
      const finish = (summary: string, advice = "") => {
        t.running = false;
        t.summary = summary;
        t.advice = advice;
        this.log(`Test de connexion : ${summary}${advice ? " — " + advice : ""}`);
        this.onChange();
        return t;
      };
      await this.endSession();
      await this.k.close();
      const ports = await listPorts();
      const forced = /kkl|auto/.test(this.files.config.source) ? this.files.config.serialPort : "";
      step("Ports série", ports.length > 0 || !!forced, [...ports.map((p) => describePort(p)), ...(forced && !ports.some((p) => p.path === forced) ? [forced + " (réglé à la main)"] : [])].join(", ") || "aucun");
      if (!ports.length && !forced) return finish("Aucun câble détecté.", "Branche le câble sur le PC. Sous Windows, vérifie dans le Gestionnaire de périphériques qu'il apparaît dans « Ports (COM et LPT) » ; sinon installe le pilote FTDI ou CH340.");
      const busy = this.busyPort();
      let portPath: string;
      try {
        portPath = await this.choosePort();
      } catch (e: any) {
        if (busy) {
          step("Câble ELM327", true, `${busy} : utilisé en ce moment par la lecture OBD`);
          return finish("L'ELM327 est connecté et lu par Nova.", "Le diagnostic complet des calculateurs (ABS, airbags, combiné…) demande le câble KKL : branche-le à la place de l'ELM327, source « KKL » ou « Auto ».");
        }
        return finish(e.message, "Indique le port du câble dans Réglages → Voiture.");
      }
      const info = ports.find((p) => p.path === portPath);
      step("Câble choisi", true, info ? describePort(info) : portPath);
      if (info?.vid === "1a86") step("Puce du câble", true, "CH340 : fonctionne, mais un câble FTDI tient mieux les 10 400 bauds de la ligne K");
      const elm = this.k.testMode ? null : await probeElm(portPath);
      if (elm) {
        step("Type de câble", true, `ELM327 (${elm})`);
        return finish("C'est un ELM327 : il lit les données OBD du moteur, pas les autres calculateurs.", "Mets la source sur « ELM327 » ou « Auto ». Pour le diagnostic complet, utilise le câble KKL.");
      }
      step("Type de câble", true, "KKL (ligne K directe)");
      try {
        await this.k.open(portPath, 10400);
        this.st.port = portPath;
      } catch (e: any) {
        step("Ouverture du port à 10 400 bauds", false, e.message);
        return finish("Impossible d'ouvrir le port.", "Ferme VCDS, ME7Logger ou tout autre logiciel qui utilise le câble, puis réessaie.");
      }
      step("Ouverture du port à 10 400 bauds", true, "");
      // écho : le câble doit renvoyer ce qu'il émet quand la prise OBD est alimentée
      this.k.flush();
      let echo = false;
      if (this.k.testMode) echo = true;
      else {
        await new Promise<void>((res) => this.k.port!.write(Buffer.from([0x55]), () => res()));
        try {
          echo = (await this.k.readByte(300, "écho")) === 0x55;
        } catch {
          echo = false;
        }
      }
      this.st.echo = echo;
      step("Écho de la ligne K", echo, echo ? "le câble est alimenté par la prise OBD" : "rien reçu");
      if (!echo) return finish("Le câble ne reçoit pas son propre écho.", "Vérifie qu'il est bien enfoncé dans la prise OBD (sous le volant) et que la prise a du 12 V (broche 16, fusible). Sans 12 V, l'interface du câble ne fonctionne pas.");
      // la ligne doit rester au repos avant le réveil 5 bauds (l'octet d'écho pourrait être pris pour une requête)
      await sleep(2500);
      this.k.flush();
      try {
        let opened: Awaited<ReturnType<typeof openSession>> | null = null;
        let lastErr: any = null;
        for (let i = 0; i < 3 && !opened; i++) {
          try {
            opened = await openSession(this.k, 0x01);
          } catch (e: any) {
            lastErr = e;
            this.k.log(`test : réveil du moteur, essai ${i + 1} : ${e.message}`);
            await sleep(2500);
            this.k.flush();
          }
        }
        if (!opened) throw lastErr || new Error("pas de réponse");
        const { session, wake } = opened;
        this.session = session;
        this.st.connected = 1;
        this.st.protocol = session.protocol;
        step("Réveil du calculateur moteur (adresse 01, 5 bauds)", true, `réponse en ${wake.ms} ms`);
        step("Synchro et mots-clés", true, `55 · ${wake.kw1.toString(16).toUpperCase()} ${wake.kw2.toString(16).toUpperCase()} → ${session.protocol}`);
        const m = this.mod(1);
        m.protocol = session.protocol;
        m.ident = session.ident;
        step("Identification", !!session.ident.partNumber, `${session.ident.partNumber} ${session.ident.component}`.trim() || "vide");
        const g = await session.readGroup(1);
        if (g) m.groups[1] = { fields: this.label(1, 1, g), at: Date.now() };
        step("Lecture du groupe 001", !!g, g ? g.map((f) => `${f.text} ${f.unit}`.trim()).join(" · ") : "refusée");
        const f = await session.readFaults();
        m.faults = f;
        m.status = f.length ? "defauts" : "ok";
        step("Codes défaut moteur", true, f.length ? `${f.length} : ${f.map((x) => x.obd || x.vag).join(", ")}` : "aucun");
        return finish(`Connexion à la voiture réussie (${session.protocol}).`);
      } catch (e: any) {
        step("Réveil du calculateur moteur (adresse 01, 5 bauds)", false, e.message);
        return finish(`Le calculateur moteur ne répond pas (${e.message}).`, "Mets le contact (moteur tournant ou non). Ferme VCDS ou ME7Logger. Dans le Gestionnaire de périphériques, mets la « latence » du port FTDI à 1 ms. Les câbles à puce CH340 gèrent mal les 10 400 bauds : un câble FTDI est plus sûr.");
      }
    });
  }

  // ---------------- lecture du moteur en direct (source « kkl ») ----------------
  private static LIVE = [3, 115, 2, 4, 3, 115, 5, 20, 3, 115, 31, 1, 3, 115, 32];

  startLive() {
    if (this.liveOn) return;
    this.liveOn = true;
    void this.liveLoop();
  }

  stopLive() {
    this.liveOn = false;
    this.st.live = false;
  }

  private async liveLoop() {
    let i = 0;
    let fails = 0;
    while (this.liveOn) {
      if (Date.now() < this.holdLiveUntil || this.st.busy) {
        if (this.st.live) {
          this.st.live = false;
          this.onChange();
        }
        await sleep(500);
        continue;
      }
      const g = VagManager.LIVE[i++ % VagManager.LIVE.length];
      try {
        await this.run("", async () => {
          const s = await this.connect(0x01);
          const f = await s.readGroup(g);
          if (f) {
            this.applyEngine(g, f);
            this.mod(1).groups[g] = { fields: this.label(1, g, f), at: Date.now() };
          }
        });
        fails = 0;
        if (!this.st.live || this.st.liveError) {
          this.st.live = true;
          this.st.liveError = "";
          this.onChange();
        }
      } catch (e: any) {
        fails++;
        this.st.live = false;
        this.st.liveError = e instanceof Timeout ? "le calculateur moteur ne répond pas (contact coupé ?)" : String(e?.message || e);
        this.session = null;
        this.st.connected = null;
        this.onChange();
        await sleep(Math.min(10000, 1500 * fails));
      }
    }
  }

  /** Groupes du ME7.5 → mesures de Nova (seulement si l'unité est celle attendue). */
  private applyEngine(g: number, f: Field[]) {
    const v: Record<string, number> = {};
    const take = (i: number, key: string, unit: string | RegExp, conv = (x: number) => x) => {
      const x = f[i];
      if (!x || x.value === null) return;
      if (typeof unit === "string" ? x.unit === unit : unit.test(x.unit)) v[key] = conv(x.value);
    };
    take(0, "rpm", "tr/min");
    if (g === 1) take(1, "water", "°C");
    if (g === 2) {
      take(1, "load", "%");
      take(3, "maf", "g/s");
    }
    if (g === 3) {
      take(1, "maf", "g/s");
      take(2, "throttle", /^(%|°)$/);
      take(3, "timing", "°");
    }
    if (g === 4) {
      take(1, "volt", "V");
      take(2, "water", "°C");
      take(3, "iat", "°C");
    }
    if (g === 5) {
      take(1, "load", "%");
      take(2, "speed", "km/h");
    }
    if (g === 20) {
      for (let k = 0; k < 4; k++) take(k, "knock" + (k + 1), /°/, (x) => Math.abs(x));
      const ks = [v.knock1, v.knock2, v.knock3, v.knock4].filter((x) => x !== undefined);
      if (ks.length) v.knock = Math.max(...ks);
    }
    if (g === 31) take(0, "lambda", /^$/);
    if (g === 32) take(1, "ltft", "%");
    if (g === 115) {
      take(1, "load", "%");
      take(2, "boostReq", "mbar", (x) => (x - 1013) / 1000);
      take(3, "boost", "mbar", (x) => (x - 1013) / 1000);
    }
    this.store.set(v);
  }

  view() {
    return {
      ...this.st,
      modules: [...this.modules.values()],
      trace: this.k.trace.slice(-40),
      labels: this.labels.summary(),
    };
  }
}
