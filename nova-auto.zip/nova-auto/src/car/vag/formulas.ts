// Décodage des valeurs de groupes de mesure VAG : chaque champ arrive en trois octets
// (type de formule, a, b). Table des formules KW1281 (blafusel.de), aussi utilisée en KWP2000.

export interface Field {
  type: number;
  a: number;
  b: number;
  value: number | null; // valeur numérique si la formule en donne une
  text: string; // valeur affichée
  unit: string;
}

const r = (x: number, d = 1) => Math.round(x * 10 ** d) / 10 ** d;
const num = (x: number, unit: string, d = 1) => ({ value: r(x, d), text: r(x, d).toLocaleString("fr-FR"), unit });
const txt = (t: string) => ({ value: null, text: t, unit: "" });
const bits = (b: number) => b.toString(2).padStart(8, "0");

export function decodeField(type: number, a: number, b: number): Field {
  let d: { value: number | null; text: string; unit: string };
  switch (type) {
    case 1: d = num(0.2 * a * b, "tr/min", 0); break;
    case 2: d = num(a * 0.002 * b, "%", 1); break;
    case 3: d = num(0.002 * a * b, "°", 1); break;
    case 4: {
      const v = Math.abs(b - 127) * 0.01 * a;
      d = { value: r(b > 127 ? -v : v, 1), text: `${r(v, 1).toLocaleString("fr-FR")} ${b > 127 ? "après PMH" : "avant PMH"}`, unit: "°" };
      break;
    }
    case 5: d = num(a * (b - 100) * 0.1, "°C", 1); break;
    case 6: d = num(0.001 * a * b, "V", 2); break;
    case 7: d = num(0.01 * a * b, "km/h", 1); break;
    case 8: d = num(0.1 * a * b, "", 1); break;
    case 9: d = num((b - 127) * 0.02 * a, "°", 1); break;
    case 10: d = txt(b === 0 ? "FROID" : "CHAUD"); break;
    case 11: d = num(0.0001 * a * (b - 128) + 1, "", 3); break;
    case 12: d = num(0.001 * a * b, "Ω", 3); break;
    case 13: d = num((b - 127) * 0.001 * a, "mm", 2); break;
    case 14: d = num(0.005 * a * b, "bar", 2); break;
    case 15: d = num(0.01 * a * b, "ms", 2); break;
    case 16: d = { value: b, text: bits(b & a) + (a !== 0xff ? ` (masque ${bits(a)})` : ""), unit: "bits" }; break;
    case 17: d = txt(String.fromCharCode(a, b)); break;
    case 18: d = num(0.04 * a * b, "mbar", 0); break;
    case 19: d = num(a * b * 0.01, "l", 2); break;
    case 20: d = num((a * (b - 128)) / 128, "%", 1); break;
    case 21: d = num(0.001 * a * b, "V", 3); break;
    case 22: d = num(0.001 * a * b, "ms", 3); break;
    case 23: d = num((b / 256) * a, "%", 1); break;
    case 24: d = num(0.001 * a * b, "A", 3); break;
    case 25: d = num(b * 1.421 + a / 182, "g/s", 2); break;
    case 26: d = num(b - a, "°C", 0); break;
    case 27: {
      const v = Math.abs(b - 128) * 0.01 * a;
      d = { value: r(b < 128 ? -v : v, 1), text: `${r(v, 1).toLocaleString("fr-FR")} ${b < 128 ? "après PMH" : "avant PMH"}`, unit: "°" };
      break;
    }
    case 28: d = num(b - a, "", 0); break;
    case 29: d = txt(b < a ? "1re cartographie" : "2e cartographie"); break;
    case 30: d = num((b / 12) * a, "° vil.", 1); break;
    case 31: d = num((b / 2560) * a, "°C", 1); break;
    case 32: d = num(b > 128 ? b - 256 : b, "", 0); break;
    case 33: d = num(a === 0 ? 100 * b : (100 * b) / a, "%", 1); break;
    case 34: d = num((b - 128) * 0.01 * a, "kW", 2); break;
    case 35: d = num(0.01 * a * b, "l/h", 2); break;
    case 36: d = num(a * 2560 + b * 10, "km", 0); break;
    case 37: d = txt("Pression d'huile 2 < mini"); break;
    case 38: d = num((b - 128) * 0.001 * a, "° vil.", 3); break;
    case 39: d = num((b / 256) * a, "mg/h", 1); break;
    case 40: d = num(b * 0.1 + 25.5 * a - 400, "A", 1); break;
    case 41: d = num(b + a * 255, "Ah", 0); break;
    case 42: d = num(b * 0.1 + 25.5 * a - 400, "kW", 1); break;
    case 43: d = num(b * 0.1 + 25.5 * a, "V", 1); break;
    case 44: d = txt(`${String(a).padStart(2, "0")}:${String(b).padStart(2, "0")}`); break;
    case 45: d = num((0.1 * a * b) / 100, "", 3); break;
    case 46: d = num((a * b - 3200) * 0.0027, "° vil.", 2); break;
    case 47: d = num((b - 128) * a, "ms", 0); break;
    case 48: d = num(b + a * 255, "", 0); break;
    case 49: d = num((b / 4) * a * 0.1, "mg/h", 1); break;
    case 50: d = num(a === 0 ? (b - 128) / 0.01 : (b - 128) / (0.01 * a), "mbar", 0); break;
    case 51: d = num(((b - 128) / 255) * a, "mg/h", 2); break;
    case 52: d = num(b * 0.02 * a - a, "Nm", 1); break;
    case 53: d = num((b - 128) * 1.4222 + 0.006 * a, "g/s", 2); break;
    case 54: d = num(a * 256 + b, "", 0); break;
    case 55: d = num((a * b) / 200, "s", 2); break;
    case 56: d = txt(`WSC ${String(a * 256 + b).padStart(5, "0")}`); break;
    case 57: d = txt(`WSC ${a * 256 + b + 65536}`); break;
    case 58: d = num(b > 128 ? 1.0225 * (256 - b) : 1.0225 * b, "/s", 1); break;
    case 59: d = num((a * 256 + b) / 32768, "", 4); break;
    case 60: d = num((a * 256 + b) * 0.01, "s", 2); break;
    case 61: d = num(a === 0 ? b - 128 : (b - 128) / a, "", 2); break;
    case 62: d = num(0.256 * a * b, "s", 1); break;
    case 63: d = txt(String.fromCharCode(a) + String.fromCharCode(b) + "?"); break;
    case 64: d = num(a + b, "Ω", 0); break;
    case 65: d = num(0.01 * a * (b - 127), "mm", 2); break;
    case 66: d = num((a * b) / 511.12, "V", 2); break;
    case 67: d = num(640 * a + b * 2.5, "°", 1); break;
    case 68: d = num((256 * a + b) / 7.365, "°/s", 1); break;
    case 69: d = num((256 * a + b) * 0.3254, "bar", 1); break;
    case 70: d = num((256 * a + b) * 0.192, "m/s²", 2); break;
    default: d = { value: null, text: `${a} / ${b}`, unit: `type ${type}` };
  }
  return { type, a, b, ...d };
}

/** Champs d'un groupe à partir des octets bruts (triplets type, a, b). */
export function decodeGroup(bytes: number[]): Field[] {
  const out: Field[] = [];
  for (let i = 0; i + 2 < bytes.length; i += 3) out.push(decodeField(bytes[i], bytes[i + 1], bytes[i + 2]));
  return out;
}
