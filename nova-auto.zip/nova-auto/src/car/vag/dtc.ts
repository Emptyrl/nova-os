// Base des codes défaut de Nova.
//   1. codes VAG à 5 chiffres des calculateurs (ABS, airbags, combiné…) : VAG_TEXT (modules.ts)
//   2. codes moteur VAG propres au groupe (P1xxx = 17408 + n) : VAG_P1 ci-dessous, en français
//   3. codes OBD génériques en français : DTC_TEXT (sources/types.ts)
//   4. codes OBD génériques en anglais (2 400 codes, liste libre MIT) : data/dtc-generiques.json
// Les codes VAG moteur se convertissent : 16384 + n = P0xxx, 17408 + n = P1xxx, 18432 + n = P2xxx.
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

/** Codes moteur VAG (ME7, 1.8T), texte et piste de réparation. */
export const VAG_P1: Record<string, { text: string; tip?: string }> = {
  P1128: { text: "Régulation lambda à long terme (multiplicative) : mélange trop pauvre", tip: "Prise d'air après le débitmètre, durites de dépression, débitmètre encrassé, pression d'essence." },
  P1129: { text: "Régulation lambda à long terme (multiplicative) : mélange trop riche", tip: "Injecteurs qui fuient, pression d'essence trop forte, sonde lambda." },
  P1136: { text: "Régulation lambda à long terme (additive, ralenti) : mélange trop pauvre", tip: "Prise d'air au ralenti : durites PCV, joint d'admission, durite du servofrein." },
  P1137: { text: "Régulation lambda à long terme (additive, ralenti) : mélange trop riche", tip: "Purge du canister (N80) bloquée ouverte, injecteurs." },
  P1176: { text: "Correction lambda après catalyseur : limite atteinte", tip: "Sonde lambda aval, catalyseur, fuite d'échappement." },
  P1196: { text: "Chauffage de la sonde lambda avant (banc 1) : défaut électrique", tip: "Fusible, connecteur et résistance de chauffage de la sonde." },
  P1200: { text: "Électrovanne de recyclage d'air du turbo (N249) : défaut mécanique", tip: "Classique sur 1.8T : durites de dépression fendues autour de la N249 et de la soupape de décharge (diverter), N249 supprimée ou débranchée, soupape de décharge non d'origine (Forge…), ou N249 elle-même. Fais le test des actionneurs pour l'entendre claquer." },
  P1213: { text: "Injecteur cylindre 1 (N30) : court-circuit au plus" },
  P1214: { text: "Injecteur cylindre 2 (N31) : court-circuit au plus" },
  P1215: { text: "Injecteur cylindre 3 (N32) : court-circuit au plus" },
  P1216: { text: "Injecteur cylindre 4 (N33) : court-circuit au plus" },
  P1225: { text: "Injecteur cylindre 1 (N30) : court-circuit à la masse" },
  P1226: { text: "Injecteur cylindre 2 (N31) : court-circuit à la masse" },
  P1227: { text: "Injecteur cylindre 3 (N32) : court-circuit à la masse" },
  P1228: { text: "Injecteur cylindre 4 (N33) : court-circuit à la masse" },
  P1237: { text: "Injecteur cylindre 1 (N30) : circuit ouvert" },
  P1238: { text: "Injecteur cylindre 2 (N31) : circuit ouvert" },
  P1239: { text: "Injecteur cylindre 3 (N32) : circuit ouvert" },
  P1240: { text: "Injecteur cylindre 4 (N33) : circuit ouvert" },
  P1250: { text: "Niveau de carburant trop bas", tip: "Panne sèche ou presque : refais le plein, le défaut s'efface après quelques trajets." },
  P1296: { text: "Système de refroidissement : défaut", tip: "Thermostat bloqué ouvert, sonde de température d'eau (G62)." },
  P1336: { text: "Surveillance du couple moteur : limite d'adaptation atteinte", tip: "Prise d'air, papillon encrassé : nettoie le papillon puis refais le réglage de base 060." },
  P1386: { text: "Calculateur moteur : défaut interne de la régulation du cliquetis" },
  P1411: { text: "Air secondaire (banc 1) : débit trop faible", tip: "Pompe d'air secondaire (V101), clapet combiné, durites." },
  P1421: { text: "Électrovanne d'air secondaire (N112) : court-circuit à la masse" },
  P1425: { text: "Électrovanne du réservoir à charbon actif (N80) : court-circuit à la masse" },
  P1426: { text: "Électrovanne du réservoir à charbon actif (N80) : circuit ouvert" },
  P1545: { text: "Commande du papillon : défaut", tip: "Papillon encrassé ou fatigué : nettoyage puis réglage de base 060." },
  P1555: { text: "Pression de suralimentation : limite supérieure dépassée", tip: "Électrovanne N75, durites de la N75 et de la wastegate, wastegate grippée." },
  P1556: { text: "Régulation de la pression de suralimentation : écart négatif (pas assez de pression)", tip: "Fuite de suralimentation (durites, échangeur), N75, soupape de décharge, turbo." },
  P1557: { text: "Régulation de la pression de suralimentation : écart positif (trop de pression)", tip: "N75, wastegate grippée ou sa durite." },
  P1558: { text: "Commande du papillon (G186) : défaut électrique" },
  P1559: { text: "Régulation du ralenti : adaptation du papillon défectueuse", tip: "Réglage de base 060 contact mis, moteur arrêté, pédale relâchée." },
  P1564: { text: "Papillon : tension trop faible pendant l'adaptation", tip: "Batterie faible : recharge-la puis refais le réglage de base 060." },
  P1565: { text: "Régulation du ralenti : limite inférieure non atteinte" },
  P1568: { text: "Régulation du ralenti : défaut mécanique du papillon" },
  P1579: { text: "Papillon : adaptation non lancée", tip: "Fais le réglage de base 060." },
  P1580: { text: "Commande du papillon (banc 1) : défaut" },
  P1602: { text: "Alimentation (borne 30) : tension trop faible", tip: "Batterie, alternateur, masses." },
  P1612: { text: "Calculateur moteur : codage incorrect" },
  P1626: { text: "Bus de données propulsion : message de la boîte absent" },
  P1630: { text: "Capteur de position de pédale 1 (G79) : signal trop faible" },
  P1631: { text: "Capteur de position de pédale 1 (G79) : signal trop fort" },
  P1633: { text: "Capteur de position de pédale 2 (G185) : signal trop faible" },
  P1634: { text: "Capteur de position de pédale 2 (G185) : signal trop fort" },
  P1639: { text: "Capteurs de position de pédale 1 et 2 (G79/G185) : signaux incohérents" },
  P1648: { text: "Bus de données propulsion : défaut" },
  P1649: { text: "Bus de données propulsion : message de l'ABS absent" },
};

/** Codes VAG à 5 chiffres des autres calculateurs (ABS/ESP, combiné, Haldex…), en plus de ceux de modules.ts. */
export const VAG_MORE: Record<number, string> = {
  281: "Capteur de vitesse du véhicule (G22)",
  301: "Pompe de retour ABS (V39)",
  526: "Contacteur de feux stop (F)",
  1044: "Calculateur mal codé",
  1276: "Pompe hydraulique ABS (V64)",
  1435: "Capteur de pression de freinage 1 (G201)",
  1486: "Test de fonctionnement du système déclenché",
  1826: "Capteur d'angle de braquage (G85) : réglage de base non fait",
  1130: "Fonctionnement de l'ABS",
  1203: "Liaison électrique entre le combiné et le calculateur moteur",
  1316: "Calculateur ABS : pas de communication",
  1314: "Calculateur moteur : pas de communication",
};

let generic: Record<string, string> | null = null;
function genericTable(): Record<string, string> {
  if (generic) return generic;
  try {
    const file = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "..", "data", "dtc-generiques.json");
    generic = JSON.parse(readFileSync(file, "utf8")).codes || {};
  } catch {
    generic = {};
  }
  return generic!;
}

/** Texte d'un code OBD (« P1200 ») : VAG en français, générique en français, générique en anglais. */
export function obdText(obd: string): { text: string; tip?: string; lang: "fr" | "en" } | null {
  const v = VAG_P1[obd];
  if (v) return { ...v, lang: "fr" };
  const en = genericTable()[obd];
  if (en) return { text: en, lang: "en" };
  return null;
}

export function dtcCount() {
  return { vagP1: Object.keys(VAG_P1).length, vag: Object.keys(VAG_MORE).length, generic: Object.keys(genericTable()).length };
}
