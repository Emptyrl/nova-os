// Calculateurs de l'Audi TT 8N (2003) joignables par la prise OBD (ligne K), libellés des groupes
// de mesure connus du ME7.5 (1.8T 225 BAM) et textes des codes défaut VAG.
import { DTC_TEXT } from "../sources/types.js";

export interface ModuleDef {
  addr: number;
  name: string;
  short: string;
}

// Adresses VAG (hexadécimales, comme dans VCDS). Le scan essaie toutes : celles que la voiture n'a pas
// (boîte auto, navigation…) répondent simplement « absent ».
export const MODULES: ModuleDef[] = [
  { addr: 0x01, name: "Électronique moteur", short: "Moteur ME7.5" },
  { addr: 0x02, name: "Boîte automatique", short: "Boîte auto" },
  { addr: 0x03, name: "Freins ABS / ESP", short: "ABS / ESP" },
  { addr: 0x08, name: "Climatisation / chauffage", short: "Climatronic" },
  { addr: 0x15, name: "Airbags", short: "Airbags" },
  { addr: 0x16, name: "Colonne de direction", short: "Colonne" },
  { addr: 0x17, name: "Combiné d'instruments", short: "Combiné" },
  { addr: 0x22, name: "Transmission intégrale (Haldex)", short: "Haldex" },
  { addr: 0x25, name: "Antidémarrage", short: "Antidémarrage" },
  { addr: 0x35, name: "Verrouillage centralisé", short: "Verrouillage" },
  { addr: 0x45, name: "Surveillance habitacle (alarme)", short: "Alarme" },
  { addr: 0x46, name: "Module confort", short: "Confort" },
  { addr: 0x47, name: "Système audio", short: "Audio" },
  { addr: 0x55, name: "Réglage portée des phares", short: "Phares" },
  { addr: 0x56, name: "Radio", short: "Radio" },
];

export const hexAddr = (a: number) => a.toString(16).toUpperCase().padStart(2, "0");

/** Libellés des champs des groupes du ME7.5 (1.8T). Les autres calculateurs : libellé déduit de l'unité. */
export const ENGINE_GROUPS: Record<number, string[]> = {
  1: ["Régime moteur", "Température liquide de refroidissement", "Correction lambda", "Conditions du réglage de base"],
  2: ["Régime moteur", "Charge moteur", "Temps d'injection", "Débit d'air"],
  3: ["Régime moteur", "Débit d'air", "Angle papillon", "Avance à l'allumage"],
  4: ["Régime moteur", "Tension batterie", "Température liquide de refroidissement", "Température air d'admission"],
  5: ["Régime moteur", "Charge moteur", "Vitesse véhicule", "Plage de charge"],
  20: ["Recul d'allumage cylindre 1", "Recul d'allumage cylindre 2", "Recul d'allumage cylindre 3", "Recul d'allumage cylindre 4"],
  22: ["Régime moteur", "Charge moteur", "Recul d'allumage cylindre 1", "Recul d'allumage cylindre 2"],
  23: ["Régime moteur", "Charge moteur", "Recul d'allumage cylindre 3", "Recul d'allumage cylindre 4"],
  31: ["Lambda réelle", "Lambda de consigne"],
  32: ["Adaptation lambda au ralenti (additive)", "Adaptation lambda en charge partielle (multiplicative)"],
  33: ["Correction lambda", "Tension sonde lambda amont"],
  60: ["Angle papillon (potentiomètre 1)", "Angle papillon (potentiomètre 2)", "Pas d'apprentissage", "Résultat de l'adaptation"],
  62: ["Angle papillon (potentiomètre 1)", "Angle papillon (potentiomètre 2)", "Pédale d'accélérateur (capteur 1)", "Pédale d'accélérateur (capteur 2)"],
  91: ["Régime moteur", "Charge moteur", "Calage arbre à cames (rapport cyclique)", "Calage arbre à cames réel"],
  114: ["Charge de consigne", "Charge de consigne corrigée", "Rapport cyclique N75 (wastegate)", "Charge réelle"],
  115: ["Régime moteur", "Charge moteur", "Pression de suralimentation de consigne", "Pression de suralimentation réelle"],
  118: ["Régime moteur", "Température air d'admission", "Rapport cyclique N75 (wastegate)", "Pression de suralimentation réelle"],
};

const UNIT_LABEL: Record<string, string> = {
  "tr/min": "Régime", "km/h": "Vitesse", "°C": "Température", V: "Tension", A: "Courant", km: "Kilométrage", l: "Volume",
  "l/h": "Débit carburant", Ω: "Résistance", bar: "Pression", mbar: "Pression", ms: "Durée", s: "Durée", "%": "Taux",
  "g/s": "Débit d'air", "°": "Angle", bits: "État (bits)", Nm: "Couple", kW: "Puissance", "/s": "Fréquence",
};

export function fieldLabel(addr: number, group: number, index: number, unit: string): string {
  if (addr === 0x01 && ENGINE_GROUPS[group]?.[index]) return ENGINE_GROUPS[group][index];
  return UNIT_LABEL[unit] ?? `Champ ${index + 1}`;
}

// ---------- codes défaut ----------
// Codes VAG hors OBD les plus courants sur la plateforme (libellés VCDS traduits)
const VAG_TEXT: Record<number, string> = {
  3: "Calculateur défectueux",
  283: "Capteur de vitesse avant gauche (G47)",
  285: "Capteur de vitesse avant droit (G45)",
  287: "Capteur de vitesse arrière droit (G44)",
  290: "Capteur de vitesse arrière gauche (G46)",
  532: "Tension d'alimentation B+",
  562: "Capteur niveau / température d'huile (G266)",
  588: "Allumeur airbag conducteur (N95)",
  589: "Allumeur airbag passager (N131)",
  595: "Données de collision enregistrées",
  625: "Signal de vitesse",
  668: "Tension d'alimentation borne 30",
  771: "Capteur de niveau de carburant (G)",
  779: "Capteur de température extérieure (G17)",
  1044: "Calculateur mal codé",
  1128: "Bobine de lecture de l'antidémarrage (D2)",
  1176: "Clé : signal trop faible ou non autorisée",
  1177: "Calculateur moteur non autorisé (antidémarrage)",
  1217: "Allumeur airbag latéral conducteur (N199)",
  1218: "Allumeur airbag latéral passager (N200)",
  1299: "Interface de diagnostic du bus de données (J533)",
  1312: "Bus de données propulsion",
  1314: "Calculateur moteur : pas de communication",
  1316: "Calculateur ABS : pas de communication",
  1317: "Calculateur du combiné (J285)",
  1321: "Calculateur airbags (J234)",
};

const ELABORATION: Record<number, string> = {
  0: "",
  1: "court-circuit au plus",
  2: "court-circuit à la masse",
  3: "pas de signal / communication",
  4: "défaut mécanique",
  5: "circuit ouvert",
  6: "signal trop fort",
  7: "signal trop faible",
  8: "limite de régulation dépassée",
  9: "limite d'adaptation dépassée",
  10: "limite d'adaptation non atteinte",
  11: "limite de régulation non atteinte",
  12: "limite d'adaptation (multiplicative) dépassée",
  13: "limite d'adaptation (multiplicative) non atteinte",
  14: "limite d'adaptation (additive) dépassée",
  15: "limite d'adaptation (additive) non atteinte",
  16: "signal hors tolérance",
  17: "écart de régulation",
  18: "limite supérieure",
  19: "limite inférieure",
  20: "défaut en réglage de base",
  27: "signal non plausible",
};

export interface Fault {
  code: number; // code VAG à 5 chiffres
  vag: string; // « 16486 »
  obd: string; // « P0102 » si c'est un code OBD
  text: string;
  status: number;
  elaboration: string;
  sporadic: boolean;
}

export function decodeFault(hi: number, lo: number, status: number): Fault {
  const code = hi * 256 + lo;
  let obd = "";
  if (code >= 16384 && code < 16384 + 4 * 1024) {
    const d = code - 16384;
    const first = Math.floor(d / 1024);
    const rest = d % 1024;
    if (rest <= 999) obd = `P${first}${String(rest).padStart(3, "0")}`;
  }
  const el = status & 0x7f;
  const text = (obd && DTC_TEXT[obd]) || VAG_TEXT[code] || (obd ? "Code moteur OBD (voir VCDS pour le détail)" : "Code constructeur (voir VCDS pour le détail)");
  return {
    code,
    vag: String(code).padStart(5, "0"),
    obd,
    text,
    status,
    elaboration: ELABORATION[el] ?? `type ${el}`,
    sporadic: (status & 0x80) !== 0,
  };
}

/** Réponse « aucun défaut ». */
export const isNoFault = (hi: number, lo: number) => hi === 0xff && lo === 0xff;
