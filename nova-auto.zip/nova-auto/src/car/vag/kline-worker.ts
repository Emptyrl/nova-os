import os from "node:os";
// Processus à part pour la ligne K. Le dialogue avec un calculateur se joue à la milliseconde
// (chaque octet reçu doit être acquitté tout de suite). Dans le fil principal, la reconnaissance vocale,
// l'écran ou la base de libellés le bloquaient parfois 50 à 200 ms : octets décalés, calculateur qui
// raccroche. Ici, rien d'autre ne tourne : seuls les blocs entiers remontent au fil principal.
import { SerialPort } from "serialport";
import { promises as fs } from "node:fs";
import { execFile } from "node:child_process";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const hex = (b: number) => b.toString(16).toUpperCase().padStart(2, "0");
const TEST = process.env.NOVA_KLINE_TEST === "1";

class TimeoutErr extends Error {
  timeout = true;
  constructor(what: string) {
    super("pas de réponse (" + what + ")");
  }
}

/** Attente précise : setTimeout jusqu'à 20 ms avant, puis attente active. */
async function until(t: number) {
  const left = t - performance.now();
  if (left > 22) await sleep(left - 20);
  while (performance.now() < t) {
    /* attente active, 20 ms maximum */
  }
}

let port: SerialPort | null = null;
let rx: number[] = [];
let waiter: (() => void) | null = null;
let stats: { echoSeen: number; echoMissing: number; restarts?: number } = { echoSeen: 0, echoMissing: 0 };

// processus enfant (fork) : messages par le canal IPC
const post = (m: unknown) => process.send?.(m);
const log = (t: string) => post({ log: t });

async function open(path: string, baudRate: number) {
  await close();
  const p = new SerialPort({ path, baudRate, autoOpen: false, dataBits: 8, stopBits: 1, parity: "none" });
  await new Promise<void>((res, rej) => p.open((e) => (e ? rej(e) : res())));
  // la plupart des câbles KKL alimentent leur interface par DTR
  await new Promise<void>((res) => p.set({ dtr: true, rts: false, brk: false }, () => res()));
  p.on("data", (b: Buffer) => {
    for (const x of b) rx.push(x);
    lastRxAt = performance.now();
    const w = waiter;
    waiter = null;
    w?.();
  });
  p.on("error", (e) => log("erreur du port : " + e.message));
  p.on("close", () => {
    if (port === p) {
      port = null;
      post({ closed: true });
    }
  });
  port = p;
  rx = [];
  curBaud = baudRate;
  log(`port ${path} ouvert à ${baudRate} bauds · délai entre blocs KW1281 : ${KW_BLK_MS} ms`);
  await checkLatency(path);
}

async function checkLatency(path: string) {
  if (process.platform !== "linux" || !/ttyUSB/.test(path)) return;
  const dev = path.split("/").pop();
  const file = `/sys/bus/usb-serial/devices/${dev}/latency_timer`;
  let v = (await fs.readFile(file, "utf8").catch(() => "")).trim();
  if (!v) return;
  if (v !== "1") {
    await fs.writeFile(file, "1").catch(async () => {
      await new Promise<void>((res) => execFile("sudo", ["-n", "sh", "-c", `echo 1 > ${file}`], () => res()));
    });
    v = (await fs.readFile(file, "utf8").catch(() => "")).trim();
  }
  log(`latence FTDI : ${v} ms${v === "1" ? "" : " (devrait être 1 : les calculateurs risquent de raccrocher)"}`);
}

let curBaud = 10400;
async function setBaud(b: number) {
  const p = port;
  if (!p) throw new Error("câble débranché");
  if (b === curBaud) return;
  await new Promise<void>((res, rej) => p.update({ baudRate: b }, (e) => (e ? rej(e) : res())));
  curBaud = b;
  log(`vitesse du port : ${b} bauds`);
}

async function close() {
  const p = port;
  port = null;
  if (p?.isOpen) await new Promise<void>((r) => p.close(() => r()));
}

/**
 * Lit un octet. Au délai écoulé, on laisse encore passer la lecture du port (setImmediate passe après
 * les entrées-sorties) : un octet arrivé pile au moment du délai n'est pas pris pour une absence.
 */
async function readByte(timeout = 1000, what = "octet"): Promise<number> {
  const end = Date.now() + timeout;
  while (!rx.length) {
    if (!port) throw new Error("câble débranché");
    const left = end - Date.now();
    if (left <= 0) {
      await new Promise((r) => setImmediate(r));
      if (rx.length) break;
      throw new TimeoutErr(what);
    }
    await new Promise<void>((res) => {
      const t = setTimeout(() => {
        waiter = null;
        res();
      }, left);
      waiter = () => {
        clearTimeout(t);
        res();
      };
    });
  }
  return rx.shift()!;
}

async function rawWrite(bytes: number[]) {
  const p = port;
  if (!p) throw new Error("câble débranché");
  await new Promise<void>((res, rej) => p.write(Buffer.from(bytes), (e) => (e ? rej(e) : res())));
  await new Promise<void>((res) => p.drain(() => res()));
}

/** Envoie un octet et jette son écho (le câble KKL renvoie tout ce qu'il émet). */
async function writeByte(b: number) {
  await rawWrite([b]);
  try {
    const e = await readByte(150, "écho");
    if (e === b) stats.echoSeen++;
    else {
      rx.unshift(e);
      stats.echoMissing++;
    }
  } catch {
    stats.echoMissing++;
  }
}

async function setBreak(on: boolean) {
  const p = port;
  if (!p) throw new Error("câble débranché");
  await new Promise<void>((res, rej) => p.set({ brk: on, dtr: true, rts: false }, (e) => (e ? rej(e) : res())));
}

/** Réveil 5 bauds : adresse à 5 bits/s (bit de départ, 7 bits, parité impaire, bit d'arrêt), puis synchro 0x55. */
async function wakeup(addr: number) {
  const t0 = Date.now();
  proto = "";
  counter = null;
  idleTurn = false;
  await sleep(300); // ligne au repos (W5)
  rx = [];
  let a = addr & 0x7f;
  let ones = 0;
  for (let i = 0; i < 7; i++) if (a & (1 << i)) ones++;
  if (ones % 2 === 0) a |= 0x80;
  log(`réveil 5 bauds de l'adresse ${hex(addr)} (octet ${hex(a)})`);
  kwpTrace = 0;
  if (TEST) {
    await rawWrite([a]);
    await sleep(50);
  } else {
    const bits = [0, ...Array.from({ length: 8 }, (_, i) => (a >> i) & 1), 1];
    const start = performance.now();
    for (let i = 0; i < bits.length; i++) {
      await until(start + i * 200);
      await setBreak(bits[i] === 0);
    }
    await until(start + bits.length * 200);
  }
  // ce qu'on a reçu pendant le réveil n'est que notre propre signal (les derniers échos arrivent
  // parfois un peu après) : on vide, puis on saute tout octet parasite jusqu'à la synchro 0x55
  await sleep(4);
  rx = [];
  const deadline = Date.now() + 1500;
  const junk: number[] = [];
  let sync = -1;
  while (Date.now() < deadline) {
    let b: number;
    try {
      b = await readByte(Math.max(1, deadline - Date.now()), "octet de synchro 0x55");
    } catch (e) {
      // des octets sont arrivés mais pas de 0x55 : le calculateur parle sans doute à une autre vitesse
      if (junk.length) throw new Error(`synchro introuvable (reçu ${junk.map(hex).join(" ")}) : autre vitesse ?`);
      throw e;
    }
    if (b === 0x55) {
      sync = b;
      break;
    }
    junk.push(b);
    if (junk.length > 8) break;
  }
  if (junk.length) log(`octets parasites ignorés avant la synchro : ${junk.map(hex).join(" ")}`);
  if (sync !== 0x55) throw new Error(`synchro introuvable (reçu ${junk.map(hex).join(" ")}) : contact coupé ou ligne perturbée ?`);
  log("synchro reçue : 55");
  const kw1 = await readByte(500, "mot-clé 1");
  const kw2 = await readByte(500, "mot-clé 2");
  const version = ((kw2 & 0x7f) << 7) + (kw1 & 0x7f);
  log(`mots-clés ${hex(kw1)} ${hex(kw2)} → protocole ${version >= 2000 ? "KWP2000" : "KW" + version}`);
  await sleep(25);
  await writeByte(kw2 ^ 0xff);
  if (version >= 2000) {
    const c = await readByte(500, "complément de l'adresse");
    if (c !== (a ^ 0xff) && c !== (addr ^ 0xff)) log(`complément d'adresse inattendu : ${hex(c)}`);
  }
  return { version, kw1, kw2, ms: Date.now() - t0 };
}

// ---------------- session en cours (maintien automatique de la liaison) ----------------
// Le calculateur raccroche après ~1 s sans bloc. Le maintien se fait ici, à heure fixe, quel que soit
// l'état du fil principal.
let proto: "" | "kw1281" | "kwp" = "";
let kwpAddr = 0;
let kwpLenInFmt = false;
let kwpKeep: number[] = [0x3e, 0x01];
let kwpP3 = 55;

/** Message KWP2000 complet : en-tête avec adresses, longueur dans l'octet de format ou à part, somme. */
function kwpFrame(target: number, body: number[], lenInFmt: boolean) {
  const msg = lenInFmt && body.length < 64 ? [0x80 | body.length, target, 0xf1, ...body] : [0x80, target, 0xf1, body.length, ...body];
  msg.push(msg.reduce((a, b) => a + b, 0) & 0xff);
  return msg;
}
let counter: number | null = null;
let lastIo = Date.now();
let busy = false;
/** C'est au testeur de parler et la conversation est au repos (dernier bloc reçu : ACK/NAK, ou réponse KWP finale). */
let idleTurn = false;

// ---------------- KW1281 : un bloc entier, octet par octet avec acquittement ----------------
/**
 * Délai entre la fin du dernier bloc reçu et le premier octet du bloc suivant du testeur.
 * VCDS utilise 55 ms par défaut (« Blk Int ») ; 25 ms est son minimum, déjà « peu fiable avec certains
 * calculateurs ». Nova envoyait après ~6 ms : les calculateurs lents à 9 600 bauds (combiné 17, Haldex 22)
 * recommençaient leurs blocs en lecture continue. Réglable avec NOVA_KW_BLK (ms).
 */
const KW_BLK_MS = Math.max(6, Number(process.env.NOVA_KW_BLK) || 55);
/** Moment (performance.now) du dernier octet reçu du câble. */
let lastRxAt = 0;
/** Attente précise et courte (attente active) : un setTimeout de 2 ms dure parfois 15 ms sur un PC chargé. */
const spin = (ms: number) => until(performance.now() + ms);

async function ackByte(b: number) {
  await spin(2);
  await writeByte(b ^ 0xff);
}

async function kwRecv(final = false) {
  let len = await readByte(1200, "début de bloc");
  // le calculateur peut se re-synchroniser (0x55, mots-clés)
  for (let i = 0; len === 0x55 && i < 5; i++) {
    await readByte(500);
    const kw2 = await readByte(500);
    await sleep(25);
    await writeByte(kw2 ^ 0xff);
    len = await readByte(1200, "début de bloc");
  }
  if (len < 3) throw new Error(`longueur de bloc impossible ${hex(len)}`);
  await ackByte(len);
  // seq = [longueur, compteur, titre, données…] ; si un acquittement se perd, le calculateur recommence
  // son bloc depuis le début : on le voit à la fin (pas de 0x03), on retrouve le début du bloc recommencé
  // dans ce qu'on a reçu et on continue avec lui, sans perdre la liaison
  let seq = [len];
  for (let shifts = 0; ; ) {
    const n = seq[0];
    while (seq.length < n) {
      const what = seq.length === 1 ? "compteur de bloc" : seq.length === 2 ? "titre de bloc" : "donnée";
      let b: number;
      try {
        b = await readByte(500, what);
      } catch (e: any) {
        // silence au milieu d'un bloc : souvent un acquittement arrivé trop tard (PC occupé). Le calculateur
        // abandonne puis recommence le bloc un peu plus tard : on l'attend au lieu de couper la liaison.
        if (!e?.timeout) throw e;
        b = await readByte(1800, what);
        stats.restarts = (stats.restarts || 0) + 1;
        log(`silence de plus de 0,5 s au milieu d'un bloc (${what}) : le calculateur a repris, liaison gardée`);
      }
      await ackByte(b);
      seq.push(b);
    }
    const end = await readByte(500, "fin de bloc");
    if (end === 0x03) break;
    const all = [...seq, end];
    let p = -1;
    for (let i = 1; i < all.length; i++) {
      if (all[i] === n && (i + 1 >= all.length || all[i + 1] === seq[1]) && (i + 2 >= all.length || all[i + 2] === seq[2])) {
        p = i;
        break;
      }
    }
    if (p < 0 || ++shifts > 3) throw new Error(`fin de bloc inattendue ${hex(end)}`);
    stats.restarts = (stats.restarts || 0) + 1;
    log(`bloc recommencé par le calculateur (acquittement perdu) : on reprend avec lui`);
    seq = all.slice(p);
    await ackByte(end);
  }
  const cnt = seq[1];
  const title = seq[2];
  const data = seq.slice(3);
  if (counter !== null && cnt !== counter) log(`compteur reçu ${cnt}, attendu ${counter}`);
  counter = (cnt + 1) & 0xff;
  // au testeur de parler : réponse finale (mesures, actionneur) ou ACK/NAK du calculateur
  idleTurn = final || title === 0x09 || title === 0x0a;
  return { cnt, title, data };
}

/** Bloc KW1281 du testeur : [longueur, compteur, titre, données…] puis 0x03. */
async function kwSendBlock(title: number, data: number[]) {
  const bytes = [data.length + 3, counter ?? 0, title, ...data];
  counter = ((counter ?? 0) + 1) & 0xff;
  await kwSend(bytes);
}

async function kwSend(bytes: number[]) {
  idleTurn = false;
  // délai entre blocs, compté depuis le dernier octet reçu (fin du bloc du calculateur)
  const waitUntil = lastRxAt + KW_BLK_MS;
  if (performance.now() < waitUntil) await until(waitUntil);
  else {
    await sleep(3);
    await spin(3);
  }
  for (const b of bytes) {
    await spin(1.5);
    await writeByte(b);
    const c = await readByte(500, "acquittement d'octet");
    if (c !== (b ^ 0xff)) throw new Error(`acquittement faux ${hex(c)} pour ${hex(b)}`);
  }
  await spin(1.5);
  await writeByte(0x03);
}

// ---------------- KWP2000 : un message entier ----------------
let kwpTrace = 0;
async function kwpSend(msg: number[], p3 = kwpP3) {
  idleTurn = false;
  // la ligne doit être silencieuse : un reste de réponse (message en plusieurs morceaux) se mélangerait
  // à l'écho de notre demande. On le lit et on le note.
  const stray: number[] = [];
  for (;;) {
    try {
      stray.push(await readByte(stray.length ? 30 : 15, "reste"));
      if (stray.length > 300) break;
    } catch {
      break;
    }
  }
  if (stray.length) log(`KWP2000 : ${stray.length} octet(s) reçus en plus avant d'envoyer : ${stray.slice(0, 40).map(hex).join(" ")}${stray.length > 40 ? " …" : ""}`);
  await sleep(Math.max(0, p3 - 15)); // P3
  for (let i = 0; i < msg.length; i++) {
    await writeByte(msg[i]);
    if (i < msg.length - 1) await sleep(5); // P4
  }
}

async function kwpRecv(timeout: number) {
  const fmt = await readByte(timeout, "réponse KWP2000");
  const head = [fmt];
  if (fmt & 0x80) head.push(await readByte(200), await readByte(200));
  let len = fmt & 0x3f;
  if (!len) {
    len = await readByte(200);
    head.push(len);
  }
  const body: number[] = [];
  for (let i = 0; i < len; i++) body.push(await readByte(200, "donnée KWP2000"));
  const cs = await readByte(200, "somme de contrôle");
  const sum = [...head, ...body].reduce((a, b) => a + b, 0) & 0xff;
  if (cs !== sum) log(`somme de contrôle fausse (${hex(cs)} au lieu de ${hex(sum)})`);
  if (kwpTrace < 25) {
    kwpTrace++;
    log(`KWP2000 ← ${[...head, ...body, cs].slice(0, 48).map(hex).join(" ")}${body.length > 44 ? " …" : ""}`);
  }
  // « réponse en préparation » (7F xx 78) : le calculateur va encore parler
  idleTurn = !(body[0] === 0x7f && body[2] === 0x78);
  return body;
}

/**
 * Sonde KWP2000 : envoie un message et rapporte TOUT ce qui revient (octets bruts), pour trouver la forme
 * de message que comprend un calculateur et voir ce qu'il répond quand on ne le comprend pas.
 */
async function kwpProbe(msg: number[], p3: number, listenMs: number) {
  rx = [];
  await kwpSend(msg, p3);
  const got: number[] = [];
  const end = Date.now() + listenMs;
  while (Date.now() < end) {
    try {
      // après le premier octet, 60 ms de silence = fin de la réponse
      got.push(await readByte(got.length ? 60 : Math.max(1, end - Date.now()), "sonde"));
    } catch {
      break;
    }
    if (got.length > 300) break;
  }
  idleTurn = got.length > 0;
  return got;
}

/**
 * Réveil rapide ISO 14230 (fast init) : ligne à 0 pendant 25 ms, à 1 pendant 25 ms, puis StartCommunication.
 * Certains calculateurs KWP2000 ne répondent bien qu'ainsi. Renvoie les octets bruts de la réponse.
 */
async function fastInit(msg: number[]) {
  proto = "";
  counter = null;
  idleTurn = false;
  await sleep(300); // ligne au repos
  rx = [];
  if (!TEST) {
    const t = performance.now();
    await setBreak(true);
    await until(t + 25);
    await setBreak(false);
    await until(t + 50);
  }
  rx = [];
  for (let i = 0; i < msg.length; i++) {
    await writeByte(msg[i]);
    if (i < msg.length - 1) await spin(5);
  }
  const got: number[] = [];
  const end = Date.now() + 600;
  while (Date.now() < end) {
    try {
      got.push(await readByte(got.length ? 60 : Math.max(1, end - Date.now()), "réponse au réveil rapide"));
    } catch {
      break;
    }
    if (got.length > 64) break;
  }
  log(`réveil rapide → ${msg.map(hex).join(" ")} ← ${got.length ? got.map(hex).join(" ") : "rien"}`);
  idleTurn = got.length > 0;
  return got;
}

/** Test du câble : il doit renvoyer l'octet émis quand la prise OBD est alimentée. */
async function echoTest() {
  if (TEST) return true;
  rx = [];
  await rawWrite([0x55]);
  try {
    return (await readByte(300, "écho")) === 0x55;
  } catch {
    return false;
  }
}

async function keepAlive() {
  if (proto === "kw1281") {
    await kwSendBlock(0x09, []);
    const b = await kwRecv();
    if (b.title !== 0x09) log(`maintien : bloc ${hex(b.title)} reçu au lieu d'ACK`);
  } else if (proto === "kwp") {
    await kwpSend(kwpFrame(kwpAddr, kwpKeep, kwpLenInFmt));
    const b = await kwpRecv(1000);
    // « service non pris en charge » (MK60…) : on garde la liaison avec une lecture du groupe 1
    if (b[0] === 0x7f && b[1] === kwpKeep[0] && kwpKeep[0] === 0x3e) {
      kwpKeep = [0x21, 0x01];
      log("KWP2000 : maintien refusé (3E), maintien par lecture du groupe 1");
    }
  }
}

const OPS: Record<string, (...a: any[]) => Promise<unknown>> = {
  begin: async (p: "kw1281" | "kwp", addr: number, lenInFmt?: boolean, p3?: number) => {
    proto = p;
    kwpAddr = addr;
    kwpLenInFmt = !!lenInFmt;
    kwpKeep = [0x3e, 0x01];
    kwpP3 = p3 || 55;
    counter = null;
  },
  end: async () => {
    proto = "";
    counter = null;
  },
  kwBlock: (title: number, data: number[]) => kwSendBlock(title, data),
  open: (path: string, baud: number) => open(path, baud),
  close: () => close(),
  flush: async () => {
    rx = [];
  },
  wakeup: (addr: number) => wakeup(addr),
  kwRecv: (final?: boolean) => kwRecv(!!final),
  setBaud: (b: number) => setBaud(b),
  kwSend: (bytes: number[]) => kwSend(bytes),
  kwpSend: (msg: number[], p3?: number) => kwpSend(msg, p3 ?? kwpP3),
  kwpRecv: (timeout: number) => kwpRecv(timeout),
  kwpProbe: (msg: number[], p3: number, listenMs: number) => kwpProbe(msg, p3, listenMs),
  fastInit: (msg: number[]) => fastInit(msg),
  echoTest: () => echoTest(),
  stats: async () => ({ ...stats, open: !!port?.isOpen }),
};

// le dialogue octet par octet ne supporte pas d'attendre : ce processus passe avant la voix et l'écran
try {
  os.setPriority(0, -15);
  log("priorité haute pour la ligne K");
} catch {
  try {
    os.setPriority(0, -5);
  } catch {}
}

// une opération à la fois, dans l'ordre d'arrivée
let chain: Promise<unknown> = Promise.resolve();
let queued = 0;
function enqueue(fn: () => Promise<void>) {
  queued++;
  const go = async () => {
    queued--;
    busy = true;
    try {
      await fn();
    } finally {
      busy = false;
      lastIo = Date.now();
    }
  };
  chain = chain.then(go, go);
}
process.on("message", (m: { id: number; op: string; args: unknown[] }) => {
  enqueue(async () => {
    try {
      const fn = OPS[m.op];
      if (!fn) throw new Error("opération inconnue " + m.op);
      const result = await fn(...(m.args || []));
      post({ id: m.id, ok: true, result, open: !!port?.isOpen });
    } catch (e: any) {
      // une erreur au milieu d'un dialogue : la session est perdue
      if (m.op !== "wakeup" && m.op !== "echoTest") {
        proto = "";
        counter = null;
      }
      post({ id: m.id, ok: false, error: { message: String(e?.message || e), timeout: !!e?.timeout }, open: !!port?.isOpen });
    }
  });
});

// maintien : un bloc au plus tard 0,35 s après le dernier échange
setInterval(() => {
  if (!proto || !idleTurn || busy || queued > 0 || !port) return;
  if (Date.now() - lastIo < 350) return;
  enqueue(async () => {
    if (!proto || !idleTurn) return;
    try {
      await keepAlive();
    } catch (e: any) {
      log("liaison perdue pendant le maintien : " + (e?.message || e));
      proto = "";
      counter = null;
      post({ lost: String(e?.message || e) });
    }
  });
}, 50);

// le processus principal disparaît : on libère le câble et on s'arrête
process.on("disconnect", () => {
  void close().finally(() => process.exit(0));
});
