// Libellés des calculateurs (noms des valeurs, plages normales, réglages de base, adaptation, codage)
// lus dans une base « base_diagnostic.sqlite » que l'utilisateur pose lui-même :
//   - dans son dossier Nova (Windows : C:\Users\<toi>\Nova, Linux : ~/Nova) ;
//   - ou à la racine de la clé Nova OS (lisible depuis Windows), ou dans un dossier « nova » sur la clé.
// La base n'est pas fournie avec Nova. Sans elle, Nova garde ses propres libellés.
//
// Tables utilisées : labels (file, type, grp, field, name, sub, description), redirects (file, target,
// part_number), label_index (filename, component, part_number, vehicle).
import { createRequire } from "node:module";
import { promises as fs, existsSync } from "node:fs";
import path from "node:path";
import { jlog } from "../journaux.js";

const require = createRequire(import.meta.url);

export type LabelType = "measuring_block" | "basic_setting" | "adaptation" | "coding" | "prefix_L" | "prefix_S" | "prefix_T";

export interface Spec {
  /** condition de la spécification : « Idle », « Warm », « Load »… (vide = générale) */
  when: string;
  min: number | null;
  max: number | null;
  approx: number | null;
  text: string;
}

export interface FieldLabel {
  field: number;
  name: string;
  sub: string;
  description: string;
  range: string;
  specs: Spec[];
  bits: { mask: string; text: string }[];
}

export interface GroupLabel {
  grp: number;
  title: string;
  fields: FieldLabel[];
}

export interface ModuleLabels {
  file: string;
  component: string;
  vehicle: string;
  via: string;
}

const CANDIDATES = (dataDir: string) => [
  path.join(dataDir, "base_diagnostic.sqlite"),
  "/run/live/medium/base_diagnostic.sqlite",
  "/run/live/medium/nova/base_diagnostic.sqlite",
  "/run/live/medium/Nova/base_diagnostic.sqlite",
];

/** « 8N0906018H » ou « 8N0 906 018 H » → « 8N0-906-018-H » (format des fichiers de libellés). */
export function normPart(pn: string): string {
  const c = pn.replace(/[\s-]/g, "").toUpperCase();
  const m = /^([0-9A-Z]{3})([0-9]{3})([0-9]{3})([A-Z]{0,3})$/.exec(c);
  if (!m) return c;
  return [m[1], m[2], m[3]].join("-") + (m[4] ? "-" + m[4] : "");
}

/** Motif de label_index (« 8N?-920-9??-?? ») → expression régulière. */
function patternToRe(p: string) {
  const parts = p.split("/").map((x) => x.trim()).filter(Boolean);
  return parts.map((x) => {
    // le suffixe « -??? » est facultatif (8N8-962-267 sans lettre)
    const m = /^(.*?)(-\?+)$/.exec(x);
    const body = (m ? m[1] : x).replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\?/g, "[0-9A-Z]?");
    const tail = m ? "(-[0-9A-Z]{0," + (m[2].length - 1) + "})?" : "";
    return new RegExp("^" + body + tail + "$", "i");
  });
}

const num = (s: string) => {
  const v = Number(s.replace(",", ".").replace(/^\+/, ""));
  return Number.isFinite(v) ? v : null;
};

/** Découpe la description d'un champ : plage d'affichage, spécifications, signification des bits. */
export function parseDescription(desc: string): { range: string; specs: Spec[]; bits: { mask: string; text: string }[] } {
  const out = { range: "", specs: [] as Spec[], bits: [] as { mask: string; text: string }[] };
  if (!desc) return out;
  for (const raw of desc.split("|").map((x) => x.trim()).filter(Boolean)) {
    const bit = /^([x01]{4,16})\s*=\s*(.+)$/i.exec(raw);
    if (bit) {
      out.bits.push({ mask: bit[1].toLowerCase(), text: bit[2] });
      continue;
    }
    const r = /^(?:Display\s+)?Range:\s*(.+)$/i.exec(raw);
    if (r) {
      out.range = r[1];
      continue;
    }
    const sp = /^(?:Specification|Sollwert|Expected)\s*(?:\(([^)]*)\))?\s*:\s*(.+)$/i.exec(raw);
    if (sp) {
      const when = sp[1] || "";
      const v = sp[2];
      const interval = /([+-]?\d+(?:[.,]\d+)?)\s*\.{2,3}\s*([+-]?\d+(?:[.,]\d+)?)/.exec(v);
      const approx = /~\s*([+-]?\d+(?:[.,]\d+)?)/.exec(v);
      let min: number | null = null;
      let max: number | null = null;
      if (interval) {
        const a = num(interval[1]);
        const b = num(interval[2]);
        if (a != null && b != null) {
          min = Math.min(a, b);
          max = Math.max(a, b);
        }
      }
      out.specs.push({ when, min, max, approx: approx ? num(approx[1]) : null, text: v });
    }
  }
  return out;
}

/** Une valeur est-elle dans la spécification ? (null : pas de spécification chiffrée utilisable) */
export function checkSpec(value: number | null, specs: Spec[], context: string[] = []): { ok: boolean; spec: Spec } | null {
  if (value == null) return null;
  const usable = specs.filter((s) => s.min != null && s.max != null);
  if (!usable.length) return null;
  // spécification générale d'abord, sinon celle qui correspond au contexte (ralenti, chaud…)
  const pick = usable.find((s) => !s.when) ?? usable.find((s) => context.some((c) => s.when.toLowerCase().includes(c))) ?? null;
  if (!pick) return null;
  const tol = Math.max(Math.abs(pick.max! - pick.min!) * 0.001, 1e-9);
  return { ok: value >= pick.min! - tol && value <= pick.max! + tol, spec: pick };
}

export class Labels {
  private db: any = null;
  file = "";
  error = "";
  private cache = new Map<string, any>();

  constructor(private dataDir: string) {}

  get ready() {
    return !!this.db;
  }

  async load(): Promise<boolean> {
    if (this.db) return true;
    const file = CANDIDATES(this.dataDir).find((f) => existsSync(f));
    if (!file) {
      this.error = "base_diagnostic.sqlite introuvable";
      return false;
    }
    try {
      const initSqlJs = require("sql.js");
      const SQL = await initSqlJs({ locateFile: (f: string) => require.resolve("sql.js/dist/" + f) });
      const buf = await fs.readFile(file);
      this.db = new SQL.Database(new Uint8Array(buf));
      const n = this.all("select count(*) as n from labels")[0]?.n ?? 0;
      this.file = file;
      this.error = "";
      jlog("nova.log", `Base de libellés chargée : ${file} (${n} libellés)`);
      return true;
    } catch (e: any) {
      this.error = "base illisible : " + (e?.message || e);
      jlog("nova.log", "Base de libellés : " + this.error);
      this.db = null;
      return false;
    }
  }

  private all(sql: string, params: unknown[] = []): any[] {
    if (!this.db) return [];
    const st = this.db.prepare(sql);
    try {
      st.bind(params);
      const rows: any[] = [];
      while (st.step()) rows.push(st.getAsObject());
      return rows;
    } finally {
      st.free();
    }
  }

  private hasLabels(file: string) {
    return this.all("select 1 from labels where lower(file) = lower(?) limit 1", [file]).length > 0;
  }

  /**
   * Fichier de libellés d'un calculateur, d'après son numéro de pièce (identification) et son adresse.
   * Ordre : renvoi exact (redirects), motif de label_index, fichier au nom du numéro, fichier du châssis (8N-17…).
   */
  find(partNumber: string, addr: number, chassis = "", component = ""): ModuleLabels | null {
    if (!this.db) return null;
    const key = `${partNumber}|${addr}|${chassis}|${component}`;
    if (this.cache.has(key)) return this.cache.get(key);
    const pn = normPart(partNumber);
    const hex = addr.toString(16).toUpperCase().padStart(2, "0");
    const ch = (chassis || pn.slice(0, 2)).toUpperCase();
    let res: ModuleLabels | null = null;
    const meta = (file: string, via: string): ModuleLabels => {
      const idx = this.all("select component, vehicle from label_index where lower(filename) = lower(?) limit 1", [file])[0] || {};
      return { file, component: idx.component || "", vehicle: idx.vehicle || "", via };
    };
    // 1. renvoi exact par numéro de pièce
    if (pn) {
      const r = this.all("select target from redirects where upper(part_number) = ? limit 1", [pn])[0] ?? this.all("select target from redirects where upper(part_number) = ? limit 1", [pn.replace(/-[A-Z]{1,3}$/, "")])[0];
      if (r?.target && this.hasLabels(r.target)) res = meta(this.realName(r.target), "numéro de pièce " + pn);
    }
    // 2. motif de label_index (« 8N?-920-9??-?? »)
    if (!res && pn) {
      for (const row of this.all("select filename, part_number from label_index where part_number is not null")) {
        if (patternToRe(String(row.part_number)).some((re) => re.test(pn)) && this.hasLabels(row.filename)) {
          res = meta(row.filename, "famille " + row.part_number);
          break;
        }
      }
    }
    // 2 bis. motifs des renvois (« 8N?-962-267-??? »)
    if (!res && pn) {
      for (const row of this.all("select target, part_number from redirects where part_number like '%?%'")) {
        if (patternToRe(String(row.part_number)).some((re) => re.test(pn)) && this.hasLabels(row.target)) {
          res = meta(this.realName(row.target), "famille " + row.part_number);
          break;
        }
      }
    }
    // 3. fichier au nom du numéro (« 8N0-959-655.lbl »)
    if (!res && pn) {
      const base = pn.replace(/-[A-Z]{1,3}$/, "");
      for (const f of [pn + ".lbl", base + ".lbl"]) if (this.hasLabels(f)) res = meta(this.realName(f), "nom du fichier");
    }
    // 4. fichier générique du châssis et de l'adresse (« 8N-17.lbl »), ou l'un de ses renvois :
    //    celui dont le commentaire (« MK20 », « MK60 AWD »…) se retrouve dans l'identification
    if (!res && ch) {
      const f = `${ch}-${hex}.lbl`;
      if (this.hasLabels(f)) res = meta(this.realName(f), "châssis " + ch);
      else {
        const reds = this.all("select target, comment from redirects where lower(file) = lower(?)", [f]).filter((r) => this.hasLabels(r.target));
        const words = (component || "").toUpperCase();
        const best = reds.find((r) => r.comment && String(r.comment).toUpperCase().split(/\s+/).every((w: string) => words.includes(w))) ?? reds[0];
        if (best) res = meta(this.realName(best.target), `châssis ${ch}${best.comment ? " · " + best.comment : ""} (à vérifier)`);
      }
    }
    this.cache.set(key, res);
    return res;
  }

  private realName(f: string) {
    return this.all("select file from labels where lower(file) = lower(?) limit 1", [f])[0]?.file || f;
  }

  /** Libellés d'un groupe : mesures (measuring_block), réglage de base (basic_setting), adaptation. */
  group(file: string, type: LabelType, grp: number): GroupLabel | null {
    const key = `g|${file}|${type}|${grp}`;
    if (this.cache.has(key)) return this.cache.get(key);
    const g = String(grp).padStart(3, "0");
    const rows = this.all("select field, name, sub, description from labels where file = ? and type = ? and (grp = ? or grp = ?) order by cast(field as integer)", [file, type, g, String(grp)]);
    let res: GroupLabel | null = null;
    if (rows.length) {
      const title = rows.find((r) => String(r.field) === "0")?.name || "";
      const fields: FieldLabel[] = [];
      for (const r of rows) {
        const field = Number(r.field);
        if (!field) continue;
        const d = parseDescription(String(r.description || ""));
        fields.push({ field, name: String(r.name || ""), sub: String(r.sub || ""), description: String(r.description || ""), ...d });
      }
      res = { grp, title: String(title), fields };
    }
    this.cache.set(key, res);
    return res;
  }

  /** Liste des groupes connus d'un type (pour choisir un groupe par son nom). */
  groups(file: string, type: LabelType): { grp: number; title: string }[] {
    return this.all("select grp, name from labels where file = ? and type = ? and field = '0' order by cast(grp as integer)", [file, type])
      .map((r) => ({ grp: Number(r.grp), title: String(r.name || "") }))
      .filter((r) => Number.isFinite(r.grp));
  }

  /** Texte libre (codage, login, aide) : lignes dans l'ordre. */
  text(file: string, type: LabelType): string[] {
    // dans ces sections, le texte est rangé dans la colonne « field »
    return this.all("select coalesce(name, field) as t from labels where file = ? and type = ? order by cast(grp as integer)", [file, type]).map((r) => (r.t == null ? "" : String(r.t)));
  }

  /** Canaux d'adaptation : titre et explications. */
  adaptation(file: string): { channel: number; title: string; lines: string[] }[] {
    const rows = this.all("select grp, field, name, sub, description from labels where file = ? and type = 'adaptation' order by cast(grp as integer), cast(field as integer)", [file]);
    const map = new Map<number, { channel: number; title: string; lines: string[] }>();
    for (const r of rows) {
      const ch = Number(r.grp);
      if (!map.has(ch)) map.set(ch, { channel: ch, title: "", lines: [] });
      const e = map.get(ch)!;
      const t = [r.name, r.sub, r.description].filter((x) => x && x !== "null").join(" · ");
      if (String(r.field) === "0" && !e.title) e.title = String(r.name || "");
      else if (t && t !== e.title) e.lines.push(t);
    }
    return [...map.values()];
  }

  summary() {
    if (!this.db) return { ready: false, file: "", error: this.error, labels: 0, files: 0 };
    return {
      ready: true,
      file: this.file,
      error: "",
      labels: this.all("select count(*) as n from labels")[0]?.n ?? 0,
      files: this.all("select count(distinct file) as n from labels")[0]?.n ?? 0,
    };
  }
}

export interface CodingSection {
  mask: string;
  title: string;
  value: number | null;
  active: string[];
  options: string[];
}

/**
 * Décode un codage avec les explications du fichier de libellés :
 * « ??xxx: Options » puis « +01 = … » (options qui s'additionnent), ou « xx?xx: Pays » puis « 0 = … / 1 = … ».
 */
export function decodeCoding(lines: string[], coding: number | null): { title: string; sections: CodingSection[]; notes: string[] } {
  const out = { title: "", sections: [] as CodingSection[], notes: [] as string[] };
  let cur: (CodingSection & { add: { n: number; t: string }[]; en: { n: number; t: string }[] }) | null = null;
  const finish = () => {
    if (!cur) return;
    if (cur.value != null) {
      if (cur.add.length) {
        let left = cur.value;
        for (const o of [...cur.add].sort((a, b) => b.n - a.n)) {
          if (o.n > 0 && left >= o.n) {
            left -= o.n;
            cur.active.unshift(`+${String(o.n).padStart(2, "0")} ${o.t}`);
          }
        }
        if (left > 0) cur.active.push(`+${left} (inconnu)`);
        if (!cur.active.length) cur.active.push("aucune option");
      } else if (cur.en.length) {
        const hit = cur.en.find((o) => o.n === cur!.value);
        cur.active.push(hit ? `${hit.n} = ${hit.t}` : `${cur.value} (valeur non décrite)`);
      }
    }
    const { add: _a, en: _e, ...sec } = cur;
    out.sections.push(sec);
    cur = null;
  };
  for (const raw of lines) {
    const l = (raw || "").trim();
    if (!l) continue;
    const head = /^([?xX]{3,9})\s*:\s*(.+)$/.exec(l);
    if (head) {
      finish();
      const mask = head[1].toLowerCase();
      let value: number | null = null;
      if (coding != null) {
        const digits = String(coding).padStart(mask.length, "0").slice(-mask.length);
        const v = [...mask].map((c, i) => (c === "?" ? digits[i] : "")).join("");
        value = v ? Number(v) : null;
      }
      cur = { mask, title: head[2], value, active: [], options: [], add: [], en: [] };
      continue;
    }
    if (!out.title && !cur && !/=/.test(l)) {
      out.title = l;
      continue;
    }
    if (cur) {
      cur.options.push(l);
      const add = /^\+\s*(\d+)\s*=\s*(.+)$/.exec(l);
      if (add) cur.add.push({ n: Number(add[1]), t: add[2] });
      else for (const part of l.split(" / ")) {
        const e = /^(\d+)\s*=\s*(.+)$/.exec(part.trim());
        if (e) cur.en.push({ n: Number(e[1]), t: e[2] });
      }
    } else out.notes.push(l);
  }
  finish();
  return out;
}
