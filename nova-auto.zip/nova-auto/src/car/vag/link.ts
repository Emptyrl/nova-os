// Ligne K par câble KKL (FTDI, CH340…) : réveil 5 bauds, blocs KW1281, messages KWP2000.
// Tout le dialogue octet par octet se fait dans un processus à part (kline-worker) : la voix,
// l'écran et le reste de Nova ne peuvent plus décaler les octets. Ici, on ne manipule que des blocs.
import { fork, type ChildProcess } from "node:child_process";
import { fileURLToPath } from "node:url";
import { jlog } from "../journaux.js";

export class Timeout extends Error {
  constructor(what: string) {
    super(what.startsWith("pas de réponse") ? what : "pas de réponse (" + what + ")");
  }
}

export interface Wake {
  version: number; // 1281 = KW1281, ≥ 2000 = KWP2000
  kw1: number;
  kw2: number;
  ms: number;
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
export const hex = (b: number) => b.toString(16).toUpperCase().padStart(2, "0");

export class KLine {
  path = "";
  trace: string[] = [];
  /** Essais sans câble : l'émulateur reçoit l'adresse comme un octet normal. */
  testMode = process.env.NOVA_KLINE_TEST === "1";
  private worker: ChildProcess | null = null;
  private seq = 0;
  private pending = new Map<number, { res: (v: any) => void; rej: (e: any) => void }>();
  private opened = false;

  /** Appelé quand le processus de la ligne K a perdu la session pendant un maintien. */
  onLost: ((why: string) => void) | null = null;

  get isOpen() {
    return this.opened;
  }

  log(t: string) {
    jlog("ligne-k.log", t);
    this.trace.push(`${new Date().toISOString().slice(11, 23)} ${t}`);
    if (this.trace.length > 400) this.trace.splice(0, 100);
  }

  private ensureWorker() {
    if (this.worker && this.worker.connected) return this.worker;
    const w = fork(fileURLToPath(new URL("./kline-worker.js", import.meta.url)), [], { stdio: ["ignore", "ignore", "pipe", "ipc"], env: process.env });
    w.stderr?.on("data", (d) => this.log("ligne K (erreur) : " + String(d).trim().slice(0, 500)));
    w.on("message", (m: any) => {
      if (m.log) return this.log(m.log);
      if (m.lost) return this.onLost?.(m.lost);
      if (m.closed) {
        this.opened = false;
        return;
      }
      const p = this.pending.get(m.id);
      if (!p) return;
      this.pending.delete(m.id);
      if (typeof m.open === "boolean") this.opened = m.open;
      if (m.ok) p.res(m.result);
      else p.rej(m.error.timeout ? new Timeout(m.error.message) : new Error(m.error.message));
    });
    const gone = (why: string) => {
      if (this.worker !== w) return;
      this.log("processus de la ligne K arrêté (" + why + ")");
      for (const p of this.pending.values()) p.rej(new Error("liaison avec le câble interrompue"));
      this.pending.clear();
      this.worker = null;
      this.opened = false;
    };
    w.on("error", (e) => gone(e.message));
    w.on("exit", (code, sig) => gone(`code ${code ?? sig}`));
    this.worker = w;
    return w;
  }

  private call<T>(op: string, ...args: unknown[]): Promise<T> {
    const w = this.ensureWorker();
    const id = ++this.seq;
    return new Promise<T>((res, rej) => {
      this.pending.set(id, { res, rej });
      w.send({ id, op, args });
    });
  }

  async open(path: string, baudRate = 10400) {
    await this.call("open", path, baudRate);
    this.path = path;
    this.opened = true;
  }

  async close() {
    if (!this.worker) return;
    await this.call("close");
    this.opened = false;
  }

  flush() {
    if (this.worker) void this.call("flush").catch(() => {});
  }

  wakeup(addr: number): Promise<Wake> {
    return this.call<Wake>("wakeup", addr);
  }

  /** Début d'une session : le processus de la ligne K en assure le maintien tout seul. */
  begin(proto: "kw1281" | "kwp", addr: number, lenInFmt = false, p3 = 55): Promise<void> {
    return this.call("begin", proto, addr, lenInFmt, p3);
  }

  /** KWP2000 : envoie un message et renvoie tous les octets bruts reçus (recherche de la bonne forme). */
  kwpProbe(msg: number[], p3: number, listenMs: number): Promise<number[]> {
    return this.call("kwpProbe", msg, p3, listenMs);
  }

  end(): Promise<void> {
    return this.call("end");
  }

  /** KW1281 : envoie un bloc (compteur géré dans le processus de la ligne K). */
  kwBlock(title: number, data: number[] = []): Promise<void> {
    return this.call("kwBlock", title, data);
  }

  /** KW1281 : reçoit un bloc entier (chaque octet acquitté dans le fil de la ligne K). */
  kwRecv(final = false): Promise<{ cnt: number; title: number; data: number[] }> {
    return this.call("kwRecv", final);
  }

  /** Vitesse de la ligne : 10 400 bauds pour la plupart, 9 600 ou 4 800 pour certains calculateurs. */
  setBaud(b: number): Promise<void> {
    return this.call("setBaud", b);
  }

  /** KW1281 : envoie un bloc entier ([longueur, compteur, titre, données…], la fin 0x03 est ajoutée). */
  kwSend(bytes: number[]): Promise<void> {
    return this.call("kwSend", bytes);
  }

  kwpSend(msg: number[], p3 = 55): Promise<void> {
    return this.call("kwpSend", msg, p3);
  }

  kwpRecv(timeout: number): Promise<number[]> {
    return this.call("kwpRecv", timeout);
  }

  echoTest(): Promise<boolean> {
    return this.call("echoTest");
  }

  stats(): Promise<{ echoSeen: number; echoMissing: number; open: boolean }> {
    return this.call("stats");
  }
}
