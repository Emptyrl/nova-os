// Ligne K par câble KKL (FTDI, CH340…) : réveil 5 bauds, lecture octet par octet, écho.
// Le câble KKL renvoie chaque octet envoyé (une seule ligne pour émettre et recevoir) : on le relit et on le jette.
import { SerialPort } from "serialport";

export class Timeout extends Error {
  constructor(what: string) {
    super("pas de réponse (" + what + ")");
  }
}

export interface Wake {
  version: number; // 1281 = KW1281, ≥ 2000 = KWP2000
  kw1: number;
  kw2: number;
  ms: number;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const hex = (b: number) => b.toString(16).toUpperCase().padStart(2, "0");

/** Attente précise : setTimeout jusqu'à 20 ms avant, puis attente active (le minuteur Windows est à ~16 ms). */
async function until(t: number) {
  const left = t - performance.now();
  if (left > 22) await sleep(left - 20);
  while (performance.now() < t) {
    /* attente active, 20 ms maximum */
  }
}

export class KLine {
  port: SerialPort | null = null;
  path = "";
  private rx: number[] = [];
  private waiter: (() => void) | null = null;
  trace: string[] = [];
  echoSeen = 0;
  echoMissing = 0;
  /** Essais sans câble : l'émulateur reçoit l'adresse comme un octet normal. */
  testMode = process.env.NOVA_KLINE_TEST === "1";

  get isOpen() {
    return !!this.port?.isOpen;
  }

  log(t: string) {
    this.trace.push(`${new Date().toISOString().slice(11, 23)} ${t}`);
    if (this.trace.length > 400) this.trace.splice(0, 100);
  }

  async open(path: string, baudRate = 10400) {
    await this.close();
    const port = new SerialPort({ path, baudRate, autoOpen: false, dataBits: 8, stopBits: 1, parity: "none" });
    await new Promise<void>((res, rej) => port.open((e) => (e ? rej(e) : res())));
    // la plupart des câbles KKL alimentent leur interface par DTR
    await new Promise<void>((res) => port.set({ dtr: true, rts: false, brk: false }, () => res()));
    port.on("data", (b: Buffer) => {
      for (const x of b) this.rx.push(x);
      const w = this.waiter;
      this.waiter = null;
      w?.();
    });
    port.on("close", () => {
      if (this.port === port) this.port = null;
    });
    this.port = port;
    this.path = path;
    this.rx = [];
    this.log(`port ${path} ouvert à ${baudRate} bauds`);
  }

  async close() {
    const p = this.port;
    this.port = null;
    if (p?.isOpen) await new Promise<void>((r) => p.close(() => r()));
  }

  flush() {
    this.rx = [];
  }

  async readByte(timeout = 1000, what = "octet"): Promise<number> {
    const end = Date.now() + timeout;
    while (!this.rx.length) {
      if (!this.port) throw new Error("câble débranché");
      const left = end - Date.now();
      if (left <= 0) throw new Timeout(what);
      await new Promise<void>((res) => {
        const t = setTimeout(() => {
          this.waiter = null;
          res();
        }, left);
        this.waiter = () => {
          clearTimeout(t);
          res();
        };
      });
    }
    return this.rx.shift()!;
  }

  private async rawWrite(bytes: number[]) {
    const p = this.port;
    if (!p) throw new Error("câble débranché");
    await new Promise<void>((res, rej) => p.write(Buffer.from(bytes), (e) => (e ? rej(e) : res())));
    await new Promise<void>((res) => p.drain(() => res()));
  }

  /** Envoie un octet et jette son écho. */
  async writeByte(b: number) {
    await this.rawWrite([b]);
    try {
      const e = await this.readByte(120, "écho");
      if (e === b) this.echoSeen++;
      else {
        // pas notre écho : c'est déjà la réponse, on la remet en tête
        this.rx.unshift(e);
        this.echoMissing++;
      }
    } catch {
      this.echoMissing++;
    }
  }

  private async setBreak(on: boolean) {
    const p = this.port;
    if (!p) throw new Error("câble débranché");
    await new Promise<void>((res, rej) => p.set({ brk: on, dtr: true, rts: false }, (e) => (e ? rej(e) : res())));
  }

  /**
   * Réveil d'un calculateur : son adresse envoyée à 5 bauds (bit de départ, 7 bits + parité impaire,
   * bit d'arrêt, 200 ms par bit), puis synchro 0x55, deux mots-clés, et le complément du 2e mot-clé.
   */
  async wakeup(addr: number): Promise<Wake> {
    const t0 = Date.now();
    await sleep(300); // ligne au repos
    this.flush();
    let a = addr & 0x7f;
    let ones = 0;
    for (let i = 0; i < 7; i++) if (a & (1 << i)) ones++;
    if (ones % 2 === 0) a |= 0x80; // parité impaire
    this.log(`réveil 5 bauds de l'adresse ${hex(addr)} (octet ${hex(a)})`);
    if (this.testMode) {
      await this.rawWrite([a]);
      await sleep(50);
    } else {
      const bits = [0, ...Array.from({ length: 8 }, (_, i) => (a >> i) & 1), 1];
      const start = performance.now();
      for (let i = 0; i < bits.length; i++) {
        await until(start + i * 200);
        await this.setBreak(bits[i] === 0); // 0 = ligne tirée à la masse (break)
      }
      await until(start + bits.length * 200);
    }
    this.flush(); // ce qu'on a reçu pendant le break n'est que notre propre signal
    const sync = await this.readByte(1500, "octet de synchro 0x55");
    this.log(`synchro reçue : ${hex(sync)}`);
    if (sync !== 0x55) throw new Error(`synchro inattendue ${hex(sync)} (attendu 55) : vitesse du port incorrecte ?`);
    const kw1 = await this.readByte(500, "mot-clé 1");
    const kw2 = await this.readByte(500, "mot-clé 2");
    const version = ((kw2 & 0x7f) << 7) + (kw1 & 0x7f);
    this.log(`mots-clés ${hex(kw1)} ${hex(kw2)} → protocole ${version >= 2000 ? "KWP2000" : "KW" + version}`);
    await sleep(25);
    await this.writeByte(kw2 ^ 0xff);
    if (version >= 2000) {
      const c = await this.readByte(500, "complément de l'adresse");
      if (c !== (a ^ 0xff) && c !== (addr ^ 0xff)) this.log(`complément d'adresse inattendu : ${hex(c)}`);
    }
    return { version, kw1, kw2, ms: Date.now() - t0 };
  }
}

export { hex, sleep };
