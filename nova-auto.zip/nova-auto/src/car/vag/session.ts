// Dialogue avec un calculateur VAG une fois réveillé : KW1281 (la plupart des calculateurs de 2003)
// ou KWP2000 sur ligne K (souvent le ME7.5). Même interface pour les deux.
import { KLine, Timeout, hex, sleep, type Wake } from "./link.js";
import { decodeGroup, type Field } from "./formulas.js";
import { decodeFault, isNoFault, type Fault } from "./modules.js";

export interface Ident {
  partNumber: string;
  component: string;
  extra: string[];
  coding: number | null;
  wsc: number | null;
  raw: string;
}

export interface Session {
  protocol: string;
  addr: number;
  ident: Ident;
  readIdent(): Promise<Ident>;
  readGroup(n: number): Promise<Field[] | null>; // null : groupe inexistant
  readFaults(): Promise<Fault[]>;
  clearFaults(): Promise<void>;
  keepAlive(): Promise<void>;
  end(): Promise<void>;
}

export class NegativeResponse extends Error {}

function parseIdent(ascii: string, codingBytes: number[] | null): Ident {
  const clean = ascii.replace(/[^\x20-\x7e\n]/g, " ");
  const lines = clean.split("\n").map((l) => l.trim()).filter(Boolean);
  const first = lines[0] ?? "";
  const partNumber = first.slice(0, 12).trim();
  const component = first.slice(12).replace(/\s+/g, " ").trim();
  let coding: number | null = null;
  let wsc: number | null = null;
  if (codingBytes && codingBytes.length >= 5) {
    coding = ((codingBytes[1] << 8) | codingBytes[2]) >> 1;
    wsc = (codingBytes[2] & 1) * 65536 + codingBytes[3] * 256 + codingBytes[4];
  }
  return { partNumber, component, extra: lines.slice(1), coding, wsc, raw: clean.trim() };
}

// ======================= KW1281 =======================
const T = { ReadIdent: 0x00, FaultsDelete: 0x05, End: 0x06, FaultsRead: 0x07, ACK: 0x09, NAK: 0x0a, GroupRead: 0x29, GroupResp: 0xe7, Ascii: 0xf6, FaultsResp: 0xfc, GroupRespText: 0x02 };

interface Block {
  title: number;
  data: number[];
}

export class KW1281 implements Session {
  protocol = "KW1281";
  ident: Ident = parseIdent("", null);
  private counter: number | null = null;

  constructor(private k: KLine, public addr: number) {}

  private async ackByte(b: number) {
    await sleep(2);
    await this.k.writeByte(b ^ 0xff);
  }

  private async recvBlock(): Promise<Block> {
    let len = await this.k.readByte(1200, "début de bloc");
    // le calculateur peut se re-synchroniser (0x55, mots-clés)
    for (let i = 0; len === 0x55 && i < 5; i++) {
      await this.k.readByte(500);
      const kw2 = await this.k.readByte(500);
      await sleep(25);
      await this.k.writeByte(kw2 ^ 0xff);
      len = await this.k.readByte(1200, "début de bloc");
    }
    await this.ackByte(len);
    const cnt = await this.k.readByte(500, "compteur de bloc");
    await this.ackByte(cnt);
    if (this.counter !== null && cnt !== this.counter) this.k.log(`compteur reçu ${cnt}, attendu ${this.counter}`);
    this.counter = (cnt + 1) & 0xff;
    const title = await this.k.readByte(500, "titre de bloc");
    await this.ackByte(title);
    const data: number[] = [];
    for (let i = 0; i < len - 3; i++) {
      const b = await this.k.readByte(500, "donnée");
      await this.ackByte(b);
      data.push(b);
    }
    const end = await this.k.readByte(500, "fin de bloc");
    if (end !== 0x03) throw new Error(`fin de bloc inattendue ${hex(end)}`);
    return { title, data };
  }

  private async sendBlock(title: number, data: number[] = []) {
    await sleep(25);
    const bytes = [data.length + 3, this.counter ?? 0, title, ...data];
    this.counter = ((this.counter ?? 0) + 1) & 0xff;
    for (const b of bytes) {
      await sleep(2);
      await this.k.writeByte(b);
      const c = await this.k.readByte(500, "acquittement d'octet");
      if (c !== (b ^ 0xff)) throw new Error(`acquittement faux ${hex(c)} pour ${hex(b)}`);
    }
    await sleep(2);
    await this.k.writeByte(0x03);
  }

  /** Reçoit des blocs jusqu'à un ACK ou un NAK, en acquittant chacun. */
  private async receiveBlocks(): Promise<Block[]> {
    const out: Block[] = [];
    for (let i = 0; i < 40; i++) {
      const b = await this.recvBlock();
      out.push(b);
      if (b.title === T.ACK || b.title === T.NAK) return out;
      await this.sendBlock(T.ACK);
    }
    return out;
  }

  private identFrom(blocks: Block[]): { ascii: string; coding: number[] | null; more: boolean } {
    let ascii = "";
    let coding: number[] | null = null;
    let more = false;
    for (const b of blocks) {
      if (b.title !== T.Ascii) continue;
      if (b.data[0] === 0x00) coding = b.data;
      else {
        more = (b.data[b.data.length - 1] & 0x80) !== 0;
        ascii += b.data.map((c) => String.fromCharCode(c & 0x7f)).join("");
      }
    }
    return { ascii, coding, more };
  }

  /** Juste après le réveil : le calculateur envoie lui-même son identification. */
  async start() {
    const first = this.identFrom(await this.receiveBlocks());
    let ascii = first.ascii;
    let more = first.more;
    for (let i = 0; more && i < 4; i++) {
      await this.sendBlock(T.ReadIdent);
      const r = this.identFrom(await this.receiveBlocks());
      ascii += "\n" + r.ascii;
      more = r.more;
    }
    this.ident = parseIdent(ascii, first.coding);
    return this;
  }

  async readIdent() {
    return this.ident;
  }

  async readGroup(n: number): Promise<Field[] | null> {
    await this.sendBlock(T.GroupRead, [n]);
    const blocks = await this.receiveBlocks();
    const g = blocks.find((b) => b.title === T.GroupResp || b.title === T.GroupRespText);
    if (!g) return null;
    return decodeGroup(g.data);
  }

  async readFaults(): Promise<Fault[]> {
    await this.sendBlock(T.FaultsRead);
    const blocks = await this.receiveBlocks();
    const out: Fault[] = [];
    for (const b of blocks) {
      if (b.title !== T.FaultsResp) continue;
      for (let i = 0; i + 2 < b.data.length; i += 3) {
        if (isNoFault(b.data[i], b.data[i + 1])) continue;
        out.push(decodeFault(b.data[i], b.data[i + 1], b.data[i + 2]));
      }
    }
    return out;
  }

  async clearFaults() {
    await this.sendBlock(T.FaultsDelete);
    await this.receiveBlocks();
  }

  async keepAlive() {
    await this.sendBlock(T.ACK);
    const b = await this.recvBlock();
    if (b.title !== T.ACK) this.k.log(`maintien : bloc ${hex(b.title)} reçu au lieu d'ACK`);
  }

  async end() {
    try {
      await this.sendBlock(T.End);
    } catch {
      /* le calculateur coupe parfois avant la fin */
    }
  }
}

// ======================= KWP2000 sur ligne K =======================
export class KWP2000 implements Session {
  protocol = "KWP2000";
  ident: Ident = parseIdent("", null);

  constructor(private k: KLine, public addr: number) {}

  private async send(sid: number, data: number[]) {
    await sleep(55); // P3 : délai entre deux messages
    const body = [sid, ...data];
    const msg = [0x80, this.addr, 0xf1, body.length, ...body];
    msg.push(msg.reduce((a, b) => a + b, 0) & 0xff);
    for (let i = 0; i < msg.length; i++) {
      await this.k.writeByte(msg[i]);
      if (i < msg.length - 1) await sleep(5); // P4
    }
  }

  private async receive(timeout: number): Promise<number[]> {
    const fmt = await this.k.readByte(timeout, "réponse KWP2000");
    const bytes = [fmt];
    if (fmt & 0x80) {
      bytes.push(await this.k.readByte(200), await this.k.readByte(200));
    }
    let len = fmt & 0x3f;
    if (!len) {
      len = await this.k.readByte(200);
      bytes.push(len);
    }
    const body: number[] = [];
    for (let i = 0; i < len; i++) body.push(await this.k.readByte(200, "donnée KWP2000"));
    const cs = await this.k.readByte(200, "somme de contrôle");
    const sum = [...bytes, ...body].reduce((a, b) => a + b, 0) & 0xff;
    if (cs !== sum) this.k.log(`somme de contrôle fausse (${hex(cs)} au lieu de ${hex(sum)})`);
    return body;
  }

  async request(sid: number, data: number[] = []): Promise<number[]> {
    await this.send(sid, data);
    let timeout = 1000;
    for (let i = 0; i < 30; i++) {
      const body = await this.receive(timeout);
      if (body[0] === 0x7f) {
        if (body[2] === 0x78) {
          timeout = 5000; // « réponse en préparation »
          continue;
        }
        throw new NegativeResponse(`refus du calculateur (service ${hex(body[1])}, code ${hex(body[2])})`);
      }
      if (body[0] === sid + 0x40) return body.slice(1);
      this.k.log(`réponse ignorée ${hex(body[0])}`);
    }
    throw new Timeout("réponse KWP2000");
  }

  async start() {
    await this.request(0x10, [0x89]); // session de diagnostic VAG
    await this.readIdent();
    return this;
  }

  async readIdent() {
    try {
      const r = await this.request(0x1a, [0x9b]);
      const ascii = r.slice(1).map((c) => (c >= 0x20 && c < 0x7f ? String.fromCharCode(c) : " ")).join("");
      // référence (12), version logicielle, puis désignation
      const part = ascii.slice(0, 12).trim();
      const rest = ascii.slice(12).replace(/\s{2,}/g, "\n").split("\n").map((s) => s.trim()).filter(Boolean);
      this.ident = { partNumber: part, component: rest.join(" "), extra: [], coding: null, wsc: null, raw: ascii.trim() };
    } catch (e: any) {
      this.k.log("identification KWP2000 : " + e.message);
    }
    return this.ident;
  }

  async readGroup(n: number): Promise<Field[] | null> {
    try {
      const r = await this.request(0x21, [n]);
      return decodeGroup(r.slice(1));
    } catch (e) {
      if (e instanceof NegativeResponse) return null;
      throw e;
    }
  }

  async readFaults(): Promise<Fault[]> {
    const r = await this.request(0x18, [0x02, 0xff, 0x00]);
    const out: Fault[] = [];
    for (let i = 1; i + 2 < r.length; i += 3) {
      if (isNoFault(r[i], r[i + 1])) continue;
      out.push(decodeFault(r[i], r[i + 1], r[i + 2]));
    }
    return out;
  }

  async clearFaults() {
    await this.request(0x14, [0xff, 0x00]);
  }

  async keepAlive() {
    await this.request(0x3e, [0x01]);
  }

  async end() {
    try {
      await this.send(0x82, []);
    } catch {
      /* fin de communication sans réponse */
    }
  }
}

/** Réveille un calculateur et ouvre le bon dialogue. */
export async function openSession(k: KLine, addr: number): Promise<{ session: Session; wake: Wake }> {
  const wake = await k.wakeup(addr);
  const s = wake.version >= 2000 ? await new KWP2000(k, addr).start() : await new KW1281(k, addr).start();
  return { session: s, wake };
}
