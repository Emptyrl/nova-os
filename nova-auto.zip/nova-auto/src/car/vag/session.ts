// Dialogue avec un calculateur VAG une fois réveillé : KW1281 (la plupart des calculateurs de 2003)
// ou KWP2000 sur ligne K (souvent le ME7.5). Même interface pour les deux.
import { KLine, Timeout, hex, sleep, type Wake } from "./link.js";
import { decodeGroup, type Field } from "./formulas.js";
import { decodeFault, isNoFault, type Fault } from "./modules.js";

export interface Ident {
  partNumber: string;
  component: string;
  extra: string[];
  coding: number | null;
  wsc: number | null;
  raw: string;
}

export interface Session {
  protocol: string;
  addr: number;
  ident: Ident;
  readIdent(): Promise<Ident>;
  readGroup(n: number): Promise<Field[] | null>; // null : groupe inexistant
  readFaults(): Promise<Fault[]>;
  clearFaults(): Promise<void>;
  keepAlive(): Promise<void>;
  end(): Promise<void>;
  /** Réglage de base d'un groupe : le calculateur lance la procédure et renvoie les valeurs du groupe. */
  basicSetting?(n: number): Promise<Field[] | null>;
  /** Test des actionneurs : passe à l'actionneur suivant ; null quand la séquence est terminée. */
  outputTest?(): Promise<{ code: number } | null>;
}

export class NegativeResponse extends Error {}

function parseIdent(ascii: string, codingBytes: number[] | null): Ident {
  const clean = ascii.replace(/[^\x20-\x7e\n]/g, " ");
  const lines = clean.split("\n").map((l) => l.trim()).filter(Boolean);
  const first = lines[0] ?? "";
  const partNumber = first.slice(0, 12).trim();
  const component = first.slice(12).replace(/\s+/g, " ").trim();
  let coding: number | null = null;
  let wsc: number | null = null;
  if (codingBytes && codingBytes.length >= 5) {
    coding = ((codingBytes[1] << 8) | codingBytes[2]) >> 1;
    wsc = (codingBytes[2] & 1) * 65536 + codingBytes[3] * 256 + codingBytes[4];
  }
  return { partNumber, component, extra: lines.slice(1), coding, wsc, raw: clean.trim() };
}

// ======================= KW1281 =======================
const T = { OutputTest: 0x04, OutputResp: 0xf5, BasicSetting: 0x28, ReadIdent: 0x00, FaultsDelete: 0x05, End: 0x06, FaultsRead: 0x07, ACK: 0x09, NAK: 0x0a, GroupRead: 0x29, GroupResp: 0xe7, Ascii: 0xf6, FaultsResp: 0xfc, GroupRespText: 0x02 };

interface Block {
  title: number;
  data: number[];
}

export class KW1281 implements Session {
  protocol = "KW1281";
  ident: Ident = parseIdent("", null);

  constructor(private k: KLine, public addr: number) {}

  private async recvBlock(final = false): Promise<Block> {
    const b = await this.k.kwRecv(final);
    return { title: b.title, data: b.data };
  }

  /**
   * Requête à réponse unique (mesures, réglage de base, actionneur) : un seul bloc en retour, sans
   * échange d'ACK derrière. Deux fois moins d'octets : lecture en direct deux fois plus rapide.
   */
  /** false : ce calculateur veut l'échange d'ACK complet après chaque réponse (mode prudent). */
  fast = true;
  onSlow: (() => void) | null = null;

  private async single(title: number, data: number[] = []): Promise<Block> {
    if (!this.fast) {
      await this.sendBlock(title, data);
      const blocks = await this.receiveBlocks();
      return blocks.find((b) => b.title !== T.ACK) ?? blocks[blocks.length - 1];
    }
    await this.sendBlock(title, data);
    const b = await this.recvBlock(true);
    // un simple ACK en réponse : ce calculateur a pris notre demande pour l'accusé de réception qu'il
    // attendait. Il veut l'échange complet : on passe en mode prudent et on redemande.
    if (b.title === T.ACK) {
      this.fast = false;
      this.k.log(`${hex(this.addr)} : réponse ACK à une demande, passage en lecture prudente`);
      this.onSlow?.();
      return this.single(title, data);
    }
    // en-tête de groupe en texte (0x02) : la suite arrive après un ACK
    if (b.title === T.GroupRespText) {
      const more = await (async () => {
        await this.sendBlock(T.ACK);
        return this.receiveBlocks();
      })();
      const g = more.find((x) => x.title === T.GroupResp);
      return g ?? b;
    }
    return b;
  }

  private async sendBlock(title: number, data: number[] = []) {
    await this.k.kwBlock(title, data);
  }

  /** Reçoit des blocs jusqu'à un ACK ou un NAK, en acquittant chacun. */
  private async receiveBlocks(): Promise<Block[]> {
    const out: Block[] = [];
    for (let i = 0; i < 40; i++) {
      const b = await this.recvBlock();
      out.push(b);
      if (b.title === T.ACK || b.title === T.NAK) return out;
      await this.sendBlock(T.ACK);
    }
    return out;
  }

  private identFrom(blocks: Block[]): { ascii: string; coding: number[] | null; more: boolean } {
    let ascii = "";
    let coding: number[] | null = null;
    let more = false;
    for (const b of blocks) {
      if (b.title !== T.Ascii) continue;
      if (b.data[0] === 0x00) coding = b.data;
      else {
        more = (b.data[b.data.length - 1] & 0x80) !== 0;
        ascii += b.data.map((c) => String.fromCharCode(c & 0x7f)).join("");
      }
    }
    return { ascii, coding, more };
  }

  /** Juste après le réveil : le calculateur envoie lui-même son identification. */
  async start() {
    const first = this.identFrom(await this.receiveBlocks());
    let ascii = first.ascii;
    let more = first.more;
    for (let i = 0; more && i < 4; i++) {
      await this.sendBlock(T.ReadIdent);
      const r = this.identFrom(await this.receiveBlocks());
      ascii += "\n" + r.ascii;
      more = r.more;
    }
    this.ident = parseIdent(ascii, first.coding);
    return this;
  }

  async readIdent() {
    return this.ident;
  }

  async readGroup(n: number): Promise<Field[] | null> {
    const b = await this.single(T.GroupRead, [n]);
    if (b.title !== T.GroupResp && b.title !== T.GroupRespText) return null; // NAK : groupe inexistant
    return decodeGroup(b.data);
  }

  async basicSetting(n: number): Promise<Field[] | null> {
    const b = await this.single(T.BasicSetting, [n]);
    if (b.title !== T.GroupResp && b.title !== T.GroupRespText) return null;
    return decodeGroup(b.data);
  }

  /** Actionneur suivant : le calculateur répond par le code de l'actionneur en marche (bloc F5), puis
   *  le maintien (ACK) le laisse fonctionner jusqu'à la demande suivante. */
  async outputTest(): Promise<{ code: number } | null> {
    const b = await this.single(T.OutputTest);
    if (b.title !== T.OutputResp || b.data.length < 2) return null; // ACK/NAK : séquence terminée ou refusée
    const code = (b.data[0] << 8) | b.data[1];
    return code === 0 ? null : { code };
  }

  async readFaults(): Promise<Fault[]> {
    await this.sendBlock(T.FaultsRead);
    const blocks = await this.receiveBlocks();
    const out: Fault[] = [];
    for (const b of blocks) {
      if (b.title !== T.FaultsResp) continue;
      for (let i = 0; i + 2 < b.data.length; i += 3) {
        if (isNoFault(b.data[i], b.data[i + 1])) continue;
        out.push(decodeFault(b.data[i], b.data[i + 1], b.data[i + 2]));
      }
    }
    return out;
  }

  async clearFaults() {
    await this.sendBlock(T.FaultsDelete);
    await this.receiveBlocks();
  }

  async keepAlive() {
    /* le maintien est fait par le processus de la ligne K */
  }

  async end() {
    try {
      await this.sendBlock(T.End);
    } catch {
      /* le calculateur coupe parfois avant la fin */
    }
  }
}

// ======================= KWP2000 sur ligne K =======================
// adresses KWP2000 « physiques » à essayer si le calculateur ne répond pas à son adresse VAG
const KWP_ALT: Record<number, number[]> = { 0x01: [0x10, 0x11], 0x02: [0x18], 0x03: [0x28, 0x29], 0x15: [0x58], 0x17: [0x60], 0x22: [0x34] };

export class KWP2000 implements Session {
  protocol = "KWP2000";
  ident: Ident = parseIdent("", null);
  /** adresse cible dans l'en-tête des messages (en principe l'adresse VAG du calculateur) */
  private target: number;

  constructor(private k: KLine, public addr: number) {
    this.target = addr;
  }

  private async send(sid: number, data: number[]) {
    const body = [sid, ...data];
    const msg = [0x80, this.target, 0xf1, body.length, ...body];
    msg.push(msg.reduce((a, b) => a + b, 0) & 0xff);
    await this.k.kwpSend(msg);
  }

  private receive(timeout: number): Promise<number[]> {
    return this.k.kwpRecv(timeout);
  }

  async request(sid: number, data: number[] = []): Promise<number[]> {
    await this.send(sid, data);
    let timeout = 1000;
    for (let i = 0; i < 30; i++) {
      const body = await this.receive(timeout);
      if (body[0] === 0x7f) {
        if (body[2] === 0x78) {
          timeout = 5000; // « réponse en préparation »
          continue;
        }
        throw new NegativeResponse(`refus du calculateur (service ${hex(body[1])}, code ${hex(body[2])})`);
      }
      if (body[0] === sid + 0x40) return body.slice(1);
      this.k.log(`réponse ignorée ${hex(body[0])}`);
    }
    throw new Timeout("réponse KWP2000");
  }

  async start() {
    // session de diagnostic VAG ; si rien ne répond à l'adresse VAG, on essaie les adresses KWP2000 connues
    const targets = [this.addr, ...(KWP_ALT[this.addr] || [])];
    let started = false;
    let lastErr: any = null;
    for (const t of targets) {
      this.target = t;
      try {
        await this.request(0x10, [0x89]);
        started = true;
      } catch (e: any) {
        if (e instanceof NegativeResponse) started = true; // il a répondu (refus) : la bonne adresse
        else lastErr = e;
      }
      if (started) {
        if (t !== this.addr) this.k.log(`KWP2000 : le calculateur ${hex(this.addr)} répond à l'adresse ${hex(t)}`);
        break;
      }
      this.k.log(`KWP2000 : pas de réponse à l'adresse ${hex(t)}`);
    }
    if (!started) {
      // dernier essai : identification directe, sans ouverture de session
      this.target = this.addr;
      try {
        await this.request(0x1a, [0x9b]);
        started = true;
      } catch (e: any) {
        if (e instanceof NegativeResponse) started = true;
        else throw lastErr || e;
      }
    }
    await this.readIdent();
    return this;
  }

  async readIdent() {
    try {
      const r = await this.request(0x1a, [0x9b]);
      const ascii = r.slice(1).map((c) => (c >= 0x20 && c < 0x7f ? String.fromCharCode(c) : " ")).join("");
      // référence (12), version logicielle, puis désignation
      const part = ascii.slice(0, 12).trim();
      const rest = ascii.slice(12).replace(/\s{2,}/g, "\n").split("\n").map((s) => s.trim()).filter(Boolean);
      this.ident = { partNumber: part, component: rest.join(" "), extra: [], coding: null, wsc: null, raw: ascii.trim() };
    } catch (e: any) {
      this.k.log("identification KWP2000 : " + e.message);
    }
    return this.ident;
  }

  async readGroup(n: number): Promise<Field[] | null> {
    try {
      const r = await this.request(0x21, [n]);
      return decodeGroup(r.slice(1));
    } catch (e) {
      if (e instanceof NegativeResponse) return null;
      throw e;
    }
  }

  async readFaults(): Promise<Fault[]> {
    const r = await this.request(0x18, [0x02, 0xff, 0x00]);
    const out: Fault[] = [];
    for (let i = 1; i + 2 < r.length; i += 3) {
      if (isNoFault(r[i], r[i + 1])) continue;
      out.push(decodeFault(r[i], r[i + 1], r[i + 2]));
    }
    return out;
  }

  async clearFaults() {
    await this.request(0x14, [0xff, 0x00]);
  }

  async keepAlive() {
    /* le maintien est fait par le processus de la ligne K */
  }

  async end() {
    try {
      await this.send(0x82, []);
    } catch {
      /* fin de communication sans réponse */
    }
  }
}

/** Réveille un calculateur et ouvre le bon dialogue. */
export async function openSession(k: KLine, addr: number, opts: { fast?: boolean; onSlow?: () => void } = {}): Promise<{ session: Session; wake: Wake }> {
  const wake = await k.wakeup(addr);
  let s: Session;
  if (wake.version >= 2000) s = await new KWP2000(k, addr).start();
  else {
    const kw = new KW1281(k, addr);
    kw.fast = opts.fast !== false;
    kw.onSlow = opts.onSlow ?? null;
    s = await kw.start();
  }
  await k.begin(wake.version >= 2000 ? "kwp" : "kw1281", addr);
  return { session: s, wake };
}
