// Surveillance : Nova compare les mesures à des seuils et prévient (écran Alerte + voix).
// Une alerte doit durer un peu avant de se déclencher, et ne revient pas tant qu'elle n'est
// pas retombée. « Compris » la met en sourdine jusqu'à ce qu'elle disparaisse.
import type { SignalStore } from "./signals.js";
import type { CarFiles } from "./config.js";

export type Level = "Critique" | "Attention" | "Info";
export type Kind = "temp" | "oil" | "service" | "battery" | "knock" | "fuel" | "boost" | "lean" | "dtc";

export interface Alert {
  id: string;
  kind: Kind;
  level: Level;
  system: string;
  title: string;
  value: string;
  limit: string;
  signal: string; // mesure tracée dans la petite courbe
  lim: number;
  min: number;
  max: number;
  sparkLbl: string;
  say: string;
  second: { label: string; action: string };
  at: number;
  acked: boolean;
}

interface Rule {
  id: string;
  holdMs: number;
  check: () => Omit<Alert, "id" | "at" | "acked"> | null;
}

const f0 = (x: number) => Math.round(x).toString();
const f1 = (x: number) => x.toFixed(1).replace(".", ",");

export class AlertManager {
  active = new Map<string, Alert>();
  private since = new Map<string, number>();
  private clearedAt = new Map<string, number>();
  private rules: Rule[];
  dtcs: { code: string; text: string }[] = [];
  private serviceShown = false;

  constructor(
    private store: SignalStore,
    private files: CarFiles,
    private onRaise: (a: Alert) => void,
    private onClear: (id: string) => void,
  ) {
    const c = () => this.files.config;
    const g = (k: string) => this.store.get(k);
    const running = () => this.store.engineRunning;
    this.rules = [
      {
        id: "eau-critique",
        holdMs: 3000,
        check: () => {
          const w = g("water");
          if (w === undefined || w < c().waterCrit) return null;
          return {
            kind: "temp", level: "Critique", system: "Refroidissement", title: "Surchauffe moteur", value: `${f0(w)} °C`, limit: `limite ${c().waterCrit} °C`,
            signal: "water", lim: c().waterCrit, min: 70, max: 120, sparkLbl: "Température d’eau · 3 dernières minutes",
            say: "Ton moteur chauffe. Lève le pied, mets le chauffage à fond et arrête-toi dès que tu peux en sécurité. Ne repars pas avant que la température soit redescendue.",
            second: { label: "Garage proche", action: "ask:Mon moteur surchauffe. Trouve-moi un garage ouvert le plus proche possible et donne-moi l'adresse." },
          };
        },
      },
      {
        id: "eau-chaude",
        holdMs: 8000,
        check: () => {
          const w = g("water");
          if (w === undefined || w < c().waterWarn || w >= c().waterCrit) return null;
          return {
            kind: "temp", level: "Attention", system: "Refroidissement", title: "Moteur très chaud", value: `${f0(w)} °C`, limit: `normal ≈ 90 °C`,
            signal: "water", lim: c().waterWarn, min: 70, max: 120, sparkLbl: "Température d’eau · 3 dernières minutes",
            say: "L'eau dépasse cent degrés. Roule tranquille et surveille : si ça continue de monter, il faudra t'arrêter.",
            second: { label: "Mode Normal", action: "mode:0" },
          };
        },
      },
      {
        id: "huile",
        holdMs: 5000,
        check: () => {
          const o = g("oil");
          if (o === undefined || o < c().oilWarn) return null;
          const crit = o >= c().oilCrit;
          return {
            kind: "oil", level: crit ? "Critique" : "Attention", system: "Lubrification", title: "Huile trop chaude", value: `${f0(o)} °C`, limit: `conseillé < ${c().oilWarn} °C`,
            signal: "oil", lim: c().oilWarn, min: 80, max: 145, sparkLbl: "Température d’huile · 3 dernières minutes",
            say: crit
              ? "L'huile est beaucoup trop chaude. Lève le pied tout de suite et roule au ralenti jusqu'à ce qu'elle redescende."
              : "L’huile monte vite. Roule tranquille quelques minutes, sous 4 000 tr/min, le temps qu’elle refroidisse.",
            second: { label: "Mode Normal", action: "mode:0" },
          };
        },
      },
      {
        id: "batterie",
        holdMs: 15000,
        check: () => {
          const v = g("volt");
          if (v === undefined || !running()) return null;
          if (v >= c().voltLow + 0.8 && v <= 15.2) return null;
          const high = v > 15.2;
          return {
            kind: "battery", level: "Attention", system: "Charge", title: high ? "Surtension de charge" : "Batterie ne charge pas", value: `${f1(v)} V`, limit: high ? "maxi 15,0 V" : "normal 13,8 à 14,6 V",
            signal: "volt", lim: high ? 15.2 : c().voltLow + 0.8, min: 11, max: 16, sparkLbl: "Tension de bord · 3 dernières minutes",
            say: high
              ? "La tension de charge est trop haute. Le régulateur de l'alternateur est peut-être en cause, fais-le vérifier."
              : "La batterie ne se recharge pas correctement moteur tournant. Vérifie la courroie et l'alternateur rapidement.",
            second: { label: "Voir le diagnostic", action: "screen:diagnostic" },
          };
        },
      },
      {
        id: "cliquetis",
        holdMs: 400,
        check: () => {
          const k = g("knock");
          if (k === undefined || k < 3) return null;
          return {
            kind: "knock", level: "Attention", system: "Allumage", title: "Cliquetis détecté", value: `${f1(k)}°`, limit: "recul d'allumage",
            signal: "knock", lim: 3, min: 0, max: 10, sparkLbl: "Recul d’allumage maxi · 3 dernières minutes",
            say: `Le calculateur recule l'allumage de ${f1(k)} degrés. Lève un peu le pied. Si ça revient souvent, vérifie la teneur en éthanol du dernier plein.`,
            second: { label: "Mode Normal", action: "mode:0" },
          };
        },
      },
      {
        id: "pauvre",
        holdMs: 600,
        check: () => {
          const l = g("lambda");
          const b = g("boost");
          if (l === undefined || b === undefined || b < 0.5 || l < 0.95) return null;
          return {
            kind: "lean", level: "Critique", system: "Injection", title: "Mélange pauvre en charge", value: `λ ${l.toFixed(2).replace(".", ",")}`, limit: "attendu ≈ 0,80",
            signal: "lambda", lim: 0.95, min: 0.7, max: 1.1, sparkLbl: "Richesse · 3 dernières minutes",
            say: "Lève le pied tout de suite : le moteur tourne pauvre en pleine charge. Avec l'E85, ça vient souvent de la pompe ou des injecteurs à leur limite.",
            second: { label: "Voir le diagnostic", action: "screen:diagnostic" },
          };
        },
      },
      {
        id: "suralim",
        holdMs: 1000,
        check: () => {
          const b = g("boost");
          if (b === undefined || b < c().boostMax) return null;
          return {
            kind: "boost", level: "Attention", system: "Turbo", title: "Suralimentation trop haute", value: `+${f1(b)} bar`, limit: `maxi +${f1(c().boostMax)} bar`,
            signal: "boost", lim: c().boostMax, min: -0.8, max: 1.6, sparkLbl: "Pression turbo · 3 dernières minutes",
            say: "Le turbo souffle plus que prévu. Vérifie l'électrovanne N75 et la wastegate avant de tirer à nouveau.",
            second: { label: "Mode Normal", action: "mode:0" },
          };
        },
      },
      {
        id: "carburant",
        holdMs: 20000,
        check: () => {
          const fl = g("fuel");
          if (fl === undefined || fl > c().fuelLowL) return null;
          const avg = this.store.avgL100 || 13;
          return {
            kind: "fuel", level: "Info", system: "Carburant", title: "Réserve", value: `${f1(fl)} L`, limit: `≈ ${f0((fl / avg) * 100)} km`,
            signal: "fuel", lim: c().fuelLowL, min: 0, max: Math.max(20, c().fuelLowL * 3), sparkLbl: "Carburant · 3 dernières minutes",
            say: `Il te reste environ ${f0(fl)} litres, de quoi faire ${f0((fl / avg) * 100)} kilomètres. Pense au plein d'E85.`,
            second: { label: "Station E85", action: "ask:Trouve la station qui vend de l'E85 la plus proche et dis-moi son prix." },
          };
        },
      },
      {
        id: "vidange",
        holdMs: 0,
        check: () => {
          if (!c().lastServiceKm) return null;
          if (this.serviceShown && !this.active.has("vidange")) return null; // une fois par démarrage
          const left = c().lastServiceKm + c().serviceIntervalKm - this.store.odometer;
          if (left > 1000) return null;
          return {
            kind: "service", level: "Info", system: "Entretien", title: left > 0 ? "Vidange bientôt" : "Vidange dépassée", value: `${f0(Math.abs(left))} km`, limit: left > 0 ? "avant la prochaine vidange" : "de retard",
            signal: "", lim: 0, min: 0, max: 1, sparkLbl: "",
            say: left > 0 ? `La vidange arrive dans environ ${f0(left)} kilomètres. Tu veux que je te le rappelle ce week-end ?` : `La vidange est dépassée de ${f0(-left)} kilomètres. Il faut la faire rapidement.`,
            second: { label: "Me le rappeler", action: "ask:Rappelle-moi de faire la vidange de la TT ce week-end. Mémorise-le." },
          };
        },
      },
      {
        id: "defaut",
        holdMs: 0,
        check: () => {
          if (!this.dtcs.length) return null;
          const first = this.dtcs[0];
          return {
            kind: "dtc", level: "Attention", system: "Calculateur moteur", title: this.dtcs.length > 1 ? `${this.dtcs.length} codes défaut` : "Code défaut moteur", value: first.code, limit: first.text,
            signal: "", lim: 0, min: 0, max: 1, sparkLbl: "",
            say: `Le calculateur a enregistré ${this.dtcs.length > 1 ? this.dtcs.length + " codes défaut" : "un code défaut"} : ${first.code}, ${first.text}.`,
            second: { label: "Voir le diagnostic", action: "screen:diagnostic" },
          };
        },
      },
    ];
    setInterval(() => this.evaluate(), 200);
  }

  private evaluate() {
    const now = Date.now();
    for (const r of this.rules) {
      const a = r.check();
      const cur = this.active.get(r.id);
      if (a) {
        if (cur) {
          // valeur mise à jour en direct (et niveau qui peut s'aggraver)
          const worse = cur.level !== a.level && a.level === "Critique";
          Object.assign(cur, a);
          if (worse) {
            cur.acked = false;
            this.onRaise(cur);
          }
          continue;
        }
        if (!this.since.has(r.id)) this.since.set(r.id, now);
        if (now - this.since.get(r.id)! < r.holdMs) continue;
        if (now - (this.clearedAt.get(r.id) ?? 0) < 60000) continue; // ne revient pas en boucle
        const alert: Alert = { ...a, id: r.id, at: now, acked: false };
        this.active.set(r.id, alert);
        if (r.id === "vidange") this.serviceShown = true;
        this.onRaise(alert);
      } else {
        this.since.delete(r.id);
        if (cur) {
          this.active.delete(r.id);
          this.clearedAt.set(r.id, now);
          this.onClear(r.id);
        }
      }
    }
  }

  ack(id: string) {
    const a = this.active.get(id);
    if (a) a.acked = true;
    if (id === "vidange" || id === "defaut") {
      this.active.delete(id);
      if (id === "defaut") this.dtcs = [];
      this.onClear(id);
    }
  }

  /** Alertes non acquittées, la plus grave d'abord. */
  pending(): Alert[] {
    const rank: Record<Level, number> = { Critique: 0, Attention: 1, Info: 2 };
    return [...this.active.values()].filter((a) => !a.acked).sort((a, b) => rank[a.level] - rank[b.level] || a.at - b.at);
  }

  all(): Alert[] {
    return [...this.active.values()];
  }

  /** Une alerte de Nova elle-même (outil show_alert). */
  custom(a: Partial<Alert> & { title: string; say: string; level: Level }) {
    const id = "nova-" + Date.now();
    const alert: Alert = {
      id, kind: a.kind ?? "service", level: a.level, system: a.system ?? "Nova", title: a.title, value: a.value ?? "", limit: a.limit ?? "",
      signal: a.signal ?? "", lim: a.lim ?? 0, min: a.min ?? 0, max: a.max ?? 1, sparkLbl: a.sparkLbl ?? "", say: a.say,
      second: a.second ?? { label: "Plus tard", action: "none" }, at: Date.now(), acked: false,
    };
    this.active.set(id, alert);
    this.onRaise(alert);
    // une alerte personnalisée se retire d'elle-même quand elle est acquittée
    return alert;
  }

  ackCustom(id: string) {
    if (id.startsWith("nova-")) {
      this.active.delete(id);
      this.onClear(id);
    }
  }
}
