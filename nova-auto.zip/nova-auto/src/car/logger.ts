// Enregistrement des logs : un fichier CSV par session (séparateur « ; », virgule décimale,
// s'ouvre directement dans Excel ou LibreOffice). Plus l'analyse d'un log pour Nova.
import { createWriteStream, promises as fs, type WriteStream } from "node:fs";
import path from "node:path";
import { SIGNALS, type SignalStore } from "./signals.js";

export interface LogInfo {
  on: boolean;
  file: string;
  rows: number;
  bytes: number;
  startedAt: number;
  reason: string;
}

export class CarLogger {
  private out: WriteStream | null = null;
  private timer: NodeJS.Timeout | null = null;
  info: LogInfo = { on: false, file: "", rows: 0, bytes: 0, startedAt: 0, reason: "" };
  private hz = 10;

  constructor(
    readonly dir: string,
    private store: SignalStore,
    private log: (t: string) => void,
  ) {}

  async start(reason: string, hz: number) {
    if (this.info.on) {
      if (hz !== this.hz) this.setRate(hz);
      return this.info.file;
    }
    await fs.mkdir(this.dir, { recursive: true });
    const d = new Date();
    const p2 = (n: number) => String(n).padStart(2, "0");
    const name = `log_${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}.csv`;
    const file = path.join(this.dir, name);
    this.out = createWriteStream(file, { encoding: "utf8" });
    const header = ["heure", "t_s", ...SIGNALS.map((s) => (s.unit ? `${s.key} (${s.unit})` : s.key))].join(";") + "\n";
    this.out.write(header);
    this.info = { on: true, file: name, rows: 0, bytes: header.length, startedAt: Date.now(), reason };
    this.setRate(hz);
    this.log(`Log démarré : ${name} (${reason}, ${hz} Hz)`);
    return name;
  }

  private setRate(hz: number) {
    this.hz = Math.max(1, Math.min(50, hz));
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.row(), 1000 / this.hz);
  }

  private row() {
    if (!this.out) return;
    const now = new Date();
    const t = ((Date.now() - this.info.startedAt) / 1000).toFixed(2).replace(".", ",");
    const cells = SIGNALS.map((s) => {
      const x = this.store.get(s.key);
      return x === undefined ? "" : x.toFixed(s.dec).replace(".", ",");
    });
    const line = [now.toTimeString().slice(0, 8) + "." + String(now.getMilliseconds()).padStart(3, "0"), t, ...cells].join(";") + "\n";
    this.out.write(line);
    this.info.rows++;
    this.info.bytes += line.length;
  }

  async stop() {
    if (!this.out) return null;
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    const out = this.out;
    this.out = null;
    await new Promise<void>((r) => out.end(() => r()));
    const name = this.info.file;
    this.log(`Log arrêté : ${name} (${this.info.rows} lignes, ${Math.round((Date.now() - this.info.startedAt) / 1000)} s)`);
    this.info = { ...this.info, on: false };
    return name;
  }

  async list() {
    try {
      const names = (await fs.readdir(this.dir)).filter((n) => n.endsWith(".csv")).sort().reverse();
      return Promise.all(
        names.slice(0, 50).map(async (n) => {
          const st = await fs.stat(path.join(this.dir, n));
          return { file: n, kb: Math.round(st.size / 1024), date: st.mtime.toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) + " (heure locale)" };
        }),
      );
    } catch {
      return [];
    }
  }

  /** Lit un log CSV : colonnes → valeurs. */
  async read(file: string) {
    const safe = path.basename(file);
    const text = await fs.readFile(path.join(this.dir, safe), "utf8");
    const lines = text.split(/\r?\n/).filter(Boolean);
    const head = lines[0].split(";").map((h) => h.replace(/\s*\(.*\)$/, ""));
    const cols: Record<string, number[]> = {};
    head.forEach((h) => (cols[h] = []));
    for (const l of lines.slice(1)) {
      const cells = l.split(";");
      head.forEach((h, i) => cols[h].push(i === 0 ? NaN : parseFloat((cells[i] ?? "").replace(",", "."))));
    }
    return { file: safe, rows: lines.length - 1, cols };
  }

  /** Résumé d'un log pour Nova : durée, maxi, moyennes, événements remarquables. */
  async analyze(file: string) {
    const { rows, cols } = await this.read(file);
    const fin = (k: string) => (cols[k] ?? []).filter((x) => Number.isFinite(x));
    const st = (k: string) => {
      const a = fin(k);
      if (!a.length) return null;
      return { min: Math.min(...a), max: Math.max(...a), avg: a.reduce((x, y) => x + y, 0) / a.length };
    };
    const t = fin("t_s");
    const out: Record<string, unknown> = { fichier: path.basename(file), lignes: rows, duree_s: t.length ? Math.round(t[t.length - 1]) : 0 };
    for (const s of SIGNALS) {
      const v = st(s.key);
      if (v) out[s.key] = { min: +v.min.toFixed(s.dec), max: +v.max.toFixed(s.dec), moy: +v.avg.toFixed(s.dec), unite: s.unit };
    }
    // cliquetis : nombre de moments avec plus de 2° de recul
    const knock = cols["knock"] ?? [];
    let knockEvents = 0;
    let inKnock = false;
    for (const k of knock) {
      if (k > 2 && !inKnock) knockEvents++;
      inKnock = k > 2;
    }
    out.evenements_cliquetis = knockEvents;
    // mélange pauvre en charge
    const lam = cols["lambda"] ?? [];
    const load = cols["load"] ?? [];
    out.pauvre_en_charge = lam.filter((l, i) => l > 0.92 && (load[i] ?? 0) > 120).length;
    // km parcourus
    const trip = fin("tripKm");
    if (trip.length) out.km = +(trip[trip.length - 1] - trip[0]).toFixed(2);
    return out;
  }
}
