// ELM327 Bluetooth : le lier à un port série /dev/rfcommN (rfcomm de BlueZ, par sudo sans mot de passe
// sous Nova OS). Le port s'ouvre ensuite comme un câble USB ; la connexion Bluetooth se fait à l'ouverture.
import { execFile } from "node:child_process";
import { existsSync } from "node:fs";
import { jlog } from "./journaux.js";

const run = (cmd: string, args: string[], timeout = 15000) =>
  new Promise<{ ok: boolean; out: string }>((res) => execFile(cmd, args, { timeout }, (e, o, er) => res({ ok: !e, out: String(o || "") + String(er || "") })));
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const RFCOMM = "/dev/rfcomm7";

/** Lie l'adresse Bluetooth à /dev/rfcomm7 ; renvoie le port, ou null si rfcomm n'est pas disponible. */
export async function bindRfcomm(mac: string): Promise<string | null> {
  if (process.platform !== "linux") return null;
  if (!/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/i.test(mac)) throw new Error("adresse Bluetooth invalide : " + mac);
  await run("rfkill", ["unblock", "bluetooth"]);
  await run("bluetoothctl", ["power", "on"]);
  // déjà lié à la bonne adresse : rien à faire
  const show = await run("rfcomm", ["show", "7"]);
  if (existsSync(RFCOMM) && show.out.toUpperCase().includes(mac.toUpperCase())) return RFCOMM;
  await run("sudo", ["-n", "rfcomm", "release", "7"]);
  const b = await run("sudo", ["-n", "rfcomm", "bind", "7", mac, "1"]);
  for (let i = 0; i < 10 && !existsSync(RFCOMM); i++) await sleep(100);
  if (!b.ok || !existsSync(RFCOMM)) {
    jlog("cables.log", `Bluetooth : rfcomm impossible pour ${mac} (${b.out.trim().slice(0, 160)})`);
    return null;
  }
  await run("sudo", ["-n", "chmod", "666", RFCOMM]);
  jlog("cables.log", `Bluetooth : ELM327 ${mac} lié à ${RFCOMM}`);
  return RFCOMM;
}
