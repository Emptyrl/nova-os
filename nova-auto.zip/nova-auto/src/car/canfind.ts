// Recherche d'une mesure sur le bus CAN en la comparant à la même mesure lue par la ligne K.
// Nova lit en continu un groupe de mesure (câble KKL) pendant que l'adaptateur CAN enregistre tout le bus.
// Ensuite, pour chaque identifiant et chaque façon de lire ses octets (1 octet, 2 octets dans les deux
// sens), elle cherche celle qui suit le mieux la valeur de référence (corrélation) et en déduit la
// formule : valeur = a × brut + b. La formule retenue est gardée dans can-decodeurs.json et sert ensuite
// en direct, comme les décodages connus.
import { promises as fs, readFileSync } from "node:fs";
import path from "node:path";

export type Kind = "u8" | "u16le" | "u16be";

export interface CustomDecoder {
  id: number;
  kind: Kind;
  at: number; // premier octet
  a: number;
  b: number;
  key: string; // mesure de Nova (oil, fuel…) ou « can_xxx »
  label: string;
  unit: string;
  r: number;
  savedAt: number;
}

export function rawOf(bytes: number[], kind: Kind, at: number): number | null {
  if (kind === "u8") return at < bytes.length ? bytes[at] : null;
  if (at + 1 >= bytes.length) return null;
  return kind === "u16le" ? bytes[at] | (bytes[at + 1] << 8) : (bytes[at] << 8) | bytes[at + 1];
}

/** Historique du bus : pour chaque identifiant, les trames des 90 dernières secondes (une toutes les 20 ms au plus). */
export class CanHistory {
  private h = new Map<number, { t: number; b: number[] }[]>();
  add(id: number, b: number[], t = Date.now()) {
    let a = this.h.get(id);
    if (!a) this.h.set(id, (a = []));
    if (a.length && t - a[a.length - 1].t < 20) {
      a[a.length - 1] = { t, b };
      return;
    }
    a.push({ t, b });
    while (a.length && t - a[0].t > 90000) a.shift();
  }
  ids() {
    return [...this.h.keys()];
  }
  /** Trame en vigueur à l'instant t (la dernière reçue avant, au plus 400 ms avant). */
  at(id: number, t: number): number[] | null {
    const a = this.h.get(id);
    if (!a || !a.length) return null;
    let lo = 0,
      hi = a.length - 1,
      best = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (a[mid].t <= t) {
        best = mid;
        lo = mid + 1;
      } else hi = mid - 1;
    }
    if (best < 0 || t - a[best].t > 400) return null;
    return a[best].b;
  }
}

// ---------------- décodages appris ----------------
let customs: CustomDecoder[] = [];
let file = "";

export function loadCustom(dataDir: string) {
  file = path.join(dataDir, "can-decodeurs.json");
  try {
    customs = JSON.parse(readFileSync(file, "utf8")).decoders || [];
  } catch {
    customs = [];
  }
}
export function listCustom() {
  return customs;
}
async function saveFile() {
  if (!file) return;
  await fs.writeFile(file, JSON.stringify({ note: "Décodages du bus CAN trouvés par Nova (comparaison avec la ligne K)", decoders: customs }, null, 2));
}
export async function addCustom(d: CustomDecoder) {
  customs = customs.filter((x) => x.key !== d.key);
  customs.push(d);
  await saveFile();
}
export async function removeCustom(key: string) {
  customs = customs.filter((x) => x.key !== key);
  await saveFile();
}
/** Valeurs apprises pour une trame. */
export function decodeCustom(id: number, bytes: number[]): Record<string, number> | null {
  let out: Record<string, number> | null = null;
  for (const c of customs) {
    if (c.id !== id) continue;
    const r = rawOf(bytes, c.kind, c.at);
    if (r === null) continue;
    (out ??= {})[c.key] = Math.round((c.a * r + c.b) * 1000) / 1000;
  }
  return out;
}

// ---------------- recherche ----------------
export interface FindResult {
  id: number;
  idHex: string;
  kind: Kind;
  at: number;
  a: number;
  b: number;
  r: number;
  rms: number;
  sample: number; // valeur calculée maintenant
}

export interface FindState {
  status: "idle" | "recording" | "done" | "error";
  addr: number;
  group: number;
  field: number;
  label: string;
  unit: string;
  samples: number;
  min: number | null;
  max: number | null;
  startedAt: number;
  seconds: number;
  text: string;
  results: FindResult[];
}

const pearson = (x: number[], y: number[]) => {
  const n = x.length;
  let sx = 0,
    sy = 0;
  for (let i = 0; i < n; i++) {
    sx += x[i];
    sy += y[i];
  }
  const mx = sx / n,
    my = sy / n;
  let cxy = 0,
    cxx = 0,
    cyy = 0;
  for (let i = 0; i < n; i++) {
    const dx = x[i] - mx,
      dy = y[i] - my;
    cxy += dx * dy;
    cxx += dx * dx;
    cyy += dy * dy;
  }
  if (cxx === 0 || cyy === 0) return null;
  const a = cxy / cxx;
  return { r: cxy / Math.sqrt(cxx * cyy), a, b: my - a * mx };
};

export class CanFinder {
  st: FindState = { status: "idle", addr: 0, group: 0, field: 0, label: "", unit: "", samples: 0, min: null, max: null, startedAt: 0, seconds: 40, text: "", results: [] };
  private ref: { t: number; v: number }[] = [];
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private history: () => CanHistory | null,
    private onChange: () => void,
  ) {}

  start(addr: number, group: number, field: number, label: string, unit: string, seconds = 40) {
    if (!this.history()) throw new Error("Pas d'adaptateur CAN actif : branche le CANable (ou l'ELM327 sur le CAN) d'abord.");
    this.stop(false);
    this.ref = [];
    this.st = { status: "recording", addr, group, field, label, unit, samples: 0, min: null, max: null, startedAt: Date.now(), seconds, text: `Enregistrement ${seconds} s : fais varier « ${label} » (accélère, laisse chauffer, roule…)`, results: [] };
    this.timer = setTimeout(() => this.finish(), seconds * 1000);
    this.onChange();
  }

  stop(notify = true) {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    if (this.st.status === "recording") {
      this.st.status = "idle";
      this.st.text = "Arrêté";
    }
    if (notify) this.onChange();
  }

  /** Chaque groupe lu par la ligne K passe par ici. */
  onGroup(addr: number, group: number, values: (number | null)[]) {
    if (this.st.status !== "recording" || addr !== this.st.addr || group !== this.st.group) return;
    const v = values[this.st.field];
    if (v === null || v === undefined || !Number.isFinite(v)) return;
    // la ligne K a mis ~100 ms à répondre : la valeur date d'un peu avant
    this.ref.push({ t: Date.now() - 100, v });
    this.st.samples = this.ref.length;
    this.st.min = this.st.min === null ? v : Math.min(this.st.min, v);
    this.st.max = this.st.max === null ? v : Math.max(this.st.max, v);
    if (this.ref.length % 5 === 0) this.onChange();
  }

  finish() {
    this.timer = null;
    if (this.st.status !== "recording") return;
    const h = this.history();
    const ref = this.ref;
    const fail = (text: string) => {
      this.st.status = "error";
      this.st.text = text;
      this.onChange();
    };
    if (!h) return fail("Plus d'adaptateur CAN actif.");
    if (ref.length < 15) return fail(`Seulement ${ref.length} lectures par la ligne K : laisse la lecture en continu tourner pendant l'enregistrement.`);
    const vs = ref.map((x) => x.v);
    const span = Math.max(...vs) - Math.min(...vs);
    if (span <= 0) return fail("La valeur n'a pas bougé pendant l'enregistrement : fais-la varier (régime, température…) et recommence.");
    const results: FindResult[] = [];
    for (const id of h.ids()) {
      const frames = ref.map((x) => h.at(id, x.t));
      const ok = frames.map((f, i) => (f ? i : -1)).filter((i) => i >= 0);
      if (ok.length < ref.length * 0.7) continue;
      const len = Math.max(...ok.map((i) => frames[i]!.length));
      for (const kind of ["u8", "u16le", "u16be"] as Kind[]) {
        for (let at = 0; at < len - (kind === "u8" ? 0 : 1); at++) {
          const x: number[] = [];
          const y: number[] = [];
          for (const i of ok) {
            const r = rawOf(frames[i]!, kind, at);
            if (r === null) continue;
            x.push(r);
            y.push(ref[i].v);
          }
          if (x.length < 15) continue;
          const p = pearson(x, y);
          if (!p || Math.abs(p.r) < 0.8) continue;
          let se = 0;
          for (let i = 0; i < x.length; i++) se += (p.a * x[i] + p.b - y[i]) ** 2;
          const last = h.at(id, Date.now());
          const now = last ? rawOf(last, kind, at) : null;
          results.push({ id, idHex: id.toString(16).toUpperCase().padStart(3, "0"), kind, at, a: p.a, b: p.b, r: p.r, rms: Math.sqrt(se / x.length), sample: now === null ? NaN : p.a * now + p.b });
        }
      }
    }
    // meilleure corrélation d'abord ; à égalité, la lecture la plus simple (1 octet)
    results.sort((m, n) => Math.abs(n.r) - Math.abs(m.r) || Number(m.kind !== "u8") - Number(n.kind !== "u8"));
    // une paire d'octets dont l'octet de poids fort suit déjà seul aussi bien : c'est cet octet seul
    // une paire d'octets n'apporte rien si l'un de ses octets seul fait aussi bien (écart à peine plus grand) :
    // on garde alors l'octet seul, plus simple
    const u8 = new Map(results.filter((x) => x.kind === "u8").map((x) => [x.id + ":" + x.at, x.rms]));
    const kept = results.filter((x) => {
      if (x.kind === "u8") return true;
      const e8 = Math.min(u8.get(x.id + ":" + x.at) ?? Infinity, u8.get(x.id + ":" + (x.at + 1)) ?? Infinity);
      return !(e8 <= x.rms * 1.15);
    });
    this.st.results = kept.slice(0, 8);
    this.st.status = "done";
    this.st.text = kept.length
      ? `${ref.length} lectures (${this.st.min} → ${this.st.max} ${this.st.unit}) : ${kept.length} candidat${kept.length > 1 ? "s" : ""}. Le premier est le plus probable.`
      : `${ref.length} lectures (${this.st.min} → ${this.st.max} ${this.st.unit}) : rien sur le CAN ne suit cette valeur. Elle n'y passe sans doute pas (valeur interne au calculateur).`;
    this.onChange();
  }
}
