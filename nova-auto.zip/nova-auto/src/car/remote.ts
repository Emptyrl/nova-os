// Démarrage à distance, version simple voulue par Joan :
// Nova met le contact, vérifie sur le CAN que le moteur est arrêté et que les 4 roues sont immobiles,
// lance le démarreur jusqu'à ce que le régime dépasse le seuil (3 s maxi, 2 essais),
// et coupe tout immédiatement si une roue bouge. Le moteur se recoupe tout seul au bout de N minutes.
import type { Hardware } from "./hardware.js";
import type { SignalStore } from "./signals.js";
import type { CarFiles } from "./config.js";

export type RemoteState = "idle" | "checking" | "ignition" | "cranking" | "running" | "failed" | "stopped";

export interface RemoteStatus {
  state: RemoteState;
  message: string;
  try: number;
  stopAt: number; // heure de coupure automatique
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export class RemoteStart {
  st: RemoteStatus = { state: "idle", message: "", try: 0, stopAt: 0 };
  private abort = false;
  private watch: NodeJS.Timeout | null = null;
  private autoStop: NodeJS.Timeout | null = null;

  constructor(
    private hw: Hardware,
    private store: SignalStore,
    private files: CarFiles,
    private canReady: () => boolean,
    private log: (t: string) => void,
    private onChange: () => void,
  ) {}

  private set(state: RemoteState, message: string) {
    this.st = { ...this.st, state, message };
    this.log("Démarrage à distance : " + message);
    this.onChange();
  }

  private wheels(): number[] | null {
    const k = ["wfl", "wfr", "wrl", "wrr"];
    if (!k.every((x) => this.store.fresh(x, 1000))) return null;
    return k.map((x) => this.store.v[x]);
  }

  private wheelsMoving() {
    const w = this.wheels();
    return w === null ? false : w.some((x) => x > 0.5);
  }

  async start(): Promise<string> {
    if (["checking", "ignition", "cranking"].includes(this.st.state)) return "Démarrage déjà en cours.";
    if (this.st.state === "running" && this.store.engineRunning) return "Le moteur tourne déjà.";
    const c = this.files.config;
    this.abort = false;
    this.st.try = 0;
    this.set("checking", "vérifications");

    if (this.hw.mode !== "pi") {
      this.set("failed", "refusé : pas de carte NovaHAT sur cet appareil (les relais sont sur la carte)");
      return this.st.message;
    }
    if (c.remoteRequireCan && !this.canReady()) {
      this.set("failed", "refusé : Nova n'est pas connectée au CAN (vitesses de roue indisponibles)");
      return this.st.message;
    }
    // contact mis : le CAN se réveille
    this.hw.setOutput("ignition", true);
    this.set("ignition", "contact mis, réveil du CAN");
    const t0 = Date.now();
    while (Date.now() - t0 < 3000 && !this.abort) {
      await sleep(100);
      if (this.store.engineRunning) {
        this.set("running", "le moteur tournait déjà");
        this.armAutoStop();
        return this.st.message;
      }
    }
    if (this.abort) return this.st.message;
    if (c.remoteRequireCan && (!this.store.fresh("rpm", 1000) || this.wheels() === null)) {
      this.hw.setOutput("ignition", false);
      this.set("failed", "refusé : pas de régime ni de vitesse de roue reçus sur le CAN");
      return this.st.message;
    }
    if (this.wheelsMoving()) {
      this.hw.setOutput("ignition", false);
      this.set("failed", "refusé : une roue bouge");
      return this.st.message;
    }

    // surveillance des roues pendant tout le démarrage
    this.watch = setInterval(() => {
      if (this.wheelsMoving()) {
        this.hw.setOutput("starter", false);
        this.hw.setOutput("ignition", false);
        this.abort = true;
        this.set("failed", "ARRÊT : une roue a bougé, tout est coupé");
      }
    }, 50);

    for (let i = 1; i <= c.remoteTries && !this.abort; i++) {
      this.st.try = i;
      this.set("cranking", `démarreur, essai ${i}/${c.remoteTries}`);
      this.hw.setOutput("starter", true);
      const tc = Date.now();
      let started = false;
      while (Date.now() - tc < c.remoteCrankMs && !this.abort) {
        await sleep(20);
        if ((this.store.get("rpm") ?? 0) > c.remoteStartRpm) {
          started = true;
          break;
        }
      }
      this.hw.setOutput("starter", false);
      if (this.abort) break;
      if (started) {
        this.stopWatch();
        this.set("running", `moteur démarré (${Math.round(this.store.get("rpm") ?? 0)} tr/min), coupure automatique dans ${c.remoteRunMinutes} min`);
        this.armAutoStop();
        return this.st.message;
      }
      if (i < c.remoteTries) await sleep(8000); // laisse reposer le démarreur
    }
    this.stopWatch();
    if (!this.abort) {
      this.hw.setOutput("ignition", false);
      this.set("failed", "le moteur n'a pas démarré, contact coupé");
    }
    return this.st.message;
  }

  private armAutoStop() {
    const min = this.files.config.remoteRunMinutes;
    this.st.stopAt = Date.now() + min * 60000;
    if (this.autoStop) clearTimeout(this.autoStop);
    this.autoStop = setTimeout(() => this.stop("coupure automatique au bout de " + min + " min"), min * 60000);
    this.onChange();
  }

  private stopWatch() {
    if (this.watch) clearInterval(this.watch);
    this.watch = null;
  }

  /** Coupe le moteur démarré à distance. Si quelqu'un a mis la clé, le contact reste par la clé. */
  stop(reason = "arrêt demandé") {
    this.abort = true;
    this.stopWatch();
    if (this.autoStop) clearTimeout(this.autoStop);
    this.autoStop = null;
    this.hw.setOutput("starter", false);
    this.hw.setOutput("ignition", false);
    this.st.stopAt = 0;
    this.set("stopped", reason);
    return reason;
  }

  /** Quelqu'un roule avec la voiture démarrée à distance : Nova lui laisse la main. */
  handOver() {
    if (this.autoStop) clearTimeout(this.autoStop);
    this.autoStop = null;
    this.st.stopAt = 0;
  }
}
