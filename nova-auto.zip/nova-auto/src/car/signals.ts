// Store central des mesures de la voiture : chaque source y écrit, tout le reste y lit
// (écrans, logs, alertes, analyses, Nova). Calcule aussi ce qu'aucun capteur ne donne :
// rapport engagé, consommation (E85), accélération, trajet, carburant restant.
import type { CarFiles } from "./config.js";

export interface SignalDef {
  key: string;
  label: string;
  unit: string;
  dec: number;
}

/** Ordre des colonnes des logs CSV. */
export const SIGNALS: SignalDef[] = [
  { key: "rpm", label: "Régime", unit: "tr/min", dec: 0 },
  { key: "speed", label: "Vitesse", unit: "km/h", dec: 1 },
  { key: "gear", label: "Rapport", unit: "", dec: 0 },
  { key: "throttle", label: "Papillon", unit: "%", dec: 1 },
  { key: "pedal", label: "Pédale", unit: "%", dec: 1 },
  { key: "load", label: "Charge", unit: "%", dec: 1 },
  { key: "maf", label: "Débit d'air", unit: "g/s", dec: 2 },
  { key: "iat", label: "Air admission", unit: "°C", dec: 0 },
  { key: "water", label: "Eau", unit: "°C", dec: 0 },
  { key: "oil", label: "Huile", unit: "°C", dec: 0 },
  { key: "boost", label: "Turbo réel", unit: "bar", dec: 2 },
  { key: "boostReq", label: "Turbo demandé", unit: "bar", dec: 2 },
  { key: "timing", label: "Avance", unit: "°", dec: 1 },
  { key: "knock", label: "Recul allumage max", unit: "°", dec: 1 },
  { key: "knock1", label: "Recul cyl. 1", unit: "°", dec: 1 },
  { key: "knock2", label: "Recul cyl. 2", unit: "°", dec: 1 },
  { key: "knock3", label: "Recul cyl. 3", unit: "°", dec: 1 },
  { key: "knock4", label: "Recul cyl. 4", unit: "°", dec: 1 },
  { key: "lambda", label: "Richesse λ", unit: "", dec: 3 },
  { key: "stft", label: "Correction courte", unit: "%", dec: 1 },
  { key: "ltft", label: "Correction longue", unit: "%", dec: 1 },
  { key: "volt", label: "Batterie", unit: "V", dec: 2 },
  { key: "ext", label: "Extérieur", unit: "°C", dec: 0 },
  { key: "fuelRate", label: "Conso instantanée", unit: "L/h", dec: 2 },
  { key: "l100", label: "Conso", unit: "L/100", dec: 1 },
  { key: "fuel", label: "Carburant", unit: "L", dec: 1 },
  { key: "glong", label: "Accél. longitudinale", unit: "g", dec: 2 },
  { key: "glat", label: "Accél. latérale", unit: "g", dec: 2 },
  { key: "haldex", label: "Couple arrière (estimé)", unit: "%", dec: 0 },
  { key: "wfl", label: "Roue AVG", unit: "km/h", dec: 1 },
  { key: "wfr", label: "Roue AVD", unit: "km/h", dec: 1 },
  { key: "wrl", label: "Roue ARG", unit: "km/h", dec: 1 },
  { key: "wrr", label: "Roue ARD", unit: "km/h", dec: 1 },
  { key: "tripKm", label: "Trajet", unit: "km", dec: 2 },
];

export type Values = Record<string, number>;

const HISTORY_SEC = 300; // 5 minutes gardées en mémoire
const HISTORY_HZ = 5;

export class SignalStore {
  v: Values = {};
  stamp: Record<string, number> = {}; // dernière mise à jour de chaque mesure
  private hist = new Map<string, Float32Array>();
  private histIdx = 0;
  private histCount = 0;
  private lastSpeed = 0;
  private lastSpeedT = 0;
  private lastTick = Date.now();
  private glongF = 0;
  private gearVotes: number[] = [];
  /** Moyenne de consommation du trajet. */
  avgL100 = 0;
  mode: 0 | 1 | 2 = 0;

  constructor(private files: CarFiles) {
    for (const s of SIGNALS) this.hist.set(s.key, new Float32Array(HISTORY_SEC * HISTORY_HZ).fill(NaN));
    setInterval(() => this.sample(), 1000 / HISTORY_HZ);
  }

  /** Une source écrit des mesures. */
  set(values: Values) {
    const now = Date.now();
    for (const [k, x] of Object.entries(values)) {
      if (!Number.isFinite(x)) continue;
      this.v[k] = x;
      this.stamp[k] = now;
    }
    if ("speed" in values) this.onSpeed(now);
  }

  /** La mesure est-elle fraîche (lue il y a moins de maxAge ms) ? */
  fresh(key: string, maxAge = 3000): boolean {
    return this.stamp[key] !== undefined && Date.now() - this.stamp[key] < maxAge;
  }

  get(key: string): number | undefined {
    return this.fresh(key, 10000) ? this.v[key] : undefined;
  }

  get engineRunning() {
    return (this.get("rpm") ?? 0) > 400;
  }

  get moving() {
    return (this.get("speed") ?? 0) > 2;
  }

  private onSpeed(now: number) {
    const sp = this.v.speed;
    if (this.lastSpeedT) {
      const dt = (now - this.lastSpeedT) / 1000;
      if (dt > 0.02 && dt < 2) {
        const a = (sp - this.lastSpeed) / 3.6 / dt / 9.81;
        this.glongF += (Math.max(-1.3, Math.min(1.3, a)) - this.glongF) * 0.35;
        if (!this.fresh("glongSensor", 1000)) this.v.glong = this.glongF;
        this.stamp.glong = now;
      }
    }
    this.lastSpeed = sp;
    this.lastSpeedT = now;
  }

  /** Calculs dérivés, appelés à 10 Hz par le serveur. */
  derive() {
    const now = Date.now();
    const dt = Math.min(1, (now - this.lastTick) / 1000);
    this.lastTick = now;
    const c = this.files.config;
    const L = this.files.learned;
    const rpm = this.get("rpm") ?? 0;
    const speed = this.get("speed") ?? 0;

    // rapport engagé : vitesse / régime comparé aux rapports connus
    let gear = 0;
    if (rpm > 600 && speed > 4) {
      const k = speed / (rpm / 1000);
      const ratios = this.files.ratios();
      let best = 0, err = 1;
      ratios.forEach((r, i) => {
        const e = Math.abs(k - r) / r;
        if (e < err) {
          err = e;
          best = i + 1;
        }
      });
      if (err < 0.12) gear = best;
    }
    this.gearVotes.push(gear);
    if (this.gearVotes.length > 4) this.gearVotes.shift();
    const stable = this.gearVotes.every((g) => g === gear);
    if (stable || !this.v.gear) this.set({ gear });

    // consommation à partir du débit d'air : carburant = air / (AFR × λ)
    const maf = this.get("maf");
    if (maf !== undefined && rpm > 300) {
      const lambda = this.get("lambda") ?? 1;
      const gps = maf / (c.afr * Math.max(0.7, Math.min(1.3, lambda)));
      const lph = (gps * 3600) / (c.fuelDensity * 1000);
      const l100 = speed > 3 ? Math.min(99, (lph / speed) * 100) : 0;
      this.set({ fuelRate: lph, l100 });
      const used = (lph / 3600) * dt;
      L.fuelL = Math.max(0, L.fuelL - used);
      L.tripFuelL += used;
    } else if (rpm <= 300) this.set({ fuelRate: 0, l100: 0 });

    const km = (speed / 3600) * dt;
    L.tripKm += km;
    L.totalKm += km;
    L.consoKm += km;
    this.avgL100 = L.tripKm > 0.5 ? (L.tripFuelL / L.tripKm) * 100 : 0;
    if (!this.fresh("fuelSensor", 5000)) this.set({ fuel: L.fuelL });
    this.set({ tripKm: L.tripKm });
    if (km > 0 || rpm > 0) this.files.saveLearnedSoon();

    // répartition avant/arrière : le Haldex n'envoie rien sur la prise OBD, estimation
    // à partir de la charge et du rapport (affichée comme estimée)
    const thr = this.get("pedal") ?? this.get("throttle") ?? 0;
    const want = thr > 50 ? (MODES_HAL[this.mode] * 100 * (gear > 0 && gear <= 2 ? 1 : 0.6)) : 4;
    this.set({ haldex: (this.v.haldex ?? 4) + (want - (this.v.haldex ?? 4)) * 0.2 });
  }

  get odometer() {
    return this.files.config.odometerKm + this.files.learned.totalKm;
  }

  resetTrip() {
    const L = this.files.learned;
    L.tripKm = 0;
    L.tripFuelL = 0;
    this.files.saveLearnedSoon();
  }

  private sample() {
    const i = this.histIdx;
    for (const s of SIGNALS) {
      const x = this.get(s.key);
      this.hist.get(s.key)![i] = x === undefined ? NaN : x;
    }
    this.histIdx = (i + 1) % (HISTORY_SEC * HISTORY_HZ);
    this.histCount = Math.min(this.histCount + 1, HISTORY_SEC * HISTORY_HZ);
  }

  /** Historique d'une mesure sur les dernières secondes (du plus ancien au plus récent). */
  history(key: string, seconds = 180): number[] {
    const buf = this.hist.get(key);
    if (!buf) return [];
    const n = Math.min(this.histCount, seconds * HISTORY_HZ);
    const out: number[] = [];
    const size = HISTORY_SEC * HISTORY_HZ;
    for (let k = n; k > 0; k--) out.push(buf[(this.histIdx - k + size) % size]);
    return out;
  }

  stats(key: string, seconds = 300) {
    const h = this.history(key, seconds).filter((x) => Number.isFinite(x));
    if (!h.length) return null;
    const sum = h.reduce((a, b) => a + b, 0);
    return { min: Math.min(...h), max: Math.max(...h), avg: sum / h.length, last: h[h.length - 1], n: h.length };
  }
}

const MODES_HAL = [0.35, 0.6, 0.9];
