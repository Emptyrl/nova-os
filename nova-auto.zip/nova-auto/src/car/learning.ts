// Apprentissage : Nova mesure ta voiture en roulant.
// 1. Rapports de boîte : vitesse / régime en conduite stabilisée, pour chaque rapport.
// 2. Courbe du moteur : tirages pied au plancher en 3e ; le couple est déduit de l'accélération
//    (masse, aéro, roulement, rendement de transmission).
// 3. Consommation : litres par tranche de régime et rapport, en croisière, sur 300 km.
import { interp, REF_RATIOS, REF_TORQUE, type CarFiles } from "./config.js";
import type { SignalStore } from "./signals.js";
import { shiftTable } from "./shift.js";

const ETA = 0.85; // rendement de la transmission quattro
const INERTIA = 1.08; // masses en rotation (3e)
const RHO = 1.2;
const CRR = 0.012;

/** Accélération du régime (tr/min par seconde) pour un couple moteur donné. */
export function rpmRate(torqueNm: number, rpm: number, kmhPer1000: number, massKg: number, cdA: number) {
  const v = (rpm * kmhPer1000) / 1000 / 3.6;
  const w = (rpm * 2 * Math.PI) / 60;
  const fWheel = v > 0.5 ? (torqueNm * w * ETA) / v : 0;
  const fRes = 0.5 * RHO * cdA * v * v + CRR * massKg * 9.81;
  const a = (fWheel - fRes) / (massKg * INERTIA);
  return ((a * 3.6) / kmhPer1000) * 1000;
}

/** Couple moteur déduit de l'accélération du régime. */
function torqueFrom(rpm: number, rpmDot: number, k: number, m: number, cdA: number) {
  const v = (rpm * k) / 1000 / 3.6;
  const a = ((rpmDot * k) / 1000) / 3.6;
  const f = m * INERTIA * a + 0.5 * RHO * cdA * v * v + CRR * m * 9.81;
  const w = (rpm * 2 * Math.PI) / 60;
  return (f * v) / w / ETA;
}

export interface LearnState {
  gears: { n: number; k: number | null; progress: number }[];
  gearsDone: number;
  pulls: number;
  pullActive: boolean;
  pullProgress: number;
  dots: [number, number, number][]; // régime, couple, n° de tirage
  fit: [number, number][];
  learnedTorque: boolean;
  consoKm: number;
  phase: "gears" | "wait" | "pull" | "between" | "done";
  say: string;
}

export class Learning {
  private gearSamples: number[][] = [[], [], [], [], [], []];
  private pull: { t: number; rpm: number }[] | null = null;
  private pullBins: Map<number, number[]> = new Map();
  dots: [number, number, number][] = [];
  private lastPullEnd = 0;
  sessionPulls = 0;

  constructor(
    private store: SignalStore,
    private files: CarFiles,
    private log: (t: string) => void,
    private onLearned: (what: string) => void,
  ) {
    setInterval(() => this.tick(), 50);
  }

  reset() {
    const L = this.files.learned;
    L.ratios = [null, null, null, null, null, null];
    L.torque = null;
    L.pulls = 0;
    L.consoKm = 0;
    L.consoBins = {};
    this.gearSamples = [[], [], [], [], [], []];
    this.pullBins.clear();
    this.dots = [];
    this.sessionPulls = 0;
    void this.files.saveLearned();
  }

  private tick() {
    const g = (k: string) => this.store.get(k);
    const rpm = g("rpm") ?? 0;
    const speed = g("speed") ?? 0;
    const thr = g("pedal") ?? g("throttle") ?? (g("load") !== undefined ? Math.min(100, g("load")!) : 0);
    const glong = g("glong") ?? 0;
    const L = this.files.learned;

    // 1. rapports
    if (rpm > 1200 && speed > 15 && Math.abs(glong) < 0.15 && thr > 3) {
      const k = speed / (rpm / 1000);
      let best = -1, err = 1;
      REF_RATIOS.forEach((r, i) => {
        const e = Math.abs(k - r) / r;
        if (e < err) {
          err = e;
          best = i;
        }
      });
      if (best >= 0 && err < 0.12 && L.ratios[best] === null) {
        const s = this.gearSamples[best];
        s.push(k);
        if (s.length > 400) s.shift();
        if (s.length >= 60) {
          const sorted = [...s].sort((a, b) => a - b);
          const med = sorted[Math.floor(sorted.length / 2)];
          const spread = (sorted[Math.floor(sorted.length * 0.8)] - sorted[Math.floor(sorted.length * 0.2)]) / med;
          if (spread < 0.04) {
            L.ratios[best] = Math.round(med * 100) / 100;
            this.log(`Apprentissage : rapport ${best + 1} = ${L.ratios[best]} km/h pour 1000 tr/min`);
            this.files.saveLearnedSoon();
            this.onLearned(`rapport ${best + 1}`);
          }
        }
      }
    }

    // 2. tirages en 3e
    const k3 = this.files.ratios()[2];
    const in3 = rpm > 1500 && speed > 10 && Math.abs(speed / (rpm / 1000) - k3) / k3 < 0.08;
    const now = Date.now();
    if (!this.pull) {
      if (in3 && thr > 85 && rpm < 3200 && now - this.lastPullEnd > 2000) this.pull = [{ t: now, rpm }];
    } else {
      const last = this.pull[this.pull.length - 1];
      if (rpm !== last.rpm || now - last.t > 100) this.pull.push({ t: now, rpm });
      if (!in3 || thr < 70 || rpm > 6750) this.endPull();
    }

    // 3. consommation en croisière
    const lph = g("fuelRate");
    const gear = g("gear") ?? 0;
    if (lph !== undefined && speed > 30 && gear > 0 && Math.abs(glong) < 0.06) {
      const key = `${gear}:${Math.floor(rpm / 500) * 500}`;
      const b = (L.consoBins[key] ??= { l: 0, km: 0 });
      b.l += (lph / 3600) * 0.05;
      b.km += (speed / 3600) * 0.05;
    }
  }

  private endPull() {
    const p = this.pull!;
    this.pull = null;
    this.lastPullEnd = Date.now();
    if (p.length < 15) return;
    const r0 = p[0].rpm, r1 = p[p.length - 1].rpm;
    if (r0 > 3000 || r1 < 5500) {
      this.log(`Apprentissage : tirage ignoré (${Math.round(r0)} → ${Math.round(r1)} tr/min, il faut de 2 000-3 000 à plus de 5 500)`);
      return;
    }
    const c = this.files.config;
    const k3 = this.files.ratios()[2];
    const pullNo = this.files.learned.pulls;
    // pente locale du régime (régression sur ±300 ms)
    for (let i = 0; i < p.length; i++) {
      const win = p.filter((q) => Math.abs(q.t - p[i].t) <= 300);
      if (win.length < 3) continue;
      const mt = win.reduce((a, q) => a + q.t, 0) / win.length;
      const mr = win.reduce((a, q) => a + q.rpm, 0) / win.length;
      let num = 0, den = 0;
      for (const q of win) {
        num += (q.t - mt) * (q.rpm - mr);
        den += (q.t - mt) ** 2;
      }
      if (!den) continue;
      const rpmDot = (num / den) * 1000;
      const tq = torqueFrom(mr, rpmDot, k3, c.massKg, c.cdA);
      if (tq < 50 || tq > 500) continue;
      const bin = Math.round(mr / 250) * 250;
      const arr = this.pullBins.get(bin) ?? [];
      arr.push(tq);
      this.pullBins.set(bin, arr);
      if (i % 2 === 0) this.dots.push([mr, tq, pullNo]);
    }
    if (this.dots.length > 600) this.dots = this.dots.slice(-600);
    const L = this.files.learned;
    L.pulls++;
    this.sessionPulls++;
    this.log(`Apprentissage : tirage n°${L.pulls} enregistré (${Math.round(r0)} → ${Math.round(r1)} tr/min)`);
    if (L.pulls >= 2) {
      const curve: [number, number][] = [...this.pullBins.entries()]
        .filter(([, a]) => a.length >= 2)
        .map(([r, a]) => {
          const s = [...a].sort((x, y) => x - y);
          return [r, Math.round(s[Math.floor(s.length / 2)])] as [number, number];
        })
        .sort((a, b) => a[0] - b[0]);
      if (curve.length >= 6) {
        // le bas du régime (avant 2 000) vient de la référence
        L.torque = [...REF_TORQUE.filter(([r]) => r < curve[0][0]), ...curve];
        this.onLearned("courbe moteur");
      }
    }
    void this.files.saveLearned();
  }

  /** Comparaison de la courbe mesurée avec la référence, en phrases. */
  verdict(): string {
    const L = this.files.learned;
    if (!L.torque) return "";
    const mean = (a: number, b: number, t: [number, number][]) => {
      let s = 0, n = 0;
      for (let r = a; r <= b; r += 100) {
        s += interp(t, r);
        n++;
      }
      return s / n;
    };
    const low = (mean(2000, 3000, L.torque) / mean(2000, 3000, REF_TORQUE) - 1) * 100;
    const high = (mean(6000, 6800, L.torque) / mean(6000, 6800, REF_TORQUE) - 1) * 100;
    const pct = (x: number) => `${Math.abs(Math.round(x))} % de couple en ${x >= 0 ? "plus" : "moins"}`;
    const rows = shiftTable(this.files);
    const r4 = rows[3];
    return `C’est bon. Ton moteur donne ${pct(low)} que la référence en bas, et ${pct(high)} vers 6 500 tr/min. J’ai recalculé tes passages : en perf, passe la 5e à ${r4.cut ? "le rupteur" : r4.perf.toLocaleString("fr-FR") + " tr/min"}.`;
  }

  state(): LearnState {
    const L = this.files.learned;
    const gears = REF_RATIOS.map((_, i) => ({ n: i + 1, k: L.ratios[i], progress: L.ratios[i] !== null ? 1 : Math.min(0.95, this.gearSamples[i].length / 60) }));
    const gearsDone = L.ratios.filter((x) => x !== null).length;
    const pullActive = !!this.pull;
    const rpm = this.store.get("rpm") ?? 0;
    const pulls = Math.min(2, L.pulls);
    const pullProgress = Math.min(1, pulls / 2 + (pullActive ? Math.max(0, (rpm - 2000) / 4800) / 2 : 0));
    let phase: LearnState["phase"] = "gears";
    if (pullActive) phase = "pull";
    else if (L.pulls >= 2 && L.torque) phase = "done";
    else if (L.pulls === 1) phase = "between";
    else if (gearsDone >= 6) phase = "wait";
    const say = {
      gears: "Roule comme d’habitude. Je mesure le rapport de chaque vitesse en comparant le régime et la vitesse.",
      wait: "Les six rapports sont mesurés. Quand tu es sur circuit ou route fermée, cale-toi à 2 000 tr/min en 3e et mets le pied au plancher jusqu’au rupteur.",
      pull: "Tirage en cours, garde le pied au plancher jusqu’au rupteur.",
      between: "Premier tirage enregistré. Un deuxième, dans les mêmes conditions, pour confirmer.",
      done: this.verdict(),
    }[phase];
    return {
      gears, gearsDone, pulls, pullActive, pullProgress, dots: this.dots.slice(-300), fit: L.torque ?? [],
      learnedTorque: !!L.torque, consoKm: L.consoKm, phase, say,
    };
  }

  /** Régimes les plus sobres appris, par rapport (pour Nova). */
  consoSummary() {
    const L = this.files.learned;
    const out: Record<string, string> = {};
    for (const [key, b] of Object.entries(L.consoBins)) if (b.km > 2) out[key.replace(":", "e à ") + " tr/min"] = ((b.l / b.km) * 100).toFixed(1) + " L/100";
    return out;
  }
}
