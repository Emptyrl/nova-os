// Bus CAN propulsion du TT 8N (500 kbit/s), lu par un adaptateur USB-CAN (CANable / MKS CANable Pro,
// firmware candleLight → gs_usb, ou slcan) ou la carte NovaHAT (MCP2515). Écoute seule : Nova met
// l'interface en « listen-only » et n'envoie rien sur ce bus. Nova prépare l'interface elle-même.
//
// Les identifiants ci-dessous sont ceux de la plateforme PQ34 (Golf 4, TT 8N, A3 8L) relevés par la
// communauté. Régime, vitesses de roues et température d'eau sont sûrs ; les autres sont à vérifier
// sur ta voiture (active « garder les trames CAN » et envoie le fichier à Nova pour les décoder).
import { spawn, execFile, type ChildProcess } from "node:child_process";
import { createWriteStream, promises as fs, type WriteStream } from "node:fs";
import { jlog } from "../journaux.js";
import { CanHistory, decodeCustom } from "../canfind.js";
import path from "node:path";
import { Rate, type Source, type SourceDeps, type SourceStatus } from "./types.js";

type Frame = number[];
const u16 = (b: Frame, lo: number) => b[lo] | (b[lo + 1] << 8);

/** Décodages connus + décodages appris par comparaison avec la ligne K. */
export function decodeFrame(id: number, full: number[]): Record<string, number> | null {
  const dec = DECODERS[id];
  const a = dec ? dec(full) : null;
  const b = decodeCustom(id, full);
  return a || b ? { ...(a || {}), ...(b || {}) } : null;
}

export const DECODERS: Record<number, (b: Frame) => Record<string, number>> = {
  // Motor_1 : régime ×0,25, pédale ×0,4 %
  0x280: (b) => ({ rpm: u16(b, 2) * 0.25, pedal: b[5] * 0.4 }),
  // Motor_2 : température d'eau
  0x288: (b) => ({ water: b[1] * 0.75 - 48 }),
  // Bremse_1 : vitesse véhicule
  0x1a0: (b) => ({ speed: (u16(b, 2) >> 1) * 0.01 }),
  // Bremse_3 : vitesses des 4 roues
  0x4a0: (b) => ({ wfl: (u16(b, 0) >> 1) * 0.01, wfr: (u16(b, 2) >> 1) * 0.01, wrl: (u16(b, 4) >> 1) * 0.01, wrr: (u16(b, 6) >> 1) * 0.01 }),
  // Kombi_1 : niveau de carburant (à vérifier)
  0x320: (b) => ({ fuel: b[2] & 0x7f, fuelSensor: 1 }),
  // Kombi_2 : température extérieure (à vérifier)
  0x420: (b) => ({ ext: b[1] * 0.5 - 50 }),
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const hex3 = (n: number) => n.toString(16).toUpperCase().padStart(3, "0");
const sh = (cmd: string, args: string[], timeout = 8000) =>
  new Promise<{ ok: boolean; out: string }>((res) => execFile(cmd, args, { timeout }, (e, o, er) => res({ ok: !e, out: (String(o || "") + String(er || "")).trim() })));

/** Interfaces CAN présentes (gs_usb / candleLight, slcan, MCP2515…) : /sys/class/net/x/type = 280. */
export async function canInterfaces(): Promise<string[]> {
  if (process.platform !== "linux") return [];
  const names = await fs.readdir("/sys/class/net").catch(() => [] as string[]);
  const out: string[] = [];
  for (const n of names) if ((await fs.readFile(`/sys/class/net/${n}/type`, "utf8").catch(() => "")).trim() === "280") out.push(n);
  return out.sort();
}

/** CANable en firmware « slcan » (port série /dev/ttyACM) : identifiants USB connus. */
async function slcanPorts(): Promise<string[]> {
  const out: string[] = [];
  const dir = await fs.readdir("/sys/class/tty").catch(() => [] as string[]);
  for (const t of dir.filter((x) => /^ttyACM\d+$/.test(x))) {
    const base = `/sys/class/tty/${t}/device/..`;
    const vid = (await fs.readFile(`${base}/idVendor`, "utf8").catch(() => "")).trim();
    const pid = (await fs.readFile(`${base}/idProduct`, "utf8").catch(() => "")).trim();
    const prod = (await fs.readFile(`${base}/product`, "utf8").catch(() => "")).trim();
    if ((vid === "16d0" && pid === "117e") || /canable|slcan|can.?usb/i.test(prod)) out.push("/dev/" + t);
  }
  return out;
}

export interface CanEntry {
  id: number;
  bytes: number[];
  count: number;
  at: number;
  changed: number;
  decoded: Record<string, number> | null;
}

const RATES = [500000, 250000, 125000, 100000];
const SLCAN_CODE: Record<number, string> = { 500000: "6", 250000: "5", 125000: "4", 100000: "3" };

export class CanSource implements Source {
  status: SourceStatus = { name: "CAN", state: "off", detail: "", hz: 0 };
  readonly hasWheelSpeeds = true;
  private child: ChildProcess | null = null;
  private raw: WriteStream | null = null;
  private rate = new Rate();
  private partial = "";
  private running = false;
  private table = new Map<number, CanEntry>();
  private ifc = "";
  private bitrate = 500000;
  private lastFrame = 0;
  readonly history = new CanHistory();

  constructor(private d: SourceDeps, private logDir: string) {}

  private setStatus(state: SourceStatus["state"], detail: string) {
    if (this.status.state === state && this.status.detail === detail) return;
    this.status.state = state;
    this.status.detail = detail;
    this.d.onStatus();
  }

  async start() {
    if (process.platform !== "linux") {
      this.setStatus("error", "le CAN se lit sous Linux (Nova OS) avec un adaptateur USB-CAN (CANable)");
      return;
    }
    this.running = true;
    void this.loop();
  }

  async stop() {
    this.running = false;
    this.child?.kill();
    this.raw?.end();
    this.raw = null;
    this.setStatus("off", "");
  }

  view() {
    return {
      state: this.status.state,
      detail: this.status.detail,
      version: this.ifc ? `${this.ifc} · ${this.bitrate / 1000} kbit/s · écoute seule` : "",
      overflow: 0,
      ids: [...this.table.values()].sort((a, b) => a.id - b.id).map((e) => ({ ...e, idHex: hex3(e.id), age: Date.now() - e.at })),
    };
  }

  /** Trouve l'interface (gs_usb, sinon CANable slcan lancé par slcand) et la met en écoute seule. */
  private async prepare(bitrate: number): Promise<string> {
    if (process.env.NOVA_CAN_TEST) return process.env.NOVA_CAN_TEST; // essais sans adaptateur
    const want = this.d.files.config.canInterface || "can0";
    let list = await canInterfaces();
    if (!list.length) {
      const tty = (await slcanPorts())[0];
      if (tty) {
        await sh("sudo", ["-n", "pkill", "-f", "slcand.*" + tty]);
        // -l : écoute seule (pas d'accusé de réception sur le bus) ; sinon -o (ouverture normale)
        let r = await sh("sudo", ["-n", "slcand", "-l", "-c", "-s" + SLCAN_CODE[bitrate], tty, "slcan0"]);
        if (!r.ok) r = await sh("sudo", ["-n", "slcand", "-o", "-c", "-s" + SLCAN_CODE[bitrate], tty, "slcan0"]);
        jlog("cables.log", `CAN : CANable en mode slcan sur ${tty} : ${r.ok ? "OK" : r.out}`);
        await sleep(800);
        await sh("sudo", ["-n", "ip", "link", "set", "slcan0", "up"]);
        return "slcan0";
      }
      throw new Error("aucun adaptateur CAN trouvé (CANable branché en USB ?)");
    }
    const ifc = list.includes(want) ? want : list[0];
    if (ifc.startsWith("slcan")) return ifc;
    await sh("sudo", ["-n", "ip", "link", "set", ifc, "down"]);
    let r = await sh("sudo", ["-n", "ip", "link", "set", ifc, "type", "can", "bitrate", String(bitrate), "listen-only", "on"]);
    if (!r.ok) {
      jlog("cables.log", `CAN : écoute seule refusée par ${ifc} (${r.out}), mode normal`);
      r = await sh("sudo", ["-n", "ip", "link", "set", ifc, "type", "can", "bitrate", String(bitrate)]);
    }
    const up = await sh("sudo", ["-n", "ip", "link", "set", ifc, "up"]);
    if (!up.ok) throw new Error(`impossible d'activer ${ifc} : ${up.out}`);
    return ifc;
  }

  private async loop() {
    let ri = 0;
    let fails = 0;
    while (this.running) {
      try {
        this.bitrate = RATES[ri % RATES.length];
        this.setStatus("connecting", `adaptateur CAN · ${this.bitrate / 1000} kbit/s…`);
        this.ifc = await this.prepare(this.bitrate);
        if (this.d.files.config.canRawLog && !this.raw) {
          const f = path.join(this.logDir, `can_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.log`);
          this.raw = createWriteStream(f);
          this.d.log("CAN : trames brutes enregistrées dans " + f);
        }
        const t0 = Date.now();
        this.lastFrame = 0;
        await new Promise<void>((resolve) => {
          const child = spawn("candump", ["-L", this.ifc]);
          this.child = child;
          let err = "";
          child.stdout.on("data", (b: Buffer) => this.onText(b.toString("latin1")));
          child.stderr.on("data", (b: Buffer) => (err += b.toString()));
          child.on("error", () => {
            err = "candump introuvable (can-utils)";
            resolve();
          });
          // pas de trame en 4 s : mauvaise vitesse, ou rien de branché
          const watch = setInterval(() => {
            const quiet = Date.now() - (this.lastFrame || t0);
            if (!this.running || quiet > 4000) {
              clearInterval(watch);
              child.kill();
            }
          }, 500);
          child.on("exit", () => {
            clearInterval(watch);
            this.child = null;
            if (err) jlog("cables.log", "CAN : " + err.trim().slice(0, 200));
            resolve();
          });
        });
        if (!this.running) break;
        if (this.lastFrame) {
          // ça marchait puis plus rien : contact coupé ? on garde la même vitesse
          this.setStatus("error", `plus de trames sur ${this.ifc} (contact coupé ?)`);
          fails = 0;
          await sleep(2000);
        } else {
          jlog("cables.log", `CAN : rien reçu à ${this.bitrate / 1000} kbit/s sur ${this.ifc}`);
          ri++;
          if (ri % RATES.length === 0) {
            this.setStatus("error", `aucune trame CAN sur ${this.ifc} (500, 250, 125, 100 kbit/s essayés) : fils CAN-H / CAN-L, masse, contact mis ? Cavalier 120 Ω retiré ?`);
            await sleep(5000);
          }
        }
      } catch (e: any) {
        fails++;
        this.setStatus("error", String(e?.message || e));
        await sleep(Math.min(15000, 3000 * fails));
      }
    }
  }

  private onText(t: string) {
    this.partial += t;
    const lines = this.partial.split("\n");
    this.partial = lines.pop() ?? "";
    for (const line of lines) {
      this.raw?.write(line + "\n");
      // (1698765432.123456) can0 280#0011223344556677
      const m = line.match(/\)\s+\S+\s+([0-9A-F]{3,8})#([0-9A-F]*)/i);
      if (!m) continue;
      const id = parseInt(m[1], 16);
      const bytes: Frame = [];
      for (let i = 0; i + 1 < m[2].length; i += 2) bytes.push(parseInt(m[2].slice(i, i + 2), 16));
      const full = bytes.concat(Array(Math.max(0, 8 - bytes.length)).fill(0));
      const decoded = decodeFrame(id, full);
      this.history.add(id, bytes);
      const e = this.table.get(id);
      if (e) {
        for (let i = 0; i < bytes.length; i++) if (bytes[i] !== e.bytes[i]) e.changed |= 1 << i;
        e.bytes = bytes;
        e.count++;
        e.at = Date.now();
        e.decoded = decoded;
      } else this.table.set(id, { id, bytes, count: 1, at: Date.now(), changed: 0, decoded });
      if (decoded) this.d.store.set(decoded);
      this.lastFrame = Date.now();
      if (id === 0x280) {
        this.rate.tick();
        this.status.hz = this.rate.hz;
      }
      if (this.status.state !== "ok" || Date.now() % 2000 < 20) this.setStatus("ok", `${this.ifc} · ${this.bitrate / 1000} kbit/s · ${this.table.size} identifiants`);
    }
  }

  ids() {
    return [...this.table.keys()].sort((a, b) => a - b).map((x) => "0x" + x.toString(16).toUpperCase());
  }
}
