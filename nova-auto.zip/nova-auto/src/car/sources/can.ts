// Bus CAN propulsion du TT 8N (500 kbit/s), lu par la carte NovaHAT (MCP2515 → can0) ou un
// adaptateur USB-CAN sous Linux. Écoute seule : Nova n'envoie rien sur ce bus.
// Prépare l'interface avant : sudo ip link set can0 up type can bitrate 500000 listen-only on
//
// Les identifiants ci-dessous sont ceux de la plateforme PQ34 (Golf 4, TT 8N, A3 8L) relevés par la
// communauté. Régime, vitesses de roues et température d'eau sont sûrs ; les autres sont à vérifier
// sur ta voiture (active « garder les trames CAN » et envoie le fichier à Nova pour les décoder).
import { spawn, type ChildProcess } from "node:child_process";
import { createWriteStream, type WriteStream } from "node:fs";
import path from "node:path";
import { Rate, type Source, type SourceDeps, type SourceStatus } from "./types.js";

type Frame = number[];
const u16 = (b: Frame, lo: number) => b[lo] | (b[lo + 1] << 8);

export const DECODERS: Record<number, (b: Frame) => Record<string, number>> = {
  // Motor_1 : régime ×0,25, pédale ×0,4 %
  0x280: (b) => ({ rpm: u16(b, 2) * 0.25, pedal: b[5] * 0.4 }),
  // Motor_2 : température d'eau
  0x288: (b) => ({ water: b[1] * 0.75 - 48 }),
  // Bremse_1 : vitesse véhicule
  0x1a0: (b) => ({ speed: (u16(b, 2) >> 1) * 0.01 }),
  // Bremse_3 : vitesses des 4 roues
  0x4a0: (b) => ({ wfl: (u16(b, 0) >> 1) * 0.01, wfr: (u16(b, 2) >> 1) * 0.01, wrl: (u16(b, 4) >> 1) * 0.01, wrr: (u16(b, 6) >> 1) * 0.01 }),
  // Kombi_1 : niveau de carburant (à vérifier)
  0x320: (b) => ({ fuel: b[2] & 0x7f, fuelSensor: 1 }),
  // Kombi_2 : température extérieure (à vérifier)
  0x420: (b) => ({ ext: b[1] * 0.5 - 50 }),
};

export class CanSource implements Source {
  status: SourceStatus = { name: "CAN", state: "off", detail: "", hz: 0 };
  readonly hasWheelSpeeds = true;
  private child: ChildProcess | null = null;
  private raw: WriteStream | null = null;
  private rate = new Rate();
  private partial = "";
  private running = false;
  private seen = new Set<number>();

  constructor(private d: SourceDeps, private logDir: string) {}

  private setStatus(state: SourceStatus["state"], detail: string) {
    this.status.state = state;
    this.status.detail = detail;
    this.d.onStatus();
  }

  async start() {
    if (process.platform !== "linux") {
      this.setStatus("error", "le CAN se lit sous Linux (Raspberry Pi ou PC sous Linux avec adaptateur USB-CAN)");
      return;
    }
    this.running = true;
    this.launch();
  }

  private launch() {
    const ifc = this.d.files.config.canInterface || "can0";
    this.setStatus("connecting", ifc);
    if (this.d.files.config.canRawLog) {
      const f = path.join(this.logDir, `can_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.log`);
      this.raw = createWriteStream(f);
      this.d.log("CAN : trames brutes enregistrées dans " + f);
    }
    const child = spawn("candump", ["-L", ifc]);
    this.child = child;
    child.stdout.on("data", (b: Buffer) => this.onText(b.toString("latin1")));
    child.stderr.on("data", (b: Buffer) => this.setStatus("error", b.toString().trim().slice(0, 160)));
    child.on("error", () => this.setStatus("error", "candump introuvable : sudo apt install can-utils"));
    child.on("exit", () => {
      this.child = null;
      this.raw?.end();
      this.raw = null;
      if (this.running) setTimeout(() => this.running && this.launch(), 3000);
    });
  }

  async stop() {
    this.running = false;
    this.child?.kill();
    this.setStatus("off", "");
  }

  private onText(t: string) {
    this.partial += t;
    const lines = this.partial.split("\n");
    this.partial = lines.pop() ?? "";
    for (const line of lines) {
      this.raw?.write(line + "\n");
      // (1698765432.123456) can0 280#0011223344556677
      const m = line.match(/\)\s+\S+\s+([0-9A-F]{3,8})#([0-9A-F]*)/i);
      if (!m) continue;
      const id = parseInt(m[1], 16);
      this.seen.add(id);
      const dec = DECODERS[id];
      if (!dec) continue;
      const bytes: Frame = [];
      for (let i = 0; i + 1 < m[2].length; i += 2) bytes.push(parseInt(m[2].slice(i, i + 2), 16));
      while (bytes.length < 8) bytes.push(0);
      this.d.store.set(dec(bytes));
      if (id === 0x280) {
        this.rate.tick();
        this.status.hz = this.rate.hz;
        if (this.status.state !== "ok") this.setStatus("ok", `${this.d.files.config.canInterface} · 500 kbit/s`);
      }
    }
  }

  /** Identifiants vus sur le bus (pour aider à décoder la voiture). */
  ids() {
    return [...this.seen].sort((a, b) => a - b).map((x) => "0x" + x.toString(16).toUpperCase());
  }
}
