// Lecture rapide du ME7.5 par le câble KKL, avec ME7Logger (20 à 50 mesures par seconde).
// Nova ne parle pas elle-même au calculateur : elle lance ME7Logger (ou lit le CSV qu'il écrit)
// et reconnaît les colonnes par leur nom de variable ME7 ou leur alias.
import { spawn, type ChildProcess } from "node:child_process";
import { promises as fs, watch, type FSWatcher } from "node:fs";
import { Rate, type Source, type SourceDeps, type SourceStatus } from "./types.js";

// variable ME7 (ou alias courant des fichiers de config ME7Logger) → mesure Nova
const COLUMNS: [RegExp, string, (x: number) => number][] = [
  [/^(nmot(_w)?|enginespeed|rpm)$/i, "rpm", (x) => x],
  [/^(vfzg(_w)?|vehiclespeed|speed)$/i, "speed", (x) => x],
  [/^(tmot|coolanttemp(erature)?)$/i, "water", (x) => x],
  [/^(tans|intakeairtemp(erature)?)$/i, "iat", (x) => x],
  [/^(rl(_w)?|engineload)$/i, "load", (x) => x],
  [/^(wdkba|throttleplateangle|throttle)$/i, "throttle", (x) => x],
  [/^(wped(_w)?|acceleratorpedalposition|pedal)$/i, "pedal", (x) => x],
  [/^(mshfm_w|massairflow|maf)$/i, "maf", (x) => x / 3.6], // kg/h → g/s
  [/^(zwout|ignitiontimingangleoverall|timing)$/i, "timing", (x) => x],
  [/^(lamsoni_w|lambdaactual|lambda)$/i, "lambda", (x) => x],
  [/^(ub|batteryvoltage)$/i, "volt", (x) => x],
  [/^(wkr_x\[0\]|wkr_0|ignitionretardcyl1)$/i, "knock1", (x) => x],
  [/^(wkr_x\[1\]|wkr_1|ignitionretardcyl2)$/i, "knock2", (x) => x],
  [/^(wkr_x\[2\]|wkr_2|ignitionretardcyl3)$/i, "knock3", (x) => x],
  [/^(wkr_x\[3\]|wkr_3|ignitionretardcyl4)$/i, "knock4", (x) => x],
  [/^(pvdks_w|boostpressureactual)$/i, "_pabs", (x) => x],
  [/^(plsol(_w)?|boostpressurespecified|boostpressuredesired)$/i, "_preq", (x) => x],
  [/^(pus_w|ambientpressure)$/i, "_pamb", (x) => x],
  [/^(fr_w|lambdacontrol)$/i, "_fr", (x) => x],
];

export class Me7LoggerSource implements Source {
  status: SourceStatus = { name: "ME7Logger", state: "off", detail: "", hz: 0 };
  readonly hasWheelSpeeds = false;
  private child: ChildProcess | null = null;
  private watcher: FSWatcher | null = null;
  private map: ((x: number) => [string, number] | null)[] = [];
  private pamb = 1013;
  private rate = new Rate();
  private partial = "";
  private offset = 0;

  constructor(private d: SourceDeps) {}

  private setStatus(state: SourceStatus["state"], detail: string) {
    this.status.state = state;
    this.status.detail = detail;
    this.d.onStatus();
  }

  async start() {
    const c = this.d.files.config;
    if (c.kklCommand) {
      this.setStatus("connecting", "lancement de ME7Logger…");
      this.child = spawn(c.kklCommand, { shell: true });
      this.child.stdout?.on("data", (b: Buffer) => this.onText(b.toString("utf8")));
      this.child.stderr?.on("data", (b: Buffer) => this.d.log("ME7Logger : " + b.toString("utf8").trim().slice(0, 300)));
      this.child.on("exit", (code) => this.setStatus("error", `ME7Logger s'est arrêté (code ${code})`));
      this.child.on("error", (e) => this.setStatus("error", "ME7Logger introuvable : " + e.message));
    } else if (c.kklCsvFile) {
      this.setStatus("connecting", "attente du fichier " + c.kklCsvFile);
      this.offset = 0;
      const poll = async () => {
        try {
          const st = await fs.stat(c.kklCsvFile);
          if (st.size < this.offset) this.offset = 0; // nouveau fichier
          if (st.size > this.offset) {
            const fh = await fs.open(c.kklCsvFile, "r");
            const buf = Buffer.alloc(st.size - this.offset);
            await fh.read(buf, 0, buf.length, this.offset);
            await fh.close();
            this.offset = st.size;
            this.onText(buf.toString("utf8"));
          }
        } catch {
          /* fichier pas encore créé */
        }
      };
      const timer = setInterval(poll, 50);
      this.watcher = { close: () => clearInterval(timer) } as unknown as FSWatcher;
    } else {
      this.setStatus("error", "indique la commande ME7Logger ou son fichier CSV dans les réglages");
    }
  }

  async stop() {
    this.child?.kill();
    this.child = null;
    this.watcher?.close();
    this.watcher = null;
    this.setStatus("off", "");
  }

  private onText(t: string) {
    this.partial += t;
    const lines = this.partial.split(/\r?\n/);
    this.partial = lines.pop() ?? "";
    for (const line of lines) this.onLine(line.trim());
  }

  private onLine(line: string) {
    if (!line) return;
    const sep = line.includes(";") ? ";" : ",";
    const cells = line.split(sep).map((x) => x.trim());
    // ligne d'en-tête : on (re)construit la correspondance des colonnes
    if (cells.some((c) => /[a-z]{3,}/i.test(c) && !/^-?[\d.]+$/.test(c)) && cells.filter((c) => /^-?[\d.]+$/.test(c)).length < cells.length / 2) {
      const names = cells.map((c) => c.replace(/\s*\(.*\)$/, "").replace(/\s+/g, ""));
      const found: string[] = [];
      this.map = names.map((n) => {
        const m = COLUMNS.find(([re]) => re.test(n));
        if (!m) return () => null;
        found.push(m[1]);
        return (x: number) => [m[1], m[2](x)];
      });
      if (found.length) {
        this.setStatus("ok", `${found.length} mesures reconnues`);
        this.d.log("KKL : colonnes reconnues → " + found.join(", "));
      }
      return;
    }
    if (!this.map.length) return;
    const out: Record<string, number> = {};
    cells.forEach((c, i) => {
      const x = parseFloat(c.replace(",", "."));
      if (!Number.isFinite(x) || !this.map[i]) return;
      const r = this.map[i](x);
      if (r) out[r[0]] = r[1];
    });
    if ("_pamb" in out) this.pamb = out._pamb;
    if ("_pabs" in out) out.boost = (out._pabs - this.pamb) / 1000;
    if ("_preq" in out) out.boostReq = (out._preq - this.pamb) / 1000;
    const k = [out.knock1, out.knock2, out.knock3, out.knock4].filter((x) => x !== undefined);
    if (k.length) out.knock = Math.max(...k);
    for (const key of Object.keys(out)) if (key.startsWith("_")) delete out[key];
    this.d.store.set(out);
    this.rate.tick();
    this.status.hz = this.rate.hz;
    if (this.status.state !== "ok") this.setStatus("ok", "lecture en cours");
  }
}
