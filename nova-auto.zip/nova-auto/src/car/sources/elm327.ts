// Lecture OBD par un ELM327 (USB ou Bluetooth appairé en port série) sur la ligne K du TT 8N.
// Lent par nature (≈ 5 à 10 questions par seconde) : régime et vitesse sont demandés à chaque tour,
// les autres mesures à tour de rôle.
import { SerialPort } from "serialport";
import { listCablePorts, probeElm } from "../cables.js";
import { bindRfcomm } from "../btserial.js";
import { jlog } from "../journaux.js";
import { Rate, DTC_TEXT, type Dtc, type Source, type SourceDeps, type SourceStatus } from "./types.js";

type Decoder = (b: number[]) => Record<string, number>;

const PIDS: Record<string, Decoder> = {
  "04": (b) => ({ load: (b[0] * 100) / 255 }),
  "05": (b) => ({ water: b[0] - 40 }),
  "06": (b) => ({ stft: ((b[0] - 128) * 100) / 128 }),
  "07": (b) => ({ ltft: ((b[0] - 128) * 100) / 128 }),
  "0B": (b) => ({ map: b[0] }),
  "0C": (b) => ({ rpm: (256 * b[0] + b[1]) / 4 }),
  "0D": (b) => ({ speed: b[0] }),
  "0E": (b) => ({ timing: b[0] / 2 - 64 }),
  "0F": (b) => ({ iat: b[0] - 40 }),
  "10": (b) => ({ maf: (256 * b[0] + b[1]) / 100 }),
  "11": (b) => ({ throttle: (b[0] * 100) / 255 }),
};
const FAST = ["0C", "0D"];
const SLOW = ["10", "04", "11", "0E", "05", "0F", "0B", "06", "07"];

export class Elm327Source implements Source {
  status: SourceStatus = { name: "ELM327", state: "off", detail: "", hz: 0 };
  readonly hasWheelSpeeds = false;
  private port: SerialPort | null = null;
  private rx = "";
  private pending: { resolve: (s: string) => void; reject: (e: Error) => void; timer: NodeJS.Timeout } | null = null;
  private lock: Promise<unknown> = Promise.resolve();
  private running = false;
  private supported = new Set<string>();
  private rate = new Rate();
  private baro = 101;

  portPath = "";

  constructor(
    private d: SourceDeps,
    private forcedPort?: string,
  ) {}

  private setStatus(state: SourceStatus["state"], detail: string) {
    this.status.state = state;
    this.status.detail = detail;
    this.d.onStatus();
  }

  async start() {
    this.running = true;
    void this.loop();
  }

  async stop() {
    this.running = false;
    await this.close();
    this.setStatus("off", "");
  }

  private async close() {
    const p = this.port;
    this.port = null;
    if (p?.isOpen) await new Promise<void>((r) => p.close(() => r()));
  }

  private async findPort(): Promise<string> {
    const cfg = this.forcedPort || this.d.files.config.serialPort;
    if (cfg) return cfg;
    const bt = this.d.files.config.elmBt;
    if (bt) {
      const dev = await bindRfcomm(bt);
      if (dev) return dev;
      throw new Error("ELM327 Bluetooth " + bt + " : liaison impossible (clé Bluetooth branchée ? ELM327 associé ?)");
    }
    // source « ELM327 » choisie à la main : le premier port qui répond comme un ELM327
    const list = await listCablePorts();
    for (const p of list) {
      if (await probeElm(p.path, (t) => jlog("cables.log", t))) return p.path;
    }
    if (!list.length) throw new Error("aucun câble trouvé (branche l'ELM327 ou indique le port dans les réglages)");
    throw new Error("aucun ELM327 ne répond (" + list.map((p) => p.path).join(", ") + ") : voir Réglages → Journaux → Câbles");
  }

  private async open(path: string, baudRate: number) {
    await this.close();
    const port = new SerialPort({ path, baudRate, autoOpen: false });
    await new Promise<void>((res, rej) => port.open((e) => (e ? rej(e) : res())));
    port.on("data", (chunk: Buffer) => this.onData(chunk.toString("latin1")));
    port.on("close", () => {
      if (this.port === port) {
        this.port = null;
        this.pending?.reject(new Error("câble débranché"));
      }
    });
    this.port = port;
    this.portPath = path;
  }

  private onData(s: string) {
    this.rx += s;
    const i = this.rx.indexOf(">");
    if (i >= 0 && this.pending) {
      const out = this.rx.slice(0, i);
      this.rx = this.rx.slice(i + 1);
      const p = this.pending;
      this.pending = null;
      clearTimeout(p.timer);
      p.resolve(out);
    }
  }

  /** Envoie une commande et attend l'invite « > ». Les commandes passent une par une. */
  cmd(c: string, timeout = 2500): Promise<string> {
    const run = () =>
      new Promise<string>((resolve, reject) => {
        if (!this.port?.isOpen) return reject(new Error("port fermé"));
        this.rx = "";
        const timer = setTimeout(() => {
          this.pending = null;
          reject(new Error("pas de réponse à " + c));
        }, timeout);
        this.pending = { resolve, reject, timer };
        this.port.write(c + "\r");
      });
    const p = this.lock.then(run, run);
    this.lock = p.catch(() => {});
    return p;
  }

  private async init(): Promise<string> {
    const cfg = this.d.files.config;
    const path = await this.findPort();
    const bauds = [cfg.baudRate, 38400, 9600, 115200].filter((b, i, a) => a.indexOf(b) === i);
    let version = "";
    for (const baud of bauds) {
      this.setStatus("connecting", `${path} à ${baud} bauds…`);
      await this.open(path, baud);
      try {
        version = (await this.cmd("ATZ", 3000)).replace(/\s+/g, " ").trim();
        if (/ELM|OBD|v\d/i.test(version)) break;
      } catch {
        /* mauvaise vitesse : on essaie la suivante */
      }
      version = "";
    }
    if (!version) throw new Error(`l'ELM327 ne répond pas sur ${path}`);
    for (const c of ["ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATSP" + (cfg.elmProtocol || "0")]) await this.cmd(c);
    this.setStatus("connecting", `${path} · réveil de la ligne K (5 à 10 s)…`);
    const r = await this.cmd("0100", 15000);
    if (!/4100/.test(r.replace(/\s/g, ""))) throw new Error("le calculateur ne répond pas (contact mis ?) : " + r.trim().slice(0, 60));
    this.parseSupported(r, 0);
    try {
      this.parseSupported(await this.cmd("0120", 4000), 0x20);
    } catch {
      /* pas de deuxième page */
    }
    let proto = "";
    try {
      proto = (await this.cmd("ATDP")).trim();
    } catch {
      /* facultatif */
    }
    this.d.log(`ELM327 connecté (${version}) sur ${path}, ${proto}, PID : ${[...this.supported].join(" ")}`);
    return `${path} · ${proto.replace(/^AUTO,\s*/i, "") || "OBD"}`;
  }

  private parseSupported(r: string, base: number) {
    const hex = r.replace(/\s/g, "");
    const m = hex.match(new RegExp("41" + (base ? "20" : "00") + "([0-9A-F]{8})", "i"));
    if (!m) return;
    const bits = parseInt(m[1], 16);
    for (let i = 0; i < 32; i++) if (bits & (1 << (31 - i))) this.supported.add((base + i + 1).toString(16).toUpperCase().padStart(2, "0"));
  }

  private async readPid(pid: string) {
    const r = (await this.cmd("01" + pid)).replace(/\s/g, "").toUpperCase();
    const at = r.indexOf("41" + pid);
    if (at < 0) return;
    const bytes: number[] = [];
    for (let i = at + 4; i + 1 < r.length && bytes.length < 4; i += 2) bytes.push(parseInt(r.slice(i, i + 2), 16));
    if (bytes.some((x) => Number.isNaN(x))) return;
    const out = PIDS[pid](bytes);
    if ("map" in out) {
      if ((this.d.store.get("rpm") ?? 0) < 100) this.baro = out.map; // moteur arrêté : pression atmosphérique
      this.d.store.set({ boost: (out.map - this.baro) / 100 });
      delete out.map;
    }
    this.d.store.set(out);
  }

  private async loop() {
    while (this.running) {
      try {
        const detail = await this.init();
        this.setStatus("ok", detail);
        const slow = SLOW.filter((p) => this.supported.has(p));
        let i = 0;
        let lastVolt = 0;
        while (this.running && this.port) {
          for (const p of FAST) await this.readPid(p);
          if (slow.length) await this.readPid(slow[i++ % slow.length]);
          if (Date.now() - lastVolt > 3000) {
            lastVolt = Date.now();
            const v = parseFloat((await this.cmd("ATRV")).replace(/[^\d.]/g, ""));
            if (v > 5 && v < 20) this.d.store.set({ volt: v });
          }
          this.rate.tick();
          this.status.hz = this.rate.hz;
        }
      } catch (e: any) {
        if (!this.running) break;
        this.setStatus("error", String(e?.message || e));
        this.d.log("ELM327 : " + (e?.message || e));
        await this.close();
        await new Promise((r) => setTimeout(r, 5000));
      }
    }
  }

  async readDtc(): Promise<Dtc[]> {
    const r = (await this.cmd("03", 8000)).toUpperCase();
    const codes: Dtc[] = [];
    for (const line of r.split(/[\r\n]+/)) {
      const hex = line.replace(/\s/g, "");
      const at = hex.indexOf("43");
      if (at < 0) continue;
      const body = hex.slice(at + 2);
      for (let i = 0; i + 3 < body.length; i += 4) {
        const a = parseInt(body.slice(i, i + 2), 16);
        const b = parseInt(body.slice(i + 2, i + 4), 16);
        if (!a && !b) continue;
        const code = "PCBU"[a >> 6] + ((a >> 4) & 3) + (a & 15).toString(16).toUpperCase() + b.toString(16).toUpperCase().padStart(2, "0");
        if (!codes.some((c) => c.code === code)) codes.push({ code, text: DTC_TEXT[code] ?? "voir VCDS pour le détail" });
      }
    }
    return codes;
  }

  async clearDtc() {
    await this.cmd("04", 8000);
  }
}
