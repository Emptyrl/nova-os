// Source « elmcan » : un ELM327 branché directement sur le bus CAN propulsion du TT 8N (500 kbit/s),
// pas sur la prise OBD (sur la 8N, la prise OBD n'a que la ligne K). Nova n'y envoie RIEN : l'ELM327 est
// mis en écoute silencieuse (ATCSM1, ATMA) et Nova ne pose aucune question OBD dans ce mode.
//
// Un ELM327 ne peut pas tout recevoir à 500 kbit/s (sa mémoire déborde : « BUFFER FULL »). Nova le fait
// donc écouter un identifiant (ou une petite famille) à la fois, à tour de rôle : le régime (0x280) un
// tour sur deux, les autres ensuite. Il découvre aussi les identifiants présents et garde, pour chacun,
// les derniers octets reçus : c'est ce qui permet de vérifier et de compléter le décodage sur ta voiture.
//
// USB (port série) ou Wi-Fi (« elmHost » : 192.168.0.10:35000). Le Bluetooth passe aussi s'il est appairé
// en port série (/dev/rfcomm0).
import { SerialPort } from "serialport";
import net from "node:net";
import { spawn } from "node:child_process";
import { bindRfcomm } from "../btserial.js";
import { createWriteStream, type WriteStream } from "node:fs";
import path from "node:path";
import { listCablePorts, probeElm } from "../cables.js";
import { jlog } from "../journaux.js";
import { DECODERS } from "./can.js";
import { Rate, type Source, type SourceDeps, type SourceStatus } from "./types.js";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const hex3 = (n: number) => n.toString(16).toUpperCase().padStart(3, "0");

export interface CanEntry {
  id: number;
  bytes: number[];
  count: number;
  at: number;
  /** octets qui ont changé depuis la découverte (bit i = octet i) */
  changed: number;
  decoded: Record<string, number> | null;
}

interface Link {
  write(s: string): void;
  close(): Promise<void>;
}

export class ElmCanSource implements Source {
  status: SourceStatus = { name: "CAN · ELM327", state: "off", detail: "", hz: 0 };
  readonly hasWheelSpeeds = true;
  portPath = "";
  private link: Link | null = null;
  private rx = "";
  private waiter: ((s: string) => void) | null = null;
  private running = false;
  private rate = new Rate();
  private table = new Map<number, CanEntry>();
  private raw: WriteStream | null = null;
  private overflow = 0;
  private version = "";
  private lines = 0;

  constructor(
    private d: SourceDeps,
    private logDir: string,
    private forcedPort?: string,
    private avoidPort: () => string = () => "",
  ) {}

  private setStatus(state: SourceStatus["state"], detail: string) {
    if (this.status.state === state && this.status.detail === detail) return;
    this.status.state = state;
    this.status.detail = detail;
    this.d.onStatus();
  }

  async start() {
    this.running = true;
    void this.loop();
  }

  async stop() {
    this.running = false;
    await this.closeLink();
    this.raw?.end();
    this.raw = null;
    this.setStatus("off", "");
  }

  /** Ce que l'écran « Bus CAN » affiche. */
  view() {
    return {
      state: this.status.state,
      detail: this.status.detail,
      version: this.version,
      overflow: this.overflow,
      ids: [...this.table.values()].sort((a, b) => a.id - b.id).map((e) => ({ ...e, idHex: hex3(e.id), age: Date.now() - e.at })),
    };
  }

  // ---------------- liaison (USB ou Wi-Fi) ----------------
  private async closeLink() {
    const l = this.link;
    this.link = null;
    if (l) await l.close().catch(() => {});
  }

  private onData(s: string) {
    this.rx += s;
    if (this.waiter && this.rx.includes(">")) {
      const i = this.rx.indexOf(">");
      const out = this.rx.slice(0, i);
      this.rx = this.rx.slice(i + 1);
      const w = this.waiter;
      this.waiter = null;
      w(out);
    }
  }

  private async openSerial(p: string, baud: number) {
    const port = new SerialPort({ path: p, baudRate: baud, autoOpen: false });
    await new Promise<void>((res, rej) => port.open((e) => (e ? rej(e) : res())));
    port.on("data", (b: Buffer) => this.onData(b.toString("latin1")));
    port.on("error", () => {});
    port.on("close", () => {
      if (this.link && this.portPath === p) this.link = null;
    });
    this.portPath = p;
    this.link = {
      write: (s) => port.write(s),
      close: () => new Promise<void>((r) => (port.isOpen ? port.close(() => r()) : r())),
    };
  }

  private async openTcp(hostPort: string) {
    const [host, portS] = hostPort.split(":");
    const sock = net.connect({ host, port: Number(portS) || 35000 });
    await new Promise<void>((res, rej) => {
      sock.once("connect", () => res());
      sock.once("error", rej);
      setTimeout(() => rej(new Error("pas de réponse de " + hostPort + " (Wi-Fi de l'ELM327 connecté ?)")), 6000);
    });
    sock.on("data", (b: Buffer) => this.onData(b.toString("latin1")));
    sock.on("error", () => {});
    sock.on("close", () => {
      if (this.link) this.link = null;
    });
    this.portPath = hostPort;
    this.link = {
      write: (s) => sock.write(s),
      close: async () => void sock.destroy(),
    };
  }

  /**
   * Bluetooth : port série /dev/rfcommN lié à l'ELM327 (rfcomm de BlueZ), sinon un petit pont Python
   * (socket RFCOMM) dont l'entrée et la sortie servent de liaison.
   */
  private async openBt(mac: string) {
    const dev = await bindRfcomm(mac);
    if (dev) {
      this.setStatus("connecting", `Bluetooth ${mac} · connexion…`);
      await this.openSerial(dev, 38400);
      this.portPath = "Bluetooth " + mac;
      return;
    }
    jlog("cables.log", "CAN · ELM327 Bluetooth : rfcomm indisponible, pont Python");
    const py = `import socket,sys,os,select
s=socket.socket(socket.AF_BLUETOOTH,socket.SOCK_STREAM,socket.BTPROTO_RFCOMM)
s.connect((sys.argv[1],1))
sys.stdout.write("CONNECTED\\n");sys.stdout.flush()
while True:
  r,_,_=select.select([s,sys.stdin],[],[])
  if s in r:
    d=s.recv(1024)
    if not d: break
    os.write(1,d)
  if sys.stdin in r:
    d=os.read(0,1024)
    if not d: break
    s.send(d)`;
    const child = spawn("python3", ["-c", py, mac], { stdio: ["pipe", "pipe", "pipe"] });
    await new Promise<void>((resolve, reject) => {
      let err = "";
      const t = setTimeout(() => reject(new Error("l'ELM327 Bluetooth ne répond pas (associé ? alimenté ?)")), 15000);
      child.stderr.on("data", (d: Buffer) => (err += d.toString()));
      child.once("exit", () => {
        clearTimeout(t);
        reject(new Error("connexion Bluetooth impossible : " + (err.trim().split("\n").pop() || "?")));
      });
      const first = (d: Buffer) => {
        const s = d.toString("latin1");
        if (s.startsWith("CONNECTED")) {
          clearTimeout(t);
          child.stdout.off("data", first);
          child.stdout.on("data", (x: Buffer) => this.onData(x.toString("latin1")));
          const rest = s.slice("CONNECTED\n".length);
          if (rest) this.onData(rest);
          resolve();
        }
      };
      child.stdout.on("data", first);
    });
    child.on("exit", () => {
      if (this.link) this.link = null;
    });
    this.portPath = "Bluetooth " + mac;
    this.link = {
      write: (s) => child.stdin.write(s),
      close: async () => void child.kill(),
    };
  }

  /** Commande AT : attend l'invite « > ». */
  private cmd(c: string, timeout = 2500): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.link) return reject(new Error("ELM327 déconnecté"));
      this.rx = "";
      const t = setTimeout(() => {
        this.waiter = null;
        reject(new Error("pas de réponse à " + c));
      }, timeout);
      this.waiter = (s) => {
        clearTimeout(t);
        resolve(s);
      };
      this.link.write(c + "\r");
    });
  }

  private async findPort(): Promise<string> {
    const cfg = this.d.files.config;
    if (this.forcedPort) return this.forcedPort;
    if (cfg.serialPort && !/kkl/.test(cfg.source)) return cfg.serialPort;
    const avoid = this.avoidPort();
    const list = (await listCablePorts()).filter((p) => p.path !== avoid);
    // les câbles KKL sont presque toujours des FTDI : on essaie les autres d'abord
    list.sort((a, b) => Number(a.vid === "0403") - Number(b.vid === "0403"));
    for (const p of list) if (await probeElm(p.path, (t) => jlog("cables.log", t))) return p.path;
    throw new Error(list.length ? "aucun ELM327 ne répond (" + list.map((p) => p.path).join(", ") + ")" : "ELM327 non branché");
  }

  private async init() {
    const cfg = this.d.files.config;
    if (cfg.elmBt) {
      this.setStatus("connecting", `Bluetooth ${cfg.elmBt}…`);
      await this.closeLink();
      await this.openBt(cfg.elmBt);
      this.version = (await this.cmd("ATZ", 5000)).replace(/\s+/g, " ").trim();
      if (!/ELM|STN|OBD|v\d/i.test(this.version)) throw new Error("l'appareil Bluetooth ne répond pas comme un ELM327 (« " + this.version.slice(0, 30) + " »)");
    } else if (cfg.elmHost) {
      this.setStatus("connecting", `Wi-Fi ${cfg.elmHost}…`);
      await this.openTcp(cfg.elmHost);
      this.version = (await this.cmd("ATZ", 4000)).replace(/\s+/g, " ").trim();
    } else {
      const p = await this.findPort();
      for (const baud of [cfg.baudRate, 38400, 115200, 9600, 230400, 500000].filter((b, i, a) => b && a.indexOf(b) === i)) {
        this.setStatus("connecting", `${p} à ${baud} bauds…`);
        await this.closeLink();
        await this.openSerial(p, baud);
        try {
          this.version = (await this.cmd("ATZ", 2500)).replace(/\s+/g, " ").trim();
          if (/ELM|STN|OBD|v\d/i.test(this.version)) break;
        } catch {
          /* vitesse suivante */
        }
        this.version = "";
      }
      if (!this.version) throw new Error("l'ELM327 ne répond pas sur " + p);
    }
    // écoute du CAN 11 bits, sans formatage, en-têtes affichés, sans accusés (silencieux)
    for (const c of ["ATE0", "ATL0", "ATS0", "ATH1", "ATD0", "ATCAF0", "ATAL"]) await this.cmd(c);
    await this.setBitrate(this.bitrateIdx);
    const silent = (await this.cmd("ATCSM1").catch(() => "?")).trim();
    jlog("cables.log", `CAN · ELM327 ${this.version} sur ${this.portPath} : écoute silencieuse ${/OK/i.test(silent) ? "activée" : "non gérée par ce modèle (" + silent + ")"}`);
    this.d.log(`CAN · ELM327 (${this.version}) sur ${this.portPath}`);
    if (cfg.canRawLog && !this.raw) {
      const f = path.join(this.logDir, `can-elm_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.log`);
      this.raw = createWriteStream(f);
    }
  }

  // vitesses essayées si rien ne passe : 500 kbit/s (propulsion), puis 250, 125 et 100 (confort)
  private static RATES: { name: string; cmds: string[] }[] = [
    { name: "500 kbit/s", cmds: ["ATSP6"] },
    { name: "250 kbit/s", cmds: ["ATSP8"] },
    { name: "125 kbit/s", cmds: ["ATPBC004", "ATSPB"] },
    { name: "100 kbit/s", cmds: ["ATPBC005", "ATSPB"] },
  ];
  private bitrateIdx = 0;
  private async setBitrate(i: number) {
    for (const c of ElmCanSource.RATES[i].cmds) await this.cmd(c);
  }

  /** Écoute pendant `ms` avec le filtre donné ; renvoie le nombre de trames reçues. */
  private async monitor(filter: number | null, mask: number, ms: number): Promise<number> {
    if (filter === null) await this.cmd("ATCRA");
    else {
      await this.cmd("ATCF " + hex3(filter));
      await this.cmd("ATCM " + hex3(mask));
    }
    this.rx = "";
    let got = 0;
    let buf = "";
    let stopTimer: NodeJS.Timeout | null = null;
    let guard: NodeJS.Timeout | null = null;
    let ended = false;
    const done = new Promise<void>((resolve) => {
      const mine = (out: string) => {
        ended = true;
        buf += out;
        resolve();
      };
      this.waiter = mine;
      // n'importe quel caractère arrête l'écoute ; l'ELM répond par « > » (sauf s'il a déjà débordé)
      stopTimer = setTimeout(() => {
        if (!ended) this.link?.write("\r");
      }, ms);
      guard = setTimeout(() => {
        if (!ended && this.waiter === mine) {
          this.waiter = null;
          ended = true;
          resolve();
        }
      }, ms + 1500);
    });
    const handler = () => {
      // lignes complètes reçues jusqu'ici
      const parts = (buf + this.rx).split(/[\r\n]+/);
      this.rx = "";
      buf = parts.pop() ?? "";
      for (const l of parts) got += this.line(l);
    };
    const iv = setInterval(handler, 20);
    this.link?.write("ATMA\r");
    await done;
    clearInterval(iv);
    if (stopTimer) clearTimeout(stopTimer);
    if (guard) clearTimeout(guard);
    for (const l of buf.split(/[\r\n]+/)) got += this.line(l);
    return got;
  }

  /** Ce que l'ELM a dit d'autre que des trames (pour comprendre un bus muet). */
  private other: string[] = [];
  private line(l: string): number {
    const s = l.replace(/\s+/g, "").toUpperCase();
    if (!s) return 0;
    if (!/^[0-9A-F]+$/.test(s) && this.other.length < 6) this.other.push(l.trim().slice(0, 40));
    if (/BUFFERFULL/.test(s)) {
      this.overflow++;
      return 0;
    }
    if (!/^[0-9A-F]{3}([0-9A-F]{2}){0,8}$/.test(s)) return 0;
    const id = parseInt(s.slice(0, 3), 16);
    const bytes: number[] = [];
    for (let i = 3; i + 1 < s.length; i += 2) bytes.push(parseInt(s.slice(i, i + 2), 16));
    this.raw?.write(`${Date.now()} ${hex3(id)}#${s.slice(3)}\n`);
    const e = this.table.get(id);
    const dec = DECODERS[id];
    const full = bytes.concat(Array(Math.max(0, 8 - bytes.length)).fill(0));
    const decoded = dec ? dec(full) : null;
    if (e) {
      for (let i = 0; i < bytes.length; i++) if (bytes[i] !== e.bytes[i]) e.changed |= 1 << i;
      e.bytes = bytes;
      e.count++;
      e.at = Date.now();
      e.decoded = decoded;
    } else this.table.set(id, { id, bytes, count: 1, at: Date.now(), changed: 0, decoded });
    if (decoded) this.d.store.set(decoded);
    if (id === 0x280) {
      this.rate.tick();
      this.status.hz = this.rate.hz;
    }
    this.lines++;
    return 1;
  }

  private async loop() {
    let fails = 0;
    while (this.running) {
      try {
        await this.init();
        fails = 0;
        // découverte : tout écouter un instant (l'ELM déborde vite, c'est normal)
        this.setStatus("connecting", `${this.portPath} · écoute du bus CAN…`);
        let n = 0;
        const said: string[] = [];
        for (let r = 0; r < ElmCanSource.RATES.length && !n; r++) {
          const ri = (this.bitrateIdx + r) % ElmCanSource.RATES.length;
          await this.setBitrate(ri);
          this.other = [];
          for (let i = 0; i < 2 && !n; i++) n += await this.monitor(null, 0, 700);
          jlog("cables.log", `CAN · écoute à ${ElmCanSource.RATES[ri].name} : ${n} trame(s)${this.other.length ? ", l'ELM327 répond « " + this.other.join(" | ") + " »" : ""}`);
          if (n) this.bitrateIdx = ri;
          else said.push(`${ElmCanSource.RATES[ri].name} : ${this.other.join(" ") || "rien"}`);
        }
        if (!n) throw new Error(`aucune trame CAN (${said.join(" ; ")}). L'ELM327 doit être relié aux fils CAN-H / CAN-L (orange/noir et orange/marron), pas à la prise OBD, contact mis`);
        this.setStatus("ok", `${this.portPath} · ${ElmCanSource.RATES[this.bitrateIdx].name} · ${this.table.size} identifiants`);
        // tour de rôle : régime un tour sur deux, puis chaque identifiant décodé, puis un inconnu
        let k = 0;
        let silent = 0;
        while (this.running) {
          const known = Object.keys(DECODERS).map(Number).filter((id) => id !== 0x280 && (this.table.has(id) || k % 50 === 0));
          const unknown = [...this.table.keys()].filter((id) => !DECODERS[id]);
          const slots: [number | null, number, number][] = [];
          for (const id of known) slots.push([0x280, 0x7f0, 250], [id, 0x7ff, 180]); // 0x280 + 0x288 ensemble
          if (unknown.length) slots.push([unknown[k % unknown.length], 0x7ff, 150]);
          if (k % 40 === 0) slots.push([null, 0, 400]); // nouveaux identifiants ?
          if (!slots.length) slots.push([0x280, 0x7f0, 300]);
          k++;
          let got = 0;
          for (const [f, m, ms] of slots) {
            if (!this.running) break;
            got += await this.monitor(f, m, ms);
          }
          silent = got ? 0 : silent + 1;
          if (silent >= 3) throw new Error("plus de trames CAN (contact coupé ?)");
          this.setStatus("ok", `${this.portPath} · ${ElmCanSource.RATES[this.bitrateIdx].name} · ${this.table.size} identifiants${this.overflow ? ` · ${this.overflow} débordements` : ""}`);
        }
      } catch (e: any) {
        fails++;
        this.setStatus("error", String(e?.message || e));
        jlog("cables.log", "CAN · ELM327 : " + (e?.message || e));
        await this.closeLink();
        await sleep(Math.min(15000, 3000 * fails));
      }
    }
  }
}
