// Source « kkl » : Nova lit elle-même le calculateur moteur ME7.5 par le câble KKL
// (groupes de mesure 001 à 118), sans logiciel externe. Le diagnostic des autres calculateurs
// passe par le même câble et met la lecture en pause le temps nécessaire.
import type { VagManager } from "../vag/manager.js";
import type { Dtc, Source, SourceDeps, SourceStatus } from "./types.js";

export class VagSource implements Source {
  status: SourceStatus = { name: "KKL", state: "off", detail: "", hz: 0 };
  readonly hasWheelSpeeds = false;
  private timer: NodeJS.Timeout | null = null;
  private last = 0;
  private count = 0;

  constructor(private d: SourceDeps, private vag: VagManager) {}

  async start() {
    this.vag.startLive();
    this.status.state = "connecting";
    this.status.detail = "réveil du calculateur moteur…";
    this.timer = setInterval(() => {
      const st = this.vag.st;
      const prev = `${this.status.state}|${this.status.detail}`;
      if (st.live) {
        this.status.state = "ok";
        this.status.detail = `${st.port} · ${st.protocol || "ligne K"}`;
      } else if (st.busy) {
        this.status.state = "ok";
        this.status.detail = `${st.port} · diagnostic en cours`;
      } else if (st.liveError) {
        this.status.state = "error";
        this.status.detail = st.liveError;
      }
      const n = this.d.store.stamp.rpm ?? 0;
      if (n !== this.last) {
        this.last = n;
        this.count++;
      }
      if (prev !== `${this.status.state}|${this.status.detail}`) this.d.onStatus();
    }, 500);
    setInterval(() => {
      this.status.hz = this.count / 2;
      this.count = 0;
    }, 2000);
  }

  async stop() {
    this.vag.stopLive();
    if (this.timer) clearInterval(this.timer);
    this.status.state = "off";
  }

  async readDtc(): Promise<Dtc[]> {
    const f = await this.vag.faults(0x01, true); // même calculateur que la lecture en direct : pas de pause de 20 s
    return f.map((x) => ({ code: x.obd || x.vag, text: `${x.text}${x.elaboration ? " : " + x.elaboration : ""}` }));
  }

  async clearDtc() {
    await this.vag.clear(0x01);
  }
}
