import type { SignalStore } from "../signals.js";
import type { CarFiles } from "../config.js";

export type SourceState = "off" | "connecting" | "ok" | "error";

export interface SourceStatus {
  name: string; // affiché : « Simulateur », « ELM327 », « KKL · ME7Logger », « CAN »
  state: SourceState;
  detail: string; // port, protocole, dernière erreur…
  hz: number; // mesures complètes par seconde
}

export interface Dtc {
  code: string;
  text: string;
}

export interface Source {
  status: SourceStatus;
  start(): Promise<void>;
  stop(): Promise<void>;
  /** Codes défaut (si la source sait les lire). */
  readDtc?(): Promise<Dtc[]>;
  clearDtc?(): Promise<void>;
  /** Vitesses des 4 roues disponibles (indispensable au démarrage à distance). */
  readonly hasWheelSpeeds: boolean;
}

export interface SourceDeps {
  store: SignalStore;
  files: CarFiles;
  log: (t: string) => void;
  onStatus: () => void;
}

/** Compteur de fréquence glissant. */
export class Rate {
  private times: number[] = [];
  tick() {
    const now = Date.now();
    this.times.push(now);
    while (this.times.length && now - this.times[0] > 2000) this.times.shift();
  }
  get hz() {
    return this.times.length / 2;
  }
}

// Libellés des codes défaut les plus courants sur le 1.8T (le reste : « voir VCDS »).
export const DTC_TEXT: Record<string, string> = {
  P0101: "Débitmètre d'air : signal incohérent",
  P0102: "Débitmètre d'air : signal trop faible",
  P0106: "Capteur de pression d'admission",
  P0130: "Sonde lambda amont : circuit",
  P0141: "Sonde lambda aval : chauffage",
  P0171: "Mélange trop pauvre (prise d'air, débitmètre, injecteurs)",
  P0172: "Mélange trop riche",
  P0234: "Suralimentation trop élevée",
  P0299: "Suralimentation trop faible (fuite, wastegate, N75)",
  P0300: "Ratés d'allumage détectés",
  P0301: "Ratés cylindre 1",
  P0302: "Ratés cylindre 2",
  P0303: "Ratés cylindre 3",
  P0304: "Ratés cylindre 4",
  P0325: "Capteur de cliquetis 1",
  P0330: "Capteur de cliquetis 2",
  P0340: "Capteur d'arbre à cames",
  P0420: "Catalyseur : efficacité insuffisante",
  P0441: "Purge canister",
  P0505: "Régulation de ralenti",
  P0507: "Ralenti trop haut (prise d'air)",
  P0511: "Régulation de ralenti",
  P1296: "Thermostat / sonde de température d'eau",
  P1545: "Papillon motorisé : contrôle de position",
  P1555: "Suralimentation : limite dépassée",
  P1556: "Suralimentation : écart de régulation négatif",
  P1557: "Suralimentation : écart de régulation positif",
  P1580: "Papillon motorisé : actionneur",
};
