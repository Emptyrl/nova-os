// Nova Auto : le cerveau de Nova (Claude Agent SDK, mémoire, équipe, voix locale) branché sur l'Audi TT.
// Un seul programme : il lit la voiture, enregistre, surveille, et sert les écrans (http://localhost:47823).
//   node dist/server.js --source sim            voiture virtuelle
//   node dist/server.js --source elm327 --port COM3
//   node dist/server.js --source can+kkl        sur le Raspberry Pi
import http from "node:http";
import { WebSocketServer, WebSocket } from "ws";
import { promises as fs, mkdirSync, createReadStream, existsSync, statSync, readFileSync } from "node:fs";
import path from "node:path";
import os from "node:os";
import dns from "node:dns/promises";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { AsyncLocalStorage } from "node:async_hooks";
import { query, tool, createSdkMcpServer, type CanUseTool } from "@anthropic-ai/claude-agent-sdk";
import { runDirect, cpuRunsClaudeCode, checkSchemas, type DirectTool } from "./brain/direct.js";
import { z } from "zod";
import { Store, DATA_DIR } from "./brain/store.js";
import { decide, summarizeTool, isSafeCommand, isDangerousCommand, type SafetyLevel } from "./brain/safety.js";
import { type Sensitivity, wakeAvailable } from "./brain/wake.js";
import { AudioSession, LocalModels } from "./brain/audio.js";
import { Workspace, workspaceTools, mediaKey, WORKSPACE_TOOL_NAMES, browserTools, BROWSER_TOOL_NAMES, openUrl } from "./brain/ui.js";
import { Browsers, type Channel } from "./brain/browser.js";
import { MusicPlayer } from "./brain/music.js";
import { LocalVoices } from "./brain/voices.js";
import { Team } from "./brain/team.js";
import { Costs, formatUsd } from "./brain/costs.js";
import { streamMessage, TagSplitter, fastSystem, restitutionSystem, narrationSystem, type FastOptions, type Msg } from "./brain/fast.js";
import { expertTools, expertAvailable, EXPERT_TOOL_NAMES, type ExpertConfig } from "./brain/experts.js";
import { Car } from "./car/index.js";
import { carTools, CAR_TOOL_NAMES, SCREENS } from "./car/tools.js";
import { MODES } from "./car/config.js";
import { SystemInfo } from "./car/system.js";
import { jlog, listLogs, tailLog, clearLogs, LOG_DIR } from "./car/journaux.js";
import { Moniteur, fullReport, snapshot } from "./car/moniteur.js";
import { Updater } from "./car/maj.js";
import { OsUpdater } from "./car/majos.js";
import { Fichiers } from "./car/fichiers.js";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let APP_VERSION = "?";
try {
  APP_VERSION = JSON.parse(readFileSync(path.join(APP_ROOT, "package.json"), "utf8")).version;
} catch {}
const WEB_DIR = path.join(APP_ROOT, "web");

// ---------- arguments ----------
const argv = process.argv.slice(2);
const arg = (name: string) => {
  const i = argv.indexOf("--" + name);
  return i >= 0 ? argv[i + 1] : undefined;
};
const PORT = Number(arg("http-port") || process.env.NOVA_PORT || 47823);
// 127.0.0.1 : seul l'écran de la voiture se connecte. 0.0.0.0 : une tablette ou un téléphone aussi.
const HOST = arg("host") || process.env.NOVA_HOST || "127.0.0.1";
const TOKEN = process.env.NOVA_TOKEN || "";

try {
  mkdirSync(DATA_DIR, { recursive: true });
  process.chdir(DATA_DIR);
} catch {}

// ---------- journal ----------
// tout va dans journaux/nova.log (Réglages → Journaux)
function log(text: string) {
  jlog("nova.log", text);
  // dans la session Nova OS la console part dans nova-console.log : on n'y recopie pas le journal
  if (process.stderr.isTTY) console.error(`[${new Date().toISOString()}] ${text}`);
}
process.on("uncaughtException", (e) => {
  log("PLANTAGE évité (exception) : " + (e?.stack || e));
  jlog("systeme.log", "Exception dans Nova : " + (e?.stack || e));
});
process.on("unhandledRejection", (e: any) => log("Promesse rejetée : " + (e?.stack || e)));
process.on("exit", (code) => jlog("systeme.log", `Nova s'arrête (code ${code})`));
for (const sig of ["SIGINT", "SIGHUP"] as const) process.on(sig, () => {
  jlog("systeme.log", "Nova reçoit " + sig);
  process.exit(0);
});
const moniteur = new Moniteur((t) => log(t));
const T_START = Date.now();
const phase = (name: string) => jlog("demarrage.log", `  ${name} : ${((Date.now() - T_START) / 1000).toFixed(2)} s`);

const store = new Store();

// ---------- réglages du cerveau (config.json) ----------
interface Config {
  anthropicApiKey: string;
  openaiApiKey: string;
  geminiApiKey: string;
  model: string;
  imageModel: string;
  gptModel: string;
  geminiModel: string;
  mistralApiKey: string;
  transcriptionProvider: "openai" | "mistral";
  mistralTranscriptionModel: string;
  transcriptionModel: string;
  ttsModel: string;
  safety: SafetyLevel;
  assistantName: string;
  wakeVariants: string[];
  browserChannel: Channel;
  browserVisible: boolean;
  fastEnabled: boolean; // double cerveau : voix rapide + cerveau réfléchi
  fastModel: string;
  updateRepo: string;
  updateBranch: string;
  githubToken: string;
}
const CONFIG_FILE = path.join(DATA_DIR, "config.json");
const ENV_KEY_AT_START = process.env.ANTHROPIC_API_KEY || "";
const DEFAULT_CONFIG: Config = {
  anthropicApiKey: "",
  openaiApiKey: "",
  geminiApiKey: "",
  model: "",
  imageModel: "gpt-image-2.5-flare",
  gptModel: "gpt-6-astra",
  geminiModel: "gemini-4-argon",
  mistralApiKey: "",
  transcriptionProvider: "openai",
  mistralTranscriptionModel: "voxtral-mini-latest",
  transcriptionModel: "gpt-4o-transcribe",
  ttsModel: "gpt-4o-mini-tts",
  safety: "normal",
  assistantName: "Nova",
  wakeVariants: [],
  browserChannel: process.platform === "win32" ? "msedge" : "chromium",
  browserVisible: false,
  fastEnabled: true,
  fastModel: "claude-haiku-5-5",
  updateRepo: "Emptyrl/nova-os",
  updateBranch: "main",
  githubToken: "",
};
let config: Config = { ...DEFAULT_CONFIG };

async function loadConfig() {
  try {
    config = { ...DEFAULT_CONFIG, ...JSON.parse(await fs.readFile(CONFIG_FILE, "utf8")) };
  } catch {
    config = { ...DEFAULT_CONFIG };
  }
  await saveConfig();
  applyKeys();
}
async function saveConfig() {
  await fs.writeFile(CONFIG_FILE, JSON.stringify(config, null, 2), "utf8");
}
function applyKeys() {
  if (config.anthropicApiKey) process.env.ANTHROPIC_API_KEY = config.anthropicApiKey;
  else if (ENV_KEY_AT_START) process.env.ANTHROPIC_API_KEY = ENV_KEY_AT_START;
  else delete process.env.ANTHROPIC_API_KEY;
}
const mask = (k: string) => (k ? "••••" + k.slice(-4) : "");
function publicConfig() {
  return {
    type: "config",
    anthropicKey: mask(config.anthropicApiKey),
    openaiKey: mask(config.openaiApiKey),
    geminiKey: mask(config.geminiApiKey),
    mistralKey: mask(config.mistralApiKey),
    model: config.model,
    transcriptionProvider: config.transcriptionProvider,
    safety: config.safety,
    assistantName: config.assistantName,
    browserChannel: config.browserChannel,
    browserVisible: config.browserVisible,
    fastEnabled: config.fastEnabled,
    fastModel: config.fastModel,
    updateRepo: config.updateRepo,
    githubToken: mask(config.githubToken),
    fastReady: !!(config.fastEnabled && (config.anthropicApiKey || ENV_KEY_AT_START)),
    dataDir: DATA_DIR,
    car: car.files.config,
  };
}
const EDITABLE: (keyof Config)[] = ["anthropicApiKey", "openaiApiKey", "geminiApiKey", "mistralApiKey", "model", "transcriptionProvider", "safety", "assistantName", "wakeVariants", "browserChannel", "browserVisible", "fastEnabled", "fastModel", "updateRepo", "updateBranch", "githubToken"];
async function updateConfig(patch: Record<string, unknown>) {
  for (const key of EDITABLE) {
    if (!(key in patch)) continue;
    const v = patch[key];
    if (key === "safety") {
      if (v === "strict" || v === "normal" || v === "free") config.safety = v;
    } else if (key === "browserChannel") {
      if ((v === "msedge" || v === "chrome" || v === "chromium") && v !== config.browserChannel) {
        config.browserChannel = v;
        void browsers.close();
      }
    } else if (key === "browserVisible") {
      if (!!v !== config.browserVisible) {
        config.browserVisible = !!v;
        void browsers.close();
      }
    } else if (key === "fastEnabled") {
      config.fastEnabled = !!v;
    } else if (key === "transcriptionProvider") {
      if (v === "openai" || v === "mistral") config.transcriptionProvider = v;
    } else if (key === "wakeVariants") {
      if (Array.isArray(v)) config.wakeVariants = v.map(String).map((x) => x.trim()).filter(Boolean).slice(0, 20);
    } else if (key === "assistantName") {
      const name = String(v).trim().slice(0, 30);
      if (name && name !== config.assistantName) {
        config.assistantName = name;
        config.wakeVariants = [];
      }
    } else if (typeof v === "string") (config as any)[key] = v.trim();
  }
  await saveConfig();
  applyKeys();
}

// ---------- voix cloud (optionnelle) ----------
async function synthesize(text: string, voice: string, instructions: string): Promise<string> {
  const key = config.openaiApiKey || process.env.OPENAI_API_KEY;
  if (!key) throw new Error("Pas de clé OpenAI : la voix locale est utilisée.");
  const res = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: { Authorization: "Bearer " + key, "Content-Type": "application/json" },
    body: JSON.stringify({ model: config.ttsModel, voice: voice || "alloy", input: text.slice(0, 4000), response_format: "mp3", ...(instructions ? { instructions } : {}) }),
  });
  if (!res.ok) throw new Error(`Voix OpenAI impossible (${res.status})`);
  return Buffer.from(await res.arrayBuffer()).toString("base64");
}

// ---------- diffusion vers les écrans ----------
const clients = new Set<WebSocket>();
function send(msg: Record<string, unknown>) {
  const data = JSON.stringify(msg);
  for (const c of clients) if (c.readyState === WebSocket.OPEN && c.bufferedAmount < 2_000_000) c.send(data);
}
const sendSnapshot = () => send({ type: "snapshot", ...store.snapshot(), busy });
const workspace = new Workspace(send);
const browsers = new Browsers(() => ({ channel: config.browserChannel, visible: config.browserVisible, dataDir: DATA_DIR }));
const music = new MusicPlayer(browsers, (st) => send({ type: "music", state: st }));
const voices = new LocalVoices(DATA_DIR, () => send(voicesMessage()), (t) => log(t));
const voicesMessage = () => ({ type: "voices", available: voices.available, items: voices.list() });
const models = new LocalModels(DATA_DIR, () => send(modelStatus()));
const modelStatus = () => ({ type: "model", models: models.info, wake: wakeAvailable() });

// ---------- la voiture ----------
let currentScreen = "veille";
const car = new Car({
  dataDir: DATA_DIR,
  appRoot: APP_ROOT,
  log,
  send,
  say: (text, from) => send({ type: "say", text, from }),
  ask: (prompt) => {
    send({ type: "user", text: prompt, from: "nova" });
    void ask(prompt);
  },
  screen: (name) => {
    currentScreen = name;
    send({ type: "screen", name });
  },
});

// ---------- le PC : batterie, Wi-Fi, Bluetooth, écran ----------
let sysTimer: NodeJS.Timeout | null = null;
const sys = new SystemInfo(DATA_DIR, log, () => {
  if (sysTimer) return;
  sysTimer = setTimeout(() => {
    sysTimer = null;
    send({ type: "sys", ...sys.st });
  }, 250);
});
void sys.start().catch((e) => log("Système : " + (e?.message || e)));
// mises à jour de Nova (sans refaire l'image Nova OS)
const updater = new Updater(DATA_DIR, APP_VERSION, () => ({ repo: config.updateRepo, token: config.githubToken, branch: config.updateBranch }), () => send({ type: "maj", ...updater.st }));
// fichiers entre le PC et le téléphone (KDE Connect)
const fichiers = new Fichiers(
  DATA_DIR,
  () => send({ type: "fichiers", ...fichiers.st }),
  (name) => send({ type: "toast", message: `Fichier reçu du téléphone : ${name} (Réglages → Fichiers)` }),
);
void fichiers.start().catch((e) => log("Fichiers : " + (e?.message || e)));
// mises à jour du système Nova OS installé sur disque (deux emplacements, retour automatique)
const osUpdater = new OsUpdater(() => send({ type: "majos", ...osUpdater.st }));
void osUpdater.refresh();
// une recherche par démarrage, 90 s après (le temps que le Wi-Fi se connecte), seulement s'il y a Internet
setTimeout(() => {
  if (sys.st.online) void updater.check();
}, 90000);
// le système : une fois, 4 min après le démarrage (après la validation d'une nouvelle version), sur disque
setTimeout(() => {
  void osUpdater.refresh().then(() => {
    if (osUpdater.st.mode === "disque" && sys.st.online && osUpdater.st.status === "idle") void osUpdater.check();
  });
}, 240000);
// itinéraire affiché sur l'écran Média (Google Maps intégré)
let mapsRoute: { dest: string; from: string } | null = null;

// ---------- autorisations ----------
const pendingPermissions = new Map<string, (allow: boolean) => void>();
interface AskExtra {
  title?: string;
  detail?: string;
  note?: string;
  level?: "normal" | "danger";
}
const askingAgent = new AsyncLocalStorage<string>();
function askUser(toolName: string, summary: string, signal: AbortSignal | null, extra: AskExtra = {}): Promise<boolean> {
  const who = askingAgent.getStore();
  if (who) summary = `${who} : ${summary}`;
  return new Promise((resolve) => {
    const id = randomUUID();
    const finish = (ok: boolean) => {
      pendingPermissions.delete(id);
      clearTimeout(timer);
      send({ type: "permission.resolved", id, allow: ok });
      resolve(ok);
    };
    const timer = setTimeout(() => finish(false), 3 * 60 * 1000);
    signal?.addEventListener("abort", () => finish(false), { once: true });
    pendingPermissions.set(id, finish);
    send({ type: "permission.request", id, tool: toolName, summary, ...extra });
  });
}

let turnId = 0;
let accountApprovedTurn = -1;
let shellApprovedTurn = -1;
const allow = (input: Record<string, unknown>) => ({ behavior: "allow" as const, updatedInput: input });
const refuse = (message: string) => ({ behavior: "deny" as const, message });
const REFUSED = "Joan a refusé cette action. Propose une autre approche.";

const team = new Team(DATA_DIR);
const costs = new Costs(DATA_DIR);
const agentNames = new Map<string, string>();

function expertConfig(): ExpertConfig {
  return {
    openaiKey: config.openaiApiKey || process.env.OPENAI_API_KEY || "",
    geminiKey: config.geminiApiKey || process.env.GEMINI_API_KEY || "",
    imageModel: config.imageModel,
    gptModel: config.gptModel,
    geminiModel: config.geminiModel,
  };
}
const MEDIA_TOOLS = ["create_3d_model", "create_video"]; // modules de l'app PC, absents dans la voiture
const toolAvailable = (name: string) => {
  if (!name.startsWith("mcp__jarvis__")) return true;
  const short = name.slice("mcp__jarvis__".length);
  if (MEDIA_TOOLS.includes(short)) return false;
  return expertAvailable(expertConfig(), short);
};

const canUseTool: CanUseTool = async (toolName, input, opts) => {
  const who = opts.agentID ? agentNames.get(opts.agentID) || "Un employé" : "";
  return who ? askingAgent.run(who, () => decideTool(toolName, input, opts)) : decideTool(toolName, input, opts);
};

const SHELL_TOOLS = ["Bash", "PowerShell"];
const decideTool: CanUseTool = async (toolName, input, { signal }) => {
  if (toolName === "Agent" || toolName === "Task") {
    const type = String(input.subagent_type ?? "");
    if (type && team.get(type) && !team.get(type)?.enabled) return refuse(`L'employé ${type} est désactivé.`);
    return allow({ ...input, run_in_background: false });
  }
  if (toolName.startsWith("mcp__jarvis__web_")) {
    if (input.profile !== "account" || accountApprovedTurn === turnId) return allow(input);
    const ok = await askUser(toolName, "Utiliser ton navigateur connecté à tes comptes : " + summarizeTool(toolName, input), signal);
    if (ok) accountApprovedTurn = turnId;
    return ok ? allow(input) : refuse("Joan refuse l'usage de son navigateur connecté. Utilise le profil clean.");
  }
  const cwd = path.join(DATA_DIR, "general");
  const workDirs = [cwd, DATA_DIR];
  const level: SafetyLevel = config.safety || "normal";
  if (SHELL_TOOLS.includes(toolName)) {
    const command = String(input.command ?? "");
    const what = String(input.description ?? "").trim();
    if (isDangerousCommand(command)) {
      const ok = await askUser(toolName, command, signal, { title: "Action sensible", detail: what || undefined, note: "Suppression, envoi en ligne ou installation : l'accord ne vaut que pour cette commande.", level: "danger" });
      return ok ? allow(input) : refuse(REFUSED);
    }
    if (level === "free" || isSafeCommand(command) || shellApprovedTurn === turnId) return allow(input);
    const ok = await askUser(toolName, command, signal, { title: "Nova veut utiliser le terminal", detail: what ? "Ce qu'elle va faire : " + what : undefined, note: "Accord valable pour cette demande." });
    if (ok) shellApprovedTurn = turnId;
    return ok ? allow(input) : refuse(REFUSED);
  }
  if (decide(level, toolName, input, workDirs) === "allow") return allow(input);
  const ok = await askUser(toolName, summarizeTool(toolName, input), signal);
  return ok ? allow(input) : refuse(REFUSED);
};

// ---------- outils de Nova ----------
const text = (t: string) => ({ content: [{ type: "text" as const, text: t }] });
const novaToolList = [
    ...workspaceTools(workspace),
    ...browserTools(browsers, music, workspace),
    ...expertTools({ config: expertConfig, workDir: () => path.join(DATA_DIR, "general"), workspace }),
    ...carTools(car, {
      screen: (s) => {
        currentScreen = s;
        send({ type: "screen", name: s });
      },
      confirm: (title, summary) => askUser("voiture", summary, null, { title, level: "danger" }),
    }),
    tool(
      "nova_logs",
      "Lit les journaux de Nova pour comprendre un problème (lenteur, plantage, câble non vu, démarrage lent). Journaux : nova.log, demarrage.log, ecran.log, systeme.log, cables.log, session.log.",
      { name: z.enum(["nova.log", "demarrage.log", "ecran.log", "systeme.log", "cables.log", "session.log"]), lines: z.number().min(10).max(800).optional() },
      async ({ name, lines }) => text(await tailLog(name, lines ?? 200)),
    ),
    tool("pc_status", "État du PC de Nova : batterie, Wi-Fi, Bluetooth, téléphone connecté, écran.", {}, async () =>
      text(JSON.stringify({ batterie: sys.st.battery, wifi: sys.st.wifi, internet: sys.st.online, bluetooth: { allume: sys.st.bt.powered, appareils: sys.st.bt.devices }, kdeConnect: sys.st.kde.devices, ecran: sys.st.display }, null, 1)),
    ),
    tool(
      "navigate_to",
      "Affiche un itinéraire Google Maps vers une destination sur l'écran Média de Nova (adresse, ville, lieu). « from » facultatif : point de départ, sinon la carte part de la destination seule. Pour le guidage vocal en roulant, propose plutôt Waze/Maps du téléphone (bouton de l'écran Média).",
      { destination: z.string(), from: z.string().optional() },
      async ({ destination, from }) => {
        mapsRoute = { dest: destination, from: from || "" };
        send({ type: "maps.route", ...mapsRoute });
        currentScreen = "media";
        send({ type: "screen", name: "media" });
        return text("Itinéraire affiché vers " + destination);
      },
    ),
    tool(
      "remember",
      "Mémorise durablement un fait sur Joan ou sur sa voiture (préférence, habitude, réglage, entretien fait…). À appeler dès que tu apprends quelque chose qui servira plus tard.",
      { category: z.string().describe("Catégorie courte : Voiture, Entretien, Conduite, Perso…"), fact: z.string() },
      async ({ category, fact }) => {
        await store.remember(category, fact);
        sendSnapshot();
        return text("Mémorisé.");
      },
    ),
];
const novaTools = createSdkMcpServer({ name: "jarvis", version: "1.0.0", alwaysLoad: true, tools: novaToolList });
{
  const bad = checkSchemas(novaToolList as unknown as DirectTool[]);
  if (bad.length) log("Cerveau direct : outils non convertibles : " + bad.join(", "));
  else if (process.env.NOVA_SCHEMA_CHECK) log(`Cerveau direct : ${novaToolList.length} outils convertis`);
}
const NOVA_TOOLS = [...EXPERT_TOOL_NAMES, "remember", "nova_logs", "pc_status", "navigate_to", ...WORKSPACE_TOOL_NAMES, ...BROWSER_TOOL_NAMES, ...CAR_TOOL_NAMES.filter((n) => n !== "clear_dtc")].map((n) => "mcp__jarvis__" + n);

function buildPrompt(): string {
  const now = new Date().toLocaleString("fr-FR", { dateStyle: "full", timeStyle: "short" });
  const memory = store.memory.length ? store.memory.map((m) => `- [${m.category}] ${m.text}`).join("\n") : "(rien pour l'instant)";
  const c = car.files.config;
  return `
# Qui tu es
Tu t'appelles ${config.assistantName}. Tu es l'intelligence embarquée de l'Audi TT 8N 225 quattro de ${c.driverName}
(2003, moteur 1.8T BAM, calculateur ME7.5, boîte 6 vitesses, convertie à l'E85). Tu tournes sur un Raspberry Pi
caché derrière l'autoradio (ou sur le PC portable de ${c.driverName} pendant le développement), avec ton propre écran.
Tu es un copilote, comme KITT : posée, précise, chaleureuse, un peu d'humour. ${c.driverName} est apprenti mécanicien :
tu peux parler technique (calage, richesse, N75, débitmètre, Haldex…), sans jargon inutile.
Tu parles français. Tes réponses sont dites à voix haute pendant que ${c.driverName} conduit :
phrases courtes, deux ou trois phrases en général, jamais de tableau, de liste ni de markdown à voix haute.
Nous sommes le ${now}.

# La voiture en ce moment
${car.describe()}
Écran affiché : ${currentScreen}.

# Ce que tu sais de ${c.driverName} et de sa voiture
${memory}
Dès que tu apprends quelque chose de durable (entretien fait, réglage, préférence), appelle remember.

# Tes outils voiture
car_status pour les mesures précises avant de répondre sur l'état de la voiture (ne devine jamais une valeur).
car_history pour une tendance. show_screen pour afficher un écran (${SCREENS.join(", ")}).
log_start / log_stop / log_list / log_analyze pour les enregistrements ; les CSV sont dans ${car.logDir}
(séparateur « ; », virgule décimale) : tu peux les lire avec Read pour une analyse fine.
diagnostic_start lance le diagnostic guidé (à l'arrêt seulement). read_dtc / clear_dtc pour les codes défaut.
shift_points et learning_status pour les passages de rapport et ce que tu as appris de la voiture.
led_logo pour le logo lumineux à l'avant, fis_text pour l'écran du combiné (8 caractères par ligne, sans accent).
show_alert pour une alerte plein écran. set_fuel quand ${c.driverName} a fait le plein. set_drive_mode pour Normal / Sport / Attack.
remote_start / remote_stop : démarrage à distance, SEULEMENT si ${c.driverName} le demande clairement.
Diagnostic complet par le câble KKL (comme VCDS) : connection_test pour vérifier la liaison, vag_scan pour tous les
calculateurs, vag_module pour l'identification et les défauts d'un calculateur, vag_group pour un groupe de mesure,
vag_read_all pour tout lire. Les rapports CSV sont dans ${path.join(DATA_DIR, "diagnostics")}.

# Sécurité au volant
Si la voiture roule (${car.store?.moving ? "c'est le cas maintenant" : "pas en ce moment"}), sois brève, ne propose jamais de regarder
une vidéo ou de lire un long texte, et ne lance pas le diagnostic. Pour une alerte grave, dis d'abord quoi faire.
Tu ne pilotes jamais l'accélérateur, les freins ni la direction : tu conseilles.

${team.describeForBoss({ crossCheck: toolAvailable("mcp__jarvis__expert_opinion") })}
L'employé « mecanicien » (Ingénieur méca) connaît la TT : confie-lui les analyses de logs poussées et les questions de mécanique.

# Ta voix
Ce que tu écris est lu à voix haute, phrase par phrase. Commence par une phrase courte qui répond.
Ne lis jamais de chemin, de code ni de longues listes : mets-les dans une fenêtre (show_window).
Si tu attends une réponse, termine par une question : le micro se rouvre tout seul.

# Musique et navigation
music_play lance YouTube Music (4G) en arrière-plan, music_control pour pause/suivant/volume.
Navigation : navigate_to affiche un itinéraire Google Maps sur l'écran Média (il faut Internet, par le partage de connexion du téléphone). Waze / Maps du téléphone peuvent aussi s'afficher sur l'écran Média (câble USB).
PC : ${sys.st.battery.present ? "batterie " + sys.st.battery.pct + " %" + (sys.st.battery.charging ? " (en charge)" : "") : "sur secteur"}, ${sys.st.online ? "Internet OK" + (sys.st.wifi.ssid ? " via " + sys.st.wifi.ssid : "") : "pas d'Internet"}. pc_status pour le détail.
Fenêtres ouvertes : ${workspace.describe()}
`.trim();
}

// ---------- cerveau réfléchi : Claude Code, ou l'API directe si ce PC ne peut pas le faire tourner ----------
// Le programme Claude Code demande SSE4.2 / POPCNT : un Core 2 Duo (Dell M4400) le fait planter (SIGILL).
let directMode = process.env.NOVA_DEEP === "api" || (process.env.NOVA_DEEP !== "claude-code" && !cpuRunsClaudeCode());
if (directMode) log("Cerveau réfléchi : API Anthropic directe (processeur sans SSE4.2/POPCNT, Claude Code ne peut pas y tourner)");
/** échanges du mode direct (le mode Claude Code garde les siens dans sa session) */
const directHistory: { role: "user" | "assistant"; content: string }[] = [];
const DIRECT_NOTE = `

# Mode de réflexion
Tu réfléchis ici par l'API directe : tu as tes outils (voiture, diagnostic, mémoire, écrans…) et web_search
pour chercher sur Internet, mais pas Read/Grep/Bash ni les employés. Si une demande en a besoin, dis-le simplement.`;

// ---------- un tour de conversation ----------
let busy = false;
let currentAbort: AbortController | null = null;

interface TurnOptions {
  /** Appelé par le double cerveau : pas de voix directe, pas de « done », l'appelant gère tout. */
  relay?: { abort: AbortController; onTool: (summary: string) => void };
}

/** Un tour du cerveau réfléchi (Agent SDK, outils, équipe). */
async function runTurn(prompt: string, opts: TurnOptions = {}): Promise<{ ok: boolean; text: string }> {
  const relay = opts.relay;
  if (!relay) {
    if (busy) {
      send({ type: "error", message: "Je suis encore sur la demande précédente." });
      return { ok: false, text: "" };
    }
    busy = true;
    turnId++;
    currentAbort = new AbortController();
    send({ type: "state", state: "think" });
    log("Demande : " + prompt.slice(0, 200));
  }
  const abort = relay ? relay.abort : currentAbort!;
  const cwd = path.join(DATA_DIR, "general");
  await fs.mkdir(cwd, { recursive: true });
  const resume = store.state.generalSessionId;
  let finalText = "";
  let sessionId = resume ?? "";
  let result: { ok: boolean; error?: string } | null = null;
  let turnCost: number | undefined;
  const t0 = Date.now();
  try {
    if (process.env.NOVA_TEST_DEEP === "1") {
      // essais automatiques : un faux cerveau réfléchi qui utilise deux outils en 6 s
      for (const s of ["Nova · log_list", "Nova · log_analyze log_test.csv"]) {
        await new Promise((r) => setTimeout(r, 3000));
        if (abort.signal.aborted) throw new Error("interrompu");
        relay?.onTool(s);
      }
      await new Promise((r) => setTimeout(r, 2500));
      finalText = "Analyse du log du 25 octobre : pression turbo maxi +1,02 bar pour +1,05 demandé, aucun recul d'allumage, richesse 0,80 en pleine charge. Tout est normal.";
      result = { ok: true };
      return { ok: true, text: finalText };
    }
    if (directMode) {
      const key = config.anthropicApiKey || process.env.ANTHROPIC_API_KEY || "";
      if (!key) throw new Error("ce PC ne peut pas faire tourner Claude Code (processeur trop ancien) : ajoute une clé Anthropic dans Réglages → Cerveau, je réfléchirai directement par l'API");
      const disallowed = new Set([...EXPERT_TOOL_NAMES, ...MEDIA_TOOLS].filter((n) => !toolAvailable("mcp__jarvis__" + n)));
      const auto = new Set(NOVA_TOOLS.filter(toolAvailable));
      const r = await runDirect({
        apiKey: key,
        baseUrl: process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com",
        model: config.model || "claude-sonnet-5-5",
        system: buildPrompt() + DIRECT_NOTE,
        history: directHistory.slice(-16),
        prompt,
        tools: novaToolList.filter((t) => !disallowed.has(t.name)) as unknown as DirectTool[],
        permit: async (name, input, id) => {
          const full = "mcp__jarvis__" + name;
          if (auto.has(full)) return { ok: true, input };
          const d: any = await canUseTool(full, input, { signal: abort.signal, toolUseID: id } as any);
          return d.behavior === "allow" ? { ok: true, input: d.updatedInput ?? input } : { ok: false, input, message: d.message };
        },
        signal: abort.signal,
        onTextStart: () => {
          if (relay) finalText = "";
          else send({ type: "text.start" });
        },
        onText: (t) => {
          finalText += t;
          if (!relay) send({ type: "text.delta", text: t });
        },
        onTool: (id, name, input) => {
          const summary = summarizeTool("mcp__jarvis__" + name, input);
          send({ type: "tool", id, name: "mcp__jarvis__" + name, summary });
          log("Outil : " + summary);
          relay?.onTool(summary);
        },
        onToolResult: (id, ok) => send({ type: "tool.result", id, ok }),
      });
      if (relay) finalText = r.text;
      directHistory.push({ role: "user", content: prompt }, { role: "assistant", content: r.text.trim() || "…" });
      if (directHistory.length > 32) directHistory.splice(0, directHistory.length - 32);
      log(`${relay ? "Réfléchi" : "Réponse"} (API directe) en ${Math.round((Date.now() - t0) / 1000)} s · ${r.inTokens} + ${r.outTokens} jetons · ${r.steps} étape${r.steps > 1 ? "s" : ""}`);
      result = { ok: true };
      return { ok: true, text: finalText };
    }
    const q = query({
      prompt,
      options: {
        cwd,
        resume,
        model: config.model || undefined,
        systemPrompt: { type: "preset", preset: "claude_code", append: buildPrompt() },
        includePartialMessages: true,
        mcpServers: { jarvis: novaTools },
        allowedTools: ["Read", "Glob", "Grep", "WebSearch", "WebFetch", "TodoWrite", ...NOVA_TOOLS.filter(toolAvailable)],
        disallowedTools: [...[...EXPERT_TOOL_NAMES, ...MEDIA_TOOLS].map((n) => "mcp__jarvis__" + n).filter((t) => !toolAvailable(t)), ...(team.settings.enabled ? [] : ["Agent", "Task"])],
        canUseTool,
        agents: team.definitions(toolAvailable),
        env: {
          ...(process.env as Record<string, string>),
          CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH: "1",
          CLAUDE_CODE_DISABLE_BACKGROUND_TASKS: "1",
          CLAUDE_CODE_MAX_CONCURRENT_SUBAGENTS: String(team.settings.maxParallel),
        },
        ...(team.settings.budgetUsd > 0 ? { maxBudgetUsd: team.settings.budgetUsd } : {}),
        settingSources: ["user", "project"],
        abortController: abort,
      },
    });
    for await (const m of q) {
      const msg = m as any;
      if (msg.type === "system" && msg.subtype === "init") {
        sessionId = msg.session_id;
        store.state.generalSessionId = msg.session_id;
        await store.saveState();
      } else if (msg.type === "stream_event" && !msg.parent_tool_use_id) {
        const ev = msg.event;
        if (ev.type === "content_block_start" && ev.content_block?.type === "text") {
          // en relais seul le dernier message compte (le rapport) : on repart de zéro à chaque bloc
          if (relay) finalText = "";
          else send({ type: "text.start" });
        }
        if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta") {
          finalText += ev.delta.text;
          if (!relay) send({ type: "text.delta", text: ev.delta.text });
        }
      } else if (msg.type === "system" && (msg.subtype === "task_started" || msg.subtype === "task_progress") && msg.subagent_type) {
        const name = team.nameOf(msg.subagent_type);
        agentNames.set(msg.task_id, name);
        if (msg.tool_use_id) agentNames.set(msg.tool_use_id, name);
      } else if (msg.type === "assistant") {
        const parent: string | undefined = msg.parent_tool_use_id || undefined;
        const who = parent ? agentNames.get(parent) : undefined;
        for (const block of msg.message?.content ?? []) {
          if (block.type !== "tool_use") continue;
          const input = block.input ?? {};
          if (block.name === "Agent" || block.name === "Task") {
            const name = team.nameOf(String(input.subagent_type || "general-purpose"));
            agentNames.set(block.id, name);
            const summary = `${name} : ${String(input.description || "au travail")}`;
            send({ type: "tool", id: block.id, name: block.name, summary, agent: name, parent });
            relay?.onTool("l'employé " + summary);
          } else {
            const summary = summarizeTool(block.name, input);
            send({ type: "tool", id: block.id, name: block.name, summary, agent: who, parent });
            log(`Outil : ${who ? who + " · " : ""}${summary}`);
            relay?.onTool((who ? who + " utilise " : "") + summary);
          }
        }
      } else if (msg.type === "user" && Array.isArray(msg.message?.content)) {
        for (const block of msg.message.content) if (block.type === "tool_result") send({ type: "tool.result", id: block.tool_use_id, ok: !block.is_error });
      } else if (msg.type === "result") {
        const ok = msg.subtype === "success";
        result = { ok, error: ok ? undefined : msg.subtype };
        if (typeof msg.total_cost_usd === "number" && sessionId) {
          const c = await costs.record(sessionId, msg.total_cost_usd, msg.modelUsage, !!resume);
          turnCost = c.usd ?? undefined;
          log(`${relay ? "Réfléchi" : "Réponse"} en ${Math.round((Date.now() - t0) / 1000)} s${c.usd !== null ? ", coût " + formatUsd(c.usd) : ""}`);
        }
      }
    }
  } catch (err: any) {
    const aborted = abort.signal.aborted;
    const t = String(err?.message || err);
    if (!relay || aborted)
      send({
        type: "error",
        message: aborted ? "Interrompu." : /SIGILL|illegal instruction/i.test(t) ? "Ce PC ne peut pas faire tourner Claude Code (processeur trop ancien) : je passe par l'API directe, redemande-moi." : /api key|authentication|401|login/i.test(t) ? "Je n'arrive pas à joindre mon cerveau : ajoute la clé Anthropic dans les réglages (ou connecte Claude Code avec /login)." : "Erreur : " + t,
      });
    log("Erreur du cerveau réfléchi : " + t);
    // Claude Code planté par le processeur : les tours suivants passent par l'API directe
    if (!directMode && /SIGILL|illegal instruction/i.test(t)) {
      directMode = true;
      log("Cerveau réfléchi : Claude Code ne tourne pas sur ce processeur, passage à l'API directe");
    }
  } finally {
    agentNames.clear();
    if (!relay) {
      busy = false;
      currentAbort = null;
      if (result) send({ type: "done", ...result, cost: turnCost, text: finalText });
      send({ type: "state", state: "idle" });
      sendSnapshot();
      if (finalText) log("Réponse : " + finalText.replace(/\s+/g, " ").slice(0, 300));
    }
  }
  return { ok: !!result?.ok, text: finalText.trim() };
}

// ---------- double cerveau : la voix rapide répond tout de suite, le réfléchi prend le relais ----------
const ENV_KEY = process.env.ANTHROPIC_API_KEY || "";
const recent: { q: string; a: string; deep: boolean }[] = []; // derniers échanges (pour le rapide, et pour le réfléchi qui ne les a pas vus)
let clientSpeaking = false;
let speakingChangedAt = 0;

function fastOptions(): FastOptions | null {
  const key = config.anthropicApiKey || ENV_KEY;
  if (!config.fastEnabled || !key) return null;
  return { apiKey: key, baseUrl: process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com", model: config.fastModel || DEFAULT_CONFIG.fastModel };
}

function fastBase() {
  return fastSystem({
    name: config.assistantName,
    driver: car.files.config.driverName,
    now: new Date().toLocaleString("fr-FR", { dateStyle: "full", timeStyle: "short" }),
    car: car.describe(),
    memory: store.memory.length ? store.memory.slice(-60).map((m) => `- [${m.category}] ${m.text}`).join("\n") : "(rien pour l'instant)",
    screen: currentScreen,
  });
}

function history(): Msg[] {
  return recent.slice(-6).flatMap((r) => [
    { role: "user" as const, content: r.q },
    { role: "assistant" as const, content: r.a || "…" },
  ]);
}

function remember(q: string, a: string, deep: boolean) {
  recent.push({ q, a: a.replace(/\s+/g, " ").trim(), deep });
  if (recent.length > 12) recent.shift();
}

/** Point d'entrée de toute question à Nova (voix, écran, boutons). */
async function ask(prompt: string) {
  const fo = fastOptions();
  if (!fo) {
    const r = await runTurn(prompt);
    if (r.text) remember(prompt, r.text, true);
    return;
  }
  if (busy) {
    send({ type: "error", message: "Je suis encore sur la demande précédente." });
    return;
  }
  busy = true;
  turnId++;
  const abort = new AbortController();
  currentAbort = abort;
  const signal = abort.signal;
  send({ type: "state", state: "think" });
  log("Demande : " + prompt.slice(0, 200));
  const driver = car.files.config.driverName;
  let said = "";
  let last = ""; // ce qui a été dit en dernier (pour détecter une question finale)
  let ok = true;
  let fallback = false;
  let usedDeep = false;
  const say = (t: string) => {
    said += t;
    last += t;
    send({ type: "text.delta", text: t });
  };
  try {
    const base = fastBase();
    send({ type: "text.start" });
    const split = new TagSplitter(say);
    const r = await streamMessage(fo, { system: base, messages: [...history(), { role: "user", content: prompt }], maxTokens: 300, signal }, (t) => split.push(t));
    split.end();
    log(`Voix rapide : ${split.route === "relais" ? "RELAIS" : "SEULE"}, premier mot en ${r.firstTokenMs} ms (${r.inTokens} + ${r.outTokens} jetons) : ${said.trim().slice(0, 200)}`);

    if (split.route === "relais" && !signal.aborted) {
      usedDeep = true;
      send({ type: "text.delta", text: "\n" }); // la voix dit la phrase tout de suite
      // le réfléchi apprend ce qui s'est dit sans lui
      const unseen = recent.filter((x) => !x.deep).slice(-4);
      const ctx = unseen.length ? `\nÉchanges récents gérés par la voix rapide :\n${unseen.map((x) => `- ${driver} : ${x.q}\n  Nova : ${x.a}`).join("\n")}` : "";
      const deepPrompt = `${prompt}

(Contexte pour toi : la voix rapide de Nova a déjà répondu à l'oral : « ${said.trim()} ».${ctx}
Fais le travail demandé avec tes outils. Ton dernier message est un rapport court et factuel pour la voix rapide,
qui le dira à ${driver} : l'essentiel en quelques phrases, les chiffres utiles, sans politesse. Les détails longs
vont dans une fenêtre (show_window). Si tu as besoin d'une réponse de ${driver}, termine le rapport par la question.)`;
      let narrations = 0;
      let lastNarr = Date.now() - 3500; // première relance possible après ~2,5 s de silence
      let narrating = false;
      let deepDone = false;
      const deep = await runTurn(deepPrompt, {
        relay: {
          abort,
          onTool: async (summary) => {
            // combler les blancs, sans parler par-dessus soi-même
            const now = Date.now();
            if (deepDone || narrating || narrations >= 3 || clientSpeaking || now - lastNarr < 6000 || now - speakingChangedAt < 1500) return;
            narrating = true;
            try {
              const n = await streamMessage(
                fo,
                { system: narrationSystem(base), messages: [{ role: "user", content: `Question de ${driver} : « ${prompt} »\nDéjà dit : « ${said.trim()} »\nEn ce moment, le cerveau réfléchi : ${summary}` }], maxTokens: 40, signal },
                () => {},
              );
              const s = n.text.trim();
              if (s && !/^RIEN\b/i.test(s) && !deepDone && !signal.aborted) {
                say(" " + s + "\n");
                narrations++;
                lastNarr = Date.now();
                log("Voix rapide (attente) : " + s);
              }
            } catch {
              /* une narration ratée n'a aucune importance */
            } finally {
              narrating = false;
            }
          },
        },
      });
      deepDone = true;
      if (signal.aborted) throw new Error("interrompu");
      log("Rapport du réfléchi : " + deep.text.replace(/\s+/g, " ").slice(0, 400));
      last = "";
      if (!deep.text) {
        ok = false;
        say(" Désolée, je n'ai pas réussi à aller au bout. Tu peux reformuler ?");
      } else {
        await streamMessage(
          fo,
          {
            system: restitutionSystem(base),
            messages: [...history(), { role: "user", content: prompt }, { role: "assistant", content: said.trim() || "…" }, { role: "user", content: `Rapport du cerveau réfléchi :\n${deep.text}` }],
            maxTokens: 300,
            signal,
          },
          (t) => say(t),
        );
        log("Voix rapide (restitution) : " + last.trim().slice(0, 300));
      }
    }
    remember(prompt, said, usedDeep);
  } catch (err: any) {
    const t = String(err?.message || err);
    if (signal.aborted) send({ type: "error", message: "Interrompu." });
    else if (!said) {
      // la voix rapide est en panne (clé, modèle, réseau) : le réfléchi répond comme avant
      log("Voix rapide indisponible, passage au cerveau réfléchi : " + t);
      fallback = true;
    } else {
      ok = false;
      send({ type: "error", message: "Erreur : " + t });
      log("Erreur du double cerveau : " + t);
    }
  } finally {
    busy = false;
    currentAbort = null;
    if (!fallback) {
      send({ type: "done", ok, text: last.trim() || said.trim() });
      send({ type: "state", state: "idle" });
      sendSnapshot();
    }
  }
  if (fallback) {
    const r = await runTurn(prompt);
    if (r.text) remember(prompt, r.text, true);
  }
}

// ---------- vérifications de démarrage (écran Lancement) ----------
async function bootChecks() {
  const src = car.sourceStatus();
  let net = false;
  try {
    await Promise.race([dns.lookup("api.anthropic.com"), new Promise((_, rej) => setTimeout(() => rej(new Error("délai")), 2500))]);
    net = true;
  } catch {
    net = false;
  }
  const hasKey = !!(config.anthropicApiKey || process.env.ANTHROPIC_API_KEY) || existsSync(path.join(os.homedir(), ".claude", ".credentials.json"));
  const fr = models.info?.fr?.status;
  const checks = src.map((s) => ({
    name: s.name === "CAN" ? "CAN moteur" : s.name,
    val: s.state === "ok" ? (s.name === "CAN" ? "500 kbit/s" : s.name === "Simulateur" ? "voiture virtuelle" : s.detail.split("·")[0].trim() || "connecté") : s.state === "connecting" ? "connexion…" : s.name === "Câble" ? "aucun câble" : "pas de réponse",
    ok: s.state === "ok",
    wait: s.state === "connecting",
  }));
  checks.push({ name: "Réseau 4G", val: net ? "connecté" : "hors ligne", ok: net, wait: false });
  checks.push({ name: "Cerveau Claude", val: hasKey ? "prêt" : "clé manquante", ok: hasKey && net, wait: false });
  checks.push({ name: `Voix de ${car.files.config.driverName}`, val: fr === "ready" ? (wakeAvailable() ? "reconnue" : "écoute locale") : fr === "downloading" ? "téléchargement" : "à installer", ok: fr === "ready", wait: false });
  checks.push({ name: car.hw.mode === "pi" ? "NovaHAT" : "Carte NovaHAT", val: car.hw.mode === "pi" ? "connectée" : "absente", ok: car.hw.mode === "pi", wait: false });
  return checks;
}

// ---------- une connexion d'écran ----------
/**
 * Copie un fichier là où Windows pourra le lire : la clé Nova OS elle-même (partition FAT de Rufus,
 * remontée en écriture le temps de la copie), ou toute autre clé USB branchée.
 */
async function copyToUsb(file: string): Promise<string[]> {
  if (process.platform !== "linux") return [];
  const out: string[] = [];
  const name = "nova-journaux-" + new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-") + ".txt";
  const runSh = (c: string) =>
    new Promise<boolean>((resolve) => {
      const p = spawn("sh", ["-c", c], { stdio: "ignore" });
      p.on("exit", (code) => resolve(code === 0));
      p.on("error", () => resolve(false));
    });
  // la clé Nova OS (montée en lecture seule sur /run/live/medium)
  const med = "/run/live/medium";
  if (existsSync(med)) {
    const ok = await runSh(`sudo -n sh -c 'fs=$(findmnt -rn -o FSTYPE ${med}); case "$fs" in vfat|exfat|ntfs|ntfs3|fuseblk) mount -o remount,rw ${med} && mkdir -p ${med}/nova-journaux && cp "${file}" ${med}/nova-journaux/${name} && sync; r=$?; mount -o remount,ro ${med}; exit $r;; *) exit 1;; esac'`);
    if (ok) out.push("clé Nova OS → dossier nova-journaux");
  }
  // autres clés USB déjà montées
  for (const base of ["/media", "/run/media"]) {
    const users = await fs.readdir(base).catch(() => [] as string[]);
    for (const u of users) {
      const dirs = await fs.readdir(path.join(base, u)).catch(() => [] as string[]);
      for (const d of dirs) {
        const target = path.join(base, u, d);
        if (await fs.copyFile(file, path.join(target, name)).then(() => true).catch(() => false)) out.push(target);
      }
    }
  }
  jlog("nova.log", "Rapport complet exporté : " + (out.join(", ") || "copie USB impossible, fichier : " + file));
  return out;
}

function onConnection(ws: WebSocket) {
  void moniteur.screenConnected("connexion de l'écran");
  ws.on("close", (code) => jlog("ecran.log", `Écran déconnecté (code ${code})`));
  const clientId = randomUUID();
  clients.add(ws);
  ws.on("close", () => clients.delete(ws));
  const reply = (m: Record<string, unknown>) => ws.readyState === WebSocket.OPEN && ws.send(JSON.stringify(m));
  reply({ type: "hello", clientId, name: config.assistantName, driver: car.files.config.driverName, modes: MODES, screen: currentScreen });
  reply({ type: "snapshot", ...store.snapshot(), busy });
  reply(voicesMessage());
  reply(publicConfig());
  reply(workspace.snapshot());
  reply(modelStatus());
  reply(team.publicState());
  for (const m of car.snapshot()) reply(m);
  reply({ type: "sys", ...sys.st });
  reply({ type: "maj", ...updater.st });
  reply({ type: "majos", ...osUpdater.st });
  reply({ type: "fichiers", ...fichiers.st });
  void fs.readFile(path.join(DATA_DIR, "ecran-affichage.json"), "utf8").then((t) => reply({ type: "display.prefs", prefs: JSON.parse(t) })).catch(() => {});
  if (mapsRoute) reply({ type: "maps.route", ...mapsRoute });
  if (music.active) void music.read().then((st) => reply({ type: "music", state: st })).catch(() => {});
  const audio = new AudioSession(models, DATA_DIR, {
    wake: (command) => reply({ type: "wake", command, local: audio.hasLocalStt() }),
    partial: (t) => reply({ type: "stt.partial", text: t }),
    final: (t) => reply({ type: "stt.final", text: t }),
    heard: (t) => reply({ type: "calib.heard", text: t }),
  });

  ws.on("message", async (raw, isBinary) => {
    if (isBinary) {
      const buf = raw as Buffer;
      try {
        audio.feed(new Float32Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength)));
      } catch {
        /* trame ignorée */
      }
      return;
    }
    let msg: any;
    try {
      msg = JSON.parse(String(raw));
    } catch {
      return;
    }
    if (typeof msg?.type === "string" && !["listen.start", "listen.stop", "listen.cancel", "ping", "voice.level", "voice.speaking", "screen.changed", "tts", "audio.pause", "audio.config", "boot.get", "config.get", "client.log", "client.perf", "client.boot", "logs.list", "logs.read", "sys.get", "vag.group", "vag.basic", "vag.watch", "can.view"].includes(msg.type)) log("← " + msg.type);
    try {
      switch (msg.type) {
        // ----- cerveau -----
        case "chat":
          if (typeof msg.text === "string" && msg.text.trim()) {
            send({ type: "user", text: msg.text.trim(), from: clientId });
            void ask(msg.text.trim());
          }
          break;
        case "interrupt":
          currentAbort?.abort();
          break;
        case "permission":
          pendingPermissions.get(msg.id)?.(!!msg.allow);
          break;
        case "audio.config": {
          const sens: Sensitivity = ["low", "normal", "high"].includes(msg.sensitivity) ? msg.sensitivity : "normal";
          await audio.configure({ sampleRate: Number(msg.sampleRate) || 48000, wake: !!msg.wake, sensitivity: sens, silence: Number(msg.silence) || 1.2, localStt: !!msg.localStt, name: config.assistantName, variants: config.wakeVariants });
          reply({ type: "audio.ready", localStt: audio.hasLocalStt() });
          break;
        }
        case "audio.pause":
          audio.pauseWake(!!msg.paused);
          break;
        case "listen.start":
          reply({ type: "listen.started", local: audio.startListening() });
          break;
        case "listen.stop":
          audio.stopListening(true);
          break;
        case "listen.cancel":
          audio.stopListening(false);
          break;
        case "model.download":
          void models.download(msg.name === "precise" ? "precise" : "fr");
          break;
        case "calib.start":
          reply({ type: "calib.started", ok: audio.startCalibration() });
          break;
        case "calib.stop":
          audio.stopCalibration();
          break;
        case "tts":
          try {
            const data = msg.engine === "openai" ? await synthesize(String(msg.text ?? ""), String(msg.voice ?? ""), String(msg.instructions ?? "")) : await voices.synth(String(msg.voice ?? ""), String(msg.text ?? ""), Number(msg.speed) || 1, Number(msg.speaker) || 0);
            reply({ type: "tts.audio", id: msg.id, data });
          } catch (e: any) {
            reply({ type: "tts.error", id: msg.id, message: String(e?.message || e) });
          }
          break;
        case "voices.list":
          await voices.scan();
          break;
        case "voices.install":
          void voices.install(String(msg.id));
          break;
        case "voices.remove":
          await voices.remove(String(msg.id));
          break;
        case "voices.warm":
          voices.warm(String(msg.id));
          break;
        case "voice.level":
          car.hw.ledLevel(Number(msg.level) || 0);
          break;
        case "voice.speaking":
          clientSpeaking = !!msg.on;
          speakingChangedAt = Date.now();
          // le logo LED parle avec Nova
          if (!car.alerts.pending().length) car.hw.setLed(msg.on ? { effect: "speak", color: "#F1F3F5" } : { effect: "breathe", color: ["#F1F3F5", "#4FD1E8", "#FF4D2E"][car.store.mode] });
          break;
        case "config.get":
          reply(publicConfig());
          break;
        case "config.set":
          await updateConfig(msg.patch ?? {});
          if (msg.car) await car.files.patch(msg.car);
          send(publicConfig());
          break;
        case "memory.add":
          await store.remember(String(msg.category || "Général"), String(msg.text));
          sendSnapshot();
          break;
        case "memory.delete":
          await store.forget(Number(msg.index));
          sendSnapshot();
          break;
        case "team.get":
          reply(team.publicState());
          break;
        case "team.set":
          await team.setSettings(msg.patch ?? {});
          send(team.publicState());
          break;
        case "ui.closed":
          workspace.close(String(msg.id));
          break;
        case "ui.check": {
          const w = workspace.windows.get(String(msg.id));
          if (w?.items) workspace.update(w.id, { items: w.items.map((it, i) => (i === Number(msg.index) ? { ...it, done: !it.done } : it)) });
          break;
        }
        case "log":
          log("Écran · " + String(msg.text ?? "").slice(0, 2000));
          break;
        case "browser.login":
          reply({ type: "browser.login", state: "open" });
          try {
            await browsers.login("https://music.youtube.com");
            reply({ type: "browser.login", state: "done" });
          } catch (e: any) {
            reply({ type: "browser.login", state: "error", message: String(e?.message || e) });
          }
          break;
        case "boot.get":
          reply({ type: "boot", checks: await bootChecks() });
          break;
        // ----- voiture -----
        case "screen.changed":
          currentScreen = String(msg.name || "veille");
          break;
        case "car.mode":
          car.setMode(Number(msg.mode));
          break;
        case "car.night":
          car.setNight(!!msg.on);
          break;
        case "alert.ack":
          car.ackAlert(String(msg.id));
          if (msg.action) car.action(String(msg.action));
          break;
        case "car.action":
          car.action(String(msg.action));
          break;
        case "diag.start":
          if (car.store.moving) throw new Error("Le diagnostic se fait à l'arrêt.");
          car.diag.start();
          break;
        case "diag.cancel":
          car.diag.cancel();
          break;
        case "diag.ask":
          send({ type: "user", text: "Analyse mon diagnostic", from: clientId });
          void ask("Je viens de faire le diagnostic moteur guidé. Lis les résultats avec diagnostic_status, explique-moi en trois phrases ce qu'ils veulent dire et ce que je dois vérifier en premier sur la voiture.");
          break;
        case "learn.reset":
          car.learning.reset();
          send({ type: "rapports", ...car.rapports() });
          break;
        case "log.start":
          await car.logger.start(String(msg.reason || "manuel"), Number(msg.hz) || car.files.config.logHz);
          break;
        case "log.stop":
          await car.logger.stop();
          break;
        case "dtc.read":
          reply({ type: "dtc", items: (await car.sources.find((s) => s.readDtc && s.status.state === "ok")?.readDtc?.()) ?? null });
          break;
        case "fuel.set":
          car.files.learned.fuelL = Math.max(0, Math.min(80, Number(msg.liters) || 0));
          car.files.saveLearnedSoon();
          break;
        case "trip.reset":
          car.store.resetTrip();
          break;
        case "remote.start":
          void car.remote.start();
          break;
        case "remote.stop":
          car.remote.stop();
          break;
        // ----- calculateurs (câble KKL) -----
        case "vag.test":
          void car.vag.test().catch((e) => reply({ type: "error", message: String(e?.message || e) }));
          break;
        case "vag.scan":
          void car.vag.scan().catch((e) => reply({ type: "error", message: "Scan : " + (e?.message || e) }));
          break;
        case "vag.open": {
          const addr = Number(msg.addr);
          void car.vag
            .ident(addr)
            .then(() => car.vag.faults(addr))
            .catch((e) => reply({ type: "error", message: "Calculateur " + addr.toString(16).toUpperCase() + " : " + (e?.message || e) }));
          break;
        }
        case "vag.faults":
          void car.vag.faults(Number(msg.addr)).catch((e) => reply({ type: "error", message: String(e?.message || e) }));
          break;
        case "vag.clear":
          void car.vag.clear(Number(msg.addr)).catch((e) => reply({ type: "error", message: String(e?.message || e) }));
          break;
        case "vag.group":
          void car.vag.group(Number(msg.addr), Number(msg.group)).catch((e) => reply({ type: "error", message: String(e?.message || e) }));
          break;
        case "maj.check":
          void updater.check();
          break;
        case "maj.install":
          reply({ type: "toast", message: await updater.install() });
          break;
        case "display.prefs": {
          const p = msg.prefs && typeof msg.prefs === "object" ? msg.prefs : {};
          const keep = { fit: p.fit === "ajuster" ? "ajuster" : "remplir", zoom: Math.max(50, Math.min(100, Number(p.zoom) || 100)), effects: ["auto", "full", "lite"].includes(p.effects) ? p.effects : "auto" };
          await fs.writeFile(path.join(DATA_DIR, "ecran-affichage.json"), JSON.stringify(keep));
          break;
        }
        case "fichiers.ouvrir":
          await fichiers.ouvrir(String(msg.racine || "recus"), String(msg.chemin || ""));
          break;
        case "fichiers.envoyer":
          reply({ type: "toast", message: await fichiers.envoyer(String(msg.racine || ""), String(msg.chemin || "")) });
          break;
        case "fichiers.supprimer":
          reply({ type: "toast", message: await fichiers.supprimer(String(msg.chemin || "")) });
          break;
        case "fichiers.ejecter":
          reply({ type: "toast", message: await fichiers.ejecter() });
          break;
        case "majos.check":
          void osUpdater.check();
          break;
        case "majos.install":
          reply({ type: "toast", message: osUpdater.install() });
          break;
        case "majos.precedente":
          reply({ type: "toast", message: await osUpdater.other("essai") });
          break;
        case "majos.revenir":
          reply({ type: "toast", message: await osUpdater.other("garder") });
          break;
        case "majos.reboot":
          reply({ type: "toast", message: osUpdater.reboot() });
          break;
        case "vag.watch":
          car.vag.watch(Number(msg.addr), Number(msg.group));
          break;
        case "vag.unwatch":
          car.vag.stopWatch();
          break;
        case "vag.multi":
          car.vag.setMulti(Array.isArray(msg.items) ? msg.items.map((x: any) => ({ addr: Number(x?.addr), group: Number(x?.group) })) : []);
          break;
        case "can.find":
          car.finder.start(Number(msg.addr), Number(msg.group), Number(msg.field), String(msg.label || "mesure"), String(msg.unit || ""), Number(msg.seconds) || 40);
          break;
        case "can.findStop":
          car.finder.stop();
          break;
        case "can.findGet":
          reply({ type: "can.find", ...car.canFindView() });
          break;
        case "can.save":
          reply({ type: "toast", message: await car.canSave(Number(msg.index), String(msg.key || "")) });
          break;
        case "can.forget":
          await car.canForget(String(msg.key || ""));
          break;
        case "can.view":
          reply({ type: "can.view", view: car.canView(), config: { source: car.files.config.source, elmMode: car.files.config.elmMode, elmHost: car.files.config.elmHost, elmBt: car.files.config.elmBt } });
          break;
        case "vag.multiStop":
          car.vag.stopMulti();
          break;
        case "vag.cancel":
          car.vag.cancel();
          break;
        case "vag.basic":
          void car.vag.basicSetting(Number(msg.addr), Number(msg.group)).catch((e) => reply({ type: "error", message: String(e?.message || e) }));
          break;
        case "vag.basicStop":
          void car.vag.basicStop(Number(msg.addr), Number(msg.group));
          break;
        case "vag.output":
          void car.vag.outputTest(Number(msg.addr)).catch((e) => reply({ type: "error", message: String(e?.message || e) }));
          break;
        case "vag.labelsReload":
          await car.vag.labels.load();
          car.vag.refreshCatalogs();
          reply({ type: "toast", message: car.vag.labels.ready ? "Base de libellés chargée" : "Base introuvable : " + car.vag.labels.error });
          break;
        case "vag.readAll":
          void car.vag.readAll(Number(msg.addr)).then((r) => reply({ type: "toast", message: `${r.found} groupes lus · rapport ${r.file}` })).catch((e) => reply({ type: "error", message: String(e?.message || e) }));
          break;
        // ----- média -----
        case "media": {
          const a = String(msg.action);
          if (msg.source === "phone") car.phone.control(a === "play_pause" ? "toggle" : (a as any));
          else if (music.active) await music.control(a === "play_pause" ? "toggle" : a);
          else mediaKey(a, 1);
          break;
        }
        case "music.play":
          try {
            await music.play(String(msg.query || ""));
          } catch (e: any) {
            reply({ type: "error", message: "YouTube Music : " + (e?.message || e) });
          }
          break;
        case "nav.open":
          reply({ type: "nav.status", message: await car.phone.openNav(msg.app === "maps" ? "maps" : "waze", msg.rect ?? null) });
          break;
        case "nav.close":
          car.phone.closeNav();
          break;
        case "maps.route":
          mapsRoute = msg.dest ? { dest: String(msg.dest).slice(0, 200), from: String(msg.from || "").slice(0, 200) } : null;
          send({ type: "maps.route", ...(mapsRoute || { dest: "", from: "" }) });
          break;
        // ----- journaux -----
        case "client.log":
          jlog("ecran.log", `${msg.level === "error" ? "ERREUR" : msg.level === "warn" ? "Attention" : "Info"} · ${String(msg.text || "").slice(0, 4000)}`);
          break;
        case "client.perf": {
          const p = msg.perf || {};
          jlog("ecran.log", `Fluidité : ${p.fps} images/s sur « ${p.screen} »${p.worst ? `, pire image ${p.worst} ms` : ""}${p.longTasks ? `, ${p.longTasks} blocages > 50 ms` : ""} · effets ${p.lite ? "légers" : "complets"}${p.heapMb ? ` · mémoire de la page ${p.heapMb} Mo` : ""} · fenêtre ${p.w}×${p.h} (×${p.dpr})`);
          if (p.fps < 15) void snapshot(`écran lent : ${p.fps} images/s`);
          break;
        }
        case "client.boot":
          jlog("ecran.log", `Page de Nova chargée · carte graphique : ${msg.gpu} · ${msg.ua}`);
          void moniteur.screenTiming({ load: Number(msg.load) || 0 });
          break;
        case "logs.list":
          reply({ type: "logs.list", dir: LOG_DIR, items: await listLogs() });
          break;
        case "logs.read":
          reply({ type: "logs.read", name: msg.name, text: await tailLog(String(msg.name), Math.min(2000, Number(msg.lines) || 300)) });
          break;
        case "logs.clear":
          await clearLogs();
          jlog("nova.log", "Journaux effacés depuis l'écran");
          reply({ type: "logs.list", dir: LOG_DIR, items: await listLogs() });
          break;
        case "logs.export": {
          const text = await fullReport(`Nova ${APP_VERSION} · source ${car.files.config.source} · ${JSON.stringify(sys.st.battery)}`);
          const file = path.join(LOG_DIR, "rapport-complet.txt");
          await fs.writeFile(file, text);
          const copied = await copyToUsb(file);
          reply({ type: "logs.exported", file, copied });
          break;
        }
        // ----- le PC : Wi-Fi, Bluetooth, téléphone, écran -----
        case "sys.get":
          reply({ type: "sys", ...sys.st });
          break;
        case "net.scan":
          await sys.wifiScan();
          break;
        case "net.connect":
          reply({ type: "toast", message: await sys.wifiConnect(String(msg.ssid || ""), String(msg.password || "")) });
          break;
        case "net.forget":
          await sys.wifiForget(String(msg.ssid || ""));
          break;
        case "net.radio":
          await sys.wifiRadio(!!msg.on);
          break;
        case "bt.power":
          await sys.btPower(!!msg.on);
          break;
        case "bt.scan":
          await sys.btScan();
          break;
        case "bt.pair":
          reply({ type: "toast", message: await sys.btPair(String(msg.mac || "")) });
          break;
        case "can.useBt": {
          // association de l'ELM327, puis source « ELM327 sur le CAN + KKL », puis redémarrage du cerveau
          const mac = String(msg.mac || "");
          reply({ type: "toast", message: await sys.btPairElm(mac) });
          await car.files.patch({ elmBt: mac, elmMode: "can", source: "elmcan+kkl" } as any);
          if (process.platform === "linux" && existsSync("/opt/nova")) {
            reply({ type: "toast", message: "ELM327 Bluetooth choisi : Nova redémarre…" });
            setTimeout(() => process.exit(0), 800);
          } else reply({ type: "toast", message: "ELM327 Bluetooth choisi : relance Nova" });
          break;
        }
        case "bt.pairElm":
          reply({ type: "toast", message: await sys.btPairElm(String(msg.mac || "")) });
          break;
        case "bt.connect":
          reply({ type: "toast", message: await sys.btConnect(String(msg.mac || ""), msg.on !== false) });
          break;
        case "bt.remove":
          await sys.btRemove(String(msg.mac || ""));
          break;
        case "kde.refresh":
          await sys.kdeRefresh();
          break;
        case "kde.pair":
          reply({ type: "toast", message: await sys.kdePair(String(msg.id || "")) });
          break;
        case "display.set":
          reply({ type: "toast", message: await sys.displaySet(String(msg.mode || "auto")) });
          break;
        case "display.gpu":
          await sys.setGpu(String(msg.mode || "auto"));
          jlog("ecran.log", "Accélération graphique réglée sur : " + sys.st.gpuMode);
          break;
        case "system.restartBrain":
          // Nova OS relance le cerveau tout seul (surveillance de la session)
          if (process.platform === "linux" && existsSync("/opt/nova")) {
            reply({ type: "toast", message: "Nova redémarre…" });
            jlog("nova.log", "Redémarrage du cerveau demandé (changement de source)");
            setTimeout(() => process.exit(0), 600);
          } else reply({ type: "toast", message: "Relance Nova à la main pour appliquer la nouvelle source" });
          break;
        case "system.restartScreen":
          // la session relance l'écran sans afficher son menu
          if (process.platform === "linux") {
            await fs.writeFile(path.join(DATA_DIR, ".relancer-ecran"), String(Date.now()));
            send({ type: "screen.closing" });
            await new Promise((r) => setTimeout(r, 300));
            jlog("ecran.log", "Relance de l'écran demandée");
            spawn("pkill", ["-f", "nova-ecran"], { stdio: "ignore" }).on("error", () => {});
          } else reply({ type: "toast", message: "Seulement sur Nova OS" });
          break;
        case "sys.report": {
          const r = await sys.report();
          reply({ type: "sys.report", ...r });
          break;
        }
        // ----- Nova OS (clé Linux / Pi) -----
        case "system.menu":
          // ferme l'écran de Nova : la session Nova OS affiche son menu (bureau, terminal, éteindre)
          if (process.platform === "linux") {
            send({ type: "screen.closing" });
            await new Promise((r) => setTimeout(r, 300));
            spawn("pkill", ["-f", "nova-ecran"], { stdio: "ignore" }).on("error", () => {});
          }
          break;
        case "persist.enable":
          reply({ type: "toast", message: await sys.enablePersistence() });
          break;
        case "system.poweroff":
          if (process.platform === "linux") {
            log("Arrêt du système demandé depuis l'écran");
            send({ type: "toast", message: "Extinction…" });
            await car.stop().catch(() => {});
            // sync : réglages et logs écrits sur la clé avant de couper ; puis systemctl
            // (autorisé par Nova OS), sinon sudo (utilisateur de la clé live), sinon on le dit
            const off = spawn("sh", ["-c", "sync; systemctl poweroff 2>&1 || sudo -n systemctl poweroff 2>&1 || exit 1"], { stdio: ["ignore", "pipe", "pipe"] });
            let out = "";
            off.stdout?.on("data", (d) => (out += d));
            off.stderr?.on("data", (d) => (out += d));
            off.on("exit", (code) => {
              if (code) {
                log("Extinction refusée : " + out.trim());
                send({ type: "toast", message: "Extinction refusée par le système : " + (out.trim().split("\n").pop() || "code " + code) });
              }
            });
          } else reply({ type: "toast", message: "Éteindre : seulement sur Nova OS." });
          break;
        case "youtube.open":
          if (car.store.moving) throw new Error("YouTube s'ouvre à l'arrêt seulement.");
          openUrl("https://www.youtube.com");
          break;
      }
    } catch (err: any) {
      log(`Erreur sur « ${msg?.type} » : ` + (err?.message || err));
      reply({ type: "error", message: String(err?.message || err) });
    }
  });
}

// ---------- serveur HTTP (écrans) + WebSocket ----------
const MIME: Record<string, string> = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".png": "image/png", ".svg": "image/svg+xml", ".woff2": "font/woff2", ".json": "application/json" };

const server = http.createServer((req, res) => {
  const url = new URL(req.url || "/", "http://localhost");
  let p = decodeURIComponent(url.pathname);
  if (p === "/") p = "/index.html";
  const file = path.normalize(path.join(WEB_DIR, p));
  if (!file.startsWith(WEB_DIR) || !existsSync(file) || !statSync(file).isFile()) {
    res.writeHead(404);
    res.end("introuvable");
    return;
  }
  res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-cache" });
  createReadStream(file).pipe(res);
});

async function main() {
  jlog("demarrage.log", "Démarrage du cerveau de Nova (node " + process.version + ")");
  await store.load();
  await loadConfig();
  phase("mémoire et réglages");
  await team.load().catch((e) => log("Équipe illisible : " + e));
  await costs.load();
  await models.init();
  phase("modèles vocaux");
  await voices.scan().catch((e) => log("Voix locales illisibles : " + e));
  phase("voix");
  await car.init({ source: arg("source"), port: arg("port") });
  phase("voiture");

  const wss = new WebSocketServer({
    server,
    path: "/ws",
    verifyClient: (info: { req: { url?: string } }) => !TOKEN || new URL(info.req.url || "/", "http://localhost").searchParams.get("token") === TOKEN,
  });
  wss.on("connection", (ws) => onConnection(ws));
  server.listen(PORT, HOST, () => {
    console.log(`\n  Nova est prête : ouvre http://localhost:${PORT}  (données : ${DATA_DIR})\n`);
    log(`Nova démarrée sur http://${HOST}:${PORT}, source ${car.files.config.source}`);
    phase("serveur prêt");
    void moniteur.start("v" + APP_VERSION);
  });

  // préchargement de la reconnaissance vocale locale : sur un petit processeur, après l'animation de
  // démarrage (le chargement du modèle prend plusieurs secondes de processeur et faisait saccader l'écran)
  setTimeout(() => {
    try {
      models.recognizer(1.2);
    } catch {
      /* chargée au premier usage */
    }
  }, os.cpus().length <= 2 ? 25000 : 500);

  const shutdown = async () => {
    log("Arrêt de Nova");
    await car.stop().catch(() => {});
    await browsers.close().catch(() => {});
    process.exit(0);
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
