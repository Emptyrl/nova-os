@echo off
rem Nova : trouve tout seul le cable branche (KKL ou ELM327). Contact mis.
cd /d "%~dp0"
if not exist node_modules (echo Installation des modules, une seule fois... & call npm install)
if not exist dist (call npm run build)
start "" cmd /c "timeout /t 4 >nul & start http://localhost:47823"
node dist\server.js --source auto
pause
