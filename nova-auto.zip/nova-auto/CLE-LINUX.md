# Clé Nova OS

Le PC démarre directement sur Nova : menu « Nova OS », animation du logo TT, puis Nova en plein écran. Pas de bureau, pas de Windows.
Nova OS est construit sur une base Linux Mint, mais on ne voit que Nova. Le bureau Linux reste caché, accessible seulement pour la maintenance.
Windows 7 n'est pas touché : sans la clé, le PC démarre normalement sur Windows 7.

Il faut :

- une clé USB de **16 Go minimum**, 32 Go conseillés, rapide (USB 3 si possible). Elle sera **effacée** ;
- Internet pendant l'installation (Wi-Fi ou câble).

## 1. Préparer la clé (sous Windows 7)

1. Télécharge **Linux Mint, édition Xfce, 64 bits** (la plus légère) : https://linuxmint.com/download.php. Tu obtiens un fichier `.iso` d'environ 3 Go.
2. Télécharge **Rufus 3.22** : https://github.com/pbatard/rufus/releases. C'est la dernière version qui fonctionne sous Windows 7 : Rufus 4 ne marche plus dessus. Prends `rufus-3.22.exe`.
3. Branche la clé, lance Rufus et règle :
   - **Périphérique** : ta clé ;
   - **Type de démarrage** : « Image disque ou ISO » → *Sélection* → l'ISO de Linux Mint ;
   - **Taille de la partition persistante** : pousse le curseur à **8 Go au moins**, le plus possible. C'est ce qui garde Nova, tes réglages et tes logs d'un démarrage à l'autre ;
   - **Schéma de partition** : MBR, système de destination « BIOS ou UEFI » (le plus compatible avec un PC de l'époque de Windows 7).
4. Clique sur **Démarrer** et accepte les questions (mode ISO recommandé, téléchargement de fichiers complémentaires).
5. Quand c'est fini, copie `Nova-Auto-1.2.3.zip` à la racine de la clé, dans l'Explorateur.

## 2. Démarrer sur la clé

1. Clé branchée, redémarre le PC et appuie tout de suite sur la touche du **menu de démarrage**. C'est souvent **F12**, sinon F9, F11, Échap ou F8 selon la marque.
2. Choisis la clé USB, puis **« Start Linux Mint »**.
3. Le bureau Linux s'ouvre au bout d'une minute ou deux.
4. Connecte-toi au Wi-Fi : icône réseau en bas à droite.

## 3. Transformer la clé en Nova OS (une seule fois)

Au premier démarrage, c'est encore le bureau Linux Mint : il sert juste à installer Nova.

1. Ouvre le dossier de la clé : icône « Poste de travail », puis le volume de la clé. Copie `Nova-Auto-1.2.3.zip` dans ton **Dossier personnel** et fais clic droit → « Extraire ici ».
2. Ouvre un **Terminal** (menu → Terminal) et tape :
   ```
   bash ~/nova-auto/scripts/pc/installer-nova-os.sh
   ```
   Le mot de passe demandé en live est vide : appuie simplement sur Entrée.
3. L'installation prend 5 à 10 minutes. Elle :
   - installe Node.js 22 et Chromium ;
   - rend les câbles accessibles sans réglage, avec la latence FTDI à 1 ms automatique ;
   - installe Nova ;
   - remplace le bureau par la session **Nova OS** ;
   - renomme le menu de démarrage de la clé en « Nova OS » et supprime l'attente.
4. À la fin, le script te propose de remplacer l'animation de démarrage Linux Mint par **celle de Nova** (le logo TT qui s'allume). Réponds `o` pour l'avoir. L'original est gardé (voir « Si ça coince »).
5. Redémarre :
   ```
   sudo reboot
   ```

## 4. Utiliser Nova OS

À chaque démarrage sur la clé :

1. le menu « Nova OS » ;
2. l'animation du logo ;
3. Nova en plein écran.

La première fois, ouvre les **Réglages** (roue dentée de l'écran de veille) :

- colle ta **clé Anthropic** ;
- **installe la voix** ;
- **télécharge la reconnaissance vocale**.

Ensuite, dans la voiture :

1. Branche le câble KKL et mets le contact.
2. Va dans **Diagnostic → Calculateurs → Tester la connexion**.

Le menu **Réglages → Nova OS** contient :

| Bouton | Ce qu'il fait |
|---|---|
| Menu Nova OS | ouvre le menu système. Il revient à Nova, ou ouvre le **bureau Linux** pour la maintenance (Wi-Fi, fichiers…), un terminal, ou redémarre. En quittant le bureau, Nova revient. |
| Éteindre | éteint proprement le PC |

## Si ça coince

| Problème | Solution |
|---|---|
| Le PC démarre sur Windows sans proposer la clé | Essaie une autre touche de menu, ou active « Boot from USB » dans le BIOS (souvent F2 ou Suppr au démarrage). |
| « Clé démarrée sans persistance » au lancement du script | Refais la clé avec Rufus en réglant bien la partition persistante. |
| La clé ne démarre plus après l'animation Nova | Branche la clé sous Windows. Dans son dossier `casper`, supprime `initrd` et renomme `initrd.mint` en `initrd`. Tu retrouves l'animation Linux Mint, et Nova OS fonctionne toujours. |
| Écran noir ou affichage bizarre | Au menu de démarrage, choisis « Nova OS (mode graphique de secours) ». |
| Le câble KKL n'apparaît pas | Débranche-le et rebranche-le. Dans le terminal du menu Nova OS, `ls /dev/ttyUSB*` doit afficher `/dev/ttyUSB0`. |
| Envoie-moi | `~/Nova/journal.log` et `~/Nova/session.log` |

Plus tard, pour que ce PC devienne une vraie machine Nova sans clé : installe Linux Mint sur le disque dur (icône « Install Linux Mint » du bureau de maintenance), puis relance le même script. Il cache alors aussi le menu de démarrage et met l'animation Nova automatiquement.
