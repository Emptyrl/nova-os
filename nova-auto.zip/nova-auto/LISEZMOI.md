# Nova Auto 1.11.0

Nova, l'IA de ta TT 225 quattro. Un seul programme, uniquement la partie fonctionnelle (plus aucune simulation) :

- il se connecte à la voiture par le câble branché : **KKL** (recommandé), ELM327, ou CAN par la NovaHAT ;
- il fait le **diagnostic complet de tous les calculateurs**, comme VCDS :
  - identification ;
  - codage ;
  - codes défaut ;
  - tous les groupes de mesure, valeur par valeur ;
- il lit le moteur en direct, enregistre les logs, surveille et déclenche les alertes ;
- il fait le test moteur guidé et apprend la voiture (rapports, courbe de couple, consommation) ;
- il affiche les écrans finaux (veille, lancement, tableau, média, diagnostic et calculateurs, rapports, apprentissage, alerte) ;
- il fait tourner le vrai cerveau de Nova, avec le double cerveau (voix rapide + cerveau réfléchi).

---

**PC sous Windows 7 :** Nova ne tourne pas dessus. Utilise la clé **Nova OS** : le PC démarre directement sur Nova. Voir `CLE-LINUX.md`.

## 1. Installer (une seule fois, sur le PC Windows)

1. Installe **Node.js 22 LTS** : https://nodejs.org
2. Extrais le zip (clic droit → « Extraire tout »).
3. Câble **KKL** dans la prise OBD (sous le volant) et en USB au PC. **Mets le contact.**
4. Double-clique sur **`lancer-nova.bat`**. La première fois, il installe les modules (2 à 3 minutes). Le navigateur s'ouvre ensuite sur http://localhost:47823 ; s'il affiche une erreur, actualise avec F5.

| Lanceur | Ce qu'il fait |
|---|---|
| `lancer-nova.bat` | trouve tout seul le câble branché, KKL ou ELM327 |
| `lancer-kkl.bat` | force le câble KKL (tu peux indiquer le port, ex. `COM4`) |
| `lancer-elm327.bat` | force l'ELM327 |

Sous Linux : `./lancer.sh auto` (ou `kkl /dev/ttyUSB0`).

**Réglage important du câble KKL sous Windows.** Dans le Gestionnaire de périphériques, ouvre Ports (COM et LPT), puis ton câble. Va dans Paramètres du port → Avancé et mets le **Temps de latence à 1 ms**. C'est le même réglage que pour VCDS-Lite : sans lui, le dialogue est lent et certains calculateurs raccrochent.

**Un seul logiciel à la fois sur le câble** : ferme VCDS, ME7Logger, etc.

## 2. Diagnostic → Calculateurs

Ouvre l'écran **Diagnostic**, puis le bouton **Calculateurs** en haut à droite. Le bouton « Test moteur » ramène au test guidé.

**Test de connexion** (colonne de droite). Nova vérifie, étape par étape :

1. le port ;
2. le type de câble ;
3. l'écho de la ligne K, c'est-à-dire que le câble est bien alimenté par la prise OBD ;
4. le réveil du calculateur moteur à 5 bauds ;
5. la synchro et les mots-clés (protocole KW1281 ou KWP2000) ;
6. l'identification ;
7. la lecture du groupe 001 ;
8. les codes défaut.

Si une étape échoue, Nova dit pourquoi et quoi faire. Tu peux aussi lui demander à la voix : « Nova, teste la connexion à la voiture ».

**Scanner tous les calculateurs** interroge toutes les adresses de la TT. Pour chacun, tu vois s'il est présent, sa référence et son codage, et ses codes défaut.

| Adresse | Calculateur | Adresse | Calculateur |
|---|---|---|---|
| 01 | moteur | 22 | Haldex |
| 02 | boîte auto | 25 | antidémarrage |
| 03 | ABS/ESP | 35 | verrouillage |
| 08 | clim | 45 | alarme |
| 15 | airbags | 46 | confort |
| 16 | colonne de direction | 47 | audio |
| 17 | combiné | 55 | phares |
| | | 56 | radio |

Ceux que ta voiture n'a pas répondent « absent ». Le rapport est enregistré dans `Nova\diagnostics\scan_….csv`.

Pour chaque calculateur (touche-le dans la liste, puis « Connecter ») :

- **Identification** : référence de pièce, désignation, **codage** et **code atelier (WSC)**.
- **Défauts** : code VAG à 5 chiffres et code OBD (P0xxx) quand il en a un, libellé, type de défaut, sporadique ou permanent, octet d'état. Le bouton « Effacer » demande une confirmation.
- **Mesures** : un groupe à la fois (001 à 255), lecture unique ou en continu. Chaque champ affiche :
  - son numéro (groupe.champ) ;
  - son libellé ;
  - sa valeur et son unité ;
  - la formule et les octets bruts (`formule 1 · a=100 b=42`).

  Les champs « bits » (comme les conditions du réglage de base, groupe 001.4) s'affichent bit par bit.
- **Tout lire** : Nova interroge les 255 groupes, garde tous ceux qui existent et affiche la grande liste. Le rapport CSV (`groupes_01_….csv`) donne pour chaque champ : calculateur, adresse, groupe, champ, libellé, valeur, unité, type de formule et octets a/b.

Les libellés exacts sont fournis pour le moteur ME7.5 (groupes 001-005, 020, 022, 023, 031-033, 060, 062, 091, 114, 115, 118). Ailleurs, le libellé vient de l'unité (« Vitesse », « Température », « Kilométrage »…), car les libellés VAG de chaque calculateur sont la propriété de Ross-Tech. Nova peut t'expliquer n'importe quel champ : « Nova, que veut dire le groupe 002 du combiné ? ».

Ce que Nova peut faire à la voix (outils) :

| Outil | Rôle |
|---|---|
| `connection_test` | test de connexion |
| `vag_scan` | scan de tous les calculateurs |
| `vag_module` | identification et défauts d'un calculateur |
| `vag_group` | un groupe de mesure |
| `vag_read_all` | lecture de tous les groupes |
| `vag_clear_faults` | effacement des codes défaut, avec ton accord |

## 3. Lecture du moteur en direct

Avec le câble KKL, Nova lit elle-même le ME7.5, sans logiciel externe. Elle tourne en boucle sur ces groupes et alimente le tableau de bord, les logs, les alertes et l'apprentissage :

| Groupe | Mesures |
|---|---|
| 003 | régime, débit d'air, papillon, avance |
| 115 | turbo réel et demandé |
| 002 | charge |
| 004 | batterie, eau, air |
| 005 | vitesse |
| 020 | recul d'allumage par cylindre |
| 031 / 032 | lambda et adaptations |

Quand tu fais du diagnostic sur un autre calculateur, la lecture moteur se met en pause et reprend 20 s après.

La ligne K est lente : compte 1 à 3 rafraîchissements par seconde du régime. Pour des logs très rapides (20 à 50 mesures/s), ME7Logger reste possible : source « ME7Logger (fichier CSV) » dans les Réglages, avec le chemin du fichier dans `"kklCsvFile"` de `voiture.json`.

Avec un **ELM327**, Nova lit les données OBD standard du moteur et ses codes défaut. Ce câble ne sait pas dialoguer avec les autres calculateurs (ABS, airbags, combiné…) : pour eux, il faut le KKL.

## 4. Le cerveau (Claude)

Sans réglage, Nova utilise la connexion Claude Code du PC : `npm install -g @anthropic-ai/claude-code`, puis `claude` et `/login`.
Sinon, colle ta clé Anthropic dans **Réglages → Cerveau**. Elle est enregistrée dans `config.json` et n'est jamais affichée en entier.

Le cerveau réfléchi seul met environ 7 s et coûte environ 0,20 $ par réponse, d'où le double cerveau ci-dessous. Le modèle du réfléchi se règle avec `"model"` dans `config.json` (vide = par défaut, ou `"sonnet"`).

### Double cerveau (voix rapide + cerveau réfléchi)

Pour supprimer l'attente et les blancs, Nova a deux cerveaux :

1. **La voix rapide** (Haiku, réglage `fastModel`) reçoit ta question avec l'état de la voiture en direct et commence à parler en moins d'une seconde. Si elle a tout ce qu'il faut (« l'huile est à combien ? », un conseil, une discussion), elle répond seule. C'est rapide et ça coûte environ 0,002 $.
2. Sinon, elle dit tout de suite ce qu'elle sait de sûr et passe le relais au **cerveau réfléchi** (Agent SDK, outils, équipe). Cela concerne l'analyse de logs, le diagnostic, la musique, le web, les actions…
3. Pendant que le réfléchi travaille, la voix rapide comble les blancs avec ce qu'il fait vraiment (« j'analyse le fichier du 25 octobre ») : au plus 3 phrases, jamais de résultat inventé.
4. Quand le réfléchi a fini, elle **restitue** son rapport en deux ou trois phrases. Les détails sont à l'écran.

Testé sur un faux serveur Anthropic, avec ces délais avant le premier mot :

| Question | Ce qui se passe | Premier mot |
|---|---|---|
| Question simple | la voix rapide répond seule | 0,4 s |
| Analyse de log | relais au réfléchi, une phrase pendant l'attente, puis la restitution | 0,4 s |

Il faut ajouter le temps de la voix de synthèse, environ 0,3 s.

**La voix rapide a besoin d'une clé Anthropic** (Réglages → Cerveau). Sans clé, si elle est désactivée, ou si le réseau ne répond pas, Nova répond comme avant avec le cerveau réfléchi seul. Le journal note pour chaque question : seule ou relais, temps du premier mot, nombre de mots envoyés.

Ce que Nova sait faire dans la voiture (outils) :

| Outil | Rôle |
|---|---|
| `car_status`, `car_history` | mesures en direct, tendance sur 5 minutes |
| `show_screen` | « Nova, montre le diagnostic » |
| `log_start` / `log_stop` / `log_list` / `log_analyze` | logs, et leur analyse (elle peut aussi lire le CSV entier) |
| `read_dtc` / `clear_dtc` | codes défaut ; l'effacement te demande ton accord |
| `diagnostic_start` / `diagnostic_status` | diagnostic guidé |
| `shift_points` / `learning_status` | passages de rapport, ce qu'elle a appris |
| `set_drive_mode` | Normal / Sport / Attack |
| `show_alert` | alerte plein écran |
| `led_logo` | logo lumineux à l'avant |
| `fis_text` | écran du combiné, 2 × 8 caractères |
| `remote_start` / `remote_stop` | démarrage à distance |
| `set_fuel`, `trip_reset` | plein fait, trajet remis à zéro |

Elle garde aussi tout ce qu'elle avait dans la v0.14.1 :

- mémoire (`remember`) ;
- l'équipe d'employés : chercheur, penseur, développeur, **mécanicien**, etc. ;
- second avis GPT et Gemini, si les clés sont mises ;
- recherche web ;
- fenêtres à l'écran ;
- YouTube Music (`music_play`).

## 5. Voix

- **Réveil « Nova »** : le modèle de mot-clé est fourni (5 Mo, `models/kws`).
- **Reconnaissance vocale locale** (sans Internet) : Réglages → Voix → *Télécharger* (≈ 100 Mo, une fois). En attendant, le navigateur fait la reconnaissance (par Internet).
- **Voix de Nova** : Réglages → Voix → *Installer la voix* (Siwis, 67 Mo, une fois). Sans voix installée, Nova parle avec la voix du système.

Quand tu parles à Nova, l'écran de veille s'affiche, les mots s'allument au rythme de la voix, puis Nova revient à l'écran d'avant.
Les alertes et les fins de diagnostic sont dites sans changer d'écran.

## Mises à jour sans refaire l'image

**Réglages → Mises à jour** : Nova récupère le `nova-auto.zip` de ton dépôt GitHub et l'installe. L'écran se relance tout seul sur la nouvelle version. Les modules restent ceux de l'image, donc seul le programme (≈ 5 Mo) est téléchargé.

- **Dépôt privé** : ajoute un jeton GitHub en lecture seule (« Jeton GitHub »).
- **Sans Internet** : pose `nova-auto.zip` à la racine de la clé depuis Windows, Nova l'installe au démarrage suivant.
- **Refaire l'image** n'est nécessaire que si le système change, ou si une version de Nova a besoin d'un nouveau module. Dans ce dernier cas, Nova essaie de l'installer par Internet et garde l'ancienne version si ça échoue.

## Base de libellés (facultative)

Si tu as une base `base_diagnostic.sqlite` (libellés de calculateurs VAG), pose-la :

- à la racine de la clé Nova OS, depuis Windows ;
- ou dans ton dossier `Nova`.

Nova la trouve toute seule. Elle n'est pas fournie avec Nova. Avec elle, l'écran **Calculateurs** :

- nomme chaque valeur comme VCDS, avec sa plage normale ;
- colore la valeur : vert dans la spécification, rouge hors spécification ;
- explique les bits des champs comme « Conditions du réglage de base » ;
- liste les groupes par leur nom ;
- décode le codage option par option ;
- liste les canaux d'adaptation et les codes d'accès (onglet **Infos**).

Sans elle, Nova garde ses propres libellés.

Onglets **Rég. base** (réglage de base, ex. groupe 060 : adaptation du papillon) et **Actionneurs** (test des actionneurs un par un) : contact mis, moteur arrêté, calculateurs en KW1281.

## 6. Logs et journal

Tout est dans ton dossier **Nova** : `C:\Users\<toi>\Nova` sous Windows, `~/Nova` sous Linux.

| Fichier | Contenu |
|---|---|
| `logs/log_AAAA-MM-JJ_HHMMSS.csv` | une ligne toutes les 0,1 s (0,05 s en apprentissage). Séparateur `;` et virgule décimale : s'ouvre directement dans Excel. |
| `journaux/nova.log` | tout ce qui se passe : connexions, alertes, relais, questions et réponses de Nova, erreurs |
| `journaux/demarrage.log` | temps de démarrage à chaque allumage : système, services les plus lents, cerveau, premier écran |
| `journaux/ecran.log` | l'écran : erreurs, images par seconde toutes les 30 s, carte graphique, écrans ouverts, plantages |
| `journaux/systeme.log` | mémoire, processeur, températures, processus gourmands, erreurs du noyau, plantages de l'affichage |
| `journaux/cables.log` | détection des câbles KKL / ELM327, port par port et vitesse par vitesse |
| `journaux/session.log`, `chromium.log`, `nova-console.log` | la session Nova OS, le navigateur et la sortie brute du cerveau |
| `diagnostics/diagnostic_*.json` | résultats de chaque diagnostic |
| `voiture.json` | réglages de la voiture (source, port, E85, seuils d'alerte, broches GPIO…) |
| `voiture-appris.json` | ce que Nova a appris : rapports, courbe de couple, carburant, km |
| `config.json`, `memoire.md`, `equipe.json` | le cerveau, comme dans la v0.14.1 |

Les journaux se lisent dans **Réglages → Journaux**. « Exporter le rapport complet » les rassemble en un fichier, copié sur la clé Nova OS (dossier `nova-journaux`, lisible sous Windows) : envoie-le-moi.

Les logs démarrent tout seuls quand le moteur tourne et s'arrêtent 30 s après l'arrêt. Le bouton « Log 20 Hz » de l'écran Apprentissage force un log rapide.

## 7. Carburant E85

La consommation est calculée depuis le débit d'air avec la stœchiométrie de l'E85 : AFR 9,8 et densité 0,785. Repasse en SP98 dans les Réglages si besoin.
Le niveau du réservoir est estimé (l'OBD ne le donne pas) : après un plein, dis « Nova, j'ai fait le plein, 62 litres », ou mets la valeur dans les Réglages.

## 8. Ce que Nova calcule elle-même

- **Rapport engagé** : vitesse comparée au régime.
- **Apprentissage des rapports** : six valeurs mesurées en roulant normalement.
- **Courbe de couple** : déduite de l'accélération pendant deux tirages en 3e, de 2 000 tr/min au rupteur. Elle tient compte de la masse (1 480 kg), de l'aéro et du roulement. Fais ces tirages sur circuit ou route fermée uniquement.
- **Points de passage** : recalculés avec ce qui a été appris. La shift light du tableau s'allume au bon régime selon le mode.
- **Répartition avant/arrière** : le Haldex ne donne rien sur la prise OBD, donc c'est une estimation, et l'écran l'indique.

## 9. Sur le Raspberry Pi (plus tard)

```
bash scripts/pi/installer-pi.sh
```

Le script installe Node, Chromium, can-utils, scrcpy, KDE Connect et les bibliothèques de la NovaHAT. Il active aussi :

- le CAN (MCP2515, 500 kbit/s, écoute seule) ;
- l'extinction propre et le chien de garde ;
- le service `nova` ;
- Chromium plein écran sur Nova au démarrage.

Ensuite, mets `"source": "can+kkl"` dans `~/Nova/voiture.json`.

Sur le Pi, `scripts/novahat.py` pilote les relais, lit les entrées (contact, phares → mode nuit, marche arrière, frein à main), la tension batterie (ADS1115), le logo LED et le FIS.

**À vérifier sur la voiture avant de s'y fier :**

- **Identifiants CAN** :
  - Sûrs : régime `0x280`, vitesse `0x1A0`, roues `0x4A0`, eau `0x288`.
  - Probables : carburant `0x320`, extérieur `0x420`.
  - Active `"canRawLog": true` et donne le fichier à Nova pour qu'elle décode le reste.
- **FIS** : protocole radio 3 fils, tiré de la bibliothèque VAGFISWriter. Il n'est pas encore essayé sur ton combiné. Les broches sont `fisEna`, `fisClk` et `fisData`, et `fisInvert` sert si l'adaptateur à transistors inverse les signaux.
- **Tension batterie** : étalonne `adcRatio` au multimètre.
- **Démarrage à distance** :
  - Nova refuse si elle ne reçoit pas le régime et les 4 roues sur le CAN.
  - Elle coupe tout si une roue bouge.
  - Elle s'arrête au bout de 10 minutes (`remoteRunMinutes`).
  - Essaie-le d'abord roues avant levées ou boîte au point mort, quelqu'un à côté.

Sur le PC il n'y a pas de NovaHAT : Nova le dit, et les relais, le logo et le FIS ne sont pas pilotés.

## 10. Média et téléphone (sur le Pi)

| Fonction | Comment |
|---|---|
| Musique du téléphone | Bluetooth, contrôlée par `playerctl` |
| Musique en 4G | YouTube Music dans le navigateur de Nova (« Nova, mets… ») |
| Waze / Maps | sur le téléphone, affiché dans le cadre par **scrcpy** (câble USB, débogage USB activé) |
| Notifications et batterie du téléphone | KDE Connect |
| YouTube | à l'arrêt seulement |

Sur un PC Windows, ces fonctions ne sont pas disponibles.

## 11. Structure

```
src/server.ts           serveur : cerveau + voiture + écrans (http://localhost:47823)
src/brain/              le cerveau de Nova v0.14.1, adapté à Linux et à la voiture
src/car/vag/            client VAG sur câble KKL : réveil 5 bauds, KW1281, KWP2000, formules, calculateurs
src/car/                sources, store de mesures, logs, alertes, diagnostic, apprentissage,
                        points de passage, matériel NovaHAT, démarrage à distance, téléphone, outils
web/                    les 8 écrans (HTML/JS sans dépendance, police Chakra Petch incluse)
scripts/novahat.py      pilote des broches du Pi
scripts/pi/             installation sur le Raspberry Pi
models/kws              modèle du mot d'activation
```

Pour modifier le code : `npm run build`, puis relance.

## Sécurité

Nova lit la voiture. Elle n'envoie rien sur le bus CAN et ne touche jamais à l'accélérateur, aux freins ni à la direction.
Ne regarde pas le PC en roulant pendant tes essais : pose-le sur le siège passager, fais conduire quelqu'un, ou teste à l'arrêt moteur tournant.
