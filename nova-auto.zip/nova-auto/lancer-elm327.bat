@echo off
rem Nova sur la voiture avec l'ELM327 (contact mis). Le port se trouve dans
rem Gestionnaire de périphériques > Ports (COM et LPT). Laisse vide pour la recherche automatique.
cd /d "%~dp0"
if not exist node_modules (echo Installation des modules, une seule fois... & call npm install)
if not exist dist (call npm run build)
set /p PORT=Port de l'ELM327 (ex. COM3, vide = automatique) : 
start "" cmd /c "timeout /t 4 >nul & start http://localhost:47823"
if "%PORT%"=="" (node dist\server.js --source elm327) else (node dist\server.js --source elm327 --port %PORT%)
pause
