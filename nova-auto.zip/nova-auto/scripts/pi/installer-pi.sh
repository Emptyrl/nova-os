#!/usr/bin/env bash
# Installation de Nova sur le Raspberry Pi 5 (Raspberry Pi OS Bookworm 64 bits, bureau).
# À lancer depuis le dossier de Nova :  bash scripts/pi/installer-pi.sh
# Relis chaque étape avant : le script modifie config.txt et installe des services.
set -e
NOVA_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
USER_NAME="$(whoami)"

echo "== Paquets système"
sudo apt update
sudo apt install -y chromium-browser can-utils python3-lgpio python3-smbus2 playerctl kdeconnect scrcpy adb i2c-tools
pip install --break-system-packages Adafruit-Blinka-Raspberry-Pi5-Neopixel || echo "Logo LED : bibliothèque à installer à la main"

echo "== Node.js 22"
if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1)" != "v22" ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt install -y nodejs
fi
cd "$NOVA_DIR" && npm install && npm run build

echo "== NovaHAT : CAN (MCP2515), extinction propre, chien de garde"
CFG=/boot/firmware/config.txt
grep -q "mcp2515-can0" $CFG || echo "dtoverlay=mcp2515-can0,oscillator=16000000,interrupt=25" | sudo tee -a $CFG
grep -q "gpio-poweroff" $CFG || echo "dtoverlay=gpio-poweroff,gpiopin=17,active_low=1" | sudo tee -a $CFG
grep -q "dtparam=watchdog=on" $CFG || echo "dtparam=watchdog=on" | sudo tee -a $CFG
grep -q "dtparam=i2c_arm=on" $CFG || echo "dtparam=i2c_arm=on" | sudo tee -a $CFG
sudo mkdir -p /etc/systemd/system.conf.d
printf "[Manager]\nRuntimeWatchdogSec=15\n" | sudo tee /etc/systemd/system.conf.d/watchdog.conf
# bus CAN à 500 kbit/s, en écoute seule
printf "[Match]\nName=can0\n\n[CAN]\nBitRate=500K\nListenOnly=yes\n" | sudo tee /etc/systemd/network/80-can.network
sudo systemctl enable systemd-networkd

echo "== Service Nova (démarre avec le Pi)"
sudo tee /etc/systemd/system/nova.service >/dev/null <<UNIT
[Unit]
Description=Nova (IA de la TT)
After=network.target

[Service]
User=$USER_NAME
WorkingDirectory=$NOVA_DIR
Environment=NOVA_HOME=/home/$USER_NAME/Nova
ExecStart=/usr/bin/node $NOVA_DIR/dist/server.js
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable nova
# l'arrêt du Pi est autorisé à Nova (coupure batterie basse)
echo "$USER_NAME ALL=(root) NOPASSWD: /usr/bin/systemctl poweroff" | sudo tee /etc/sudoers.d/nova-poweroff

echo "== Écran : Chromium plein écran sur Nova au démarrage du bureau"
mkdir -p ~/.config/labwc
AUTO=~/.config/labwc/autostart
grep -q "localhost:47823" $AUTO 2>/dev/null || echo "chromium-browser --kiosk --noerrdialogs --disable-infobars --use-fake-ui-for-media-stream --autoplay-policy=no-user-gesture-required --check-for-update-interval=31536000 --ignore-gpu-blocklist --enable-gpu-rasterization http://localhost:47823 &" >> $AUTO

echo
echo "Fini. Avant de redémarrer :"
echo " 1. Mets la source dans ~/Nova/voiture.json : \"source\": \"can+kkl\" (ou \"can\")"
echo " 2. Redémarre : sudo reboot"
echo " 3. Vérifie le CAN : candump can0   (contact mis, des trames doivent défiler)"
