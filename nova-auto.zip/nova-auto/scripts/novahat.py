#!/usr/bin/env python3
"""Pilote de la carte NovaHAT sur le Raspberry Pi 5, lancé par Nova.

Entrée standard : une commande JSON par ligne. Sortie standard : événements JSON.
  {"cmd":"init", ...}                    broches et réglages (envoyé par Nova au démarrage)
  {"cmd":"out","name":"starter","on":true}
  {"cmd":"led","effect":"breathe","rgb":[255,255,255],"brightness":0.6}
  {"cmd":"level","v":0.7}                niveau de la voix (effet « speak »)
  {"cmd":"fis","l1":"NOVA    ","l2":"PRETE   "}

Bibliothèques (Raspberry Pi OS) :
  sudo apt install python3-lgpio python3-smbus2
  pip install --break-system-packages Adafruit-Blinka-Raspberry-Pi5-Neopixel   (logo LED sur Pi 5)
Chaque partie est facultative : si une bibliothèque manque, le reste fonctionne.
"""
import colorsys
import json
import math
import sys
import threading
import time

state = {"led": {"effect": "breathe", "rgb": [241, 243, 245], "brightness": 0.6}, "level": 0.0, "fis": None}
lock = threading.Lock()
cfg = {}
features = {}


def emit(**kw):
    sys.stdout.write(json.dumps(kw) + "\n")
    sys.stdout.flush()


# ---------- GPIO (relais et entrées) ----------
def open_chip():
    """Pi 5 : les broches du connecteur sont sur la puce « rp1 » (gpiochip0 ou gpiochip4 selon le noyau)."""
    for n in (0, 4):
        try:
            hh = lgpio.gpiochip_open(n)
        except Exception:
            continue
        try:
            label = str(lgpio.gpio_get_chip_info(hh)[2]).lower()
        except Exception:
            label = ""
        if "rp1" in label or n == 4:
            return hh
        lgpio.gpiochip_close(hh)
    raise RuntimeError("puce GPIO du connecteur introuvable")


try:
    import lgpio

    h = open_chip()
    features["gpio"] = True
except Exception as e:  # pas sur un Pi, ou lgpio absent
    h = None
    features["gpio"] = "absent: %s" % e


def setup_io():
    if h is None:
        return
    for name, pin in cfg.get("outputs", {}).items():
        lgpio.gpio_claim_output(h, pin, 0)
    for name, pin in cfg.get("inputs", {}).items():
        # entrées par optocoupleur : actives à l'état bas, tirage interne vers le haut
        lgpio.gpio_claim_input(h, pin, lgpio.SET_PULL_UP)
    fis = cfg.get("fis")
    if fis:
        for p in (fis["ena"], fis["clk"], fis["data"]):
            lgpio.gpio_claim_output(h, p, idle_level(fis))


def idle_level(fis):
    # bus FIS au repos : CLK et DATA hauts côté combiné ; avec l'adaptateur à transistors, 0 côté Pi
    return 0 if fis.get("invert") else 1


def watch_inputs():
    last = {}
    while True:
        if h is not None:
            for name, pin in cfg.get("inputs", {}).items():
                try:
                    v = 1 if lgpio.gpio_read(h, pin) == 0 else 0
                except Exception:
                    continue
                if last.get(name) != v:
                    last[name] = v
                    emit(ev="in", name=name, v=v)
        time.sleep(0.1)


# ---------- tension batterie (ADS1115 à l'adresse 0x48) ----------
def watch_adc():
    try:
        from smbus2 import SMBus

        bus = SMBus(1)
        features["adc"] = True
    except Exception as e:
        features["adc"] = "absent: %s" % e
        return
    adc = cfg.get("adc", {"channel": 0, "ratio": 5.7})
    mux = {0: 0x4000, 1: 0x5000, 2: 0x6000, 3: 0x7000}[int(adc.get("channel", 0))]
    while True:
        try:
            # mesure unique, gain ±4,096 V, 128 échantillons/s
            conf = 0x8000 | mux | 0x0200 | 0x0100 | 0x0080 | 0x0003
            bus.write_i2c_block_data(0x48, 0x01, [conf >> 8, conf & 0xFF])
            time.sleep(0.01)
            hi, lo = bus.read_i2c_block_data(0x48, 0x00, 2)
            raw = (hi << 8) | lo
            if raw > 0x7FFF:
                raw -= 0x10000
            volts = raw * 4.096 / 32768 * float(adc.get("ratio", 5.7))
            emit(ev="adc", volt=round(volts, 2))
        except Exception as e:
            emit(ev="err", msg="ADS1115 : %s" % e)
            time.sleep(5)
        time.sleep(1)


# ---------- logo LED (WS2812) ----------
def led_loop():
    try:
        import board
        import neopixel

        pin = getattr(board, "D%d" % cfg.get("led", {}).get("pin", 18))
        n = int(cfg.get("led", {}).get("count", 30))
        pixels = neopixel.NeoPixel(pin, n, auto_write=False, brightness=1.0)
        features["led"] = True
    except Exception as e:
        features["led"] = "absent: %s" % e
        return
    t0 = time.time()
    while True:
        with lock:
            led = dict(state["led"])
            level = state["level"]
        t = time.time() - t0
        eff, rgb, br = led["effect"], led["rgb"], float(led["brightness"])
        k = 0.0
        if eff == "solid":
            k = 1
        elif eff == "breathe":
            k = 0.35 + 0.65 * (0.5 - 0.5 * math.cos(t * 2 * math.pi / 8))
        elif eff == "pulse":
            k = 0.2 + 0.8 * (0.5 - 0.5 * math.cos(t * 2 * math.pi / 1.0))
        elif eff == "speak":
            k = 0.35 + 0.65 * min(1.0, level)
        for i in range(n):
            if eff == "scan":
                pos = (math.sin(t * 2.2) * 0.5 + 0.5) * (n - 1)
                kk = max(0.0, 1 - abs(i - pos) / 2.5)
            elif eff == "rainbow":
                r, g, b = colorsys.hsv_to_rgb((i / n + t * 0.1) % 1, 1, 1)
                pixels[i] = (int(r * 255 * br), int(g * 255 * br), int(b * 255 * br))
                continue
            else:
                kk = k if eff != "off" else 0
            pixels[i] = tuple(int(v * kk * br) for v in rgb)
        pixels.show()
        time.sleep(0.03)


# ---------- écran FIS du combiné (protocole radio 3 fils, ENA / CLK / DATA) ----------
def fis_send(l1, l2):
    """Paquet radio : 0xF0, 16 caractères, somme de contrôle 0xFF ^ (somme sur 8 bits).
    Chaque octet est envoyé inversé, bit de poids fort d'abord, lu sur le front descendant de CLK.
    D'après la bibliothèque VAGFISWriter (tomaskovacik) : à valider sur ton combiné."""
    fis = cfg.get("fis")
    if h is None or not fis:
        return
    inv = bool(fis.get("invert"))

    def w(pin, level):
        lgpio.gpio_write(h, pin, (1 - level) if inv else level)

    data = [ord(c) & 0x7F for c in (l1 + l2)[:16].ljust(16)]
    crc = 0xF0
    for b in data:
        crc = (crc + b) & 0xFF
    packet = [0xF0] + data + [0xFF ^ crc]
    w(fis["ena"], 1)
    time.sleep(0.0001)
    for byte in packet:
        out = 0xFF ^ byte
        for bit in range(7, -1, -1):
            w(fis["data"], (out >> bit) & 1)
            w(fis["clk"], 0)
            time.sleep(0.000004)
            w(fis["clk"], 1)
            time.sleep(0.000004)
        w(fis["data"], 1)
        time.sleep(0.0001)
    w(fis["ena"], 0)


def fis_loop():
    last = None
    while True:
        with lock:
            cur = state["fis"]
        # le combiné efface le texte s'il n'est pas répété : on le renvoie toutes les 500 ms
        if cur:
            try:
                fis_send(*cur)
            except Exception as e:
                emit(ev="err", msg="FIS : %s" % e)
                time.sleep(2)
        time.sleep(0.5 if cur == last else 0.1)
        last = cur


def main():
    global cfg
    for line in sys.stdin:
        try:
            m = json.loads(line)
        except Exception:
            continue
        c = m.get("cmd")
        if c == "init":
            cfg = m
            setup_io()
            for fn in (watch_inputs, watch_adc, led_loop, fis_loop):
                threading.Thread(target=fn, daemon=True).start()
            time.sleep(0.5)
            emit(ev="ready", features=features)
        elif c == "out" and h is not None:
            pin = cfg.get("outputs", {}).get(m.get("name"))
            if pin is not None:
                lgpio.gpio_write(h, pin, 1 if m.get("on") else 0)
        elif c == "led":
            with lock:
                state["led"] = {"effect": m.get("effect", "solid"), "rgb": m.get("rgb", [255, 255, 255]), "brightness": m.get("brightness", 0.6)}
        elif c == "level":
            with lock:
                state["level"] = float(m.get("v", 0))
        elif c == "fis":
            with lock:
                state["fis"] = (m.get("l1", ""), m.get("l2", "")) if (m.get("l1", "").strip() or m.get("l2", "").strip()) else None
    # Nova s'est arrêtée : on relâche tous les relais
    if h is not None:
        for pin in cfg.get("outputs", {}).values():
            lgpio.gpio_write(h, pin, 0)


if __name__ == "__main__":
    main()
