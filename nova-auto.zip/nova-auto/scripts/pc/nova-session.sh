#!/usr/bin/env bash
# Session Nova OS : le cerveau tourne, l'écran de Nova occupe tout l'écran. Pas de bureau.
#   nova-session.sh --session   session complète (lancée au démarrage par Nova OS) : quand on ferme
#                               Nova (Réglages → Menu Nova OS, ou Alt + F4), un menu propose de revenir,
#                               d'ouvrir le bureau Linux pour la maintenance, un terminal, redémarrer ou éteindre.
#   nova-session.sh             une seule fois (icône Nova depuis le bureau Linux)
APP="$(cd "$(dirname "$0")/../.." && pwd)"
LOG="$HOME/Nova/session.log"
mkdir -p "$HOME/Nova"
URL="http://localhost:47823"
SESSION=""
[ "$1" = "--session" ] && SESSION=1

# fond sombre pendant le chargement, pas de veille d'écran, pas de curseur au repos
xsetroot -solid "#0E1013" 2>/dev/null || true
xset s off -dpms 2>/dev/null || true
command -v unclutter >/dev/null && { unclutter -idle 2 >/dev/null 2>&1 & }

start_brain() {
  curl -s -o /dev/null "$URL" && return
  (cd "$APP" && exec node dist/server.js >>"$LOG" 2>&1) &
  BRAIN=$!
  for _ in $(seq 1 60); do
    curl -s -o /dev/null "$URL" && break
    sleep 0.5
  done
}

screen_nova() {
  local FLAGS=(--kiosk --noerrdialogs --disable-infobars --no-first-run --password-store=basic
    --use-fake-ui-for-media-stream --autoplay-policy=no-user-gesture-required
    --check-for-update-interval=31536000 --user-data-dir="$HOME/.config/nova-ecran"
    --ignore-gpu-blocklist --enable-gpu-rasterization --enable-zero-copy
    --disable-session-crashed-bubble --disable-features=Translate)
  if command -v chromium >/dev/null; then chromium "${FLAGS[@]}" "$URL"
  elif command -v chromium-browser >/dev/null; then chromium-browser "${FLAGS[@]}" "$URL"
  elif command -v google-chrome >/dev/null; then google-chrome "${FLAGS[@]}" "$URL"
  else firefox --kiosk "$URL"
  fi
}

start_brain

if [ -z "$SESSION" ]; then
  screen_nova
  exit 0
fi

while true; do
  screen_nova
  CHOICE=$(zenity --list --title="Nova OS" --text="Nova est en pause." --hide-header --column="Action" \
    "Revenir à Nova" "Bureau Linux (maintenance)" "Terminal" "Redémarrer" "Éteindre" \
    --width=420 --height=330 2>/dev/null)
  case "$CHOICE" in
    "Bureau Linux (maintenance)") startxfce4 || xfce4-session || true ;;
    "Terminal") xfce4-terminal --maximize || x-terminal-emulator || xterm ;;
    "Redémarrer") systemctl reboot ;;
    "Éteindre") systemctl poweroff ;;
    *) ;; # Revenir à Nova (ou fenêtre fermée)
  esac
  start_brain
done
