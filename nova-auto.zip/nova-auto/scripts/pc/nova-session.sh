#!/usr/bin/env bash
# Session Nova OS : le cerveau tourne, l'écran de Nova occupe tout l'écran. Pas de bureau.
#   nova-session.sh --session   session complète (lancée au démarrage par Nova OS) : quand on ferme
#                               Nova (Réglages → Menu Nova OS, ou Alt + F4), un menu propose de revenir,
#                               d'ouvrir le bureau Linux pour la maintenance, un terminal, redémarrer ou éteindre.
#   nova-session.sh             une seule fois (icône Nova depuis le bureau Linux)
APP="$(cd "$(dirname "$0")/../.." && pwd)"
LOG="$HOME/Nova/session.log"
mkdir -p "$HOME/Nova"
URL="http://localhost:47823"
SESSION=""
[ "$1" = "--session" ] && SESSION=1
echo "== session $(date '+%F %T')" >>"$LOG"

# fond sombre pendant le chargement, pas de veille d'écran, pas de curseur au repos
xsetroot -solid "#0E1013" 2>/dev/null || true
xset s off -dpms 2>/dev/null || true
command -v unclutter >/dev/null && { unclutter -idle 2 >/dev/null 2>&1 & }

# résolution choisie dans Réglages → Écran (sinon celle de l'écran)
apply_screen() {
  [ -f "$HOME/Nova/ecran.conf" ] || return
  read -r OUT MODE <"$HOME/Nova/ecran.conf" || true
  [ -n "$OUT" ] && [ -n "$MODE" ] && xrandr --output "$OUT" --mode "$MODE" >>"$LOG" 2>&1 || true
}
screen_size() {
  # taille actuelle de l'écran, ex. 1920x1080
  xrandr 2>/dev/null | awk '/\*/{print $1; exit}' | grep -Eo '^[0-9]+x[0-9]+' || echo "1024x600"
}

# gestionnaire de fenêtres léger : sans lui, Chromium ne sait pas se mettre en plein écran
# et Maps / Waze du téléphone ne peuvent pas s'afficher par-dessus
start_wm() {
  [ -n "$SESSION" ] || return
  pgrep -x xfwm4 >/dev/null && return
  command -v xfwm4 >/dev/null && { xfwm4 --compositor=off >>"$LOG" 2>&1 & }
  sleep 0.3
}

# téléphone : KDE Connect (notifications, batterie) et commandes de musique Bluetooth
start_phone() {
  [ -n "$SESSION" ] || return
  for d in /usr/lib/x86_64-linux-gnu/libexec/kdeconnectd /usr/libexec/kdeconnectd /usr/lib/kdeconnectd; do
    [ -x "$d" ] && { pgrep -f kdeconnectd >/dev/null || { "$d" >>"$LOG" 2>&1 & }; break; }
  done
  command -v mpris-proxy >/dev/null && { pgrep -x mpris-proxy >/dev/null || { mpris-proxy >>"$LOG" 2>&1 & }; }
}

start_brain() {
  curl -s -o /dev/null "$URL" && return
  (cd "$APP" && exec node dist/server.js >>"$LOG" 2>&1) &
}

screen_nova() {
  local SIZE W H
  SIZE="$(screen_size)"
  W="${SIZE%x*}"
  H="${SIZE#*x}"
  local FLAGS=(--kiosk --start-fullscreen --window-position=0,0 --window-size="$W,$H"
    --noerrdialogs --disable-infobars --no-first-run --password-store=basic
    --use-fake-ui-for-media-stream --autoplay-policy=no-user-gesture-required
    --check-for-update-interval=31536000 --user-data-dir="$HOME/.config/nova-ecran"
    --ignore-gpu-blocklist --enable-gpu-rasterization --force-device-scale-factor=1
    --disable-session-crashed-bubble --disable-features=Translate,MediaRouter
    --disable-background-networking --disable-component-update)
  # page de chargement locale : le logo s'affiche tout de suite, Nova prend le relais dès que le cerveau répond
  local START="$URL"
  [ -f "$APP/web/demarrage.html" ] && START="file://$APP/web/demarrage.html"
  if command -v chromium >/dev/null; then chromium "${FLAGS[@]}" "$START"
  elif command -v chromium-browser >/dev/null; then chromium-browser "${FLAGS[@]}" "$START"
  elif command -v google-chrome >/dev/null; then google-chrome "${FLAGS[@]}" "$START"
  else firefox --kiosk "$URL"
  fi >>"$LOG" 2>&1
}

apply_screen
start_wm
start_brain
start_phone

if [ -z "$SESSION" ]; then
  screen_nova
  exit 0
fi

while true; do
  screen_nova
  CHOICE=$(zenity --list --title="Nova OS" --text="Nova est en pause." --hide-header --column="Action" \
    "Revenir à Nova" "Bureau Linux (maintenance)" "Terminal" "Redémarrer" "Éteindre" \
    --width=420 --height=330 2>/dev/null)
  case "$CHOICE" in
    "Bureau Linux (maintenance)")
      pkill -x xfwm4 2>/dev/null
      startxfce4 || xfce4-session || true
      start_wm ;;
    "Terminal") xfce4-terminal --maximize || x-terminal-emulator || xterm ;;
    "Redémarrer") systemctl reboot ;;
    "Éteindre") systemctl poweroff ;;
    *) ;; # Revenir à Nova (ou fenêtre fermée)
  esac
  apply_screen
  start_brain
done
