#!/usr/bin/env bash
# Session Nova OS : le cerveau tourne, l'écran de Nova occupe tout l'écran. Pas de bureau.
#   nova-session.sh --session   session complète (lancée au démarrage par Nova OS) : quand on ferme
#                               Nova (Réglages → Menu Nova OS, ou Alt + F4), un menu propose de revenir,
#                               d'ouvrir le bureau Linux pour la maintenance, un terminal, redémarrer ou éteindre.
#   nova-session.sh             une seule fois (icône Nova depuis le bureau Linux)
# Tout est noté dans ~/Nova/journaux/session.log (et chromium.log pour le navigateur).
APP="$(cd "$(dirname "$0")/../.." && pwd)"
NOVA="${NOVA_HOME:-$HOME/Nova}"
LOGDIR="$NOVA/journaux"
mkdir -p "$LOGDIR"
LOG="$LOGDIR/session.log"

# ---------- mises à jour de Nova sans refaire l'image ----------
# La version la plus récente gagne : celle de l'image (/opt/nova), celle installée par Réglages →
# Mises à jour (~/Nova/app), ou un nova-auto.zip posé sur la clé (racine, ou dossier nova-maj).
ver_of() { sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' "$1/package.json" 2>/dev/null | head -1; }
newer() { [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -1)" = "$1" ] && [ "$1" != "$2" ]; }
pick_update() {
  local best="" bestv="" z v
  for z in /run/live/medium/nova-maj/nova-auto.zip /run/live/medium/nova-auto.zip "$NOVA/maj/nova-auto.zip"; do
    [ -f "$z" ] || continue
    v="$(unzip -p "$z" nova-auto/package.json 2>/dev/null | sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' | head -1)"
    [ -n "$v" ] || continue
    if [ -z "$bestv" ] || newer "$v" "$bestv"; then best="$z"; bestv="$v"; fi
  done
  [ -n "$best" ] || return 0
  local cur; cur="$(ver_of "$NOVA/app")"
  local img; img="$(ver_of /opt/nova)"
  # déjà installée, ou pas plus récente que l'image
  [ "$cur" = "$bestv" ] && return 0
  newer "$bestv" "${img:-0}" || return 0
  printf '[%s] mise à jour : installation de Nova %s depuis %s\n' "$(date '+%F %T')" "$bestv" "$best" >>"$LOG"
  rm -rf "$NOVA/app.new" && mkdir -p "$NOVA/app.new"
  if unzip -q "$best" -d "$NOVA/app.new" && [ -d "$NOVA/app.new/nova-auto" ]; then
    rm -rf "$NOVA/app"
    mv "$NOVA/app.new/nova-auto" "$NOVA/app"
    rm -rf "$NOVA/app.new"
    # mêmes dépendances que l'image : on réutilise ses modules (700 Mo) sans rien télécharger
    if [ -d /opt/nova/node_modules ] && cmp -s <(sed -n '/"dependencies"/,/}/p' /opt/nova/package.json) <(sed -n '/"dependencies"/,/}/p' "$NOVA/app/package.json"); then
      ln -sfn /opt/nova/node_modules "$NOVA/app/node_modules"
    else
      printf '[%s] mise à jour : nouvelles dépendances, installation par npm (Internet nécessaire)\n' "$(date '+%F %T')" >>"$LOG"
      (cd "$NOVA/app" && npm install --omit=dev --no-audit --no-fund >>"$LOG" 2>&1) || {
        printf '[%s] mise à jour : npm a échoué, on garde la version précédente\n' "$(date '+%F %T')" >>"$LOG"
        rm -rf "$NOVA/app"
        return 0
      }
    fi
    chmod +x "$NOVA/app/scripts/pc/"*.sh 2>/dev/null
  else
    printf '[%s] mise à jour : archive illisible (%s)\n' "$(date '+%F %T')" "$best" >>"$LOG"
    rm -rf "$NOVA/app.new"
  fi
}
if [ -z "$NOVA_REEXEC" ]; then
  pick_update
  # une version installée plus récente que celle qui tourne : on relance sa propre session
  if [ -x "$NOVA/app/scripts/pc/nova-session.sh" ] && [ "$APP" != "$NOVA/app" ] && newer "$(ver_of "$NOVA/app")" "$(ver_of "$APP")"; then
    printf '[%s] lancement de Nova %s (mise à jour) au lieu de %s\n' "$(date '+%F %T')" "$(ver_of "$NOVA/app")" "$(ver_of "$APP")" >>"$LOG"
    NOVA_REEXEC=1 exec "$NOVA/app/scripts/pc/nova-session.sh" "$@"
  fi
fi
CHLOG="$LOGDIR/chromium.log"
URL="http://localhost:47823"
SESSION=""
[ "$1" = "--session" ] && SESSION=1

log() { printf '[%s] %s\n' "$(date '+%F %T.%3N')" "$*" >>"$LOG"; }
up() { cut -d' ' -f1 /proc/uptime 2>/dev/null; }
# journaux limités à 3 Mo
for f in "$LOG" "$CHLOG"; do
  [ -f "$f" ] && [ "$(stat -c %s "$f" 2>/dev/null || echo 0)" -gt 3145728 ] && mv -f "$f" "$f.1"
done

BOOT="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null)"
if [ -n "$SESSION" ] && grep -q "boot=$BOOT" "$LOG" 2>/dev/null; then
  log "ATTENTION : la session graphique a redémarré pendant ce même allumage (écran noir : plantage de l'affichage ou du navigateur). Voir systeme.log."
fi
log "=== session ${SESSION:+complète }boot=$BOOT · $(up) s après l'allumage · $(xrandr 2>/dev/null | awk '/\*/{print $1; exit}') · $(free -m | awk '/Mem:/{print $2" Mo, "$7" Mo libres"}')"

# fond sombre pendant le chargement, pas de veille d'écran, pas de curseur au repos
xsetroot -solid "#0E1013" 2>/dev/null || true
xset s off -dpms 2>/dev/null || true
command -v unclutter >/dev/null && { unclutter -idle 2 >/dev/null 2>&1 & }

# résolution choisie dans Réglages → Écran (sinon celle de l'écran)
apply_screen() {
  [ -f "$NOVA/ecran.conf" ] || return
  read -r OUT MODE <"$NOVA/ecran.conf" || true
  if [ -n "$OUT" ] && [ -n "$MODE" ]; then
    xrandr --output "$OUT" --mode "$MODE" >>"$LOG" 2>&1 && log "écran réglé en $MODE sur $OUT" || log "résolution $MODE refusée par $OUT"
  fi
}
screen_size() {
  xrandr 2>/dev/null | awk '/\*/{print $1; exit}' | grep -Eo '^[0-9]+x[0-9]+' || echo "1024x600"
}

# gestionnaire de fenêtres léger : sans lui, Chromium ne sait pas se mettre en plein écran
# et Maps / Waze du téléphone ne peuvent pas s'afficher par-dessus
start_wm() {
  [ -n "$SESSION" ] || return
  pgrep -x xfwm4 >/dev/null && return
  if command -v xfwm4 >/dev/null; then
    xfwm4 --compositor=off >>"$LOG" 2>&1 &
    log "xfwm4 lancé"
  else
    log "xfwm4 absent : pas de gestionnaire de fenêtres"
  fi
  sleep 0.3
}

# téléphone : KDE Connect (notifications, batterie) et commandes de musique Bluetooth
start_phone() {
  [ -n "$SESSION" ] || return
  for d in /usr/lib/x86_64-linux-gnu/libexec/kdeconnectd /usr/libexec/kdeconnectd /usr/lib/kdeconnectd; do
    if [ -x "$d" ]; then
      pgrep -f kdeconnectd >/dev/null || { "$d" >>"$LOGDIR/kdeconnect.log" 2>&1 & log "KDE Connect lancé"; }
      break
    fi
  done
  command -v mpris-proxy >/dev/null && { pgrep -x mpris-proxy >/dev/null || { mpris-proxy >/dev/null 2>&1 & }; }
}

# cerveau : relancé tout seul s'il s'arrête, avec le code de sortie dans le journal
start_brain() {
  curl -s -o /dev/null "$URL" && return
  pgrep -f "nova-cerveau-surveillance" >/dev/null && return
  (
    exec -a nova-cerveau-surveillance bash -c '
      cd "$0" || exit 1
      n=0
      while true; do
        t0=$(date +%s)
        node dist/server.js >>"$1/nova-console.log" 2>&1
        code=$?
        n=$((n + 1))
        printf "[%s] cerveau arrêté (code %s après %ss, arrêt n°%s) : relance\n" "$(date "+%F %T")" "$code" "$(( $(date +%s) - t0 ))" "$n" >>"$2"
        [ $(( $(date +%s) - t0 )) -lt 10 ] && sleep 5 || sleep 1
      done' "$APP" "$LOGDIR" "$LOG"
  ) &
  log "cerveau lancé"
}

gpu_flags() {
  local mode
  mode="$(cat "$NOVA/ecran-gpu.conf" 2>/dev/null || echo auto)"
  case "$mode" in
    force) echo "--ignore-gpu-blocklist --enable-gpu-rasterization --enable-zero-copy" ;;
    off) echo "--disable-gpu --disable-gpu-compositing --disable-software-rasterizer" ;;
    *)
      # auto : avec le pilote libre « nouveau » (cartes NVIDIA), Chromium n'obtient pas d'accélération
      # (« GLES3 is unsupported ») et perd 2 à 3 s à essayer au lancement : on la coupe d'office
      if lsmod 2>/dev/null | grep -q '^nouveau' || grep -q "Exiting GPU process due to errors during initialization" "$CHLOG" 2>/dev/null; then
        echo "--disable-gpu --disable-gpu-compositing"
      else
        echo ""
      fi ;;
  esac
}

FAST_EXITS=0
screen_nova() {
  local SIZE W H GPU T0 CODE DUR
  SIZE="$(screen_size)"
  W="${SIZE%x*}"
  H="${SIZE#*x}"
  GPU="$(gpu_flags)"
  # shellcheck disable=SC2206
  local FLAGS=(--kiosk --start-fullscreen --window-position=0,0 --window-size="$W,$H"
    --noerrdialogs --disable-infobars --no-first-run --password-store=basic
    --use-fake-ui-for-media-stream --autoplay-policy=no-user-gesture-required
    --check-for-update-interval=31536000 --user-data-dir="$HOME/.config/nova-ecran"
    --force-device-scale-factor=1 --disable-session-crashed-bubble
    --disable-features=Translate,MediaRouter --disable-background-networking --disable-component-update
    --enable-logging=stderr --v=0 $GPU)
  local START="$URL"
  [ -f "$APP/web/demarrage.html" ] && START="file://$APP/web/demarrage.html"
  local BIN=""
  for b in chromium chromium-browser google-chrome; do command -v "$b" >/dev/null && { BIN="$b"; break; }; done
  log "écran lancé ($BIN, ${W}x${H}, accélération : $(cat "$NOVA/ecran-gpu.conf" 2>/dev/null || echo auto))"
  T0=$(date +%s)
  echo "=== $(date '+%F %T') lancement de $BIN ${GPU}" >>"$CHLOG"
  if [ -n "$BIN" ]; then
    "$BIN" "${FLAGS[@]}" "$START" >>"$CHLOG" 2>&1
  else
    firefox --kiosk "$URL" >>"$CHLOG" 2>&1
  fi
  CODE=$?
  DUR=$(( $(date +%s) - T0 ))
  log "écran fermé (code $CODE après ${DUR}s)"
  # navigateur qui plante tout de suite trois fois : on coupe l'accélération graphique
  if [ "$DUR" -lt 15 ] && [ "$CODE" -ne 0 ]; then FAST_EXITS=$((FAST_EXITS + 1)); else FAST_EXITS=0; fi
  if [ "$FAST_EXITS" -ge 3 ] && [ "$(cat "$NOVA/ecran-gpu.conf" 2>/dev/null)" != "off" ]; then
    echo off >"$NOVA/ecran-gpu.conf"
    log "le navigateur plante au lancement : accélération graphique désactivée automatiquement"
    FAST_EXITS=0
    touch "$NOVA/.relancer-ecran"
  fi
}

# bureau de maintenance : xfce4-session ; s'il ne tient pas, un bureau minimal avec un bouton « Revenir à Nova »
desktop() {
  log "bureau Linux demandé"
  pkill -x xfwm4 2>/dev/null
  local T0 DUR
  T0=$(date +%s)
  if command -v xfce4-session >/dev/null; then
    if [ -z "$DBUS_SESSION_BUS_ADDRESS" ] && command -v dbus-launch >/dev/null; then
      dbus-launch --exit-with-session xfce4-session >>"$LOG" 2>&1
    else
      xfce4-session >>"$LOG" 2>&1
    fi
  fi
  DUR=$(( $(date +%s) - T0 ))
  log "xfce4-session terminé après ${DUR}s"
  if [ "$DUR" -lt 8 ]; then
    log "le bureau complet n'a pas tenu : bureau minimal"
    xfwm4 --replace >>"$LOG" 2>&1 &
    local WM=$!
    command -v xfdesktop >/dev/null && { xfdesktop >>"$LOG" 2>&1 & }
    command -v xfce4-panel >/dev/null && { xfce4-panel >>"$LOG" 2>&1 & }
    command -v nm-applet >/dev/null && { nm-applet >/dev/null 2>&1 & }
    zenity --info --title="Bureau de maintenance" --text="Bureau Linux de maintenance.\nTouche « Revenir à Nova » quand tu as fini." --ok-label="Revenir à Nova" --width=380 2>/dev/null
    pkill -x xfdesktop 2>/dev/null
    pkill -x xfce4-panel 2>/dev/null
    pkill -x nm-applet 2>/dev/null
    kill "$WM" 2>/dev/null
  fi
  log "retour à Nova"
}

# Wi-Fi et Bluetooth débloqués (certains PC démarrent avec la radio coupée par logiciel)
command -v rfkill >/dev/null && { rfkill unblock all 2>/dev/null || sudo -n rfkill unblock all 2>/dev/null; }
apply_screen
start_wm
start_brain
start_phone

if [ -z "$SESSION" ]; then
  screen_nova
  exit 0
fi

while true; do
  screen_nova
  if [ -f "$NOVA/.relancer-ecran" ]; then
    rm -f "$NOVA/.relancer-ecran"
    log "relance de l'écran (sans menu)"
    start_brain
    continue
  fi
  CHOICE=$(zenity --list --title="Nova OS" --text="Nova est en pause." --hide-header --column="Action" \
    "Revenir à Nova" "Bureau Linux (maintenance)" "Terminal" "Redémarrer" "Éteindre" \
    --width=420 --height=330 2>>"$LOG")
  log "menu Nova OS : ${CHOICE:-Revenir à Nova}"
  case "$CHOICE" in
    "Bureau Linux (maintenance)") desktop; start_wm ;;
    "Terminal") xfce4-terminal --maximize || x-terminal-emulator || xterm ;;
    "Redémarrer") sync; systemctl reboot ;;
    "Éteindre") sync; systemctl poweroff ;;
    *) ;; # Revenir à Nova (ou fenêtre fermée)
  esac
  apply_screen
  start_brain
done
