#!/usr/bin/env bash
# Transforme une clé Linux Mint (live avec persistance, ou Linux installé) en « Nova OS » :
# le PC démarre directement sur Nova, sans bureau. Le bureau Linux reste accessible pour la maintenance.
#   - Node.js 22, Chromium, outils série ; câbles KKL / ELM327 reconnus sans réglage ;
#   - Nova installée dans ~/nova-auto, ses données dans ~/Nova ;
#   - session « Nova OS » ouverte automatiquement au démarrage (plus de bureau) ;
#   - menu de démarrage renommé « Nova OS », sans attente ;
#   - animation de démarrage Nova (logo TT) : automatique si Linux est installé, au choix sur une clé live.
# Lancement, depuis le dossier nova-auto décompressé :   bash scripts/pc/installer-nova-os.sh
set -euo pipefail

SRC="$(cd "$(dirname "$0")/../.." && pwd)"
DEST="$HOME/nova-auto"
ME="$(whoami)"
say() { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m!! %s\033[0m\n' "$*"; }
LIVE=""
grep -q "boot=casper" /proc/cmdline && LIVE=1

if ! command -v apt-get >/dev/null; then
  echo "Ce script est fait pour Linux Mint / Ubuntu / Debian."; exit 1
fi
if [ -n "$LIVE" ] && ! grep -qE "persistent|persistence" /proc/cmdline; then
  warn "La clé démarre SANS persistance : tout sera perdu à l'arrêt."
  warn "Refais la clé avec Rufus en réglant « Taille de la partition persistante » (voir CLE-LINUX.md)."
  read -r -p "Continuer quand même ? (o/N) " r; [ "${r:-n}" = "o" ] || exit 1
fi

say "Mise à jour de la liste des paquets"
sudo apt-get update

say "Outils de base, Chromium, son et port série"
sudo apt-get install -y curl unzip ca-certificates x11-xserver-utils zenity unclutter || true
if ! sudo apt-get install -y chromium; then
  sudo apt-get install -y chromium-browser || warn "Chromium introuvable : Firefox sera utilisé"
fi
# brltty (lecteur braille) s'empare des câbles à puce CH340/CH341 : on le retire
sudo apt-get remove -y brltty 2>/dev/null || true

say "Node.js 22"
if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1)" != "v22" ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi
node -v

say "Câbles KKL et ELM327 : accès direct, latence FTDI à 1 ms"
sudo tee /etc/udev/rules.d/99-nova-cables.rules >/dev/null <<'RULES'
# Nova : câbles de diagnostic (KKL, ELM327) utilisables sans être administrateur
SUBSYSTEM=="tty", KERNEL=="ttyUSB[0-9]*", MODE="0666"
SUBSYSTEM=="tty", KERNEL=="ttyACM[0-9]*", MODE="0666"
# FTDI : latence 1 ms, indispensable au dialogue octet par octet de la ligne K
ACTION=="add", SUBSYSTEM=="usb-serial", DRIVER=="ftdi_sio", ATTR{latency_timer}="1"
RULES
sudo udevadm control --reload-rules
sudo udevadm trigger || true
sudo usermod -aG dialout "$ME" || true

say "Installation de Nova dans $DEST"
if [ "$SRC" != "$DEST" ]; then
  mkdir -p "$DEST"
  cp -a "$SRC"/. "$DEST"/
fi
cd "$DEST"
npm install --omit=dev --no-audit --no-fund
[ -d dist ] || { npm install --no-audit --no-fund && npm run build; }
chmod +x scripts/pc/*.sh lancer.sh

say "Session Nova OS (démarrage direct sur Nova, sans bureau)"
sudo tee /usr/share/xsessions/nova.desktop >/dev/null <<SESS
[Desktop Entry]
Name=Nova OS
Comment=Nova, l'IA de la TT, en plein écran
Exec=$DEST/scripts/pc/nova-session.sh --session
Type=Application
DesktopNames=Nova
SESS
sudo mkdir -p /etc/lightdm/lightdm.conf.d
sudo tee /etc/lightdm/lightdm.conf.d/90-nova-os.conf >/dev/null <<CONF
[Seat:*]
autologin-user=$ME
autologin-user-timeout=0
autologin-session=nova
user-session=nova
CONF
# session par défaut de l'utilisateur (lue aussi par la connexion automatique de la clé live)
sudo mkdir -p /var/lib/AccountsService/users
printf '[User]\nXSession=nova\nSession=nova\n' | sudo tee "/var/lib/AccountsService/users/$ME" >/dev/null
printf '[Desktop]\nSession=nova\n' > "$HOME/.dmrc"
# l'ancien démarrage automatique dans le bureau n'a plus lieu d'être
rm -f "$HOME/.config/autostart/nova.desktop"
# icône Nova sur le bureau Linux (mode maintenance)
DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
mkdir -p "$DESKTOP_DIR"
cat > "$DESKTOP_DIR/Nova.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Nova
Exec=$DEST/scripts/pc/nova-session.sh
Icon=$DEST/web/logo.png
DESK
chmod +x "$DESKTOP_DIR/Nova.desktop"
gio set "$DESKTOP_DIR/Nova.desktop" metadata::trusted true 2>/dev/null || true

say "Fond d'écran TT (bureau de maintenance)"
WALL="$DEST/scripts/pc/fond-nova.png"
if command -v xfconf-query >/dev/null; then
  for p in $(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep -E "last-image$" || true); do
    xfconf-query -c xfce4-desktop -p "$p" -s "$WALL" || true
  done
fi

say "Animation de démarrage Nova"
THEME=/usr/share/plymouth/themes/nova
sudo mkdir -p "$THEME"
sudo cp scripts/pc/plymouth/* "$THEME"/
if [ -z "$LIVE" ]; then
  # Linux installé : thème par défaut, menu GRUB caché, nom de la machine
  sudo apt-get install -y plymouth plymouth-themes || true
  sudo update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth "$THEME/nova.plymouth" 200 || true
  sudo update-alternatives --set default.plymouth "$THEME/nova.plymouth" || true
  sudo update-initramfs -u || warn "initramfs non régénéré"
  if [ -f /etc/default/grub ]; then
    sudo sed -i -E 's/^GRUB_TIMEOUT_STYLE=.*/GRUB_TIMEOUT_STYLE=hidden/; s/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=0/; s/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR="Nova OS"/' /etc/default/grub
    grep -q "^GRUB_TIMEOUT_STYLE=" /etc/default/grub || echo 'GRUB_TIMEOUT_STYLE=hidden' | sudo tee -a /etc/default/grub >/dev/null
    sudo update-grub || true
  fi
  sudo hostnamectl set-hostname nova 2>/dev/null || true
fi

# ---------- clé live : menu de démarrage et (au choix) animation, sur la partition de démarrage de la clé ----------
if [ -n "$LIVE" ]; then
  set +e # une étape ratée ici ne doit pas empêcher le reste
  BOOT=/cdrom
  if [ -d "$BOOT/casper" ]; then
    if ! sudo mount -o remount,rw "$BOOT" 2>/dev/null; then
      DEV="$(findmnt -n -o SOURCE "$BOOT" || true)"
      sudo mkdir -p /mnt/novaboot
      if [ -n "$DEV" ] && sudo mount "$DEV" /mnt/novaboot 2>/dev/null; then BOOT=/mnt/novaboot; else BOOT=""; warn "Partition de démarrage de la clé non modifiable : le menu garde le nom Linux Mint."; fi
    fi
  else
    BOOT=""
  fi
  if [ -n "$BOOT" ]; then
    say "Menu de démarrage de la clé : « Nova OS », sans attente"
    while IFS= read -r f; do
      [ -f "$f.mint" ] || sudo cp "$f" "$f.mint"   # copie d'origine, une seule fois
      sudo sed -i -E \
        -e 's/(menuentry ")Start Linux Mint[^"]*\(compatibility mode\)"/\1Nova OS (mode graphique de secours)"/' \
        -e 's/(menuentry ")Start Linux Mint[^"(]*"/\1Nova OS"/' \
        -e 's/^([[:space:]]*set timeout=)[0-9]+/\11/' \
        -e 's/^([[:space:]]*menu label \^?)Start Linux Mint.*/\1Nova OS/' \
        -e 's/^([[:space:]]*timeout )[0-9]+/\110/' \
        -e 's/^([[:space:]]*menu title ).*/\1Nova OS/' "$f"
    done < <(sudo find "$BOOT" -maxdepth 3 -name "*.cfg" \( -path "*grub*" -o -path "*isolinux*" -o -path "*syslinux*" -o -name "syslinux.cfg" \))

    echo
    echo "Sur une clé live, l'animation de démarrage est dans le fichier de démarrage de Linux (initrd)."
    echo "Nova peut la remplacer par la sienne. L'original est gardé : en cas de souci, sous Windows,"
    echo "renomme casper/initrd.mint en casper/initrd sur la clé (voir CLE-LINUX.md)."
    read -r -p "Mettre l'animation Nova au démarrage de la clé ? (o/N) " r
    if [ "${r:-n}" = "o" ]; then
      INITRD="$(ls "$BOOT"/casper/initrd* 2>/dev/null | grep -v '\.mint$' | head -1)"
      if [ -z "$INITRD" ] || ! command -v unmkinitramfs >/dev/null || ! command -v zstd >/dev/null; then
        sudo apt-get install -y initramfs-tools-core zstd cpio || true
      fi
      if [ -n "$INITRD" ] && command -v unmkinitramfs >/dev/null; then
        W="$(mktemp -d)"
        sudo unmkinitramfs "$INITRD" "$W"
        MAIN="$W/main"; [ -d "$MAIN" ] || MAIN="$W"
        sudo mkdir -p "$MAIN/usr/share/plymouth/themes/nova" "$MAIN/etc/plymouth"
        sudo cp "$THEME"/* "$MAIN/usr/share/plymouth/themes/nova/"
        sudo ln -sf /usr/share/plymouth/themes/nova/nova.plymouth "$MAIN/usr/share/plymouth/themes/default.plymouth"
        printf '[Daemon]\nTheme=nova\n' | sudo tee "$MAIN/etc/plymouth/plymouthd.conf" >/dev/null
        # le module « script » de Plymouth n'est dans l'initrd que si le thème d'origine l'utilise
        PLUG="$(dirname "$(find /usr/lib -path '*plymouth/script.so' 2>/dev/null | head -1)")"
        if [ -n "$PLUG" ] && [ -f "$PLUG/script.so" ]; then
          sudo mkdir -p "$MAIN$PLUG"
          sudo cp "$PLUG/script.so" "$MAIN$PLUG/"
        fi
        NEW="$(mktemp)"
        {
          for e in early early2 early3; do
            [ -d "$W/$e" ] && (cd "$W/$e" && sudo find . | sort | sudo cpio -o -H newc --quiet)
          done
          (cd "$MAIN" && sudo find . | sort | sudo cpio -o -H newc --quiet | zstd -q -19 -T0)
        } > "$NEW"
        if [ -s "$NEW" ] && sudo unmkinitramfs "$NEW" "$W/verif" && sudo test -f "$(ls -d "$W"/verif/main 2>/dev/null || echo "$W/verif")/usr/share/plymouth/themes/nova/nova.script"; then
          [ -f "$INITRD.mint" ] || sudo cp "$INITRD" "$INITRD.mint"
          sudo cp "$NEW" "$INITRD"
          sync
          say "Animation Nova installée sur la clé"
        else
          warn "Animation non installée (vérification ratée) : la clé garde celle de Linux Mint."
        fi
        sudo rm -rf "$W" "$NEW"
      else
        warn "Outils initramfs indisponibles : animation non installée."
      fi
    fi
    sync
  fi
fi

say "Terminé"
echo "Au prochain démarrage, la clé ouvre directement Nova (Nova OS)."
echo "Pour la maintenance : dans Nova, Réglages → Menu Nova OS (bureau Linux, terminal, éteindre)."
echo "Redémarre maintenant : sudo reboot"
