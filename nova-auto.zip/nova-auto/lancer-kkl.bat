@echo off
rem Nova avec le cable KKL : lecture du moteur et diagnostic de tous les calculateurs. Contact mis.
cd /d "%~dp0"
if not exist node_modules (echo Installation des modules, une seule fois... & call npm install)
if not exist dist (call npm run build)
set /p PORT=Port du cable KKL (ex. COM4, vide = automatique) : 
start "" cmd /c "timeout /t 4 >nul & start http://localhost:47823"
if "%PORT%"=="" (node dist\server.js --source kkl) else (node dist\server.js --source kkl --port %PORT%)
pause
