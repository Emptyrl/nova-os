// Surveillance de la machine pour les journaux : temps de démarrage, mémoire, processeur,
// températures, processus gourmands, erreurs du noyau et plantages (OOM, segfault, Xorg).
import { execFile } from "node:child_process";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { monitorEventLoopDelay } from "node:perf_hooks";
import { jlog, LOG_DIR, flushLogs } from "./journaux.js";

const LINUX = process.platform === "linux";
const run = (cmd: string, args: string[], timeout = 8000) =>
  new Promise<string>((resolve) => {
    execFile(cmd, args, { timeout, maxBuffer: 8 << 20, env: { ...process.env, LC_ALL: "C" } }, (e, out, err) => resolve(String(out || "") + (e && !out ? String(err || e.message || "") : "")));
  });
const sh = (c: string, t = 8000) => run("sh", ["-c", c], t);

/** Secondes depuis l'allumage (noyau). */
export async function uptime(): Promise<number> {
  if (!LINUX) return os.uptime();
  const t = await fs.readFile("/proc/uptime", "utf8").catch(() => "");
  return Number(t.split(" ")[0]) || os.uptime();
}

export async function memory() {
  if (!LINUX) {
    return { totalMb: Math.round(os.totalmem() / 1048576), availMb: Math.round(os.freemem() / 1048576), swapTotalMb: 0, swapFreeMb: 0 };
  }
  const t = await fs.readFile("/proc/meminfo", "utf8").catch(() => "");
  const g = (k: string) => Math.round(Number(new RegExp("^" + k + ":\\s+(\\d+)", "m").exec(t)?.[1] || 0) / 1024);
  return { totalMb: g("MemTotal"), availMb: g("MemAvailable"), swapTotalMb: g("SwapTotal"), swapFreeMb: g("SwapFree") };
}

async function temps(): Promise<string> {
  if (!LINUX) return "";
  const zones = await fs.readdir("/sys/class/thermal").catch(() => [] as string[]);
  const out: string[] = [];
  for (const z of zones.filter((x) => x.startsWith("thermal_zone"))) {
    const type = (await fs.readFile(`/sys/class/thermal/${z}/type`, "utf8").catch(() => "")).trim();
    const v = Number(await fs.readFile(`/sys/class/thermal/${z}/temp`, "utf8").catch(() => "0")) / 1000;
    if (v > 0) out.push(`${type || z} ${v.toFixed(0)}°C`);
  }
  return out.slice(0, 6).join(", ");
}

export async function snapshot(reason: string) {
  const m = await memory();
  const load = os.loadavg().map((x) => x.toFixed(2)).join(" ");
  const lines = [
    `Instantané (${reason}) · charge ${load} sur ${os.cpus().length} cœurs · mémoire libre ${m.availMb}/${m.totalMb} Mo · échange ${m.swapTotalMb ? m.swapTotalMb - m.swapFreeMb + "/" + m.swapTotalMb + " Mo utilisés" : "aucun"}`,
  ];
  const t = await temps();
  if (t) lines.push("Températures : " + t);
  if (LINUX) {
    const ps = await sh("ps -eo pid,comm,%cpu,%mem,rss --sort=-%cpu | head -9");
    lines.push("Processus les plus gourmands :", ps.trim());
  }
  jlog("systeme.log", lines.join("\n"));
  return m;
}

export class Moniteur {
  private screenAt = 0;
  private startUptime = 0;
  private lastKernel = "";

  constructor(private log: (t: string) => void) {}

  async start(info: string) {
    this.startUptime = await uptime();
    const m = await memory();
    jlog(
      "demarrage.log",
      `=== Allumage · Nova ${info} prête ${this.startUptime.toFixed(1)} s après l'allumage du PC · ${os.cpus()[0]?.model || "?"} × ${os.cpus().length} · ${m.totalMb} Mo de mémoire · ${os.platform()} ${os.release()}`,
    );
    jlog("systeme.log", `=== Nova démarrée (${this.startUptime.toFixed(1)} s après l'allumage)`);
    void snapshot("démarrage de Nova");
    if (LINUX) {
      // démarrage du système : après 40 s (systemd a fini)
      setTimeout(() => void this.bootReport(), 40000);
      // plantages de la session précédente (écran noir, redémarrage de Nova)
      void this.previousCrashes();
      setInterval(() => void this.kernelErrors(), 60000);
    }
    // instantané toutes les 2 minutes, et dès que la mémoire manque
    setInterval(async () => {
      const mm = await memory();
      if (mm.availMb < 300) {
        jlog("systeme.log", `ALERTE mémoire presque pleine : ${mm.availMb} Mo libres`);
        void snapshot("mémoire basse");
      }
    }, 15000);
    setInterval(() => void snapshot("régulier"), 120000);
    // blocages du fil principal (ce qui rend les boutons lents)
    const h = monitorEventLoopDelay({ resolution: 20 });
    h.enable();
    setInterval(() => {
      const max = h.max / 1e6;
      const p99 = h.percentile(99) / 1e6;
      if (max > 150) jlog("systeme.log", `Nova bloquée jusqu'à ${max.toFixed(0)} ms (99 % des attentes sous ${p99.toFixed(0)} ms) sur la dernière minute`);
      h.reset();
    }, 60000);
  }

  /** Premier écran connecté (le navigateur de Nova). */
  async screenConnected(detail: string) {
    const up = await uptime();
    if (!this.screenAt) {
      this.screenAt = up;
      jlog("demarrage.log", `Écran de Nova connecté ${up.toFixed(1)} s après l'allumage (${(up - this.startUptime).toFixed(1)} s après le cerveau) · ${detail}`);
    } else jlog("ecran.log", `Écran reconnecté à ${up.toFixed(0)} s · ${detail}`);
  }

  async screenTiming(t: Record<string, number>) {
    const up = await uptime();
    jlog("demarrage.log", `Premier affichage de l'écran : page chargée en ${(t.load / 1000).toFixed(1)} s, lancement terminé à ${up.toFixed(1)} s après l'allumage`);
  }

  private async bootReport() {
    const time = (await run("systemd-analyze", ["time"])).trim();
    const blame = (await sh("systemd-analyze blame --no-pager 2>/dev/null | head -15")).trim();
    const chain = (await sh("systemd-analyze critical-chain --no-pager graphical.target 2>/dev/null | head -25")).trim();
    const persist = (await sh("findmnt -rn -o TARGET,SOURCE,FSTYPE | grep -E '^/run/live|^/ ' ")).trim();
    const disk = (await sh("lsblk -d -o NAME,TRAN,SIZE,MODEL,ROTA 2>/dev/null")).trim();
    // étapes du noyau et de la clé live (le « kernel » de systemd-analyze compte aussi la recherche de la clé)
    const kern = (await sh("journalctl -b -k -o short-monotonic --no-pager 2>/dev/null | grep -Ei 'usb-storage|scsi .*Direct-Access|sd[a-z]: \\[sd[a-z]\\] Attached|squashfs|loop0|overlay|EXT4-fs|FAT-fs|nouveau .*DRM|i915 .*Initialized|Run /init|Freeing unused|switching root|systemd\\[1\\]: systemd' | head -40")).trim();
    const liveLog = (await sh("tail -n 40 /var/log/live/boot.log 2>/dev/null")).trim();
    jlog("demarrage.log", ["Démarrage du système :", time || "(systemd-analyze indisponible)", "", "Services les plus lents :", blame, "", "Chaîne critique :", chain, "", "Montages de la clé :", persist, "", "Disques :", disk, "", "Étapes du noyau et de la clé :", kern || "(indisponible)", ...(liveLog ? ["", "live-boot :", liveLog] : [])].join("\n"));
  }

  private async previousCrashes() {
    // Xorg de la session précédente (lightdm garde l'ancien journal en .old)
    for (const f of ["/var/log/Xorg.0.log.old", path.join(os.homedir(), ".local/share/xorg/Xorg.0.log.old")]) {
      const t = await fs.readFile(f, "utf8").catch(() => "");
      if (!t) continue;
      const bad = t.split("\n").filter((l) => /\(EE\)|Backtrace|Segmentation|Fatal|GPU hang|lockup/i.test(l)).slice(-25);
      if (bad.length) jlog("systeme.log", `Session graphique précédente (${f}) : erreurs\n${bad.join("\n")}`);
    }
    const x = await fs.readFile("/var/log/Xorg.0.log", "utf8").catch(() => "");
    if (x) {
      const drv = x.split("\n").filter((l) => /LoadModule: "(modesetting|intel|amdgpu|radeon|nouveau|nvidia|fbdev|vesa)"|glamor|DRI2|DRI3|AIGLX|Matched .* as autoconfigured/i.test(l)).slice(0, 20);
      jlog("systeme.log", "Affichage (Xorg) :\n" + (drv.join("\n") || "(rien)"));
    }
    // plantages du démarrage précédent (journal persistant)
    const prev = (await sh("journalctl -b -1 -p err --no-pager -o short-monotonic 2>/dev/null | tail -60", 15000)).trim();
    if (prev && !/No journal|Specifying boot ID|not found/i.test(prev)) jlog("systeme.log", "Erreurs du démarrage précédent :\n" + prev);
    const oom = (await sh("journalctl -k -b -1 --no-pager 2>/dev/null | grep -Ei 'out of memory|oom-kill|killed process|segfault|gpu hang|i915.*(error|hang)|amdgpu.*(error|timeout)|nouveau.*(error|fault)' | tail -30", 15000)).trim();
    if (oom) jlog("systeme.log", "Plantages au démarrage précédent (noyau) :\n" + oom);
  }

  private async kernelErrors() {
    const t = (await sh("journalctl -k -b -p warning --no-pager -o short-monotonic 2>/dev/null | tail -40", 10000)).trim();
    const lines = t.split("\n").filter(Boolean);
    const idx = this.lastKernel ? lines.lastIndexOf(this.lastKernel) : -1;
    const fresh = lines.slice(idx + 1);
    if (fresh.length) {
      this.lastKernel = lines[lines.length - 1];
      const important = fresh.filter((l) => /oom|killed process|segfault|error|fail|hang|timeout|firmware|i915|amdgpu|nouveau|usb .*disconnect|ftdi|ch341|ttyUSB|ttyACM/i.test(l));
      if (important.length) jlog("systeme.log", "Noyau :\n" + important.join("\n"));
    }
  }
}

/** Un seul texte avec tout, pour me l'envoyer. */
export async function fullReport(extra: string): Promise<string> {
  await flushLogs();
  const parts: string[] = [`Rapport complet de Nova · ${new Date().toLocaleString("fr-FR")}`, extra, ""];
  const m = await memory();
  parts.push(`PC : ${os.cpus()[0]?.model || "?"} × ${os.cpus().length}, ${m.totalMb} Mo (${m.availMb} libres), ${os.platform()} ${os.release()}, allumé depuis ${(await uptime()).toFixed(0)} s`, "");
  for (const [name, n] of [["demarrage.log", 300], ["systeme.log", 400], ["ecran.log", 300], ["cables.log", 200], ["ligne-k.log", 300], ["session.log", 200], ["nova.log", 400], ["chromium.log", 150], ["nova-console.log", 100]] as const) {
    const t = await fs.readFile(path.join(LOG_DIR, name), "utf8").catch(() => "");
    const lines = t.split("\n");
    parts.push(`##### ${name} (${lines.length} lignes, les ${n} dernières)`, lines.slice(-n).join("\n"), "");
  }
  if (LINUX) {
    parts.push("##### Matériel", (await sh("lspci -nnk 2>/dev/null | grep -A3 -Ei 'vga|3d|display|network|ethernet|wireless'; echo; lsusb 2>/dev/null; echo; echo '--- radios'; rfkill list 2>/dev/null; echo; echo '--- bluetooth'; bluetoothctl list 2>/dev/null; bluetoothctl show 2>/dev/null | head -12; ls /sys/class/bluetooth 2>/dev/null; journalctl -k -b --no-pager 2>/dev/null | grep -i -m8 'bluetooth\\|btusb\\|hci'; echo; glxinfo -B 2>/dev/null | head -25; echo; xrandr 2>/dev/null | head -15; echo; free -m; echo; df -h / /run/live/* 2>/dev/null")).trim());
  }
  return parts.join("\n");
}
